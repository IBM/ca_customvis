define( [], function()
{
    return {};
} );
