import { RenderBase, DataSet, UpdateInfo, CatPalette } from "@businessanalytics/customvis-lib";
import * as d3 from "https://d3js.org/d3.v3.min.js";

const CATEGORY = 0, SIZE = 1;
const WIDTH = 960, HEIGHT = 500;
const MIN_RADIUS = 5, MAX_RADIUS = 20;

export default class extends RenderBase
{
    protected create( _node: HTMLElement ): HTMLElement
    {
		// Initialize the chart
		var svg = d3.select( _node ).append("svg")
		    .attr("width", WIDTH)
		    .attr("height", HEIGHT);
        return svg.node();
	}
	
	protected update( _info: UpdateInfo ): void
    {
		const svg = d3.select( _info.node );

		// If there's no data, don't render the chart at all
		const rows = _info.data.rows;
		if ( !rows || rows.length === 0 )
			return;

		// Calculate the radius based on the domain
		const valueDomain = _info.data.cols[ SIZE ].domain.asArray();
		const radius = d3.scale.linear().domain( valueDomain ).range( [ MIN_RADIUS, MAX_RADIUS ] );

		// Get color palette
		const palette = _info.props.get( "color" ) as CatPalette;

		// Add data rows to nodes, for each dataPoint, calculate the radius and fill color from palette
		const nodes = [];
		rows.forEach( row => nodes.push( 
			{ 
				radius: radius( row.value( SIZE ) ),
				fill: palette.getFillColor( row )
			} 
		) );

		// Add a "virtual" node for collision calculation, named as root
		nodes.unshift(
			{ 
				radius: 0,
				fixed: true,
				data: null,
				fill: null
			}
		)
		const root = nodes[ 0 ];

		var force = d3.layout.force()
		    .gravity(0.05)
		    .charge(function(d, i) { return i ? 0 : -2000; })
		    .nodes(nodes)
		    .size([WIDTH, HEIGHT]);

		force.start();
		
		svg.selectAll("circle").remove();
		svg.selectAll("circle")
		    .data(nodes.slice( 1 ))
		  	.enter().append("circle")
		    .attr("r", function(d) { return d.radius; })
			.style("fill", function(d) { return d.fill });

		force.on("tick", function(e) {
		  	var q = d3.geom.quadtree(nodes),
		    	i = 0,
		    	n = nodes.length;

		  	while (++i < n) q.visit(collide(nodes[i]));

		  	svg.selectAll("circle")
		      	.attr("cx", function(d) { return d.x; })
		      	.attr("cy", function(d) { return d.y; });
		});

		svg.on("mousemove", function() {
		  	var p1 = d3.mouse(this);
		  	root.px = p1[0];
		  	root.py = p1[1];
		  	force.resume();
		});

		function collide(node) {
		  	var r = node.radius + 16,
		      	nx1 = node.x - r,
		      	nx2 = node.x + r,
		      	ny1 = node.y - r,
		      	ny2 = node.y + r;
		  	return function(quad, x1, y1, x2, y2) {
		    	if (quad.point && (quad.point !== node)) {
		      		var x = node.x - quad.point.x,
		          		y = node.y - quad.point.y,
		          		l = Math.sqrt(x * x + y * y),
		          		r = node.radius + quad.point.radius;
		      	if (l < r) {
		        	l = (l - r) / l * .5;
		        	node.x -= x *= l;
		        	node.y -= y *= l;
		        	quad.point.x += x;
		        	quad.point.y += y;
		      	}
		    }
		    return x1 > nx2 || x2 < nx1 || y1 > ny2 || y2 < ny1;
		  	};
		}
	}
}
