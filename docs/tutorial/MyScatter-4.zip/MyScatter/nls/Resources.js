define(
{
    "root": {
        "prop_color_cat":       "Point Color",
        "prop_color_cont":      "Color Range",
        "prop_shape":           "Shape",
        "prop_shape_circle":    "Circle",
        "prop_shape_square":    "Square",
        "prop_background":      "Background",
        "prop_show_background": "Show Background",
        "prop_xmax":            "X-axis max",
        "prop_ymax":            "Y-axis max",
        "prop_axis":            "Axis"
    },

    "nl": true
} );
