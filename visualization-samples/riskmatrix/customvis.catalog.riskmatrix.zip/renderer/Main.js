define(['require'], (function (requirejs) { 'use strict';

  function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
  }
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function () {
      return !!t;
    })();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : String(i);
  }
  function _classCallCheck$1(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties$1(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass$1(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties$1(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    Object.defineProperty(subClass, "prototype", {
      writable: false
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    } else if (call !== void 0) {
      throw new TypeError("Derived constructors may only return object or undefined");
    }
    return _assertThisInitialized(self);
  }
  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }
  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
    return arr2;
  }
  function _createForOfIteratorHelper(o, allowArrayLike) {
    var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
    if (!it) {
      if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
        if (it) o = it;
        var i = 0;
        var F = function () {};
        return {
          s: F,
          n: function () {
            if (i >= o.length) return {
              done: true
            };
            return {
              done: false,
              value: o[i++]
            };
          },
          e: function (e) {
            throw e;
          },
          f: F
        };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var normalCompletion = true,
      didErr = false,
      err;
    return {
      s: function () {
        it = it.call(o);
      },
      n: function () {
        var step = it.next();
        normalCompletion = step.done;
        return step;
      },
      e: function (e) {
        didErr = true;
        err = e;
      },
      f: function () {
        try {
          if (!normalCompletion && it.return != null) it.return();
        } finally {
          if (didErr) throw err;
        }
      }
    };
  }

  class e{constructor(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}getName(){return this.name}getSlot(){return this.slot}getAttributes(){return this.attributes}static slotLimit(t,s){return new e("limit",t).attr("n",s)}static dataLimit(t){return new e("limit").attr("n",t)}attr(t,e){return this.attributes.set(t,e),this}}function s(t,e,s){return t.getDecoration(e,s)}function r(t){return t.hasDecoration("hasSelection")?s(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}class n{constructor(t,e){this.min=t,this.max=e;}asArray(){return [this.min,this.max]}}n.empty=new n(0,0);class o extends n{static fromRS(t){return new n(t.min,t.max)}constructor(t,e){super(t,e);}}class i{constructor(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";const s=t.getItems()||[];this.segments=s.map((t=>new c(t)));}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class l extends i{constructor(t,e){super(t,e);}}class a{constructor(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class c extends a{constructor(t){super(t);}}const u=new class{format(t){return t?t.toString():""}};var h;!function(t){t.label="label",t.data="data";}(h||(h={}));class p{constructor(t,e,s,r,n){this.source=t,this.tuples=e,this.segments=s,this.domain=r,this.caption=n;const o=t.dataItems||[],i=o.length>0?o[0]:null,l=i&&i.asCont();l?(this._labelFormatter=l.getFormatter("label")||u,this._dataFormatter=l.getFormatter("data")||u):this._labelFormatter=this._dataFormatter=u;}get mapped(){return this.source.mapped}get dataType(){const t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"}format(t,e){return function(t,e){return t.format(e)}(e===h.data?this._dataFormatter:this._labelFormatter,t)}}class g extends p{constructor(t,e,s,r,n){super(t,e,s,r,n);}}class f{constructor(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}tuple(t){const e=this._getSlot(t);if(!e||0===e.tuples.length)return null;const s=this.source.get(e.source);if(!s)return null;const r=s.asCat();return r?e.tuples[r.index]:null}value(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);if(!s)return null;const r=s.asCont();return r&&"numeric"===r.valueType?r.value:null}caption(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);return s&&s.getCaption("data")||""}_getSlot(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null}}class d extends f{constructor(t,e){super(t,e);}}class m{constructor(t,e,s){this.source=t,this.rows=t.dataPoints.map((t=>new d(t,this))),this.cols=e,this.slotMap=s;}static filterRows(t,e,s){return t.filter((t=>{const r=t.tuple(e);return !!r&&r.key===s}))}get hasSelections(){return r(this.source)}}class y extends m{constructor(t,e,s){super(t,e,s);}}function _(t){const e=new Map,s=t.getSlots().map(((t,s)=>{let r=[],i=[],a=n.empty,u="";if(t.isMapped()){const e=t.getDataItem(0);if(u=e.getCaption("label"),"cat"===e.getRSType()){r=e.getTuples().map(((t,e)=>new l(t,e)));i=e.getItemClassSet(0).getItemClasses().map((t=>new c(t)));}else a=o.fromRS(e.getDomain()),i.push(new c(e.getItemClass()));}const h=new g(t,r,i,a,u);return e.set(t.name,h),h}));return new y(t,s,e)}const w=/^\s*#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{0,2})\s*$/,C=/^\s*rgba?\s*\(\s*(\d+\%?)\s*,\s*(\d+\%?)\s*,\s*(\d+\%?)\s*(?:,\s*(\d+(?:\.\d+)?\%?)\s*)?\)\s*/;function b(t){return t<0?0:t>255?255:Math.floor(t)}class S{constructor(t,e,s,r){var n;this.r=b(t),this.g=b(e),this.b=b(s),this.a=(n=r)<0?0:n>1?1:n;}static darker(t,e){const s=e?Math.pow(.7,e):.7;return new S(t.r*s,t.g*s,t.b*s,t.a)}static fromObject(t){return new S(t.r,t.g,t.b,void 0===t.a?1:t.a)}static fromString(t){const e=C.exec(t);let s=e||w.exec(t);const r=e?void 0:16;if(!s)return null;const n=parseInt(s[1],r),o=parseInt(s[2],r),i=parseInt(s[3],r);let l;return s[4]&&(l=e?parseFloat(s[4]):Math.round(parseInt(s[4],r)/255*100)/100),this.fromObject({r:n,g:o,b:i,a:l})}toString(){return 1===this.a?`rgb(${this.r},${this.g},${this.b})`:`rgba(${this.r},${this.g},${this.b},${this.a})`}}function x(t,e){let s=null;if(t instanceof f)s=t.source.getDataSet(e);else {const r=t.source.getDataItem(e);s=r&&r.getDataSet(e);}return !!s&&r(s)}const I=t=>`rgba(${t.r},${t.g},${t.b},0.4)`,j=t=>`rgba(${Math.round(.7*t.r)},${Math.round(.7*t.g)},${Math.round(.7*t.b)},${t.a})`;class E{constructor(t,e,s){this.source=t,this._dataContext=e,this._slotResolver=s;}get slot(){return this.source.slot}getColor(t){return t?S.fromObject(this.source.getTupleColor(t.source,-1)):S.fromObject(this.source.getColor(null))}_getTuple(t){if(t instanceof i)return t;let e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null}getFillColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),!t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class P{constructor(t,e,s){this.color=t,this.at=e,this.value=s;}}function D(t){return t.map((t=>new P(S.fromObject(t.color),t.at,t.value)))}class F{constructor(t,e,s){this.source=t,this._slot=e,this._dataContext=s,this.stops=D(t.stops),this.aligned=D(t.aligned),this.interpolate=t.interpolate;}getColor(t){return S.fromObject(this.source.getColor(t))}getFillColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return !t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class T{constructor(t,e,s){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=s;}get slot(){return this.source.slot}getColorStops(t){const e=t?t.source.getDataItem(0):null,s=e&&e.asCont();let r=s?s.getDomain(null):null;const n=this.source.getColorStops(s,r),o=t?t.source.name:null;return new F(n,o,this._dataContext)}_fetchColorStops(t){const e=t.source.getDataSet(this._dataContext),s=this.slot||this._slotResolver(t.dataSet,this.source.name),r=s?e.getSlot(s):null,n=r?r.getDataItem(0):null,o=n?n.asCont():null;if(this.source.dirty||!this._cachedStops||o!==this._lastDataItem){const t=o?o.getDomain(null):null,e=this.source.getColorStops(o,t);this._cachedStops=new F(e,r&&r.name,this._dataContext),this._lastDataItem=o;}return this._cachedStops}getFillColor(t){return this._fetchColorStops(t).getFillColor(t)}getOutlineColor(t){return this._fetchColorStops(t).getOutlineColor(t)}}class A extends S{constructor(t){super(t.r,t.g,t.b,t.a),this._color=t;}getRed(){return this.r}getGreen(){return this.g}getBlue(){return this.b}getAlpha(){return this.a}}const O=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:()=>0,getMax:()=>0,isEmpty:()=>!0,isExplicit:()=>!1});class ${constructor(t,e,s,r,n,o){this.caption=t,this.color=e,this.shape=s,this.selected=r,this.highlighted=n,this.ref=o;}getCaption(){return this.caption}getColor(){return this.color?new A(this.color):null}getShape(){return this.shape}isSelected(){return this.selected}isHighlighted(){return this.highlighted}getRef(){return this.ref}}class R{constructor(t,e,s,r,n,o){this.type=t,this.channel=e,this.slot=s,this.caption=r,this.subCaption=n,this.ref=o;}getRSType(){return this.type}getChannel(){return this.channel}getSlot(){return this.slot}getCaption(){return this.caption}getSubCaption(){return this.subCaption}getRef(){return this.ref}}class M extends R{constructor(t,e,r,n,o){const i=e&&e.source,l=i&&i.name,a=i&&i.getDataItem(0),c=a&&a.asCat();super("cat",t,l,r,"",c);const u=c?c.tuples:[];this.entries=u.map((t=>{const e=t.getCaption("label")||"",r=o&&o.source.getTupleColor(t,-1),i=s(t,"selected",!1),l=s(t,"highlighted",!1);return new $(e,r?S.fromObject(r):null,n,i,l,t)}));}getEntries(){return this.entries}}class L extends R{constructor(t,e,s,r){const n=e&&e.source,o=n&&n.name,i=n&&n.getDataItem(0),l=i&&i.asCont();if(super("cont",t,o,s,"",l),this.domain=l?l.getDomain(null):O,r&&"color"===t){const t=r.source.getColorStops(l,null);this.stops=t.stops,this.interpolate=t.interpolate;}else this.stops=null,this.interpolate=!1;}getDomain(){return this.domain}getInterpolate(){return this.interpolate}getStops(){return this.stops}}function k(t,e,s,r){if(!t)return [];const n=new Map,o=new Map;e.palettes.forEach((e=>{const s=e.slot||r&&r(t,e.source.name);s&&(e instanceof E?n.set(s,e):e instanceof T&&o.set(s,e));}));const i=[];return t.cols.forEach((t=>{const e=t.source;if(!e.mapped)return;const r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;const r=n.get(e.name);r&&i.push(new M("color",t,t.caption,s.legendShape,r));break;case"cont":if(-1!==e.channels.indexOf("color")){const s=o.get(e.name);s&&i.push(new L("color",t,t.caption,s));}-1!==e.channels.indexOf("size")&&i.push(new L("size",t,t.caption,null));}})),i}class z{constructor(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;}}var B,H,U;!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(B||(B={}));class V{constructor(t,e){this.value=t,this.unit=e;}static fromObject(t){return new V(t.value,function(t){switch(t){case"em":return B.Em;case"%":return B.Percentage;case"cm":return B.Centimeter;case"mm":return B.Millimeter;case"in":return B.Inch;case"pc":return B.Pica;case"pt":return B.Point;case"px":return B.Pixel;default:throw new Error(`Invalid length unit '${t}' specified`)}}(t.unit))}toString(){return `${this.value}${this.unit}`}}!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));const q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){let e=[];if(t)for(let s=0,r=t.length;s<r;++s){const r=t[s],n=q.test(r);e.push(n?`"${r}"`:r);}return e.join(", ")}class J{constructor(t,e,s,r){this.family=t,this.size=e,this.style=s,this.weight=r;}static fromObject(t){const e=t.family||null,s=t.size?V.fromObject(t.size):null,r=t.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error(`Invalid font style '${t}' specified`)}}(t.style):null,n=void 0!==t.weight&&null!==t.weight?t.weight:null;return new J(e,s,r,n)}toString(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){const t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){const e=[];let s=G(t.family);var r;return s.length>0&&e.push(`font-family: ${s};`),s=t.size?t.size.toString():"",s.length>0&&e.push(`font-size: ${s};`),s=(r=t.style)?r.toString():"",s.length>0&&e.push(`font-style: ${s};`),s=K(t.weight),s.length>0&&e.push(`font-weight: ${s};`),e.join(" ")}(this)}}class Q{constructor(t,e,s){const r=new Map;null!==t&&t.forEach(((t,n)=>{if("palette"===t.type){const o=t;switch(o.paletteType){case"cat":r.set(n,new E(o,e,s));break;case"cont":r.set(n,new T(o,e,s));}}})),this.source=t,this.palettes=r;}get(t){return this._getValue(t,!1)}peek(t){return this._getValue(t,!0)}_getValue(t,e){const s=this.source&&this.source.get(t);if(!s)return null;switch(s.type){case"string":case"number":case"boolean":case"enum":return e?s.peek:s.value;case"length":const r=e?s.peek:s.value;return r?V.fromObject(r):null;case"font":const n=e?s.peek:s.value;return n?J.fromObject(n):null;case"color":const o=e?s.peek:s.value;return o?S.fromObject(o):null;case"palette":return this.palettes.get(t)||null;default:return null}}isActive(t){const e=this.source&&this.source.get(t);return !!e&&e.active}setActive(t,e){const s=this.source&&this.source.get(t);s&&s.setActive(e);}isDirty(t){const e=this.source&&this.source.get(t);return !!e&&e.dirty}}function W(t,e){this.name="AggregateError",this.errors=t,this.message=e||"";}W.prototype=Error.prototype;var X=setTimeout;function Y(t){return Boolean(t&&void 0!==t.length)}function Z(){}function tt(t){if(!(this instanceof tt))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],it(t,this);}function et(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,tt._immediateFn((function(){var s=1===t._state?e.onFulfilled:e.onRejected;if(null!==s){var r;try{r=s(t._value);}catch(t){return void rt(e.promise,t)}st(e.promise,r);}else (1===t._state?st:rt)(e.promise,t._value);}))):t._deferreds.push(e);}function st(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var s=e.then;if(e instanceof tt)return t._state=3,t._value=e,void nt(t);if("function"==typeof s)return void it((r=s,n=e,function(){r.apply(n,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){rt(t,e);}var r,n;}function rt(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&tt._immediateFn((function(){t._handled||tt._unhandledRejectionFn(t._value);}));for(var e=0,s=t._deferreds.length;e<s;e++)et(t,t._deferreds[e]);t._deferreds=null;}function ot(t,e,s){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=s;}function it(t,e){var s=!1;try{t((function(t){s||(s=!0,st(e,t));}),(function(t){s||(s=!0,rt(e,t));}));}catch(t){if(s)return;s=!0,rt(e,t);}}tt.prototype.catch=function(t){return this.then(null,t)},tt.prototype.then=function(t,e){var s=new this.constructor(Z);return et(this,new ot(t,e,s)),s},tt.prototype.finally=function(t){var e=this.constructor;return this.then((function(s){return e.resolve(t()).then((function(){return s}))}),(function(s){return e.resolve(t()).then((function(){return e.reject(s)}))}))},tt.all=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,i){try{if(i&&("object"==typeof i||"function"==typeof i)){var l=i.then;if("function"==typeof l)return void l.call(i,(function(e){o(t,e);}),s)}r[t]=i,0==--n&&e(r);}catch(t){s(t);}}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.any=function(t){var e=this;return new e((function(s,r){if(!t||void 0===t.length)return r(new TypeError("Promise.any accepts an array"));var n=Array.prototype.slice.call(t);if(0===n.length)return r();for(var o=[],i=0;i<n.length;i++)try{e.resolve(n[i]).then(s).catch((function(t){o.push(t),o.length===n.length&&r(new W(o,"All promises were rejected"));}));}catch(t){r(t);}}))},tt.allSettled=function(t){return new this((function(e,s){if(!t||void 0===t.length)return s(new TypeError(typeof t+" "+t+" is not iterable(cannot read property Symbol(Symbol.iterator))"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,s){if(s&&("object"==typeof s||"function"==typeof s)){var i=s.then;if("function"==typeof i)return void i.call(s,(function(e){o(t,e);}),(function(s){r[t]={status:"rejected",reason:s},0==--n&&e(r);}))}r[t]={status:"fulfilled",value:s},0==--n&&e(r);}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.resolve=function(t){return t&&"object"==typeof t&&t.constructor===tt?t:new tt((function(e){e(t);}))},tt.reject=function(t){return new tt((function(e,s){s(t);}))},tt.race=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.race accepts an array"));for(var r=0,n=t.length;r<n;r++)tt.resolve(t[r]).then(e,s);}))},tt._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){X(t,0);},tt._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};class lt{constructor(t,e,s,r){this.data=t,this.decorations=e,this.properties=s,this.size=r;}}class at{constructor(t,e,s,r,n){this.reason=t,this.data=e,this.node=s,this.props=r,this.locale=n;}}class ct{constructor(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new z;}init(t,e){const s=t.surface.appendChild(document.createElement("div"));s.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),s.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,tt.resolve(this.create(s)).then((r=>{this._elem=r||s;t.properties.forEach(((t,e)=>this.updateProperty(e,t.value))),e.complete();})).catch((t=>{e.fail(t);}));}destroy(){}getPropertyApi(){return null}setData(t){t&&t.dataSets&&t.dataSets[0]?this._data=_(t.dataSets[0]):this._data=null;}setProperty(t,e){this.updateProperty(t,this.properties.peek(t));}getBlockingRequests(){return null}render(t,e,s){if(!this._elem)return s.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return s.complete(null,null,null),null;try{const t=this.update(new at(function(t){return new lt(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));tt.resolve(t).then((()=>s.complete(null,null,null))).catch(s.error);}catch(t){s.error(t);}return null}getEncodings(){return this._data?this.updateLegend(this._data):[]}getCapabilities(){const t=[];return this.meta.slotLimits.forEach(((s,r)=>{t.push(e.slotLimit(r,s));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t}getInteractivity(){return null}getVisCoordinate(t,e){return e}getRegionAtPoint(t,e){return null}getItemsAtPoint(t,e,s){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;const r=t,n=document.elementFromPoint(r.x,r.y),o=this.hitTest(n,r,e);return Array.isArray(o)?o.length?[...o.map((t=>t.source))]:[]:o&&o.source?[o.source]:[]}getItemsInPolygon(t,e){return []}getAxisItemsAtPoint(t,e,s){return []}getState(){return null}setState(t){}loadCss(t){const e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);}toUrl(e){return requirejs.toUrl(e)}update(t){}create(t){}updateProperty(t,e){}updateLegend(t){return k(t,this.properties,this.meta,this._slotResolver)}getSlotForPalette(t,e){return null}hitTest(t,e,s){const r=t&&t.__data__;return r&&r.source?r:null}nls(t){return this._nls&&this._nls.get(t)||""}}

  class InternMap extends Map {
    constructor(entries, key = keyof) {
      super();
      Object.defineProperties(this, {_intern: {value: new Map()}, _key: {value: key}});
      if (entries != null) for (const [key, value] of entries) this.set(key, value);
    }
    get(key) {
      return super.get(intern_get(this, key));
    }
    has(key) {
      return super.has(intern_get(this, key));
    }
    set(key, value) {
      return super.set(intern_set(this, key), value);
    }
    delete(key) {
      return super.delete(intern_delete(this, key));
    }
  }

  function intern_get({_intern, _key}, value) {
    const key = _key(value);
    return _intern.has(key) ? _intern.get(key) : value;
  }

  function intern_set({_intern, _key}, value) {
    const key = _key(value);
    if (_intern.has(key)) return _intern.get(key);
    _intern.set(key, value);
    return value;
  }

  function intern_delete({_intern, _key}, value) {
    const key = _key(value);
    if (_intern.has(key)) {
      value = _intern.get(key);
      _intern.delete(key);
    }
    return value;
  }

  function keyof(value) {
    return value !== null && typeof value === "object" ? value.valueOf() : value;
  }

  function range(start, stop, step) {
    start = +start, stop = +stop, step = (n = arguments.length) < 2 ? (stop = start, start = 0, 1) : n < 3 ? 1 : +step;

    var i = -1,
        n = Math.max(0, Math.ceil((stop - start) / step)) | 0,
        range = new Array(n);

    while (++i < n) {
      range[i] = start + i * step;
    }

    return range;
  }

  function identity$1(x) {
    return x;
  }

  var top = 1,
      right = 2,
      bottom = 3,
      left = 4,
      epsilon = 1e-6;

  function translateX(x) {
    return "translate(" + x + ",0)";
  }

  function translateY(y) {
    return "translate(0," + y + ")";
  }

  function number(scale) {
    return d => +scale(d);
  }

  function center(scale, offset) {
    offset = Math.max(0, scale.bandwidth() - offset * 2) / 2;
    if (scale.round()) offset = Math.round(offset);
    return d => +scale(d) + offset;
  }

  function entering() {
    return !this.__axis;
  }

  function axis(orient, scale) {
    var tickArguments = [],
        tickValues = null,
        tickFormat = null,
        tickSizeInner = 6,
        tickSizeOuter = 6,
        tickPadding = 3,
        offset = typeof window !== "undefined" && window.devicePixelRatio > 1 ? 0 : 0.5,
        k = orient === top || orient === left ? -1 : 1,
        x = orient === left || orient === right ? "x" : "y",
        transform = orient === top || orient === bottom ? translateX : translateY;

    function axis(context) {
      var values = tickValues == null ? (scale.ticks ? scale.ticks.apply(scale, tickArguments) : scale.domain()) : tickValues,
          format = tickFormat == null ? (scale.tickFormat ? scale.tickFormat.apply(scale, tickArguments) : identity$1) : tickFormat,
          spacing = Math.max(tickSizeInner, 0) + tickPadding,
          range = scale.range(),
          range0 = +range[0] + offset,
          range1 = +range[range.length - 1] + offset,
          position = (scale.bandwidth ? center : number)(scale.copy(), offset),
          selection = context.selection ? context.selection() : context,
          path = selection.selectAll(".domain").data([null]),
          tick = selection.selectAll(".tick").data(values, scale).order(),
          tickExit = tick.exit(),
          tickEnter = tick.enter().append("g").attr("class", "tick"),
          line = tick.select("line"),
          text = tick.select("text");

      path = path.merge(path.enter().insert("path", ".tick")
          .attr("class", "domain")
          .attr("stroke", "currentColor"));

      tick = tick.merge(tickEnter);

      line = line.merge(tickEnter.append("line")
          .attr("stroke", "currentColor")
          .attr(x + "2", k * tickSizeInner));

      text = text.merge(tickEnter.append("text")
          .attr("fill", "currentColor")
          .attr(x, k * spacing)
          .attr("dy", orient === top ? "0em" : orient === bottom ? "0.71em" : "0.32em"));

      if (context !== selection) {
        path = path.transition(context);
        tick = tick.transition(context);
        line = line.transition(context);
        text = text.transition(context);

        tickExit = tickExit.transition(context)
            .attr("opacity", epsilon)
            .attr("transform", function(d) { return isFinite(d = position(d)) ? transform(d + offset) : this.getAttribute("transform"); });

        tickEnter
            .attr("opacity", epsilon)
            .attr("transform", function(d) { var p = this.parentNode.__axis; return transform((p && isFinite(p = p(d)) ? p : position(d)) + offset); });
      }

      tickExit.remove();

      path
          .attr("d", orient === left || orient === right
              ? (tickSizeOuter ? "M" + k * tickSizeOuter + "," + range0 + "H" + offset + "V" + range1 + "H" + k * tickSizeOuter : "M" + offset + "," + range0 + "V" + range1)
              : (tickSizeOuter ? "M" + range0 + "," + k * tickSizeOuter + "V" + offset + "H" + range1 + "V" + k * tickSizeOuter : "M" + range0 + "," + offset + "H" + range1));

      tick
          .attr("opacity", 1)
          .attr("transform", function(d) { return transform(position(d) + offset); });

      line
          .attr(x + "2", k * tickSizeInner);

      text
          .attr(x, k * spacing)
          .text(format);

      selection.filter(entering)
          .attr("fill", "none")
          .attr("font-size", 10)
          .attr("font-family", "sans-serif")
          .attr("text-anchor", orient === right ? "start" : orient === left ? "end" : "middle");

      selection
          .each(function() { this.__axis = position; });
    }

    axis.scale = function(_) {
      return arguments.length ? (scale = _, axis) : scale;
    };

    axis.ticks = function() {
      return tickArguments = Array.from(arguments), axis;
    };

    axis.tickArguments = function(_) {
      return arguments.length ? (tickArguments = _ == null ? [] : Array.from(_), axis) : tickArguments.slice();
    };

    axis.tickValues = function(_) {
      return arguments.length ? (tickValues = _ == null ? null : Array.from(_), axis) : tickValues && tickValues.slice();
    };

    axis.tickFormat = function(_) {
      return arguments.length ? (tickFormat = _, axis) : tickFormat;
    };

    axis.tickSize = function(_) {
      return arguments.length ? (tickSizeInner = tickSizeOuter = +_, axis) : tickSizeInner;
    };

    axis.tickSizeInner = function(_) {
      return arguments.length ? (tickSizeInner = +_, axis) : tickSizeInner;
    };

    axis.tickSizeOuter = function(_) {
      return arguments.length ? (tickSizeOuter = +_, axis) : tickSizeOuter;
    };

    axis.tickPadding = function(_) {
      return arguments.length ? (tickPadding = +_, axis) : tickPadding;
    };

    axis.offset = function(_) {
      return arguments.length ? (offset = +_, axis) : offset;
    };

    return axis;
  }

  function axisBottom(scale) {
    return axis(bottom, scale);
  }

  function axisLeft(scale) {
    return axis(left, scale);
  }

  var noop = {value: () => {}};

  function dispatch() {
    for (var i = 0, n = arguments.length, _ = {}, t; i < n; ++i) {
      if (!(t = arguments[i] + "") || (t in _) || /[\s.]/.test(t)) throw new Error("illegal type: " + t);
      _[t] = [];
    }
    return new Dispatch(_);
  }

  function Dispatch(_) {
    this._ = _;
  }

  function parseTypenames$1(typenames, types) {
    return typenames.trim().split(/^|\s+/).map(function(t) {
      var name = "", i = t.indexOf(".");
      if (i >= 0) name = t.slice(i + 1), t = t.slice(0, i);
      if (t && !types.hasOwnProperty(t)) throw new Error("unknown type: " + t);
      return {type: t, name: name};
    });
  }

  Dispatch.prototype = dispatch.prototype = {
    constructor: Dispatch,
    on: function(typename, callback) {
      var _ = this._,
          T = parseTypenames$1(typename + "", _),
          t,
          i = -1,
          n = T.length;

      // If no callback was specified, return the callback of the given type and name.
      if (arguments.length < 2) {
        while (++i < n) if ((t = (typename = T[i]).type) && (t = get$1(_[t], typename.name))) return t;
        return;
      }

      // If a type was specified, set the callback for the given type and name.
      // Otherwise, if a null callback was specified, remove callbacks of the given name.
      if (callback != null && typeof callback !== "function") throw new Error("invalid callback: " + callback);
      while (++i < n) {
        if (t = (typename = T[i]).type) _[t] = set$1(_[t], typename.name, callback);
        else if (callback == null) for (t in _) _[t] = set$1(_[t], typename.name, null);
      }

      return this;
    },
    copy: function() {
      var copy = {}, _ = this._;
      for (var t in _) copy[t] = _[t].slice();
      return new Dispatch(copy);
    },
    call: function(type, that) {
      if ((n = arguments.length - 2) > 0) for (var args = new Array(n), i = 0, n, t; i < n; ++i) args[i] = arguments[i + 2];
      if (!this._.hasOwnProperty(type)) throw new Error("unknown type: " + type);
      for (t = this._[type], i = 0, n = t.length; i < n; ++i) t[i].value.apply(that, args);
    },
    apply: function(type, that, args) {
      if (!this._.hasOwnProperty(type)) throw new Error("unknown type: " + type);
      for (var t = this._[type], i = 0, n = t.length; i < n; ++i) t[i].value.apply(that, args);
    }
  };

  function get$1(type, name) {
    for (var i = 0, n = type.length, c; i < n; ++i) {
      if ((c = type[i]).name === name) {
        return c.value;
      }
    }
  }

  function set$1(type, name, callback) {
    for (var i = 0, n = type.length; i < n; ++i) {
      if (type[i].name === name) {
        type[i] = noop, type = type.slice(0, i).concat(type.slice(i + 1));
        break;
      }
    }
    if (callback != null) type.push({name: name, value: callback});
    return type;
  }

  var xhtml = "http://www.w3.org/1999/xhtml";

  var namespaces = {
    svg: "http://www.w3.org/2000/svg",
    xhtml: xhtml,
    xlink: "http://www.w3.org/1999/xlink",
    xml: "http://www.w3.org/XML/1998/namespace",
    xmlns: "http://www.w3.org/2000/xmlns/"
  };

  function namespace(name) {
    var prefix = name += "", i = prefix.indexOf(":");
    if (i >= 0 && (prefix = name.slice(0, i)) !== "xmlns") name = name.slice(i + 1);
    return namespaces.hasOwnProperty(prefix) ? {space: namespaces[prefix], local: name} : name; // eslint-disable-line no-prototype-builtins
  }

  function creatorInherit(name) {
    return function() {
      var document = this.ownerDocument,
          uri = this.namespaceURI;
      return uri === xhtml && document.documentElement.namespaceURI === xhtml
          ? document.createElement(name)
          : document.createElementNS(uri, name);
    };
  }

  function creatorFixed(fullname) {
    return function() {
      return this.ownerDocument.createElementNS(fullname.space, fullname.local);
    };
  }

  function creator(name) {
    var fullname = namespace(name);
    return (fullname.local
        ? creatorFixed
        : creatorInherit)(fullname);
  }

  function none() {}

  function selector(selector) {
    return selector == null ? none : function() {
      return this.querySelector(selector);
    };
  }

  function selection_select(select) {
    if (typeof select !== "function") select = selector(select);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = new Array(n), node, subnode, i = 0; i < n; ++i) {
        if ((node = group[i]) && (subnode = select.call(node, node.__data__, i, group))) {
          if ("__data__" in node) subnode.__data__ = node.__data__;
          subgroup[i] = subnode;
        }
      }
    }

    return new Selection$1(subgroups, this._parents);
  }

  // Given something array like (or null), returns something that is strictly an
  // array. This is used to ensure that array-like objects passed to d3.selectAll
  // or selection.selectAll are converted into proper arrays when creating a
  // selection; we don’t ever want to create a selection backed by a live
  // HTMLCollection or NodeList. However, note that selection.selectAll will use a
  // static NodeList as a group, since it safely derived from querySelectorAll.
  function array(x) {
    return x == null ? [] : Array.isArray(x) ? x : Array.from(x);
  }

  function empty() {
    return [];
  }

  function selectorAll(selector) {
    return selector == null ? empty : function() {
      return this.querySelectorAll(selector);
    };
  }

  function arrayAll(select) {
    return function() {
      return array(select.apply(this, arguments));
    };
  }

  function selection_selectAll(select) {
    if (typeof select === "function") select = arrayAll(select);
    else select = selectorAll(select);

    for (var groups = this._groups, m = groups.length, subgroups = [], parents = [], j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          subgroups.push(select.call(node, node.__data__, i, group));
          parents.push(node);
        }
      }
    }

    return new Selection$1(subgroups, parents);
  }

  function matcher(selector) {
    return function() {
      return this.matches(selector);
    };
  }

  function childMatcher(selector) {
    return function(node) {
      return node.matches(selector);
    };
  }

  var find = Array.prototype.find;

  function childFind(match) {
    return function() {
      return find.call(this.children, match);
    };
  }

  function childFirst() {
    return this.firstElementChild;
  }

  function selection_selectChild(match) {
    return this.select(match == null ? childFirst
        : childFind(typeof match === "function" ? match : childMatcher(match)));
  }

  var filter = Array.prototype.filter;

  function children() {
    return Array.from(this.children);
  }

  function childrenFilter(match) {
    return function() {
      return filter.call(this.children, match);
    };
  }

  function selection_selectChildren(match) {
    return this.selectAll(match == null ? children
        : childrenFilter(typeof match === "function" ? match : childMatcher(match)));
  }

  function selection_filter(match) {
    if (typeof match !== "function") match = matcher(match);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = [], node, i = 0; i < n; ++i) {
        if ((node = group[i]) && match.call(node, node.__data__, i, group)) {
          subgroup.push(node);
        }
      }
    }

    return new Selection$1(subgroups, this._parents);
  }

  function sparse(update) {
    return new Array(update.length);
  }

  function selection_enter() {
    return new Selection$1(this._enter || this._groups.map(sparse), this._parents);
  }

  function EnterNode(parent, datum) {
    this.ownerDocument = parent.ownerDocument;
    this.namespaceURI = parent.namespaceURI;
    this._next = null;
    this._parent = parent;
    this.__data__ = datum;
  }

  EnterNode.prototype = {
    constructor: EnterNode,
    appendChild: function(child) { return this._parent.insertBefore(child, this._next); },
    insertBefore: function(child, next) { return this._parent.insertBefore(child, next); },
    querySelector: function(selector) { return this._parent.querySelector(selector); },
    querySelectorAll: function(selector) { return this._parent.querySelectorAll(selector); }
  };

  function constant$1(x) {
    return function() {
      return x;
    };
  }

  function bindIndex(parent, group, enter, update, exit, data) {
    var i = 0,
        node,
        groupLength = group.length,
        dataLength = data.length;

    // Put any non-null nodes that fit into update.
    // Put any null nodes into enter.
    // Put any remaining data into enter.
    for (; i < dataLength; ++i) {
      if (node = group[i]) {
        node.__data__ = data[i];
        update[i] = node;
      } else {
        enter[i] = new EnterNode(parent, data[i]);
      }
    }

    // Put any non-null nodes that don’t fit into exit.
    for (; i < groupLength; ++i) {
      if (node = group[i]) {
        exit[i] = node;
      }
    }
  }

  function bindKey(parent, group, enter, update, exit, data, key) {
    var i,
        node,
        nodeByKeyValue = new Map,
        groupLength = group.length,
        dataLength = data.length,
        keyValues = new Array(groupLength),
        keyValue;

    // Compute the key for each node.
    // If multiple nodes have the same key, the duplicates are added to exit.
    for (i = 0; i < groupLength; ++i) {
      if (node = group[i]) {
        keyValues[i] = keyValue = key.call(node, node.__data__, i, group) + "";
        if (nodeByKeyValue.has(keyValue)) {
          exit[i] = node;
        } else {
          nodeByKeyValue.set(keyValue, node);
        }
      }
    }

    // Compute the key for each datum.
    // If there a node associated with this key, join and add it to update.
    // If there is not (or the key is a duplicate), add it to enter.
    for (i = 0; i < dataLength; ++i) {
      keyValue = key.call(parent, data[i], i, data) + "";
      if (node = nodeByKeyValue.get(keyValue)) {
        update[i] = node;
        node.__data__ = data[i];
        nodeByKeyValue.delete(keyValue);
      } else {
        enter[i] = new EnterNode(parent, data[i]);
      }
    }

    // Add any remaining nodes that were not bound to data to exit.
    for (i = 0; i < groupLength; ++i) {
      if ((node = group[i]) && (nodeByKeyValue.get(keyValues[i]) === node)) {
        exit[i] = node;
      }
    }
  }

  function datum(node) {
    return node.__data__;
  }

  function selection_data(value, key) {
    if (!arguments.length) return Array.from(this, datum);

    var bind = key ? bindKey : bindIndex,
        parents = this._parents,
        groups = this._groups;

    if (typeof value !== "function") value = constant$1(value);

    for (var m = groups.length, update = new Array(m), enter = new Array(m), exit = new Array(m), j = 0; j < m; ++j) {
      var parent = parents[j],
          group = groups[j],
          groupLength = group.length,
          data = arraylike(value.call(parent, parent && parent.__data__, j, parents)),
          dataLength = data.length,
          enterGroup = enter[j] = new Array(dataLength),
          updateGroup = update[j] = new Array(dataLength),
          exitGroup = exit[j] = new Array(groupLength);

      bind(parent, group, enterGroup, updateGroup, exitGroup, data, key);

      // Now connect the enter nodes to their following update node, such that
      // appendChild can insert the materialized enter node before this node,
      // rather than at the end of the parent node.
      for (var i0 = 0, i1 = 0, previous, next; i0 < dataLength; ++i0) {
        if (previous = enterGroup[i0]) {
          if (i0 >= i1) i1 = i0 + 1;
          while (!(next = updateGroup[i1]) && ++i1 < dataLength);
          previous._next = next || null;
        }
      }
    }

    update = new Selection$1(update, parents);
    update._enter = enter;
    update._exit = exit;
    return update;
  }

  // Given some data, this returns an array-like view of it: an object that
  // exposes a length property and allows numeric indexing. Note that unlike
  // selectAll, this isn’t worried about “live” collections because the resulting
  // array will only be used briefly while data is being bound. (It is possible to
  // cause the data to change while iterating by using a key function, but please
  // don’t; we’d rather avoid a gratuitous copy.)
  function arraylike(data) {
    return typeof data === "object" && "length" in data
      ? data // Array, TypedArray, NodeList, array-like
      : Array.from(data); // Map, Set, iterable, string, or anything else
  }

  function selection_exit() {
    return new Selection$1(this._exit || this._groups.map(sparse), this._parents);
  }

  function selection_join(onenter, onupdate, onexit) {
    var enter = this.enter(), update = this, exit = this.exit();
    if (typeof onenter === "function") {
      enter = onenter(enter);
      if (enter) enter = enter.selection();
    } else {
      enter = enter.append(onenter + "");
    }
    if (onupdate != null) {
      update = onupdate(update);
      if (update) update = update.selection();
    }
    if (onexit == null) exit.remove(); else onexit(exit);
    return enter && update ? enter.merge(update).order() : update;
  }

  function selection_merge(context) {
    var selection = context.selection ? context.selection() : context;

    for (var groups0 = this._groups, groups1 = selection._groups, m0 = groups0.length, m1 = groups1.length, m = Math.min(m0, m1), merges = new Array(m0), j = 0; j < m; ++j) {
      for (var group0 = groups0[j], group1 = groups1[j], n = group0.length, merge = merges[j] = new Array(n), node, i = 0; i < n; ++i) {
        if (node = group0[i] || group1[i]) {
          merge[i] = node;
        }
      }
    }

    for (; j < m0; ++j) {
      merges[j] = groups0[j];
    }

    return new Selection$1(merges, this._parents);
  }

  function selection_order() {

    for (var groups = this._groups, j = -1, m = groups.length; ++j < m;) {
      for (var group = groups[j], i = group.length - 1, next = group[i], node; --i >= 0;) {
        if (node = group[i]) {
          if (next && node.compareDocumentPosition(next) ^ 4) next.parentNode.insertBefore(node, next);
          next = node;
        }
      }
    }

    return this;
  }

  function selection_sort(compare) {
    if (!compare) compare = ascending;

    function compareNode(a, b) {
      return a && b ? compare(a.__data__, b.__data__) : !a - !b;
    }

    for (var groups = this._groups, m = groups.length, sortgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, sortgroup = sortgroups[j] = new Array(n), node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          sortgroup[i] = node;
        }
      }
      sortgroup.sort(compareNode);
    }

    return new Selection$1(sortgroups, this._parents).order();
  }

  function ascending(a, b) {
    return a < b ? -1 : a > b ? 1 : a >= b ? 0 : NaN;
  }

  function selection_call() {
    var callback = arguments[0];
    arguments[0] = this;
    callback.apply(null, arguments);
    return this;
  }

  function selection_nodes() {
    return Array.from(this);
  }

  function selection_node() {

    for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
      for (var group = groups[j], i = 0, n = group.length; i < n; ++i) {
        var node = group[i];
        if (node) return node;
      }
    }

    return null;
  }

  function selection_size() {
    let size = 0;
    for (const node of this) ++size; // eslint-disable-line no-unused-vars
    return size;
  }

  function selection_empty() {
    return !this.node();
  }

  function selection_each(callback) {

    for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
      for (var group = groups[j], i = 0, n = group.length, node; i < n; ++i) {
        if (node = group[i]) callback.call(node, node.__data__, i, group);
      }
    }

    return this;
  }

  function attrRemove$1(name) {
    return function() {
      this.removeAttribute(name);
    };
  }

  function attrRemoveNS$1(fullname) {
    return function() {
      this.removeAttributeNS(fullname.space, fullname.local);
    };
  }

  function attrConstant$1(name, value) {
    return function() {
      this.setAttribute(name, value);
    };
  }

  function attrConstantNS$1(fullname, value) {
    return function() {
      this.setAttributeNS(fullname.space, fullname.local, value);
    };
  }

  function attrFunction$1(name, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) this.removeAttribute(name);
      else this.setAttribute(name, v);
    };
  }

  function attrFunctionNS$1(fullname, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) this.removeAttributeNS(fullname.space, fullname.local);
      else this.setAttributeNS(fullname.space, fullname.local, v);
    };
  }

  function selection_attr(name, value) {
    var fullname = namespace(name);

    if (arguments.length < 2) {
      var node = this.node();
      return fullname.local
          ? node.getAttributeNS(fullname.space, fullname.local)
          : node.getAttribute(fullname);
    }

    return this.each((value == null
        ? (fullname.local ? attrRemoveNS$1 : attrRemove$1) : (typeof value === "function"
        ? (fullname.local ? attrFunctionNS$1 : attrFunction$1)
        : (fullname.local ? attrConstantNS$1 : attrConstant$1)))(fullname, value));
  }

  function defaultView(node) {
    return (node.ownerDocument && node.ownerDocument.defaultView) // node is a Node
        || (node.document && node) // node is a Window
        || node.defaultView; // node is a Document
  }

  function styleRemove$1(name) {
    return function() {
      this.style.removeProperty(name);
    };
  }

  function styleConstant$1(name, value, priority) {
    return function() {
      this.style.setProperty(name, value, priority);
    };
  }

  function styleFunction$1(name, value, priority) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) this.style.removeProperty(name);
      else this.style.setProperty(name, v, priority);
    };
  }

  function selection_style(name, value, priority) {
    return arguments.length > 1
        ? this.each((value == null
              ? styleRemove$1 : typeof value === "function"
              ? styleFunction$1
              : styleConstant$1)(name, value, priority == null ? "" : priority))
        : styleValue(this.node(), name);
  }

  function styleValue(node, name) {
    return node.style.getPropertyValue(name)
        || defaultView(node).getComputedStyle(node, null).getPropertyValue(name);
  }

  function propertyRemove(name) {
    return function() {
      delete this[name];
    };
  }

  function propertyConstant(name, value) {
    return function() {
      this[name] = value;
    };
  }

  function propertyFunction(name, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) delete this[name];
      else this[name] = v;
    };
  }

  function selection_property(name, value) {
    return arguments.length > 1
        ? this.each((value == null
            ? propertyRemove : typeof value === "function"
            ? propertyFunction
            : propertyConstant)(name, value))
        : this.node()[name];
  }

  function classArray(string) {
    return string.trim().split(/^|\s+/);
  }

  function classList(node) {
    return node.classList || new ClassList(node);
  }

  function ClassList(node) {
    this._node = node;
    this._names = classArray(node.getAttribute("class") || "");
  }

  ClassList.prototype = {
    add: function(name) {
      var i = this._names.indexOf(name);
      if (i < 0) {
        this._names.push(name);
        this._node.setAttribute("class", this._names.join(" "));
      }
    },
    remove: function(name) {
      var i = this._names.indexOf(name);
      if (i >= 0) {
        this._names.splice(i, 1);
        this._node.setAttribute("class", this._names.join(" "));
      }
    },
    contains: function(name) {
      return this._names.indexOf(name) >= 0;
    }
  };

  function classedAdd(node, names) {
    var list = classList(node), i = -1, n = names.length;
    while (++i < n) list.add(names[i]);
  }

  function classedRemove(node, names) {
    var list = classList(node), i = -1, n = names.length;
    while (++i < n) list.remove(names[i]);
  }

  function classedTrue(names) {
    return function() {
      classedAdd(this, names);
    };
  }

  function classedFalse(names) {
    return function() {
      classedRemove(this, names);
    };
  }

  function classedFunction(names, value) {
    return function() {
      (value.apply(this, arguments) ? classedAdd : classedRemove)(this, names);
    };
  }

  function selection_classed(name, value) {
    var names = classArray(name + "");

    if (arguments.length < 2) {
      var list = classList(this.node()), i = -1, n = names.length;
      while (++i < n) if (!list.contains(names[i])) return false;
      return true;
    }

    return this.each((typeof value === "function"
        ? classedFunction : value
        ? classedTrue
        : classedFalse)(names, value));
  }

  function textRemove() {
    this.textContent = "";
  }

  function textConstant$1(value) {
    return function() {
      this.textContent = value;
    };
  }

  function textFunction$1(value) {
    return function() {
      var v = value.apply(this, arguments);
      this.textContent = v == null ? "" : v;
    };
  }

  function selection_text(value) {
    return arguments.length
        ? this.each(value == null
            ? textRemove : (typeof value === "function"
            ? textFunction$1
            : textConstant$1)(value))
        : this.node().textContent;
  }

  function htmlRemove() {
    this.innerHTML = "";
  }

  function htmlConstant(value) {
    return function() {
      this.innerHTML = value;
    };
  }

  function htmlFunction(value) {
    return function() {
      var v = value.apply(this, arguments);
      this.innerHTML = v == null ? "" : v;
    };
  }

  function selection_html(value) {
    return arguments.length
        ? this.each(value == null
            ? htmlRemove : (typeof value === "function"
            ? htmlFunction
            : htmlConstant)(value))
        : this.node().innerHTML;
  }

  function raise() {
    if (this.nextSibling) this.parentNode.appendChild(this);
  }

  function selection_raise() {
    return this.each(raise);
  }

  function lower() {
    if (this.previousSibling) this.parentNode.insertBefore(this, this.parentNode.firstChild);
  }

  function selection_lower() {
    return this.each(lower);
  }

  function selection_append(name) {
    var create = typeof name === "function" ? name : creator(name);
    return this.select(function() {
      return this.appendChild(create.apply(this, arguments));
    });
  }

  function constantNull() {
    return null;
  }

  function selection_insert(name, before) {
    var create = typeof name === "function" ? name : creator(name),
        select = before == null ? constantNull : typeof before === "function" ? before : selector(before);
    return this.select(function() {
      return this.insertBefore(create.apply(this, arguments), select.apply(this, arguments) || null);
    });
  }

  function remove() {
    var parent = this.parentNode;
    if (parent) parent.removeChild(this);
  }

  function selection_remove() {
    return this.each(remove);
  }

  function selection_cloneShallow() {
    var clone = this.cloneNode(false), parent = this.parentNode;
    return parent ? parent.insertBefore(clone, this.nextSibling) : clone;
  }

  function selection_cloneDeep() {
    var clone = this.cloneNode(true), parent = this.parentNode;
    return parent ? parent.insertBefore(clone, this.nextSibling) : clone;
  }

  function selection_clone(deep) {
    return this.select(deep ? selection_cloneDeep : selection_cloneShallow);
  }

  function selection_datum(value) {
    return arguments.length
        ? this.property("__data__", value)
        : this.node().__data__;
  }

  function contextListener(listener) {
    return function(event) {
      listener.call(this, event, this.__data__);
    };
  }

  function parseTypenames(typenames) {
    return typenames.trim().split(/^|\s+/).map(function(t) {
      var name = "", i = t.indexOf(".");
      if (i >= 0) name = t.slice(i + 1), t = t.slice(0, i);
      return {type: t, name: name};
    });
  }

  function onRemove(typename) {
    return function() {
      var on = this.__on;
      if (!on) return;
      for (var j = 0, i = -1, m = on.length, o; j < m; ++j) {
        if (o = on[j], (!typename.type || o.type === typename.type) && o.name === typename.name) {
          this.removeEventListener(o.type, o.listener, o.options);
        } else {
          on[++i] = o;
        }
      }
      if (++i) on.length = i;
      else delete this.__on;
    };
  }

  function onAdd(typename, value, options) {
    return function() {
      var on = this.__on, o, listener = contextListener(value);
      if (on) for (var j = 0, m = on.length; j < m; ++j) {
        if ((o = on[j]).type === typename.type && o.name === typename.name) {
          this.removeEventListener(o.type, o.listener, o.options);
          this.addEventListener(o.type, o.listener = listener, o.options = options);
          o.value = value;
          return;
        }
      }
      this.addEventListener(typename.type, listener, options);
      o = {type: typename.type, name: typename.name, value: value, listener: listener, options: options};
      if (!on) this.__on = [o];
      else on.push(o);
    };
  }

  function selection_on(typename, value, options) {
    var typenames = parseTypenames(typename + ""), i, n = typenames.length, t;

    if (arguments.length < 2) {
      var on = this.node().__on;
      if (on) for (var j = 0, m = on.length, o; j < m; ++j) {
        for (i = 0, o = on[j]; i < n; ++i) {
          if ((t = typenames[i]).type === o.type && t.name === o.name) {
            return o.value;
          }
        }
      }
      return;
    }

    on = value ? onAdd : onRemove;
    for (i = 0; i < n; ++i) this.each(on(typenames[i], value, options));
    return this;
  }

  function dispatchEvent(node, type, params) {
    var window = defaultView(node),
        event = window.CustomEvent;

    if (typeof event === "function") {
      event = new event(type, params);
    } else {
      event = window.document.createEvent("Event");
      if (params) event.initEvent(type, params.bubbles, params.cancelable), event.detail = params.detail;
      else event.initEvent(type, false, false);
    }

    node.dispatchEvent(event);
  }

  function dispatchConstant(type, params) {
    return function() {
      return dispatchEvent(this, type, params);
    };
  }

  function dispatchFunction(type, params) {
    return function() {
      return dispatchEvent(this, type, params.apply(this, arguments));
    };
  }

  function selection_dispatch(type, params) {
    return this.each((typeof params === "function"
        ? dispatchFunction
        : dispatchConstant)(type, params));
  }

  function* selection_iterator() {
    for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
      for (var group = groups[j], i = 0, n = group.length, node; i < n; ++i) {
        if (node = group[i]) yield node;
      }
    }
  }

  var root = [null];

  function Selection$1(groups, parents) {
    this._groups = groups;
    this._parents = parents;
  }

  function selection() {
    return new Selection$1([[document.documentElement]], root);
  }

  function selection_selection() {
    return this;
  }

  Selection$1.prototype = selection.prototype = {
    constructor: Selection$1,
    select: selection_select,
    selectAll: selection_selectAll,
    selectChild: selection_selectChild,
    selectChildren: selection_selectChildren,
    filter: selection_filter,
    data: selection_data,
    enter: selection_enter,
    exit: selection_exit,
    join: selection_join,
    merge: selection_merge,
    selection: selection_selection,
    order: selection_order,
    sort: selection_sort,
    call: selection_call,
    nodes: selection_nodes,
    node: selection_node,
    size: selection_size,
    empty: selection_empty,
    each: selection_each,
    attr: selection_attr,
    style: selection_style,
    property: selection_property,
    classed: selection_classed,
    text: selection_text,
    html: selection_html,
    raise: selection_raise,
    lower: selection_lower,
    append: selection_append,
    insert: selection_insert,
    remove: selection_remove,
    clone: selection_clone,
    datum: selection_datum,
    on: selection_on,
    dispatch: selection_dispatch,
    [Symbol.iterator]: selection_iterator
  };

  function select(selector) {
    return typeof selector === "string"
        ? new Selection$1([[document.querySelector(selector)]], [document.documentElement])
        : new Selection$1([[selector]], root);
  }

  function define(constructor, factory, prototype) {
    constructor.prototype = factory.prototype = prototype;
    prototype.constructor = constructor;
  }

  function extend(parent, definition) {
    var prototype = Object.create(parent.prototype);
    for (var key in definition) prototype[key] = definition[key];
    return prototype;
  }

  function Color() {}

  var darker = 0.7;
  var brighter = 1 / darker;

  var reI = "\\s*([+-]?\\d+)\\s*",
      reN = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",
      reP = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
      reHex = /^#([0-9a-f]{3,8})$/,
      reRgbInteger = new RegExp(`^rgb\\(${reI},${reI},${reI}\\)$`),
      reRgbPercent = new RegExp(`^rgb\\(${reP},${reP},${reP}\\)$`),
      reRgbaInteger = new RegExp(`^rgba\\(${reI},${reI},${reI},${reN}\\)$`),
      reRgbaPercent = new RegExp(`^rgba\\(${reP},${reP},${reP},${reN}\\)$`),
      reHslPercent = new RegExp(`^hsl\\(${reN},${reP},${reP}\\)$`),
      reHslaPercent = new RegExp(`^hsla\\(${reN},${reP},${reP},${reN}\\)$`);

  var named = {
    aliceblue: 0xf0f8ff,
    antiquewhite: 0xfaebd7,
    aqua: 0x00ffff,
    aquamarine: 0x7fffd4,
    azure: 0xf0ffff,
    beige: 0xf5f5dc,
    bisque: 0xffe4c4,
    black: 0x000000,
    blanchedalmond: 0xffebcd,
    blue: 0x0000ff,
    blueviolet: 0x8a2be2,
    brown: 0xa52a2a,
    burlywood: 0xdeb887,
    cadetblue: 0x5f9ea0,
    chartreuse: 0x7fff00,
    chocolate: 0xd2691e,
    coral: 0xff7f50,
    cornflowerblue: 0x6495ed,
    cornsilk: 0xfff8dc,
    crimson: 0xdc143c,
    cyan: 0x00ffff,
    darkblue: 0x00008b,
    darkcyan: 0x008b8b,
    darkgoldenrod: 0xb8860b,
    darkgray: 0xa9a9a9,
    darkgreen: 0x006400,
    darkgrey: 0xa9a9a9,
    darkkhaki: 0xbdb76b,
    darkmagenta: 0x8b008b,
    darkolivegreen: 0x556b2f,
    darkorange: 0xff8c00,
    darkorchid: 0x9932cc,
    darkred: 0x8b0000,
    darksalmon: 0xe9967a,
    darkseagreen: 0x8fbc8f,
    darkslateblue: 0x483d8b,
    darkslategray: 0x2f4f4f,
    darkslategrey: 0x2f4f4f,
    darkturquoise: 0x00ced1,
    darkviolet: 0x9400d3,
    deeppink: 0xff1493,
    deepskyblue: 0x00bfff,
    dimgray: 0x696969,
    dimgrey: 0x696969,
    dodgerblue: 0x1e90ff,
    firebrick: 0xb22222,
    floralwhite: 0xfffaf0,
    forestgreen: 0x228b22,
    fuchsia: 0xff00ff,
    gainsboro: 0xdcdcdc,
    ghostwhite: 0xf8f8ff,
    gold: 0xffd700,
    goldenrod: 0xdaa520,
    gray: 0x808080,
    green: 0x008000,
    greenyellow: 0xadff2f,
    grey: 0x808080,
    honeydew: 0xf0fff0,
    hotpink: 0xff69b4,
    indianred: 0xcd5c5c,
    indigo: 0x4b0082,
    ivory: 0xfffff0,
    khaki: 0xf0e68c,
    lavender: 0xe6e6fa,
    lavenderblush: 0xfff0f5,
    lawngreen: 0x7cfc00,
    lemonchiffon: 0xfffacd,
    lightblue: 0xadd8e6,
    lightcoral: 0xf08080,
    lightcyan: 0xe0ffff,
    lightgoldenrodyellow: 0xfafad2,
    lightgray: 0xd3d3d3,
    lightgreen: 0x90ee90,
    lightgrey: 0xd3d3d3,
    lightpink: 0xffb6c1,
    lightsalmon: 0xffa07a,
    lightseagreen: 0x20b2aa,
    lightskyblue: 0x87cefa,
    lightslategray: 0x778899,
    lightslategrey: 0x778899,
    lightsteelblue: 0xb0c4de,
    lightyellow: 0xffffe0,
    lime: 0x00ff00,
    limegreen: 0x32cd32,
    linen: 0xfaf0e6,
    magenta: 0xff00ff,
    maroon: 0x800000,
    mediumaquamarine: 0x66cdaa,
    mediumblue: 0x0000cd,
    mediumorchid: 0xba55d3,
    mediumpurple: 0x9370db,
    mediumseagreen: 0x3cb371,
    mediumslateblue: 0x7b68ee,
    mediumspringgreen: 0x00fa9a,
    mediumturquoise: 0x48d1cc,
    mediumvioletred: 0xc71585,
    midnightblue: 0x191970,
    mintcream: 0xf5fffa,
    mistyrose: 0xffe4e1,
    moccasin: 0xffe4b5,
    navajowhite: 0xffdead,
    navy: 0x000080,
    oldlace: 0xfdf5e6,
    olive: 0x808000,
    olivedrab: 0x6b8e23,
    orange: 0xffa500,
    orangered: 0xff4500,
    orchid: 0xda70d6,
    palegoldenrod: 0xeee8aa,
    palegreen: 0x98fb98,
    paleturquoise: 0xafeeee,
    palevioletred: 0xdb7093,
    papayawhip: 0xffefd5,
    peachpuff: 0xffdab9,
    peru: 0xcd853f,
    pink: 0xffc0cb,
    plum: 0xdda0dd,
    powderblue: 0xb0e0e6,
    purple: 0x800080,
    rebeccapurple: 0x663399,
    red: 0xff0000,
    rosybrown: 0xbc8f8f,
    royalblue: 0x4169e1,
    saddlebrown: 0x8b4513,
    salmon: 0xfa8072,
    sandybrown: 0xf4a460,
    seagreen: 0x2e8b57,
    seashell: 0xfff5ee,
    sienna: 0xa0522d,
    silver: 0xc0c0c0,
    skyblue: 0x87ceeb,
    slateblue: 0x6a5acd,
    slategray: 0x708090,
    slategrey: 0x708090,
    snow: 0xfffafa,
    springgreen: 0x00ff7f,
    steelblue: 0x4682b4,
    tan: 0xd2b48c,
    teal: 0x008080,
    thistle: 0xd8bfd8,
    tomato: 0xff6347,
    turquoise: 0x40e0d0,
    violet: 0xee82ee,
    wheat: 0xf5deb3,
    white: 0xffffff,
    whitesmoke: 0xf5f5f5,
    yellow: 0xffff00,
    yellowgreen: 0x9acd32
  };

  define(Color, color, {
    copy(channels) {
      return Object.assign(new this.constructor, this, channels);
    },
    displayable() {
      return this.rgb().displayable();
    },
    hex: color_formatHex, // Deprecated! Use color.formatHex.
    formatHex: color_formatHex,
    formatHex8: color_formatHex8,
    formatHsl: color_formatHsl,
    formatRgb: color_formatRgb,
    toString: color_formatRgb
  });

  function color_formatHex() {
    return this.rgb().formatHex();
  }

  function color_formatHex8() {
    return this.rgb().formatHex8();
  }

  function color_formatHsl() {
    return hslConvert(this).formatHsl();
  }

  function color_formatRgb() {
    return this.rgb().formatRgb();
  }

  function color(format) {
    var m, l;
    format = (format + "").trim().toLowerCase();
    return (m = reHex.exec(format)) ? (l = m[1].length, m = parseInt(m[1], 16), l === 6 ? rgbn(m) // #ff0000
        : l === 3 ? new Rgb((m >> 8 & 0xf) | (m >> 4 & 0xf0), (m >> 4 & 0xf) | (m & 0xf0), ((m & 0xf) << 4) | (m & 0xf), 1) // #f00
        : l === 8 ? rgba(m >> 24 & 0xff, m >> 16 & 0xff, m >> 8 & 0xff, (m & 0xff) / 0xff) // #ff000000
        : l === 4 ? rgba((m >> 12 & 0xf) | (m >> 8 & 0xf0), (m >> 8 & 0xf) | (m >> 4 & 0xf0), (m >> 4 & 0xf) | (m & 0xf0), (((m & 0xf) << 4) | (m & 0xf)) / 0xff) // #f000
        : null) // invalid hex
        : (m = reRgbInteger.exec(format)) ? new Rgb(m[1], m[2], m[3], 1) // rgb(255, 0, 0)
        : (m = reRgbPercent.exec(format)) ? new Rgb(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, 1) // rgb(100%, 0%, 0%)
        : (m = reRgbaInteger.exec(format)) ? rgba(m[1], m[2], m[3], m[4]) // rgba(255, 0, 0, 1)
        : (m = reRgbaPercent.exec(format)) ? rgba(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, m[4]) // rgb(100%, 0%, 0%, 1)
        : (m = reHslPercent.exec(format)) ? hsla(m[1], m[2] / 100, m[3] / 100, 1) // hsl(120, 50%, 50%)
        : (m = reHslaPercent.exec(format)) ? hsla(m[1], m[2] / 100, m[3] / 100, m[4]) // hsla(120, 50%, 50%, 1)
        : named.hasOwnProperty(format) ? rgbn(named[format]) // eslint-disable-line no-prototype-builtins
        : format === "transparent" ? new Rgb(NaN, NaN, NaN, 0)
        : null;
  }

  function rgbn(n) {
    return new Rgb(n >> 16 & 0xff, n >> 8 & 0xff, n & 0xff, 1);
  }

  function rgba(r, g, b, a) {
    if (a <= 0) r = g = b = NaN;
    return new Rgb(r, g, b, a);
  }

  function rgbConvert(o) {
    if (!(o instanceof Color)) o = color(o);
    if (!o) return new Rgb;
    o = o.rgb();
    return new Rgb(o.r, o.g, o.b, o.opacity);
  }

  function rgb(r, g, b, opacity) {
    return arguments.length === 1 ? rgbConvert(r) : new Rgb(r, g, b, opacity == null ? 1 : opacity);
  }

  function Rgb(r, g, b, opacity) {
    this.r = +r;
    this.g = +g;
    this.b = +b;
    this.opacity = +opacity;
  }

  define(Rgb, rgb, extend(Color, {
    brighter(k) {
      k = k == null ? brighter : Math.pow(brighter, k);
      return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
    },
    darker(k) {
      k = k == null ? darker : Math.pow(darker, k);
      return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
    },
    rgb() {
      return this;
    },
    clamp() {
      return new Rgb(clampi(this.r), clampi(this.g), clampi(this.b), clampa(this.opacity));
    },
    displayable() {
      return (-0.5 <= this.r && this.r < 255.5)
          && (-0.5 <= this.g && this.g < 255.5)
          && (-0.5 <= this.b && this.b < 255.5)
          && (0 <= this.opacity && this.opacity <= 1);
    },
    hex: rgb_formatHex, // Deprecated! Use color.formatHex.
    formatHex: rgb_formatHex,
    formatHex8: rgb_formatHex8,
    formatRgb: rgb_formatRgb,
    toString: rgb_formatRgb
  }));

  function rgb_formatHex() {
    return `#${hex(this.r)}${hex(this.g)}${hex(this.b)}`;
  }

  function rgb_formatHex8() {
    return `#${hex(this.r)}${hex(this.g)}${hex(this.b)}${hex((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
  }

  function rgb_formatRgb() {
    const a = clampa(this.opacity);
    return `${a === 1 ? "rgb(" : "rgba("}${clampi(this.r)}, ${clampi(this.g)}, ${clampi(this.b)}${a === 1 ? ")" : `, ${a})`}`;
  }

  function clampa(opacity) {
    return isNaN(opacity) ? 1 : Math.max(0, Math.min(1, opacity));
  }

  function clampi(value) {
    return Math.max(0, Math.min(255, Math.round(value) || 0));
  }

  function hex(value) {
    value = clampi(value);
    return (value < 16 ? "0" : "") + value.toString(16);
  }

  function hsla(h, s, l, a) {
    if (a <= 0) h = s = l = NaN;
    else if (l <= 0 || l >= 1) h = s = NaN;
    else if (s <= 0) h = NaN;
    return new Hsl(h, s, l, a);
  }

  function hslConvert(o) {
    if (o instanceof Hsl) return new Hsl(o.h, o.s, o.l, o.opacity);
    if (!(o instanceof Color)) o = color(o);
    if (!o) return new Hsl;
    if (o instanceof Hsl) return o;
    o = o.rgb();
    var r = o.r / 255,
        g = o.g / 255,
        b = o.b / 255,
        min = Math.min(r, g, b),
        max = Math.max(r, g, b),
        h = NaN,
        s = max - min,
        l = (max + min) / 2;
    if (s) {
      if (r === max) h = (g - b) / s + (g < b) * 6;
      else if (g === max) h = (b - r) / s + 2;
      else h = (r - g) / s + 4;
      s /= l < 0.5 ? max + min : 2 - max - min;
      h *= 60;
    } else {
      s = l > 0 && l < 1 ? 0 : h;
    }
    return new Hsl(h, s, l, o.opacity);
  }

  function hsl(h, s, l, opacity) {
    return arguments.length === 1 ? hslConvert(h) : new Hsl(h, s, l, opacity == null ? 1 : opacity);
  }

  function Hsl(h, s, l, opacity) {
    this.h = +h;
    this.s = +s;
    this.l = +l;
    this.opacity = +opacity;
  }

  define(Hsl, hsl, extend(Color, {
    brighter(k) {
      k = k == null ? brighter : Math.pow(brighter, k);
      return new Hsl(this.h, this.s, this.l * k, this.opacity);
    },
    darker(k) {
      k = k == null ? darker : Math.pow(darker, k);
      return new Hsl(this.h, this.s, this.l * k, this.opacity);
    },
    rgb() {
      var h = this.h % 360 + (this.h < 0) * 360,
          s = isNaN(h) || isNaN(this.s) ? 0 : this.s,
          l = this.l,
          m2 = l + (l < 0.5 ? l : 1 - l) * s,
          m1 = 2 * l - m2;
      return new Rgb(
        hsl2rgb(h >= 240 ? h - 240 : h + 120, m1, m2),
        hsl2rgb(h, m1, m2),
        hsl2rgb(h < 120 ? h + 240 : h - 120, m1, m2),
        this.opacity
      );
    },
    clamp() {
      return new Hsl(clamph(this.h), clampt(this.s), clampt(this.l), clampa(this.opacity));
    },
    displayable() {
      return (0 <= this.s && this.s <= 1 || isNaN(this.s))
          && (0 <= this.l && this.l <= 1)
          && (0 <= this.opacity && this.opacity <= 1);
    },
    formatHsl() {
      const a = clampa(this.opacity);
      return `${a === 1 ? "hsl(" : "hsla("}${clamph(this.h)}, ${clampt(this.s) * 100}%, ${clampt(this.l) * 100}%${a === 1 ? ")" : `, ${a})`}`;
    }
  }));

  function clamph(value) {
    value = (value || 0) % 360;
    return value < 0 ? value + 360 : value;
  }

  function clampt(value) {
    return Math.max(0, Math.min(1, value || 0));
  }

  /* From FvD 13.37, CSS Color Module Level 3 */
  function hsl2rgb(h, m1, m2) {
    return (h < 60 ? m1 + (m2 - m1) * h / 60
        : h < 180 ? m2
        : h < 240 ? m1 + (m2 - m1) * (240 - h) / 60
        : m1) * 255;
  }

  var constant = x => () => x;

  function linear(a, d) {
    return function(t) {
      return a + t * d;
    };
  }

  function exponential(a, b, y) {
    return a = Math.pow(a, y), b = Math.pow(b, y) - a, y = 1 / y, function(t) {
      return Math.pow(a + t * b, y);
    };
  }

  function gamma(y) {
    return (y = +y) === 1 ? nogamma : function(a, b) {
      return b - a ? exponential(a, b, y) : constant(isNaN(a) ? b : a);
    };
  }

  function nogamma(a, b) {
    var d = b - a;
    return d ? linear(a, d) : constant(isNaN(a) ? b : a);
  }

  var interpolateRgb = (function rgbGamma(y) {
    var color = gamma(y);

    function rgb$1(start, end) {
      var r = color((start = rgb(start)).r, (end = rgb(end)).r),
          g = color(start.g, end.g),
          b = color(start.b, end.b),
          opacity = nogamma(start.opacity, end.opacity);
      return function(t) {
        start.r = r(t);
        start.g = g(t);
        start.b = b(t);
        start.opacity = opacity(t);
        return start + "";
      };
    }

    rgb$1.gamma = rgbGamma;

    return rgb$1;
  })(1);

  function interpolateNumber(a, b) {
    return a = +a, b = +b, function(t) {
      return a * (1 - t) + b * t;
    };
  }

  var reA = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
      reB = new RegExp(reA.source, "g");

  function zero(b) {
    return function() {
      return b;
    };
  }

  function one(b) {
    return function(t) {
      return b(t) + "";
    };
  }

  function interpolateString(a, b) {
    var bi = reA.lastIndex = reB.lastIndex = 0, // scan index for next number in b
        am, // current match in a
        bm, // current match in b
        bs, // string preceding current number in b, if any
        i = -1, // index in s
        s = [], // string constants and placeholders
        q = []; // number interpolators

    // Coerce inputs to strings.
    a = a + "", b = b + "";

    // Interpolate pairs of numbers in a & b.
    while ((am = reA.exec(a))
        && (bm = reB.exec(b))) {
      if ((bs = bm.index) > bi) { // a string precedes the next number in b
        bs = b.slice(bi, bs);
        if (s[i]) s[i] += bs; // coalesce with previous string
        else s[++i] = bs;
      }
      if ((am = am[0]) === (bm = bm[0])) { // numbers in a & b match
        if (s[i]) s[i] += bm; // coalesce with previous string
        else s[++i] = bm;
      } else { // interpolate non-matching numbers
        s[++i] = null;
        q.push({i: i, x: interpolateNumber(am, bm)});
      }
      bi = reB.lastIndex;
    }

    // Add remains of b.
    if (bi < b.length) {
      bs = b.slice(bi);
      if (s[i]) s[i] += bs; // coalesce with previous string
      else s[++i] = bs;
    }

    // Special optimization for only a single match.
    // Otherwise, interpolate each of the numbers and rejoin the string.
    return s.length < 2 ? (q[0]
        ? one(q[0].x)
        : zero(b))
        : (b = q.length, function(t) {
            for (var i = 0, o; i < b; ++i) s[(o = q[i]).i] = o.x(t);
            return s.join("");
          });
  }

  var degrees = 180 / Math.PI;

  var identity = {
    translateX: 0,
    translateY: 0,
    rotate: 0,
    skewX: 0,
    scaleX: 1,
    scaleY: 1
  };

  function decompose(a, b, c, d, e, f) {
    var scaleX, scaleY, skewX;
    if (scaleX = Math.sqrt(a * a + b * b)) a /= scaleX, b /= scaleX;
    if (skewX = a * c + b * d) c -= a * skewX, d -= b * skewX;
    if (scaleY = Math.sqrt(c * c + d * d)) c /= scaleY, d /= scaleY, skewX /= scaleY;
    if (a * d < b * c) a = -a, b = -b, skewX = -skewX, scaleX = -scaleX;
    return {
      translateX: e,
      translateY: f,
      rotate: Math.atan2(b, a) * degrees,
      skewX: Math.atan(skewX) * degrees,
      scaleX: scaleX,
      scaleY: scaleY
    };
  }

  var svgNode;

  /* eslint-disable no-undef */
  function parseCss(value) {
    const m = new (typeof DOMMatrix === "function" ? DOMMatrix : WebKitCSSMatrix)(value + "");
    return m.isIdentity ? identity : decompose(m.a, m.b, m.c, m.d, m.e, m.f);
  }

  function parseSvg(value) {
    if (value == null) return identity;
    if (!svgNode) svgNode = document.createElementNS("http://www.w3.org/2000/svg", "g");
    svgNode.setAttribute("transform", value);
    if (!(value = svgNode.transform.baseVal.consolidate())) return identity;
    value = value.matrix;
    return decompose(value.a, value.b, value.c, value.d, value.e, value.f);
  }

  function interpolateTransform(parse, pxComma, pxParen, degParen) {

    function pop(s) {
      return s.length ? s.pop() + " " : "";
    }

    function translate(xa, ya, xb, yb, s, q) {
      if (xa !== xb || ya !== yb) {
        var i = s.push("translate(", null, pxComma, null, pxParen);
        q.push({i: i - 4, x: interpolateNumber(xa, xb)}, {i: i - 2, x: interpolateNumber(ya, yb)});
      } else if (xb || yb) {
        s.push("translate(" + xb + pxComma + yb + pxParen);
      }
    }

    function rotate(a, b, s, q) {
      if (a !== b) {
        if (a - b > 180) b += 360; else if (b - a > 180) a += 360; // shortest path
        q.push({i: s.push(pop(s) + "rotate(", null, degParen) - 2, x: interpolateNumber(a, b)});
      } else if (b) {
        s.push(pop(s) + "rotate(" + b + degParen);
      }
    }

    function skewX(a, b, s, q) {
      if (a !== b) {
        q.push({i: s.push(pop(s) + "skewX(", null, degParen) - 2, x: interpolateNumber(a, b)});
      } else if (b) {
        s.push(pop(s) + "skewX(" + b + degParen);
      }
    }

    function scale(xa, ya, xb, yb, s, q) {
      if (xa !== xb || ya !== yb) {
        var i = s.push(pop(s) + "scale(", null, ",", null, ")");
        q.push({i: i - 4, x: interpolateNumber(xa, xb)}, {i: i - 2, x: interpolateNumber(ya, yb)});
      } else if (xb !== 1 || yb !== 1) {
        s.push(pop(s) + "scale(" + xb + "," + yb + ")");
      }
    }

    return function(a, b) {
      var s = [], // string constants and placeholders
          q = []; // number interpolators
      a = parse(a), b = parse(b);
      translate(a.translateX, a.translateY, b.translateX, b.translateY, s, q);
      rotate(a.rotate, b.rotate, s, q);
      skewX(a.skewX, b.skewX, s, q);
      scale(a.scaleX, a.scaleY, b.scaleX, b.scaleY, s, q);
      a = b = null; // gc
      return function(t) {
        var i = -1, n = q.length, o;
        while (++i < n) s[(o = q[i]).i] = o.x(t);
        return s.join("");
      };
    };
  }

  var interpolateTransformCss = interpolateTransform(parseCss, "px, ", "px)", "deg)");
  var interpolateTransformSvg = interpolateTransform(parseSvg, ", ", ")", ")");

  var frame = 0, // is an animation frame pending?
      timeout$1 = 0, // is a timeout pending?
      interval = 0, // are any timers active?
      pokeDelay = 1000, // how frequently we check for clock skew
      taskHead,
      taskTail,
      clockLast = 0,
      clockNow = 0,
      clockSkew = 0,
      clock = typeof performance === "object" && performance.now ? performance : Date,
      setFrame = typeof window === "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(f) { setTimeout(f, 17); };

  function now() {
    return clockNow || (setFrame(clearNow), clockNow = clock.now() + clockSkew);
  }

  function clearNow() {
    clockNow = 0;
  }

  function Timer() {
    this._call =
    this._time =
    this._next = null;
  }

  Timer.prototype = timer.prototype = {
    constructor: Timer,
    restart: function(callback, delay, time) {
      if (typeof callback !== "function") throw new TypeError("callback is not a function");
      time = (time == null ? now() : +time) + (delay == null ? 0 : +delay);
      if (!this._next && taskTail !== this) {
        if (taskTail) taskTail._next = this;
        else taskHead = this;
        taskTail = this;
      }
      this._call = callback;
      this._time = time;
      sleep();
    },
    stop: function() {
      if (this._call) {
        this._call = null;
        this._time = Infinity;
        sleep();
      }
    }
  };

  function timer(callback, delay, time) {
    var t = new Timer;
    t.restart(callback, delay, time);
    return t;
  }

  function timerFlush() {
    now(); // Get the current time, if not already set.
    ++frame; // Pretend we’ve set an alarm, if we haven’t already.
    var t = taskHead, e;
    while (t) {
      if ((e = clockNow - t._time) >= 0) t._call.call(undefined, e);
      t = t._next;
    }
    --frame;
  }

  function wake() {
    clockNow = (clockLast = clock.now()) + clockSkew;
    frame = timeout$1 = 0;
    try {
      timerFlush();
    } finally {
      frame = 0;
      nap();
      clockNow = 0;
    }
  }

  function poke() {
    var now = clock.now(), delay = now - clockLast;
    if (delay > pokeDelay) clockSkew -= delay, clockLast = now;
  }

  function nap() {
    var t0, t1 = taskHead, t2, time = Infinity;
    while (t1) {
      if (t1._call) {
        if (time > t1._time) time = t1._time;
        t0 = t1, t1 = t1._next;
      } else {
        t2 = t1._next, t1._next = null;
        t1 = t0 ? t0._next = t2 : taskHead = t2;
      }
    }
    taskTail = t0;
    sleep(time);
  }

  function sleep(time) {
    if (frame) return; // Soonest alarm already set, or will be.
    if (timeout$1) timeout$1 = clearTimeout(timeout$1);
    var delay = time - clockNow; // Strictly less than if we recomputed clockNow.
    if (delay > 24) {
      if (time < Infinity) timeout$1 = setTimeout(wake, time - clock.now() - clockSkew);
      if (interval) interval = clearInterval(interval);
    } else {
      if (!interval) clockLast = clock.now(), interval = setInterval(poke, pokeDelay);
      frame = 1, setFrame(wake);
    }
  }

  function timeout(callback, delay, time) {
    var t = new Timer;
    delay = delay == null ? 0 : +delay;
    t.restart(elapsed => {
      t.stop();
      callback(elapsed + delay);
    }, delay, time);
    return t;
  }

  var emptyOn = dispatch("start", "end", "cancel", "interrupt");
  var emptyTween = [];

  var CREATED = 0;
  var SCHEDULED = 1;
  var STARTING = 2;
  var STARTED = 3;
  var RUNNING = 4;
  var ENDING = 5;
  var ENDED = 6;

  function schedule(node, name, id, index, group, timing) {
    var schedules = node.__transition;
    if (!schedules) node.__transition = {};
    else if (id in schedules) return;
    create(node, id, {
      name: name,
      index: index, // For context during callback.
      group: group, // For context during callback.
      on: emptyOn,
      tween: emptyTween,
      time: timing.time,
      delay: timing.delay,
      duration: timing.duration,
      ease: timing.ease,
      timer: null,
      state: CREATED
    });
  }

  function init(node, id) {
    var schedule = get(node, id);
    if (schedule.state > CREATED) throw new Error("too late; already scheduled");
    return schedule;
  }

  function set(node, id) {
    var schedule = get(node, id);
    if (schedule.state > STARTED) throw new Error("too late; already running");
    return schedule;
  }

  function get(node, id) {
    var schedule = node.__transition;
    if (!schedule || !(schedule = schedule[id])) throw new Error("transition not found");
    return schedule;
  }

  function create(node, id, self) {
    var schedules = node.__transition,
        tween;

    // Initialize the self timer when the transition is created.
    // Note the actual delay is not known until the first callback!
    schedules[id] = self;
    self.timer = timer(schedule, 0, self.time);

    function schedule(elapsed) {
      self.state = SCHEDULED;
      self.timer.restart(start, self.delay, self.time);

      // If the elapsed delay is less than our first sleep, start immediately.
      if (self.delay <= elapsed) start(elapsed - self.delay);
    }

    function start(elapsed) {
      var i, j, n, o;

      // If the state is not SCHEDULED, then we previously errored on start.
      if (self.state !== SCHEDULED) return stop();

      for (i in schedules) {
        o = schedules[i];
        if (o.name !== self.name) continue;

        // While this element already has a starting transition during this frame,
        // defer starting an interrupting transition until that transition has a
        // chance to tick (and possibly end); see d3/d3-transition#54!
        if (o.state === STARTED) return timeout(start);

        // Interrupt the active transition, if any.
        if (o.state === RUNNING) {
          o.state = ENDED;
          o.timer.stop();
          o.on.call("interrupt", node, node.__data__, o.index, o.group);
          delete schedules[i];
        }

        // Cancel any pre-empted transitions.
        else if (+i < id) {
          o.state = ENDED;
          o.timer.stop();
          o.on.call("cancel", node, node.__data__, o.index, o.group);
          delete schedules[i];
        }
      }

      // Defer the first tick to end of the current frame; see d3/d3#1576.
      // Note the transition may be canceled after start and before the first tick!
      // Note this must be scheduled before the start event; see d3/d3-transition#16!
      // Assuming this is successful, subsequent callbacks go straight to tick.
      timeout(function() {
        if (self.state === STARTED) {
          self.state = RUNNING;
          self.timer.restart(tick, self.delay, self.time);
          tick(elapsed);
        }
      });

      // Dispatch the start event.
      // Note this must be done before the tween are initialized.
      self.state = STARTING;
      self.on.call("start", node, node.__data__, self.index, self.group);
      if (self.state !== STARTING) return; // interrupted
      self.state = STARTED;

      // Initialize the tween, deleting null tween.
      tween = new Array(n = self.tween.length);
      for (i = 0, j = -1; i < n; ++i) {
        if (o = self.tween[i].value.call(node, node.__data__, self.index, self.group)) {
          tween[++j] = o;
        }
      }
      tween.length = j + 1;
    }

    function tick(elapsed) {
      var t = elapsed < self.duration ? self.ease.call(null, elapsed / self.duration) : (self.timer.restart(stop), self.state = ENDING, 1),
          i = -1,
          n = tween.length;

      while (++i < n) {
        tween[i].call(node, t);
      }

      // Dispatch the end event.
      if (self.state === ENDING) {
        self.on.call("end", node, node.__data__, self.index, self.group);
        stop();
      }
    }

    function stop() {
      self.state = ENDED;
      self.timer.stop();
      delete schedules[id];
      for (var i in schedules) return; // eslint-disable-line no-unused-vars
      delete node.__transition;
    }
  }

  function interrupt(node, name) {
    var schedules = node.__transition,
        schedule,
        active,
        empty = true,
        i;

    if (!schedules) return;

    name = name == null ? null : name + "";

    for (i in schedules) {
      if ((schedule = schedules[i]).name !== name) { empty = false; continue; }
      active = schedule.state > STARTING && schedule.state < ENDING;
      schedule.state = ENDED;
      schedule.timer.stop();
      schedule.on.call(active ? "interrupt" : "cancel", node, node.__data__, schedule.index, schedule.group);
      delete schedules[i];
    }

    if (empty) delete node.__transition;
  }

  function selection_interrupt(name) {
    return this.each(function() {
      interrupt(this, name);
    });
  }

  function tweenRemove(id, name) {
    var tween0, tween1;
    return function() {
      var schedule = set(this, id),
          tween = schedule.tween;

      // If this node shared tween with the previous node,
      // just assign the updated shared tween and we’re done!
      // Otherwise, copy-on-write.
      if (tween !== tween0) {
        tween1 = tween0 = tween;
        for (var i = 0, n = tween1.length; i < n; ++i) {
          if (tween1[i].name === name) {
            tween1 = tween1.slice();
            tween1.splice(i, 1);
            break;
          }
        }
      }

      schedule.tween = tween1;
    };
  }

  function tweenFunction(id, name, value) {
    var tween0, tween1;
    if (typeof value !== "function") throw new Error;
    return function() {
      var schedule = set(this, id),
          tween = schedule.tween;

      // If this node shared tween with the previous node,
      // just assign the updated shared tween and we’re done!
      // Otherwise, copy-on-write.
      if (tween !== tween0) {
        tween1 = (tween0 = tween).slice();
        for (var t = {name: name, value: value}, i = 0, n = tween1.length; i < n; ++i) {
          if (tween1[i].name === name) {
            tween1[i] = t;
            break;
          }
        }
        if (i === n) tween1.push(t);
      }

      schedule.tween = tween1;
    };
  }

  function transition_tween(name, value) {
    var id = this._id;

    name += "";

    if (arguments.length < 2) {
      var tween = get(this.node(), id).tween;
      for (var i = 0, n = tween.length, t; i < n; ++i) {
        if ((t = tween[i]).name === name) {
          return t.value;
        }
      }
      return null;
    }

    return this.each((value == null ? tweenRemove : tweenFunction)(id, name, value));
  }

  function tweenValue(transition, name, value) {
    var id = transition._id;

    transition.each(function() {
      var schedule = set(this, id);
      (schedule.value || (schedule.value = {}))[name] = value.apply(this, arguments);
    });

    return function(node) {
      return get(node, id).value[name];
    };
  }

  function interpolate(a, b) {
    var c;
    return (typeof b === "number" ? interpolateNumber
        : b instanceof color ? interpolateRgb
        : (c = color(b)) ? (b = c, interpolateRgb)
        : interpolateString)(a, b);
  }

  function attrRemove(name) {
    return function() {
      this.removeAttribute(name);
    };
  }

  function attrRemoveNS(fullname) {
    return function() {
      this.removeAttributeNS(fullname.space, fullname.local);
    };
  }

  function attrConstant(name, interpolate, value1) {
    var string00,
        string1 = value1 + "",
        interpolate0;
    return function() {
      var string0 = this.getAttribute(name);
      return string0 === string1 ? null
          : string0 === string00 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, value1);
    };
  }

  function attrConstantNS(fullname, interpolate, value1) {
    var string00,
        string1 = value1 + "",
        interpolate0;
    return function() {
      var string0 = this.getAttributeNS(fullname.space, fullname.local);
      return string0 === string1 ? null
          : string0 === string00 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, value1);
    };
  }

  function attrFunction(name, interpolate, value) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0, value1 = value(this), string1;
      if (value1 == null) return void this.removeAttribute(name);
      string0 = this.getAttribute(name);
      string1 = value1 + "";
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : (string10 = string1, interpolate0 = interpolate(string00 = string0, value1));
    };
  }

  function attrFunctionNS(fullname, interpolate, value) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0, value1 = value(this), string1;
      if (value1 == null) return void this.removeAttributeNS(fullname.space, fullname.local);
      string0 = this.getAttributeNS(fullname.space, fullname.local);
      string1 = value1 + "";
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : (string10 = string1, interpolate0 = interpolate(string00 = string0, value1));
    };
  }

  function transition_attr(name, value) {
    var fullname = namespace(name), i = fullname === "transform" ? interpolateTransformSvg : interpolate;
    return this.attrTween(name, typeof value === "function"
        ? (fullname.local ? attrFunctionNS : attrFunction)(fullname, i, tweenValue(this, "attr." + name, value))
        : value == null ? (fullname.local ? attrRemoveNS : attrRemove)(fullname)
        : (fullname.local ? attrConstantNS : attrConstant)(fullname, i, value));
  }

  function attrInterpolate(name, i) {
    return function(t) {
      this.setAttribute(name, i.call(this, t));
    };
  }

  function attrInterpolateNS(fullname, i) {
    return function(t) {
      this.setAttributeNS(fullname.space, fullname.local, i.call(this, t));
    };
  }

  function attrTweenNS(fullname, value) {
    var t0, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t0 = (i0 = i) && attrInterpolateNS(fullname, i);
      return t0;
    }
    tween._value = value;
    return tween;
  }

  function attrTween(name, value) {
    var t0, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t0 = (i0 = i) && attrInterpolate(name, i);
      return t0;
    }
    tween._value = value;
    return tween;
  }

  function transition_attrTween(name, value) {
    var key = "attr." + name;
    if (arguments.length < 2) return (key = this.tween(key)) && key._value;
    if (value == null) return this.tween(key, null);
    if (typeof value !== "function") throw new Error;
    var fullname = namespace(name);
    return this.tween(key, (fullname.local ? attrTweenNS : attrTween)(fullname, value));
  }

  function delayFunction(id, value) {
    return function() {
      init(this, id).delay = +value.apply(this, arguments);
    };
  }

  function delayConstant(id, value) {
    return value = +value, function() {
      init(this, id).delay = value;
    };
  }

  function transition_delay(value) {
    var id = this._id;

    return arguments.length
        ? this.each((typeof value === "function"
            ? delayFunction
            : delayConstant)(id, value))
        : get(this.node(), id).delay;
  }

  function durationFunction(id, value) {
    return function() {
      set(this, id).duration = +value.apply(this, arguments);
    };
  }

  function durationConstant(id, value) {
    return value = +value, function() {
      set(this, id).duration = value;
    };
  }

  function transition_duration(value) {
    var id = this._id;

    return arguments.length
        ? this.each((typeof value === "function"
            ? durationFunction
            : durationConstant)(id, value))
        : get(this.node(), id).duration;
  }

  function easeConstant(id, value) {
    if (typeof value !== "function") throw new Error;
    return function() {
      set(this, id).ease = value;
    };
  }

  function transition_ease(value) {
    var id = this._id;

    return arguments.length
        ? this.each(easeConstant(id, value))
        : get(this.node(), id).ease;
  }

  function easeVarying(id, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (typeof v !== "function") throw new Error;
      set(this, id).ease = v;
    };
  }

  function transition_easeVarying(value) {
    if (typeof value !== "function") throw new Error;
    return this.each(easeVarying(this._id, value));
  }

  function transition_filter(match) {
    if (typeof match !== "function") match = matcher(match);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = [], node, i = 0; i < n; ++i) {
        if ((node = group[i]) && match.call(node, node.__data__, i, group)) {
          subgroup.push(node);
        }
      }
    }

    return new Transition(subgroups, this._parents, this._name, this._id);
  }

  function transition_merge(transition) {
    if (transition._id !== this._id) throw new Error;

    for (var groups0 = this._groups, groups1 = transition._groups, m0 = groups0.length, m1 = groups1.length, m = Math.min(m0, m1), merges = new Array(m0), j = 0; j < m; ++j) {
      for (var group0 = groups0[j], group1 = groups1[j], n = group0.length, merge = merges[j] = new Array(n), node, i = 0; i < n; ++i) {
        if (node = group0[i] || group1[i]) {
          merge[i] = node;
        }
      }
    }

    for (; j < m0; ++j) {
      merges[j] = groups0[j];
    }

    return new Transition(merges, this._parents, this._name, this._id);
  }

  function start(name) {
    return (name + "").trim().split(/^|\s+/).every(function(t) {
      var i = t.indexOf(".");
      if (i >= 0) t = t.slice(0, i);
      return !t || t === "start";
    });
  }

  function onFunction(id, name, listener) {
    var on0, on1, sit = start(name) ? init : set;
    return function() {
      var schedule = sit(this, id),
          on = schedule.on;

      // If this node shared a dispatch with the previous node,
      // just assign the updated shared dispatch and we’re done!
      // Otherwise, copy-on-write.
      if (on !== on0) (on1 = (on0 = on).copy()).on(name, listener);

      schedule.on = on1;
    };
  }

  function transition_on(name, listener) {
    var id = this._id;

    return arguments.length < 2
        ? get(this.node(), id).on.on(name)
        : this.each(onFunction(id, name, listener));
  }

  function removeFunction(id) {
    return function() {
      var parent = this.parentNode;
      for (var i in this.__transition) if (+i !== id) return;
      if (parent) parent.removeChild(this);
    };
  }

  function transition_remove() {
    return this.on("end.remove", removeFunction(this._id));
  }

  function transition_select(select) {
    var name = this._name,
        id = this._id;

    if (typeof select !== "function") select = selector(select);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = new Array(n), node, subnode, i = 0; i < n; ++i) {
        if ((node = group[i]) && (subnode = select.call(node, node.__data__, i, group))) {
          if ("__data__" in node) subnode.__data__ = node.__data__;
          subgroup[i] = subnode;
          schedule(subgroup[i], name, id, i, subgroup, get(node, id));
        }
      }
    }

    return new Transition(subgroups, this._parents, name, id);
  }

  function transition_selectAll(select) {
    var name = this._name,
        id = this._id;

    if (typeof select !== "function") select = selectorAll(select);

    for (var groups = this._groups, m = groups.length, subgroups = [], parents = [], j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          for (var children = select.call(node, node.__data__, i, group), child, inherit = get(node, id), k = 0, l = children.length; k < l; ++k) {
            if (child = children[k]) {
              schedule(child, name, id, k, children, inherit);
            }
          }
          subgroups.push(children);
          parents.push(node);
        }
      }
    }

    return new Transition(subgroups, parents, name, id);
  }

  var Selection = selection.prototype.constructor;

  function transition_selection() {
    return new Selection(this._groups, this._parents);
  }

  function styleNull(name, interpolate) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0 = styleValue(this, name),
          string1 = (this.style.removeProperty(name), styleValue(this, name));
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, string10 = string1);
    };
  }

  function styleRemove(name) {
    return function() {
      this.style.removeProperty(name);
    };
  }

  function styleConstant(name, interpolate, value1) {
    var string00,
        string1 = value1 + "",
        interpolate0;
    return function() {
      var string0 = styleValue(this, name);
      return string0 === string1 ? null
          : string0 === string00 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, value1);
    };
  }

  function styleFunction(name, interpolate, value) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0 = styleValue(this, name),
          value1 = value(this),
          string1 = value1 + "";
      if (value1 == null) string1 = value1 = (this.style.removeProperty(name), styleValue(this, name));
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : (string10 = string1, interpolate0 = interpolate(string00 = string0, value1));
    };
  }

  function styleMaybeRemove(id, name) {
    var on0, on1, listener0, key = "style." + name, event = "end." + key, remove;
    return function() {
      var schedule = set(this, id),
          on = schedule.on,
          listener = schedule.value[key] == null ? remove || (remove = styleRemove(name)) : undefined;

      // If this node shared a dispatch with the previous node,
      // just assign the updated shared dispatch and we’re done!
      // Otherwise, copy-on-write.
      if (on !== on0 || listener0 !== listener) (on1 = (on0 = on).copy()).on(event, listener0 = listener);

      schedule.on = on1;
    };
  }

  function transition_style(name, value, priority) {
    var i = (name += "") === "transform" ? interpolateTransformCss : interpolate;
    return value == null ? this
        .styleTween(name, styleNull(name, i))
        .on("end.style." + name, styleRemove(name))
      : typeof value === "function" ? this
        .styleTween(name, styleFunction(name, i, tweenValue(this, "style." + name, value)))
        .each(styleMaybeRemove(this._id, name))
      : this
        .styleTween(name, styleConstant(name, i, value), priority)
        .on("end.style." + name, null);
  }

  function styleInterpolate(name, i, priority) {
    return function(t) {
      this.style.setProperty(name, i.call(this, t), priority);
    };
  }

  function styleTween(name, value, priority) {
    var t, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t = (i0 = i) && styleInterpolate(name, i, priority);
      return t;
    }
    tween._value = value;
    return tween;
  }

  function transition_styleTween(name, value, priority) {
    var key = "style." + (name += "");
    if (arguments.length < 2) return (key = this.tween(key)) && key._value;
    if (value == null) return this.tween(key, null);
    if (typeof value !== "function") throw new Error;
    return this.tween(key, styleTween(name, value, priority == null ? "" : priority));
  }

  function textConstant(value) {
    return function() {
      this.textContent = value;
    };
  }

  function textFunction(value) {
    return function() {
      var value1 = value(this);
      this.textContent = value1 == null ? "" : value1;
    };
  }

  function transition_text(value) {
    return this.tween("text", typeof value === "function"
        ? textFunction(tweenValue(this, "text", value))
        : textConstant(value == null ? "" : value + ""));
  }

  function textInterpolate(i) {
    return function(t) {
      this.textContent = i.call(this, t);
    };
  }

  function textTween(value) {
    var t0, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t0 = (i0 = i) && textInterpolate(i);
      return t0;
    }
    tween._value = value;
    return tween;
  }

  function transition_textTween(value) {
    var key = "text";
    if (arguments.length < 1) return (key = this.tween(key)) && key._value;
    if (value == null) return this.tween(key, null);
    if (typeof value !== "function") throw new Error;
    return this.tween(key, textTween(value));
  }

  function transition_transition() {
    var name = this._name,
        id0 = this._id,
        id1 = newId();

    for (var groups = this._groups, m = groups.length, j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          var inherit = get(node, id0);
          schedule(node, name, id1, i, group, {
            time: inherit.time + inherit.delay + inherit.duration,
            delay: 0,
            duration: inherit.duration,
            ease: inherit.ease
          });
        }
      }
    }

    return new Transition(groups, this._parents, name, id1);
  }

  function transition_end() {
    var on0, on1, that = this, id = that._id, size = that.size();
    return new Promise(function(resolve, reject) {
      var cancel = {value: reject},
          end = {value: function() { if (--size === 0) resolve(); }};

      that.each(function() {
        var schedule = set(this, id),
            on = schedule.on;

        // If this node shared a dispatch with the previous node,
        // just assign the updated shared dispatch and we’re done!
        // Otherwise, copy-on-write.
        if (on !== on0) {
          on1 = (on0 = on).copy();
          on1._.cancel.push(cancel);
          on1._.interrupt.push(cancel);
          on1._.end.push(end);
        }

        schedule.on = on1;
      });

      // The selection was empty, resolve end immediately
      if (size === 0) resolve();
    });
  }

  var id = 0;

  function Transition(groups, parents, name, id) {
    this._groups = groups;
    this._parents = parents;
    this._name = name;
    this._id = id;
  }

  function newId() {
    return ++id;
  }

  var selection_prototype = selection.prototype;

  Transition.prototype = {
    constructor: Transition,
    select: transition_select,
    selectAll: transition_selectAll,
    selectChild: selection_prototype.selectChild,
    selectChildren: selection_prototype.selectChildren,
    filter: transition_filter,
    merge: transition_merge,
    selection: transition_selection,
    transition: transition_transition,
    call: selection_prototype.call,
    nodes: selection_prototype.nodes,
    node: selection_prototype.node,
    size: selection_prototype.size,
    empty: selection_prototype.empty,
    each: selection_prototype.each,
    on: transition_on,
    attr: transition_attr,
    attrTween: transition_attrTween,
    style: transition_style,
    styleTween: transition_styleTween,
    text: transition_text,
    textTween: transition_textTween,
    remove: transition_remove,
    tween: transition_tween,
    delay: transition_delay,
    duration: transition_duration,
    ease: transition_ease,
    easeVarying: transition_easeVarying,
    end: transition_end,
    [Symbol.iterator]: selection_prototype[Symbol.iterator]
  };

  function cubicInOut(t) {
    return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2;
  }

  var defaultTiming = {
    time: null, // Set on use.
    delay: 0,
    duration: 250,
    ease: cubicInOut
  };

  function inherit(node, id) {
    var timing;
    while (!(timing = node.__transition) || !(timing = timing[id])) {
      if (!(node = node.parentNode)) {
        throw new Error(`transition ${id} not found`);
      }
    }
    return timing;
  }

  function selection_transition(name) {
    var id,
        timing;

    if (name instanceof Transition) {
      id = name._id, name = name._name;
    } else {
      id = newId(), (timing = defaultTiming).time = now(), name = name == null ? null : name + "";
    }

    for (var groups = this._groups, m = groups.length, j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          schedule(node, name, id, i, group, timing || inherit(node, id));
        }
      }
    }

    return new Transition(groups, this._parents, name, id);
  }

  selection.prototype.interrupt = selection_interrupt;
  selection.prototype.transition = selection_transition;

  function tree_add(d) {
    const x = +this._x.call(null, d),
        y = +this._y.call(null, d);
    return add(this.cover(x, y), x, y, d);
  }

  function add(tree, x, y, d) {
    if (isNaN(x) || isNaN(y)) return tree; // ignore invalid points

    var parent,
        node = tree._root,
        leaf = {data: d},
        x0 = tree._x0,
        y0 = tree._y0,
        x1 = tree._x1,
        y1 = tree._y1,
        xm,
        ym,
        xp,
        yp,
        right,
        bottom,
        i,
        j;

    // If the tree is empty, initialize the root as a leaf.
    if (!node) return tree._root = leaf, tree;

    // Find the existing leaf for the new point, or add it.
    while (node.length) {
      if (right = x >= (xm = (x0 + x1) / 2)) x0 = xm; else x1 = xm;
      if (bottom = y >= (ym = (y0 + y1) / 2)) y0 = ym; else y1 = ym;
      if (parent = node, !(node = node[i = bottom << 1 | right])) return parent[i] = leaf, tree;
    }

    // Is the new point is exactly coincident with the existing point?
    xp = +tree._x.call(null, node.data);
    yp = +tree._y.call(null, node.data);
    if (x === xp && y === yp) return leaf.next = node, parent ? parent[i] = leaf : tree._root = leaf, tree;

    // Otherwise, split the leaf node until the old and new point are separated.
    do {
      parent = parent ? parent[i] = new Array(4) : tree._root = new Array(4);
      if (right = x >= (xm = (x0 + x1) / 2)) x0 = xm; else x1 = xm;
      if (bottom = y >= (ym = (y0 + y1) / 2)) y0 = ym; else y1 = ym;
    } while ((i = bottom << 1 | right) === (j = (yp >= ym) << 1 | (xp >= xm)));
    return parent[j] = node, parent[i] = leaf, tree;
  }

  function addAll(data) {
    var d, i, n = data.length,
        x,
        y,
        xz = new Array(n),
        yz = new Array(n),
        x0 = Infinity,
        y0 = Infinity,
        x1 = -Infinity,
        y1 = -Infinity;

    // Compute the points and their extent.
    for (i = 0; i < n; ++i) {
      if (isNaN(x = +this._x.call(null, d = data[i])) || isNaN(y = +this._y.call(null, d))) continue;
      xz[i] = x;
      yz[i] = y;
      if (x < x0) x0 = x;
      if (x > x1) x1 = x;
      if (y < y0) y0 = y;
      if (y > y1) y1 = y;
    }

    // If there were no (valid) points, abort.
    if (x0 > x1 || y0 > y1) return this;

    // Expand the tree to cover the new points.
    this.cover(x0, y0).cover(x1, y1);

    // Add the new points.
    for (i = 0; i < n; ++i) {
      add(this, xz[i], yz[i], data[i]);
    }

    return this;
  }

  function tree_cover(x, y) {
    if (isNaN(x = +x) || isNaN(y = +y)) return this; // ignore invalid points

    var x0 = this._x0,
        y0 = this._y0,
        x1 = this._x1,
        y1 = this._y1;

    // If the quadtree has no extent, initialize them.
    // Integer extent are necessary so that if we later double the extent,
    // the existing quadrant boundaries don’t change due to floating point error!
    if (isNaN(x0)) {
      x1 = (x0 = Math.floor(x)) + 1;
      y1 = (y0 = Math.floor(y)) + 1;
    }

    // Otherwise, double repeatedly to cover.
    else {
      var z = x1 - x0 || 1,
          node = this._root,
          parent,
          i;

      while (x0 > x || x >= x1 || y0 > y || y >= y1) {
        i = (y < y0) << 1 | (x < x0);
        parent = new Array(4), parent[i] = node, node = parent, z *= 2;
        switch (i) {
          case 0: x1 = x0 + z, y1 = y0 + z; break;
          case 1: x0 = x1 - z, y1 = y0 + z; break;
          case 2: x1 = x0 + z, y0 = y1 - z; break;
          case 3: x0 = x1 - z, y0 = y1 - z; break;
        }
      }

      if (this._root && this._root.length) this._root = node;
    }

    this._x0 = x0;
    this._y0 = y0;
    this._x1 = x1;
    this._y1 = y1;
    return this;
  }

  function tree_data() {
    var data = [];
    this.visit(function(node) {
      if (!node.length) do data.push(node.data); while (node = node.next)
    });
    return data;
  }

  function tree_extent(_) {
    return arguments.length
        ? this.cover(+_[0][0], +_[0][1]).cover(+_[1][0], +_[1][1])
        : isNaN(this._x0) ? undefined : [[this._x0, this._y0], [this._x1, this._y1]];
  }

  function Quad(node, x0, y0, x1, y1) {
    this.node = node;
    this.x0 = x0;
    this.y0 = y0;
    this.x1 = x1;
    this.y1 = y1;
  }

  function tree_find(x, y, radius) {
    var data,
        x0 = this._x0,
        y0 = this._y0,
        x1,
        y1,
        x2,
        y2,
        x3 = this._x1,
        y3 = this._y1,
        quads = [],
        node = this._root,
        q,
        i;

    if (node) quads.push(new Quad(node, x0, y0, x3, y3));
    if (radius == null) radius = Infinity;
    else {
      x0 = x - radius, y0 = y - radius;
      x3 = x + radius, y3 = y + radius;
      radius *= radius;
    }

    while (q = quads.pop()) {

      // Stop searching if this quadrant can’t contain a closer node.
      if (!(node = q.node)
          || (x1 = q.x0) > x3
          || (y1 = q.y0) > y3
          || (x2 = q.x1) < x0
          || (y2 = q.y1) < y0) continue;

      // Bisect the current quadrant.
      if (node.length) {
        var xm = (x1 + x2) / 2,
            ym = (y1 + y2) / 2;

        quads.push(
          new Quad(node[3], xm, ym, x2, y2),
          new Quad(node[2], x1, ym, xm, y2),
          new Quad(node[1], xm, y1, x2, ym),
          new Quad(node[0], x1, y1, xm, ym)
        );

        // Visit the closest quadrant first.
        if (i = (y >= ym) << 1 | (x >= xm)) {
          q = quads[quads.length - 1];
          quads[quads.length - 1] = quads[quads.length - 1 - i];
          quads[quads.length - 1 - i] = q;
        }
      }

      // Visit this point. (Visiting coincident points isn’t necessary!)
      else {
        var dx = x - +this._x.call(null, node.data),
            dy = y - +this._y.call(null, node.data),
            d2 = dx * dx + dy * dy;
        if (d2 < radius) {
          var d = Math.sqrt(radius = d2);
          x0 = x - d, y0 = y - d;
          x3 = x + d, y3 = y + d;
          data = node.data;
        }
      }
    }

    return data;
  }

  function tree_remove(d) {
    if (isNaN(x = +this._x.call(null, d)) || isNaN(y = +this._y.call(null, d))) return this; // ignore invalid points

    var parent,
        node = this._root,
        retainer,
        previous,
        next,
        x0 = this._x0,
        y0 = this._y0,
        x1 = this._x1,
        y1 = this._y1,
        x,
        y,
        xm,
        ym,
        right,
        bottom,
        i,
        j;

    // If the tree is empty, initialize the root as a leaf.
    if (!node) return this;

    // Find the leaf node for the point.
    // While descending, also retain the deepest parent with a non-removed sibling.
    if (node.length) while (true) {
      if (right = x >= (xm = (x0 + x1) / 2)) x0 = xm; else x1 = xm;
      if (bottom = y >= (ym = (y0 + y1) / 2)) y0 = ym; else y1 = ym;
      if (!(parent = node, node = node[i = bottom << 1 | right])) return this;
      if (!node.length) break;
      if (parent[(i + 1) & 3] || parent[(i + 2) & 3] || parent[(i + 3) & 3]) retainer = parent, j = i;
    }

    // Find the point to remove.
    while (node.data !== d) if (!(previous = node, node = node.next)) return this;
    if (next = node.next) delete node.next;

    // If there are multiple coincident points, remove just the point.
    if (previous) return (next ? previous.next = next : delete previous.next), this;

    // If this is the root point, remove it.
    if (!parent) return this._root = next, this;

    // Remove this leaf.
    next ? parent[i] = next : delete parent[i];

    // If the parent now contains exactly one leaf, collapse superfluous parents.
    if ((node = parent[0] || parent[1] || parent[2] || parent[3])
        && node === (parent[3] || parent[2] || parent[1] || parent[0])
        && !node.length) {
      if (retainer) retainer[j] = node;
      else this._root = node;
    }

    return this;
  }

  function removeAll(data) {
    for (var i = 0, n = data.length; i < n; ++i) this.remove(data[i]);
    return this;
  }

  function tree_root() {
    return this._root;
  }

  function tree_size() {
    var size = 0;
    this.visit(function(node) {
      if (!node.length) do ++size; while (node = node.next)
    });
    return size;
  }

  function tree_visit(callback) {
    var quads = [], q, node = this._root, child, x0, y0, x1, y1;
    if (node) quads.push(new Quad(node, this._x0, this._y0, this._x1, this._y1));
    while (q = quads.pop()) {
      if (!callback(node = q.node, x0 = q.x0, y0 = q.y0, x1 = q.x1, y1 = q.y1) && node.length) {
        var xm = (x0 + x1) / 2, ym = (y0 + y1) / 2;
        if (child = node[3]) quads.push(new Quad(child, xm, ym, x1, y1));
        if (child = node[2]) quads.push(new Quad(child, x0, ym, xm, y1));
        if (child = node[1]) quads.push(new Quad(child, xm, y0, x1, ym));
        if (child = node[0]) quads.push(new Quad(child, x0, y0, xm, ym));
      }
    }
    return this;
  }

  function tree_visitAfter(callback) {
    var quads = [], next = [], q;
    if (this._root) quads.push(new Quad(this._root, this._x0, this._y0, this._x1, this._y1));
    while (q = quads.pop()) {
      var node = q.node;
      if (node.length) {
        var child, x0 = q.x0, y0 = q.y0, x1 = q.x1, y1 = q.y1, xm = (x0 + x1) / 2, ym = (y0 + y1) / 2;
        if (child = node[0]) quads.push(new Quad(child, x0, y0, xm, ym));
        if (child = node[1]) quads.push(new Quad(child, xm, y0, x1, ym));
        if (child = node[2]) quads.push(new Quad(child, x0, ym, xm, y1));
        if (child = node[3]) quads.push(new Quad(child, xm, ym, x1, y1));
      }
      next.push(q);
    }
    while (q = next.pop()) {
      callback(q.node, q.x0, q.y0, q.x1, q.y1);
    }
    return this;
  }

  function defaultX(d) {
    return d[0];
  }

  function tree_x(_) {
    return arguments.length ? (this._x = _, this) : this._x;
  }

  function defaultY(d) {
    return d[1];
  }

  function tree_y(_) {
    return arguments.length ? (this._y = _, this) : this._y;
  }

  function quadtree(nodes, x, y) {
    var tree = new Quadtree(x == null ? defaultX : x, y == null ? defaultY : y, NaN, NaN, NaN, NaN);
    return nodes == null ? tree : tree.addAll(nodes);
  }

  function Quadtree(x, y, x0, y0, x1, y1) {
    this._x = x;
    this._y = y;
    this._x0 = x0;
    this._y0 = y0;
    this._x1 = x1;
    this._y1 = y1;
    this._root = undefined;
  }

  function leaf_copy(leaf) {
    var copy = {data: leaf.data}, next = copy;
    while (leaf = leaf.next) next = next.next = {data: leaf.data};
    return copy;
  }

  var treeProto = quadtree.prototype = Quadtree.prototype;

  treeProto.copy = function() {
    var copy = new Quadtree(this._x, this._y, this._x0, this._y0, this._x1, this._y1),
        node = this._root,
        nodes,
        child;

    if (!node) return copy;

    if (!node.length) return copy._root = leaf_copy(node), copy;

    nodes = [{source: node, target: copy._root = new Array(4)}];
    while (node = nodes.pop()) {
      for (var i = 0; i < 4; ++i) {
        if (child = node.source[i]) {
          if (child.length) nodes.push({source: child, target: node.target[i] = new Array(4)});
          else node.target[i] = leaf_copy(child);
        }
      }
    }

    return copy;
  };

  treeProto.add = tree_add;
  treeProto.addAll = addAll;
  treeProto.cover = tree_cover;
  treeProto.data = tree_data;
  treeProto.extent = tree_extent;
  treeProto.find = tree_find;
  treeProto.remove = tree_remove;
  treeProto.removeAll = removeAll;
  treeProto.root = tree_root;
  treeProto.size = tree_size;
  treeProto.visit = tree_visit;
  treeProto.visitAfter = tree_visitAfter;
  treeProto.x = tree_x;
  treeProto.y = tree_y;

  function initRange(domain, range) {
    switch (arguments.length) {
      case 0: break;
      case 1: this.range(domain); break;
      default: this.range(range).domain(domain); break;
    }
    return this;
  }

  const implicit = Symbol("implicit");

  function ordinal() {
    var index = new InternMap(),
        domain = [],
        range = [],
        unknown = implicit;

    function scale(d) {
      let i = index.get(d);
      if (i === undefined) {
        if (unknown !== implicit) return unknown;
        index.set(d, i = domain.push(d) - 1);
      }
      return range[i % range.length];
    }

    scale.domain = function(_) {
      if (!arguments.length) return domain.slice();
      domain = [], index = new InternMap();
      for (const value of _) {
        if (index.has(value)) continue;
        index.set(value, domain.push(value) - 1);
      }
      return scale;
    };

    scale.range = function(_) {
      return arguments.length ? (range = Array.from(_), scale) : range.slice();
    };

    scale.unknown = function(_) {
      return arguments.length ? (unknown = _, scale) : unknown;
    };

    scale.copy = function() {
      return ordinal(domain, range).unknown(unknown);
    };

    initRange.apply(scale, arguments);

    return scale;
  }

  function band() {
    var scale = ordinal().unknown(undefined),
        domain = scale.domain,
        ordinalRange = scale.range,
        r0 = 0,
        r1 = 1,
        step,
        bandwidth,
        round = false,
        paddingInner = 0,
        paddingOuter = 0,
        align = 0.5;

    delete scale.unknown;

    function rescale() {
      var n = domain().length,
          reverse = r1 < r0,
          start = reverse ? r1 : r0,
          stop = reverse ? r0 : r1;
      step = (stop - start) / Math.max(1, n - paddingInner + paddingOuter * 2);
      if (round) step = Math.floor(step);
      start += (stop - start - step * (n - paddingInner)) * align;
      bandwidth = step * (1 - paddingInner);
      if (round) start = Math.round(start), bandwidth = Math.round(bandwidth);
      var values = range(n).map(function(i) { return start + step * i; });
      return ordinalRange(reverse ? values.reverse() : values);
    }

    scale.domain = function(_) {
      return arguments.length ? (domain(_), rescale()) : domain();
    };

    scale.range = function(_) {
      return arguments.length ? ([r0, r1] = _, r0 = +r0, r1 = +r1, rescale()) : [r0, r1];
    };

    scale.rangeRound = function(_) {
      return [r0, r1] = _, r0 = +r0, r1 = +r1, round = true, rescale();
    };

    scale.bandwidth = function() {
      return bandwidth;
    };

    scale.step = function() {
      return step;
    };

    scale.round = function(_) {
      return arguments.length ? (round = !!_, rescale()) : round;
    };

    scale.padding = function(_) {
      return arguments.length ? (paddingInner = Math.min(1, paddingOuter = +_), rescale()) : paddingInner;
    };

    scale.paddingInner = function(_) {
      return arguments.length ? (paddingInner = Math.min(1, _), rescale()) : paddingInner;
    };

    scale.paddingOuter = function(_) {
      return arguments.length ? (paddingOuter = +_, rescale()) : paddingOuter;
    };

    scale.align = function(_) {
      return arguments.length ? (align = Math.max(0, Math.min(1, _)), rescale()) : align;
    };

    scale.copy = function() {
      return band(domain(), [r0, r1])
          .round(round)
          .paddingInner(paddingInner)
          .paddingOuter(paddingOuter)
          .align(align);
    };

    return initRange.apply(rescale(), arguments);
  }

  // Licensed Materials - Property of IBM

  function _typeof(obj) {
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof = function (obj) {
        return typeof obj;
      };
    } else {
      _typeof = function (obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };
    }

    return _typeof(obj);
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  var LabelLayoutMode = Object.freeze({
    Automode: "automatic",
    Horizontal: "horizontal",
    Rotate90: "rotate90",
    Rotate45: "rotate45",
    Stagger: "stagger"
  });

  var Orientation = Object.freeze({
    Bottom: "bottom",
    Top: "top",
    Left: "left",
    Right: "right"
  });

  function verifyBounds(_bounds) {
    if (_typeof(_bounds) !== 'object') throw Error("bounds must be an object with width and height property");
    if (_bounds.height === null || _bounds.height === undefined || _bounds.width === null || _bounds.width === undefined) throw Error("bounds must specify height and width");
  }
  function verifyLabelMode(_mode) {
    switch (_mode) {
      case LabelLayoutMode.Automode:
      case LabelLayoutMode.Horizontal:
      case LabelLayoutMode.Rotate45:
      case LabelLayoutMode.Rotate90:
      case LabelLayoutMode.Stagger:
        break;

      default:
        throw Error("Unsupported label layout mode");
    }
  }
  function verifyAxis(_axis) {
    if (!_axis || !_axis.scale || typeof _axis.scale !== "function") throw Error("Unsupported axis");
  }
  function verifyOrientation(_orientation) {
    switch (_orientation) {
      case Orientation.Left:
      case Orientation.Top:
      case Orientation.Right:
      case Orientation.Bottom:
        break;

      default:
        throw Error("Unsupported orientation");
    }
  }

  function calculate45DegreeSpace(_node, _bbox, _orientation, _maxWidth) {
    // - Axis.java: from Axis.axis(g) method ... "Each 'tick' is a group node ... which contains a line (the tick mark)
    //   and a text node (the tick label)."
    // - The incoming node passed here is the text node, to get the x location our text node is displayed at, we lookup
    //   the transform on the parent group node and parse the "translate(x," from it. If anything fails, we return the
    //   incoming maxWidth (length of a 45 degree label that isn't restricted by edge conditions)
    var width = _maxWidth; // consolidate the SVGTransformList containing all transformations
    // to a single SVGTransform of type SVG_TRANSFORM_MATRIX and get
    // its SVGMatrix.

    var matrix = _node.parentNode.transform.baseVal.consolidate().matrix;

    if (matrix) {
      var xLabelPos = matrix.e; // 0.7071 = Math.cos(45)

      var xLabelWidth = _bbox.width * 0.7071;
      var isBottom = _orientation === Orientation.Bottom;

      if (isBottom) {
        // given xLabelPos is baseline, shift slightly to left (want top of text box)
        xLabelPos -= _bbox.height / 4;

        if (xLabelPos - xLabelWidth < 0) {
          xLabelWidth = xLabelPos;
          width = xLabelWidth / 0.7071;
        }
      } // no shift of xLabelPos (as was done for bottom axis), baseline works well for top axis.

      /*if ( xLabelPos + xLabelWidth > bounds.width )
      {
          xLabelWidth = bounds.width - xLabelPos;
          width = xLabelWidth / 0.7071;
      }*/
      // don't make text longer than space available.


      if (width > _maxWidth) width = _maxWidth;
    }

    return Math.abs(width);
  }

  var HORIZONTAL_WEIGHT = 1.1;
  var LabelLayoutCalculator = function LabelLayoutCalculator() {
    // Input needed to do layout.
    var labelBounds, layoutMode, isContinuous, cachedBBoxMap, orientation; // computed output layout values.

    var labelHeight = 0,
        usedSizeForLabels = 0,
        layoutSpillOver = 0;
    var isHorizontal;

    function layout(_textSelection) {
      var cellWidth = labelBounds.width;
      var cellWidth90 = labelBounds.height;
      var horizontalScore = 0;
      var staggerScore = 0;
      var rotate45Score = 0;
      var rotate90Score = 0;
      isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom; // For numeric axis:
      // (1) layout is HORIZONTAL for vertical oriented axis and
      // (2) either HORIZONTAL or ROTATE90 for horizontal oriented axis based on configured _layoutMode.

      if (isContinuous) {
        // _layoutMode can be a bunch of invalid values (categorical axis
        // has more modes), so unless _layoutMode is explicitly
        // ROTATE90, we use HORIZONTAL.
        var _mode2 = LabelLayoutMode.Horizontal;
        if (isHorizontal) _mode2 = layoutMode === LabelLayoutMode.Rotate90 ? LabelLayoutMode.Rotate90 : LabelLayoutMode.Horizontal;
        measureNumericLabel();
        layoutMode = _mode2;
        return _mode2;
      }

      var labelCount = _textSelection.size(); // determine which scores to calculate


      var calcStagger = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Stagger;
      var calcRotate45 = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Rotate45;
      var calcRotate90 = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Rotate90;
      var spaceFor45Label = 0;
      var widestLabel = 0;

      _textSelection.each(function (_data, _index) {
        var labelBounds = cachedBBoxMap.get(_index); // In case of empty label, do not calculate space for each mode, it is zero always.

        if (labelBounds.height > 0 && labelBounds.width > 0) {
          var labelWidth = labelBounds.width;
          if (labelWidth > widestLabel) widestLabel = labelWidth;
          labelHeight = labelBounds.height;
          horizontalScore += labelWidth <= cellWidth ? 1 : cellWidth / labelWidth;

          if (isHorizontal) {
            if (calcStagger) {
              // we don't consider stagger/rotated for left/right axis orientation
              var spaceForLabel = cellWidth * 2; // if only a single label, half normal stagger space

              if (_index === 0 && _index === labelCount - 1) spaceForLabel *= 0.5; // first and last label only get 3/4 normal stagger space
              else if (_index === 0 || _index === labelCount - 1) spaceForLabel *= 0.75;
              staggerScore += labelWidth <= spaceForLabel ? 1 : spaceForLabel / labelWidth;
            }

            if (calcRotate45) {
              // vertical space for 90 degree rotated label is 'cellWidth90'
              // height of tick label is 'labelHeight'
              // longest label at 45 degree rotation is cellWidth90 / Math.cos(45) - labelHeight
              // 0.7071 = Math.cos(45)
              if (spaceFor45Label === 0) spaceFor45Label = cellWidth90 / 0.7071 - labelHeight;
              var space = calculate45DegreeSpace(this, labelBounds, orientation, spaceFor45Label);
              rotate45Score += labelWidth <= space ? 1 : space / labelWidth;
            }

            if (calcRotate90) {
              rotate90Score += labelWidth <= cellWidth90 ? 1 : cellWidth90 / labelWidth;
            }
          }
        }
      });

      var mode = LabelLayoutMode.Horizontal;

      if (layoutMode === LabelLayoutMode.Automode) {
        // Product Management has decided that it is better to truncate a little with horizontal label orientation
        // than to show text rotated with no truncation, so bump up scores if stagger is allowed
        if (isHorizontal) {
          horizontalScore *= HORIZONTAL_WEIGHT;
          staggerScore *= HORIZONTAL_WEIGHT;
        } // determine the winner (highest score), mode is initialized to HORIZONTAL


        if (staggerScore > horizontalScore && staggerScore >= rotate45Score && staggerScore >= rotate90Score) mode = LabelLayoutMode.Stagger;else if (rotate45Score > horizontalScore && rotate45Score >= rotate90Score) mode = LabelLayoutMode.Rotate45;else if (rotate90Score > horizontalScore) mode = LabelLayoutMode.Rotate90;
      } else {
        if (!isHorizontal) mode = LabelLayoutMode.Horizontal;else mode = layoutMode; // forced to one of HORIZONTAL, STAGGER, ROTATE45 or ROTATE90
      }

      if (isHorizontal) {
        switch (mode) {
          case LabelLayoutMode.Stagger:
            usedSizeForLabels = labelHeight * 2;
            break;

          case LabelLayoutMode.Rotate45:
            // 0.7071 = Math.cos(45)
            usedSizeForLabels = (widestLabel + labelHeight) * 0.7071;
            break;

          case LabelLayoutMode.Rotate90:
            usedSizeForLabels = widestLabel;
            break;

          case LabelLayoutMode.Horizontal:
          default:
            usedSizeForLabels = labelHeight;
            break;
        }
      } else {
        usedSizeForLabels = widestLabel;
        layoutSpillOver = labelHeight / 2;
      }

      layoutMode = mode;
      return mode;
    }

    layout.labelBounds = function (_bounds) {
      labelBounds = _bounds;
      return layout;
    };

    layout.cachedBBoxMap = function (_map) {
      cachedBBoxMap = _map;
      return layout;
    };

    layout.layoutMode = function (_mode) {
      if (_mode !== null && _mode !== undefined) {
        layoutMode = _mode;
        return layout;
      } else {
        return layoutMode;
      }
    };

    layout.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return layout;
    };

    layout.isContinuousAxis = function (_isContinuos) {
      isContinuous = _isContinuos;
      return layout;
    };

    layout.labelHeight = function () {
      return labelHeight;
    };

    layout.usedSizeForLabels = function () {
      return usedSizeForLabels;
    };

    layout.layoutSpillOver = function () {
      return layoutSpillOver;
    };

    function measureNumericLabel() {
      layoutSpillOver = 0;
      labelHeight = 0;
      var widestLabel = 0;

      for (var index = 0; index < cachedBBoxMap.size; index++) {
        if (cachedBBoxMap.get(index).width > widestLabel) widestLabel = cachedBBoxMap.get(index).width;
        if (cachedBBoxMap.get(index).height > labelHeight) labelHeight = cachedBBoxMap.get(index).height;
      }

      if (isHorizontal) {
        layoutSpillOver = layoutMode === LabelLayoutMode.Rotate90 ? labelHeight / 2 : widestLabel / 2 + 2;
        usedSizeForLabels = layoutMode === LabelLayoutMode.Rotate90 ? widestLabel : labelHeight;
      } else {
        layoutSpillOver = labelHeight / 2;
        usedSizeForLabels = widestLabel;
      }
    }

    return layout;
  };

  var LabelAnchor = function LabelAnchor() {
    var mode, orientation;

    function anchor(_textSelection) {
      var isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom;
      var anchorVal;

      if (mode === LabelLayoutMode.Rotate45 || mode === LabelLayoutMode.Rotate90) {
        if (isHorizontal) {
          if (orientation === Orientation.Bottom) anchorVal = "end";else if (orientation === Orientation.Top) anchorVal = "start";else anchorVal = "middle";
        }
      } else {
        if (isHorizontal) anchorVal = "middle";else if (orientation === Orientation.Right) anchorVal = "start";else anchorVal = "end";
      }

      _textSelection.style("text-anchor", anchorVal);
    }

    anchor.labelMode = function (_mode) {
      mode = _mode;
      return anchor;
    };

    anchor.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return anchor;
    };

    return anchor;
  };

  var LabelTransform = function LabelTransform() {
    var mode, orientation, cachedBBoxMap;

    function transform(_textSelection) {
      var isBottom = orientation === Orientation.Bottom;

      _textSelection.attr("transform", function (_data, _index, _grouIndex) {
        var bbox = cachedBBoxMap.get(_index);
        var x = 0;
        var y = 0;
        var rotation_cy = 0; // if stagger, every other label is on the second line
        // adjust x for first / last if not doing 'middle' alignment

        if (mode === LabelLayoutMode.Stagger) {
          if (_index % 2 === 1) {
            var staggerDirection = isBottom ? 1 : -1;
            y += bbox.height * staggerDirection;
          }
        } // if rotate 45 degrees, shift x position


        if (mode === LabelLayoutMode.Rotate45) {
          if (isBottom) x -= bbox.height;else x += bbox.height / 2;
        } // if rotate 90 degrees, shift x position.
        else if (mode === LabelLayoutMode.Rotate90) {
            if (isBottom) {
              // assumption is height * 1/4 is descent
              x -= cachedBBoxMap.get(_index).height * 1 / 4; // space to move away from axis

              rotation_cy = 10;
            } else {
              x += cachedBBoxMap.get(_index).height / 2; // space to move away from axis

              rotation_cy = -10;
            }
          }

        var rotationDegrees = mode === LabelLayoutMode.Rotate90 ? -90 : mode === LabelLayoutMode.Rotate45 ? -45 : 0;
        return "translate(" + x + "," + y + ") rotate(" + rotationDegrees + ",0," + rotation_cy + ")";
      });
    }

    transform.labelMode = function (_mode) {
      mode = _mode;
      return transform;
    };

    transform.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return transform;
    };

    transform.cachedBBoxMap = function (_map) {
      cachedBBoxMap = _map;
      return transform;
    };

    return transform;
  };

  /**
   * Set font to a struct of the following 6 properties: font-style
   * font-variant font-weight font-size/line-height font-family. see
   * https://developer.mozilla.org/en-US/docs/Web/CSS/font
   */

  var FontStyleStruct =
  /*#__PURE__*/
  function () {
    function FontStyleStruct(_textNode) {
      _classCallCheck(this, FontStyleStruct);

      var styles = getComputedStyle(_textNode);
      this.fontStyle = styles["font-style"];
      this.fontVariant = styles["font-variant"];
      this.fontWeight = styles["font-weight"];
      this.fontSize = styles["font-size"];
      this.lineHeight = styles["line-height"];
      this.fontFamily = styles["font-family"];
    }

    _createClass(FontStyleStruct, [{
      key: "toString",
      value: function toString() {
        return this.fontStyle.toString() + " " + this.fontVariant.toString() + " " + this.fontWeight.toString() + " " + this.fontSize.toString() + "/" + this.lineHeight.toString() + " " + this.fontFamily.toString();
      }
    }]);

    return FontStyleStruct;
  }();

  var TextData =
  /*#__PURE__*/
  function () {
    function TextData() {
      _classCallCheck(this, TextData);

      /**
      * Lines array
      */
      this.lines = [];
    }
    /**
     * @param line line text string
     */


    _createClass(TextData, [{
      key: "add",
      value: function add(_line) {
        if (_line) this.lines.push(_line);
      }
      /**
       * @return number of lines
       */

    }, {
      key: "length",
      value: function length() {
        return this.lines.length;
      }
    }]);

    return TextData;
  }();

  var Canvas =
  /*#__PURE__*/
  function () {
    function Canvas() {
      _classCallCheck(this, Canvas);
    }

    _createClass(Canvas, null, [{
      key: "create",
      value: function create() {
        if (typeof document !== "undefined") {
          var canvas = document.createElement("canvas");
          return canvas;
        }

        return null;
      }
    }]);

    return Canvas;
  }();

  var LabelWrap = function LabelWrap() {
    var bounds;
    var canvas = Canvas.create();
    var textOverFlow = "...";
    var multiLine = false;

    function wrap(_selection) {
      var height = bounds.height;
      var width = bounds.width; // Read the font style once.
      // Assumption: All axis labels have the same font.

      var fontStyleStruct = new FontStyleStruct(_selection.node());
      var lineHeight = fontStyleStruct.lineHeight || fontStyleStruct.fontSize.value;
      var fontStyle = fontStyleStruct.toString();

      _selection.each(function (_data) {
        var textData = new TextData();
        var n;
        var line = "";
        var space = "";
        var total_height = 0;
        var clipped = false;
        var words = multiLine ? this.textContent.split(' ') : [this.textContent];

        for (n = 0; !clipped && n < words.length && total_height < height; ++n) {
          var testLine = line.concat(space).concat(words[n]);
          space = " ";

          if (_measureText(testLine, fontStyle) > width) {
            // even 1 word could not be wrapped, clip|truncate and exit
            if (_measureText(words[n], fontStyle) > width) {
              // Adds a truncated line to the textData
              textData.add(_truncate(testLine, width, fontStyle)); // If we can't even fit a single ellipse, return immediately

              if (textData.length() <= 0) return; // Otherwise, stop adding lines now

              clipped = true;
              line = "";
            } else {
              textData.add(line); // line could be wider than max width, but if so, it will be truncated.

              line = words[n];
            }

            total_height += lineHeight;
          } else {
            line = testLine;
          }
        } // once we are out we either run out of vertical space or words
        // if we run out of words we have one last line to add
        // we run out of words, add last line if there is anything in it, truncate|clip if needed


        if (n === words.length) {
          if (total_height + lineHeight <= height) {
            // height allows, add last line
            // Don't allow a blank line to be added--it will not change appearance, but
            // it can mess up the flags.
            if (line) textData.add(_truncate(line, width, fontStyle));
          }
        } // now we are back within height bounds
        // step back - remove trailing line to add ellipses and add it back truncated


        var lastAddedLine = "";
        if (textData.length() > 0) lastAddedLine = textData.lines.pop();
        line = lastAddedLine.concat(" ").concat(line);
        textData.add(_truncate(line, width, fontStyle));

        if (textData.length() <= 1) {
          select(this).text(line);
        }
      });
    }

    wrap.bounds = function (_bounds) {
      bounds = _bounds;
      return wrap;
    };

    wrap.multiLine = function (_multiLine) {
      multiLine = _multiLine;
      return wrap;
    };

    function _measureText(_text, _fontStruct) {
      var ctx = canvas.getContext("2d");
      ctx.font = _fontStruct;
      return ctx.measureText(_text).width;
    }

    function _truncate(_text, _width, _fontStruct) {
      // Should optimize by using an educated guess.
      var marker = _text.length;
      var testLine = _text.substring(0, marker) + " ";
      marker = marker + 1;
      var exit = false;

      while (_measureText(testLine.concat(textOverFlow), _fontStruct) > _width && !exit) {
        marker--;

        if (marker <= 0) {
          marker = 0;
          exit = true;
        }

        testLine = testLine.substring(0, marker);
      }

      return testLine.concat(textOverFlow);
    }

    return wrap;
  };

  var DropOverlap = function DropOverlap() {
    var widthRadius = 0;
    var heightRadius = 0;
    var rect;
    var hasCollided = false;

    function drop(_selection) {
      var quadtree$1 = quadtree().x(function (d) {
        return d.x;
      }).y(function (d) {
        return d.y;
      });

      _selection.each(function () {
        rect = this.getBoundingClientRect();
        widthRadius = Math.max(widthRadius, rect.width);
        heightRadius = Math.max(heightRadius, rect.height);
        hasCollided = false;
        quadtree$1.visit(visit);

        if (!hasCollided) {
          quadtree$1.add(rect);
          this.collide = false;
        } else this.collide = true;
      });

      _selection.style("visibility", function () {
        return this.collide ? "hidden" : null;
      });
    }

    function visit(_node, _x1, _y1, _x2, _y2) {
      if (hasCollided) return true;
      if (_node.data === rect) return false; // child node

      if (!_node.length) hasCollided = !(rect.x + rect.width < _node.data.x || _node.data.x + _node.data.width < rect.x || rect.y + rect.height < _node.data.y || _node.data.y + _node.data.height < rect.y);
      return !(rect.x < _x2 + widthRadius && rect.x + rect.width > _x1 - widthRadius && rect.y < _y2 + heightRadius && rect.y + rect.height > _y1 - heightRadius);
    }

    return drop;
  };

  var AxisLabelLayout = function AxisLabelLayout() {
    var bounds, axis;
    var isContinuous, orientation, isHorizontal;
    var labelModeCalculator = LabelLayoutCalculator();
    var labelAnchor = LabelAnchor();
    var labelTransform = LabelTransform();
    var labelWrap = LabelWrap();
    var labelDropOverlap = DropOverlap();
    var cachedBBoxMap = new Map();

    function layout(_selection) {
      cachedBBoxMap.clear();
      var scale = axis.scale();
      isContinuous = !scale.rangeBand && !scale.step;
      isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom;

      var textSelection = _selection.selectAll(".tick text");

      textSelection.each(function (_data, _index) {
        cachedBBoxMap.set(_index, this.getBBox());
      });
      var labelSpace = labelExtent(textSelection);
      labelModeCalculator.labelBounds(labelSpace).isContinuousAxis(isContinuous).cachedBBoxMap(cachedBBoxMap).axisOrientation(orientation);
      textSelection.call(labelModeCalculator);
      labelAnchor.labelMode(labelModeCalculator.layoutMode()).axisOrientation(orientation);
      labelTransform.labelMode(labelModeCalculator.layoutMode()).axisOrientation(orientation).cachedBBoxMap(cachedBBoxMap);
      if (!isContinuous) doLabelWrapping(textSelection, labelSpace);else textSelection.call(labelDropOverlap);
      textSelection.call(labelTransform);
      textSelection.call(labelAnchor);
    }

    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };

    layout.mode = function (_mode) {
      if (_mode) {
        verifyLabelMode(_mode);
        labelModeCalculator.layoutMode(_mode);
        return layout;
      } else {
        return labelModeCalculator.layoutMode();
      }
    };

    layout.axis = function (_axis) {
      verifyAxis(_axis);
      axis = _axis;
      return layout;
    };

    layout.axisOrientation = function (_orientation) {
      verifyOrientation(_orientation);
      orientation = _orientation;
      return layout;
    };

    layout.layoutSpillOver = function () {
      return labelModeCalculator.layoutSpillOver();
    };

    layout.usedSizeForLabels = function () {
      return labelModeCalculator.usedSizeForLabels();
    };

    function labelExtent(_textSelection) {
      var w = bounds.width;
      var h = bounds.height;

      var tickCount = _textSelection.size();

      var range = axis.scale().range();
      var tickSpace = Math.abs(range[range.length - 1] - range[0]) / tickCount; // set w (for top/bottom) or h (for left/right) based on cell size

      if (isHorizontal) w = tickSpace;else h = tickSpace; // reduce space used by ticks, padding and title

      if (isHorizontal) {
        h -= axis.tickSize(); // ticks space always given regardless if they are visible

        h -= axis.tickPadding(); // half the padding goes to labels
      } else {
        w -= axis.tickSize();
        w -= axis.tickPadding();
      }

      return {
        width: w,
        height: h
      };
    }

    function doLabelWrapping(_textSelection, _labelExtent) {
      if (!_labelExtent || _labelExtent.width < 0 || _labelExtent.height < 0) return;
      var mode = labelModeCalculator.layoutMode();
      var w = _labelExtent.width;
      var h = _labelExtent.height;

      if (mode === LabelLayoutMode.Rotate45) {
        w = _labelExtent.height / 0.7071 - labelModeCalculator.labelHeight();
        h = labelModeCalculator.labelHeight() / 0.7071;
      } else if (mode === LabelLayoutMode.Rotate90) {
        var tmp = w;
        w = h;
        h = tmp;
      }

      var cellWidth = w;

      _textSelection.each(function (_data, _index, _groupIndex) {
        var width = cellWidth; // 1.2 magic constant to prevent textFlow removing labels due to height issues.

        if (mode === LabelLayoutMode.Rotate45) {
          width = calculate45DegreeSpace(this, cachedBBoxMap.get(_index), orientation, cellWidth);
        }

        if (mode === LabelLayoutMode.Stagger) {
          width = cellWidth * 2;
        }

        if (cachedBBoxMap.get(_index).width > width) {
          labelWrap.bounds({
            width: width,
            height: h / 2
          });
          select(this).call(labelWrap);
        }
      });
    }

    return layout;
  };

  var AxisProperty =
  /*#__PURE__*/
  function () {
    function AxisProperty() {
      _classCallCheck(this, AxisProperty);

      this._axisTitle = "";
      this._showTitle = true;
      this._showTicks = true;
      this._showTickLabels = true;
      this._showAxisLine = true;
      this._titleFont = {};
      this._tickLabelFont = {};
      this._tickLabelColor = "currentColor";
      this._titleColor = "currentColor";
      this._lineColor = "currentColor";
      this._tickColor = "currentColor";
      this._labelLayoutMode = "automatic";
    }

    _createClass(AxisProperty, [{
      key: "title",
      value: function title(_axisTitle) {
        if (_axisTitle !== null && _axisTitle !== undefined) {
          this._axisTitle = _axisTitle;
          return this;
        }

        return this._axisTitle;
      }
    }, {
      key: "showTitle",
      value: function showTitle(_showTitle) {
        if (_showTitle !== null && _showTitle !== undefined) {
          this._showTitle = _showTitle;
          return this;
        }

        return this._showTitle;
      }
    }, {
      key: "showTicks",
      value: function showTicks(_showTicks) {
        if (_showTicks !== null && _showTicks !== undefined) {
          this._showTicks = _showTicks;
          return this;
        }

        return this._showTicks;
      }
    }, {
      key: "ticksColor",
      value: function ticksColor(_tickColor) {
        if (_tickColor !== null && _tickColor !== undefined) {
          this._tickColor = _tickColor;
          return this;
        }

        return this._tickColor;
      }
    }, {
      key: "showTickLabels",
      value: function showTickLabels(_showTickLabels) {
        if (_showTickLabels !== null && _showTickLabels !== undefined) {
          this._showTickLabels = _showTickLabels;
          return this;
        }

        return this._showTickLabels;
      }
    }, {
      key: "tickLabelMode",
      value: function tickLabelMode(_labelLayoutMode) {
        if (_labelLayoutMode !== null && _labelLayoutMode !== undefined) {
          this._labelLayoutMode = _labelLayoutMode;
          return this;
        }

        return this._labelLayoutMode;
      }
    }, {
      key: "showAxisLine",
      value: function showAxisLine(_showAxisLine) {
        if (_showAxisLine !== null && _showAxisLine !== undefined) {
          this._showAxisLine = _showAxisLine;
          return this;
        }

        return this._showAxisLine;
      }
    }, {
      key: "axisLineColor",
      value: function axisLineColor(_lineColor) {
        if (_lineColor !== null && _lineColor !== undefined) {
          this._lineColor = _lineColor;
          return this;
        }

        return this._lineColor;
      }
    }, {
      key: "tickLabelFont",
      value: function tickLabelFont(_tickLabelFont) {
        if (_tickLabelFont !== null && _tickLabelFont !== undefined) {
          this._tickLabelFont = _tickLabelFont;
          return this;
        }

        return this._tickLabelFont;
      }
    }, {
      key: "tickLabelColor",
      value: function tickLabelColor(_tickLabelColor) {
        if (_tickLabelColor !== null && _tickLabelColor !== undefined) {
          this._tickLabelColor = _tickLabelColor;
          return this;
        }

        return this._tickLabelColor;
      }
    }, {
      key: "titleFont",
      value: function titleFont(_titleFont) {
        if (_titleFont !== null && _titleFont !== undefined) {
          this._titleFont = _titleFont;
          return this;
        }

        return this._titleFont;
      }
    }, {
      key: "titleColor",
      value: function titleColor(_titleColor) {
        if (_titleColor !== null && _titleColor !== undefined) {
          this._titleColor = _titleColor;
          return this;
        }

        return this._titleColor;
      }
    }]);

    return AxisProperty;
  }();

  function applyAxisProperties(_selector, _axisProperty) {
    _selector.selectAll(".tick text").style("visibility", _axisProperty.showTickLabels() ? null : "hidden").attr("fill", _axisProperty.tickLabelColor());

    var styles = _axisProperty.tickLabelFont();

    for (var property in styles) {
      if (styles.hasOwnProperty(property)) {
        _selector.style(property, styles[property]);

        _selector.attr(property, styles[property]);
      }
    }

    _selector.selectAll(".tick line").style("visibility", _axisProperty.showTicks() ? null : "hidden").attr("stroke", _axisProperty.ticksColor());

    _selector.selectAll("path.domain").style("visibility", _axisProperty.showAxisLine() ? null : "hidden").attr("stroke", _axisProperty.axisLineColor());
  }

  var AxisLayout = function AxisLayout() {
    var bounds;
    var axis;
    var axisTitle;
    var orientation;
    var axisTitleHeight = 0;
    var DEFAULT_TICKS_COUNT = 10;
    var axisLabelLayout = AxisLabelLayout();
    var axisProperty = new AxisProperty();

    function layout(_selector) {
      if (bounds.height <= 0 || bounds.width <= 0) return;
      var scale = axis.scale();
      var range = scale.range();
      var axisExtent = Math.abs(range[range.length - 1] - range[0]);
      var labelHeight = 20; // space the ticks at least to have labelHeight between them to avoid collision.

      var isOrdinal = scale.bandwidth || scale.step;

      if (isOrdinal && axisExtent > 0) {
        var maxTickCount = Math.round(axisExtent / (labelHeight + axis.tickPadding()));

        if (scale.domain().length > maxTickCount) {
          var tickSkipCount = Math.round(scale.domain().length / maxTickCount);
          var tickValues = [];
          var domain = scale.domain();

          for (var i = 0; i < domain.length; i = i + tickSkipCount) {
            tickValues.push(domain[i]);
          }

          axis.tickValues(tickValues);
        }
      } else if (axisExtent > 0) {
        if (axisLabelLayout.mode() === LabelLayoutMode.Horizontal) labelHeight = axisLabelLayout.usedSizeForLabels();
        var tickCount = axisExtent / (labelHeight + axis.tickPadding());
        axis.tickArguments([Math.ceil(Math.min(tickCount, DEFAULT_TICKS_COUNT))]);
      }

      _selector.call(axis);

      applyAxisProperties(_selector, axisProperty); // axis path should contains H command for d.

      var isHorizontal = _selector.select(".domain").attr("d").split("H").length === 2;
      var labelPos;

      if (isHorizontal) {
        labelPos = _selector.select(".tick text").attr("y");
        orientation = labelPos > 0 ? Orientation.Bottom : Orientation.Top;
      } else {
        labelPos = _selector.select(".tick text").attr("x");
        orientation = labelPos > 0 ? Orientation.Right : Orientation.Left;
      }

      if (axisProperty.showTickLabels()) {
        axisLabelLayout.bounds(bounds).mode(axisProperty.tickLabelMode()).axis(axis).axisOrientation(orientation);

        _selector.call(axisLabelLayout);
      }

      drawTitle(_selector);
      drawTitle(_selector, true);
    }

    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };

    layout.axis = function (_axis) {
      verifyAxis(_axis);
      axis = _axis;
      return layout;
    };

    layout.axisProperty = function (_axisProperty) {
      axisProperty = _axisProperty;
      return layout;
    };

    layout.getSpillOver = function () {
      return axisLabelLayout.layoutSpillOver();
    };

    layout.getPreferredSize = function () {
      var layoutPaddingSize = 0;
      var usedSizeForLabels = 0; // axis will by null if the chart has no data

      if (axis) {
        layoutPaddingSize = axis.tickSize();
        usedSizeForLabels = axisLabelLayout.usedSizeForLabels();

        if (usedSizeForLabels !== 0) {
          // Add additional breathing space for the title and the labels.
          // Both the labels and the title will get half of the padding size as additional breathing
          // space at the bottom to leave some space there.
          // Since this is two times half of the padding, we will add padding as breathing space.
          layoutPaddingSize += layoutPaddingSize; // Besides the breathing space we need to add an additional 2px for truncation of doubles to
          // ints in textflow calculations.
          // Please note that this is only applicable if there are labels available.

          layoutPaddingSize += 2;
        } else if (axisTitleHeight !== 0) {
          // In this case no ticks / tick labels are shown. Only the title is visible.
          // Add padding as breathing space.
          layoutPaddingSize += layoutPaddingSize;
        }
      }

      return usedSizeForLabels + axisTitleHeight + layoutPaddingSize;
    };

    function drawTitle(_axisSelector, _usePreferredSize) {
      axisTitle = axisProperty.title();

      if (!axisTitle || !axisProperty.showTitle()) {
        _axisSelector.selectAll("text." + orientation).remove();

        axisTitleHeight = 0;
        return;
      } // Origins for each axis location (T for Top, L for Left, R for Right, B for Bottom)
      //
      // -------L-----------R-------        Unrotated axis orientation @ T,B,L,R
      // |      |    Top    |      |
      // T------+-----------+------|         *----x
      // |      |           |      |         |
      // | Left |  Element  | Right|         y
      // |      |           |      |
      //  B------+-----------+-----|
      // |      |   Bottom  |      |
      // ---------------------------


      var x = 0;
      var y = 0;
      var dy = "";
      var transform = null;
      var axisWidth = 0.0;
      var padding = 16;
      if (orientation === Orientation.Top || orientation === Orientation.Bottom) axisWidth = bounds.height;else axisWidth = bounds.width;
      if (_usePreferredSize) axisWidth = Math.min(layout.getPreferredSize(), axisWidth);
      var axisRange = axis.scale().range();
      var extent = Math.abs(axisRange[0] + axisRange[axisRange.length - 1]);

      if (orientation === Orientation.Top) {
        x = extent / 2;
        y = -axisWidth + padding / 4;
        dy = "0.75em"; // assumption is that text is 0.75em above baseline and 0.25em below baseline
      } else if (orientation === Orientation.Bottom) {
        x = extent / 2;
        y = axisWidth - padding / 4;
        dy = "-0.25em";
      } else if (orientation === Orientation.Left) {
        x = -extent / 2; // Rotated axis orientation

        y = -axisWidth + padding / 4;
        dy = "0.75em";
        transform = "rotate(-90)";
      } else {
        x = extent / 2; // Rotated axis orientation

        y = -axisWidth + padding / 4;
        dy = "0.75em";
        transform = "rotate(90)";
      }

      var titleSelector = _axisSelector.selectAll("text." + orientation);

      if (titleSelector.empty()) {
        // There was no title text, so add it using the final attribute values (to avoid transitions from off-screen)
        titleSelector = _axisSelector.append("text").attr("class", orientation).style("text-anchor", "middle");
      }

      titleSelector.attr("x", x).attr("y", y).attr("transform", transform).attr("dy", dy).style("fill", axisProperty.titleColor()).text(axisTitle).each(function (_d) {
        var styles = axisProperty.titleFont();

        for (var property in styles) {
          if (styles.hasOwnProperty(property)) this.style[property] = styles[property];
        }
      });
      if (!_usePreferredSize) axisTitleHeight = titleSelector.node().getBBox().height;
    }

    return layout;
  };

  function copyRect(_rect) {
    return {
      x: _rect.x || 0,
      y: _rect.y || 0,
      width: _rect.width,
      height: _rect.height
    };
  }

  var ChartLayoutComponent =
  /*#__PURE__*/
  function () {
    function ChartLayoutComponent() {
      _classCallCheck(this, ChartLayoutComponent);

      this._axisSizable = new Map();
      this._orientationMap = new Map();
    }

    _createClass(ChartLayoutComponent, [{
      key: "chartRect",
      value: function chartRect(_chartBounds) {
        this._chartRect = copyRect(_chartBounds);
        this._elementRect = copyRect(_chartBounds);
      }
    }, {
      key: "add",
      value: function add(_orientation, _axisLabelComp) {
        this._axisSizable.set(_orientation, _axisLabelComp);
      }
    }, {
      key: "getRect",
      value: function getRect(_orientation) {
        return this._orientationMap.get(_orientation);
      }
    }, {
      key: "elementRect",
      value: function elementRect() {
        return this._elementRect;
      }
    }, {
      key: "layout",
      value: function layout() {
        var _this = this;

        if (this._chartRect.width <= 0 || this._chartRect.height <= 0) {
          this._elementRect = copyRect(this._chartRect);

          this._orientationMap.set(Orientation.Left, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });

          this._orientationMap.set(Orientation.Right, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });

          this._orientationMap.set(Orientation.Top, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });

          this._orientationMap.set(Orientation.Bottom, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });
        } else {
          var bottomH = 0;
          var topH = 0;
          var leftW = 0;
          var rightW = 0;
          var tbSO = 0; // top-bottom spill over: amount y1,y2 axes need above and below of the element rectangle

          var lrSO = 0; // left-right spill over: amount x1,x2 axes need left and right of the element rectangle
          // Determine space for top,left,bottom,right rectangles based on the preferred size of each axis

          this._axisSizable.forEach(function (_axisLabelComp, _orientation) {
            var sizable = _axisLabelComp;
            var orientation = _orientation;
            var tbAxis = Orientation.Top === orientation || Orientation.Bottom === orientation;
            var axisDynamicSize = sizable.getPreferredSize();
            var spillOver = sizable.getSpillOver();

            if (tbAxis) {
              if (axisDynamicSize > _this._chartRect.height * 0.5) axisDynamicSize = _this._chartRect.height * 0.5;
              if (Orientation.Top === orientation) topH = axisDynamicSize;else bottomH = axisDynamicSize;
              if (spillOver > lrSO) lrSO = spillOver;
            } else {
              if (axisDynamicSize > _this._chartRect.width * 0.5) axisDynamicSize = _this._chartRect.width * 0.5;
              if (Orientation.Left === orientation) leftW = axisDynamicSize;else rightW = axisDynamicSize;
              if (spillOver > tbSO) tbSO = spillOver;
            }
          });

          if (lrSO > leftW) leftW = lrSO;
          if (lrSO > rightW) rightW = lrSO;
          if (tbSO > topH) topH = tbSO;
          if (tbSO > bottomH) bottomH = tbSO;
          var elementRectW = Math.max(0, this._chartRect.width - (leftW + rightW));
          var elementRectH = Math.max(0, this._chartRect.height - (topH + bottomH));
          var elementRectT = this._chartRect.y + topH;

          this._orientationMap.set(Orientation.Left, {
            x: this._chartRect.x,
            y: elementRectT,
            width: leftW,
            height: elementRectH
          });

          this._orientationMap.set(Orientation.Right, {
            x: this._chartRect.x + this._chartRect.width - rightW,
            y: elementRectT,
            width: rightW,
            height: elementRectH
          });

          this._orientationMap.set(Orientation.Top, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: this._chartRect.width,
            height: topH
          });

          this._orientationMap.set(Orientation.Bottom, {
            x: this._chartRect.x,
            y: this._chartRect.y + this._chartRect.height - bottomH,
            width: this._chartRect.width,
            height: bottomH
          });

          this._elementRect = {
            x: this._chartRect.x + leftW,
            y: elementRectT,
            width: elementRectW,
            height: elementRectH
          };
        }
      }
    }]);

    return ChartLayoutComponent;
  }();

  // 1: vertical numeric; 2: vertical categorical; 3: horizontal numeric; 4: horizontal categorical; 5: axis with no scale

  var AxisScaleScore = Object.freeze({
    VerticalNumeric: 1,
    VerticalCategorical: 2,
    HorizontalNumeric: 3,
    HorizontalCategorical: 4,
    NoScale: 5
  });
  var AxisLayoutOrder = [Orientation.Bottom, Orientation.Top, Orientation.Left, Orientation.Right];

  var AxisLayoutScore = function AxisLayoutScore(_orientation, _score) {
    _classCallCheck(this, AxisLayoutScore);

    this.orientation = _orientation;
    this.score = _score;
  };

  function getOrientation(_axisSelector) {
    var labelPos = 0,
        orientation = null;
    var isHorizontal = _axisSelector.select(".domain").attr("d").split("H").length === 2;

    if (_axisSelector.selectAll(".tick text").size() > 0) {
      if (isHorizontal) {
        labelPos = _axisSelector.select(".tick text").attr("y");
        orientation = labelPos > 0 ? Orientation.Bottom : Orientation.Top;
      } else {
        labelPos = _axisSelector.select(".tick text").attr("x");
        orientation = labelPos > 0 ? Orientation.Right : Orientation.Left;
      }
    }

    return orientation;
  }

  var AxesComponent = function AxesComponent() {
    var selector, axes, bounds;
    var layoutProgress;
    var axesScore;
    var elementRect;
    var axisLayoutComponents = new Map();
    var chartLayoutComponent = new ChartLayoutComponent();
    var axisRects = new Map();
    var axisOrientationMap = new Map();
    var layoutAxisOrder = new Array(4);
    var axesPropertyMap = new Map();

    function draw() {
      for (var index = 0; index < 4; index++) {
        var orientation = layoutAxisOrder[index];
        var axisGroup = selector.select(".axisTransform." + orientation);
        if (!orientation) continue;
        var axis = axisOrientationMap.get(orientation);

        if (!axis) {
          axisGroup.remove();
          continue;
        }

        if (axisGroup.empty()) axisGroup = selector.append("g").attr("class", "axisTransform " + orientation);
        var axisLayoutComp = axisLayoutComponents.get(orientation);
        var axisProperty = axesPropertyMap.get(orientation);
        if (!axisProperty) axisProperty = new AxisProperty();

        if (!axisLayoutComp) {
          axisLayoutComp = AxisLayout().axisProperty(axisProperty);
          axisLayoutComponents.set(orientation, axisLayoutComp);
        }

        setScaleRangePadded(orientation);
        var axisRect = axisRects.get(orientation);
        axisLayoutComp.bounds(axisRect).axis(axis);
        axisGroup.call(axisLayoutComp);
        var transform = getTransform(orientation);
        var axisTransform = "translate(" + transform[0] + "," + transform[1] + ")";
        axisGroup.attr("transform", axisTransform);
        if (layoutProgress) postDraw(orientation);
      }
    }

    function postDraw(_orientation) {
      // chip away at the _elementRect based on how much space the just rendered axis wants
      var axisLayoutComponent = axisLayoutComponents.get(_orientation);
      var size = axisLayoutComponent.getPreferredSize();

      if (_orientation === Orientation.Top || _orientation === Orientation.Bottom) {
        if (size > bounds.height * 0.5) size = bounds.height * 0.5;

        if (_orientation === Orientation.Top) {
          elementRect.y += size;
          elementRect.height -= size;
        } else {
          elementRect.height -= size;
        }
      } else {
        if (size > bounds.width * 0.5) size = bounds.width;

        if (_orientation === Orientation.Left) {
          elementRect.x += size;
          elementRect.width -= size;
        } else {
          elementRect.width -= size;
        }
      }

      chartLayoutComponent.add(_orientation, axisLayoutComponent);
    }

    function layout(_selector) {
      selector = _selector.append("g");
      preLayout();
      selector = _selector; // Update rect bounds to use from chartlayout.

      elementRect = chartLayoutComponent.elementRect();
      axisRects.forEach(function (_rect, _orientation) {
        return axisRects.set(_orientation, chartLayoutComponent.getRect(_orientation));
      });
      draw();
    }

    function preLayout() {
      // extra layer to do prelayout.
      layoutProgress = true;
      axisLayoutComponents.clear();
      chartLayoutComponent.chartRect(bounds);

      if (axes) {
        axes.forEach(function (_axis) {
          var dummyNode = selector.append("g");
          dummyNode.call(_axis);
          axisOrientationMap.set(getOrientation(dummyNode), _axis);
          dummyNode.remove();
        });
      }

      for (var index = 0; index < 4; index++) {
        var orientation = AxisLayoutOrder[index];
        if (axisOrientationMap.get(orientation)) // initialize all axis 'rects' to the chart area.
          axisRects.set(orientation, {
            x: bounds.x || 0,
            y: bounds.y || 0,
            width: bounds.width,
            height: bounds.height
          });
      }

      elementRect = {
        x: bounds.x || 0,
        y: bounds.y || 0,
        width: bounds.width,
        height: bounds.height
      };
      axesScore = [];
      var score = 0;

      for (var _index = 0; _index < 4; _index++) {
        var _orientation2 = AxisLayoutOrder[_index];
        var isHorz = _orientation2 === Orientation.Top || _orientation2 === Orientation.Bottom;
        var axis = axisOrientationMap.get(_orientation2);

        if (axis) {
          var scale = axis.scale();
          var isContinuousAxis = scale.rangeBand || scale.step ? false : true;

          if (!isContinuousAxis) {
            score = isHorz ? AxisScaleScore.HorizontalCategorical : AxisScaleScore.VerticalCategorical;
            axesScore.push(new AxisLayoutScore(_orientation2, score));
          } else {
            score = isHorz ? AxisScaleScore.HorizontalNumeric : AxisScaleScore.VerticalNumeric;
            axesScore.push(new AxisLayoutScore(_orientation2, score));
          }
        } else {
          axesScore.push(new AxisLayoutScore(_orientation2, AxisScaleScore.NoScale));
        }
      }

      axesScore.sort(function (a1, a2) {
        return a1.score < a2.score ? -1 : a1.score > a2.score ? 1 : 0;
      });

      for (var i = 0; i < 4; i++) {
        layoutAxisOrder[i] = axesScore[i] ? axesScore[i].orientation : null;
      }

      draw();
      chartLayoutComponent.layout();
      selector.remove();
      layoutProgress = false;
    }

    layout.axes = function (_axes) {
      axes = [];
      _axes && _axes.forEach(function (_axis) {
        verifyAxis(_axis);
        axes.push(_axis);
      });
      return layout;
    };

    layout.axisProperty = function (_orientation, _axisProperty) {
      axesPropertyMap.set(_orientation, _axisProperty);
      return this;
    };

    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };

    layout.getRect = function (_orientation) {
      verifyOrientation(_orientation);
      return chartLayoutComponent.getRect(_orientation);
    };

    layout.getScale = function (_orientation) {
      var axis = axisOrientationMap.get(_orientation);
      return axis ? axis.scale() : null;
    };

    function getTransform(_orientation) {
      if (_orientation === Orientation.Left) return [elementRect.x, 0.0];
      if (_orientation === Orientation.Right) return [elementRect.x + elementRect.width, 0.0];
      if (_orientation === Orientation.Top) return [0.0, elementRect.y];
      return [0.0, elementRect.y + elementRect.height];
    }

    function setScaleRangePadded(_orientation) {
      var axis = axisOrientationMap.get(_orientation);

      if (axis) {
        var scale = axis.scale();
        var min, max;
        var isHorizontal = _orientation === Orientation.Bottom || _orientation === Orientation.Top;

        if (isHorizontal) {
          // This axis is on the horizontal
          min = elementRect.x;
          max = elementRect.x + elementRect.width;
        } else {
          min = elementRect.y + elementRect.height;
          max = elementRect.y;
        }

        scale.range([min, max]);
      }
    }

    return layout;
  };

  /* eslint-disable @typescript-eslint/no-namespace */
  // Licensed Materials - Property of IBM
  //
  // VIDA Bundles
  //
  // (C) Copyright IBM Corp. 2023, 2024
  //
  // US Government Users Restricted Rights - Use, duplication or
  // disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

  var ScaleSteps = /*#__PURE__*/function (ScaleSteps) {
    ScaleSteps["Low"] = "Low";
    ScaleSteps["Medium"] = "Medium";
    ScaleSteps["High"] = "High";
    ScaleSteps["VeryHigh"] = "Very High";
    return ScaleSteps;
  }({});
  (function (_ScaleSteps) {
    function parse(_value) {
      switch (_value.toLowerCase()) {
        case "low":
          return ScaleSteps.Low;
        case "medium":
          return ScaleSteps.Medium;
        case "high":
          return ScaleSteps.High;
        case "very high":
          return ScaleSteps.VeryHigh;
        default:
          throw new TypeError("".concat(_value, " is not a valid scale value. Please use \"").concat(ScaleSteps.Low, "\", \"").concat(ScaleSteps.Medium, "\", \"").concat(ScaleSteps.High, "\" or \"").concat(ScaleSteps.VeryHigh, "\""));
      }
    }
    _ScaleSteps.parse = parse;
  })(ScaleSteps || (ScaleSteps = {}));
  var colorThresholds = [{
    name: ScaleSteps.Low,
    threshold: 0.2
  }, {
    name: ScaleSteps.Medium,
    threshold: 0.4
  }, {
    name: ScaleSteps.High,
    threshold: 0.8
  }, {
    name: ScaleSteps.VeryHigh,
    threshold: 1
  }];
  function getColorCategory(value) {
    var _iterator = _createForOfIteratorHelper(colorThresholds),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var colorEntry = _step.value;
        if (value < colorEntry.threshold) return colorEntry.name;
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    return ScaleSteps.VeryHigh;
  }
  var scaleStepsMap = new Map([[ScaleSteps.Low, {
    weight: 0.3
  }], [ScaleSteps.Medium, {
    weight: 0.5
  }], [ScaleSteps.High, {
    weight: 0.8
  }], [ScaleSteps.VeryHigh, {
    weight: 1
  }]]);

  var PROBABILITY = 0,
    IMPACT = 1;
  var xSymbol = "×";
  var PROBABILITY_DATUM = "probability";
  var IMPACT_DATUM = "impact";
  var RiskTileData = /*#__PURE__*/function () {
    function RiskTileData(probabilityTuple, impactTuple) {
      _classCallCheck$1(this, RiskTileData);
      _defineProperty(this, "children", []);
      _defineProperty(this, "probabilityTuple", void 0);
      _defineProperty(this, "impactTuple", void 0);
      _defineProperty(this, "_probabilityCaption", void 0);
      _defineProperty(this, "_impactCaption", void 0);
      this.probabilityTuple = probabilityTuple;
      this.impactTuple = impactTuple;
      this._probabilityCaption = ScaleSteps.parse(probabilityTuple.caption);
      this._impactCaption = ScaleSteps.parse(impactTuple.caption);
    }
    _createClass$1(RiskTileData, [{
      key: "addChild",
      value: function addChild(_dataPoint) {
        this.children.push(_dataPoint);
      }
    }, {
      key: "getKey",
      value: function getKey() {
        return "".concat(this.probabilityKey).concat(xSymbol).concat(this.impactKey);
      }
    }, {
      key: "childrenCount",
      get: function get() {
        return this.children.length;
      }
    }, {
      key: "probabilityKey",
      get: function get() {
        return this.probabilityTuple.key;
      }
    }, {
      key: "impactKey",
      get: function get() {
        return this.impactTuple.key;
      }
    }, {
      key: "probabilityCaption",
      get: function get() {
        return this._probabilityCaption;
      }
    }, {
      key: "impactCaption",
      get: function get() {
        return this._impactCaption;
      }
    }, {
      key: "riskRating",
      get: function get() {
        var impactWeight = scaleStepsMap.get(this.probabilityCaption).weight;
        var probabilityWeight = scaleStepsMap.get(this.impactCaption).weight;
        return getColorCategory(impactWeight * probabilityWeight);
      }
    }, {
      key: "selected",
      get: function get() {
        return this.children.some(function (_item) {
          return _item.selected;
        });
      }
    }, {
      key: "highlighted",
      get: function get() {
        return this.children.some(function (_item) {
          if (_item.highlighted) return _item.highlighted;
        });
      }
    }]);
    return RiskTileData;
  }();
  var RiskData = /*#__PURE__*/function () {
    function RiskData(_dataSet) {
      _classCallCheck$1(this, RiskData);
      _defineProperty(this, "_dataSet", null);
      _defineProperty(this, "_isEmpty", void 0);
      _defineProperty(this, "_tiles", void 0);
      _defineProperty(this, "_impactCaption", void 0);
      _defineProperty(this, "_probabilityCaption", void 0);
      this._dataSet = _dataSet;
      this._isEmpty = _dataSet === null;
      this._tiles = new Map();
      this._impactCaption = "";
      this._probabilityCaption = "";
    }
    _createClass$1(RiskData, [{
      key: "hasSelection",
      get: function get() {
        return this._dataSet ? this._dataSet.hasSelections : false;
      }
    }, {
      key: "riskTiles",
      get: function get() {
        return Array.from(this._tiles.values());
      }
    }, {
      key: "addRiskTile",
      value: function addRiskTile(_probabilityTuple, _impactTuple) {
        var key = "".concat(_probabilityTuple.key).concat(xSymbol).concat(_impactTuple.key);
        this._tiles.set(key, new RiskTileData(_probabilityTuple, _impactTuple));
      }
    }, {
      key: "probabilityCaption",
      get: function get() {
        return this._probabilityCaption;
      }
    }, {
      key: "impactCaption",
      get: function get() {
        return this._impactCaption;
      }
    }], [{
      key: "process",
      value: function process(_dataSet) {
        var riskData = new RiskData(_dataSet);

        // If the data we received is null, we assume empty data.
        // In that case there is not much to process, so we're done.
        if (!_dataSet) return riskData;
        var probabilitySlot = _dataSet.cols[PROBABILITY];
        var impactSlot = _dataSet.cols[IMPACT];
        var probabilityTuples = probabilitySlot.tuples;
        var impactTuples = impactSlot.tuples;
        probabilityTuples.forEach(function (probabilityTuple) {
          impactTuples.forEach(function (impactTuple) {
            riskData.addRiskTile(probabilityTuple, impactTuple); //.set( key , new RiskTileData( probabilityKey, impactKey ) );
          });
        });

        // Remember the titles
        riskData._impactCaption = impactSlot.caption;
        riskData._probabilityCaption = probabilitySlot.caption;

        // Iterate all data points and add LineItems to each LineGroup. A LineGroup represents
        // a series item. A LineItem is added for each category item.

        _dataSet.rows.forEach(function (row) {
          var probabilityKey = row.source.get(PROBABILITY_DATUM).asCat().getKey(true);
          var impactKey = row.source.get(IMPACT_DATUM).asCat().getKey(true);

          // extract function to create key - maybe static on RiskTileData
          var rowString = "".concat(probabilityKey).concat(xSymbol).concat(impactKey);
          var riskTile = riskData._tiles.get(rowString);
          if (riskTile) {
            // TODO: keep this if we want to have a property
            // riskTile.riskRating = row.source.get( "risk" ).asCat().getCaption( FormatType.label );
            riskTile.addChild(row);
          }
        });
        return riskData;
      }

      // TODO: hittest on axes labels
    }, {
      key: "getHittestData",
      value: function getHittestData(_data) {
        if (_data instanceof RiskTileData) {
          if (_data.children.length !== 0) {
            return _data.children;
          }
        }
        return null;
      }
    }]);
    return RiskData;
  }();

  var TILE_GUTTER_WIDTH = 2;
  var MINIMUM_LIGHTNESS_DIFFERENCE = 50;
  function getContrastColor(tileColor, labelColor) {
    var calulcatedLabelColor;
    var labelLightness = 0;
    var tileLightness = 0;
    function getColorLightness(color) {
      return 0.3 * +color.r + 0.59 * +color.g + 0.11 * +color.b;
    }
    var tileColorObj = S.fromString(tileColor);
    if (tileColorObj) tileLightness = getColorLightness(tileColorObj);
    var labelColorObj = S.fromString(labelColor);
    if (labelColorObj) {
      labelLightness = getColorLightness(labelColorObj);
    }
    if (Math.abs(tileLightness - labelLightness) < MINIMUM_LIGHTNESS_DIFFERENCE) calulcatedLabelColor = tileLightness > 127 ? "black" : "white";
    return calulcatedLabelColor;
  }
  var _default = /*#__PURE__*/function (_RenderBase) {
    _inherits(_default, _RenderBase);
    function _default() {
      var _this;
      _classCallCheck$1(this, _default);
      _this = _callSuper(this, _default);

      // Create the axes component
      _defineProperty(_assertThisInitialized(_this), "_tilesLayer", void 0);
      _defineProperty(_assertThisInitialized(_this), "_labelsLayer", void 0);
      _defineProperty(_assertThisInitialized(_this), "_chartNode", void 0);
      _defineProperty(_assertThisInitialized(_this), "_padding", void 0);
      _defineProperty(_assertThisInitialized(_this), "_riskData", null);
      _defineProperty(_assertThisInitialized(_this), "_axesComponent", void 0);
      _defineProperty(_assertThisInitialized(_this), "_bottomAxisProperties", void 0);
      _defineProperty(_assertThisInitialized(_this), "_leftAxisProperties", void 0);
      _this._bottomAxisProperties = new AxisProperty();
      _this._leftAxisProperties = new AxisProperty();
      _this._axesComponent = AxesComponent().axisProperty(Orientation.Left, _this._leftAxisProperties).axisProperty(Orientation.Bottom, _this._bottomAxisProperties);
      return _this;
    }
    _createClass$1(_default, [{
      key: "create",
      value: function create(_node) {
        var svg = select(_node).append("svg").attr("width", "100%").attr("height", "100%");
        this._chartNode = svg.append("svg:g").attr("class", "chart");
        var chartContentArea = this._chartNode.append("svg:g").attr("class", "chartContent");
        this._tilesLayer = chartContentArea.append("svg:g").attr("class", "tiles");
        this._labelsLayer = chartContentArea.append("svg:g").attr("class", "labels");
        this._chartNode.append("svg:g").attr("class", "axes");

        // return the root node so it can be used in `update`.
        return _node;
      }
    }, {
      key: "updateLegend",
      value: function updateLegend(_data) {
        // Call base class implementation to setup initial encodings.
        var encodings = [];
        var encoding = new M("color", null, "Risk Matrix", null, null);
        var colorKeys = scaleStepsMap.keys(); // Note: works until scale steps are the same for axes and color scale
        var _iterator = _createForOfIteratorHelper(colorKeys),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var colorKey = _step.value;
            var colorString = this.getFillColor(colorKey);
            var entryColor = S.fromString(colorString);
            encoding.entries.push(new $(colorKey, entryColor, null, false, false, null));
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
        encodings.push(encoding);
        return encodings;
      }
    }, {
      key: "getFillColor",
      value: function getFillColor(_riskCategory) {
        switch (_riskCategory) {
          case ScaleSteps.Low:
            return this.properties.get("low").toString();
          case ScaleSteps.Medium:
            return this.properties.get("medium").toString();
          case ScaleSteps.High:
            return this.properties.get("high").toString();
          case ScaleSteps.VeryHigh:
            return this.properties.get("veryHigh").toString();
          default:
            return "none";
        }
      }
    }, {
      key: "update",
      value: function update(_info) {
        var node = _info.node;
        var data = _info.data;
        var properties = _info.props;
        if (_info.reason.properties) this._updateProperties(properties);
        if (_info.reason.data) this._riskData = RiskData.process(data);
        if (_info.reason.size || _info.reason.properties) this._applySize(node);
        if (_info.reason.data || _info.reason.properties || _info.reason.size) {
          this._updateAxes(this._riskData, properties);
          // After updating the axes and setting the size, a re-render needs to be triggered on the AxesComponent.
          this._chartNode.selectAll(".axes").call(this._axesComponent);
          this._updateTiles(this._riskData, properties);
          this._updateLabels(this._riskData, properties);
        }
        if (_info.reason.decorations) this._updateDecorations(this._riskData, properties);
      }
    }, {
      key: "_updateTiles",
      value: function _updateTiles(_data, _properties) {
        if (!_data) return;
        var elements = this._tilesLayer.selectAll(".tile").data(_data.riskTiles);
        this._removeElements(elements.exit());
        this._createElements(elements.enter(), _properties);
        this._updateElements(elements, _properties);
      }
    }, {
      key: "_removeElements",
      value: function _removeElements(_selection) {
        return _selection.remove();
      }
    }, {
      key: "_createElements",
      value: function _createElements(_selection, _properties) {
        // Draw the matrix by creating a rect for each data element.
        var elements = _selection.append("rect").attr("class", "tile").attr("fill", "none");

        // For all created elements: Call update as well.
        this._updateElements(elements, _properties);
      }
    }, {
      key: "_updateElements",
      value: function _updateElements(_selection, _properties) {
        var _this2 = this;
        var bottomScale = this._axesComponent.getScale(Orientation.Bottom);
        var leftScale = this._axesComponent.getScale(Orientation.Left);
        _selection.attr("x", function (d) {
          return bottomScale(d.impactCaption);
        }).attr("y", function (d) {
          return leftScale(d.probabilityCaption) + TILE_GUTTER_WIDTH;
        }).attr("width", bottomScale.bandwidth() - TILE_GUTTER_WIDTH).attr("height", leftScale.bandwidth() - TILE_GUTTER_WIDTH).attr("fill", function (d) {
          return _this2.getFillColor(d.riskRating);
        });
      }
    }, {
      key: "_updateLabels",
      value: function _updateLabels(_data, _properties) {
        if (!_data) return;
        var elements = this._labelsLayer.selectAll(".label").data(_data.riskTiles);
        this._removeTileLabels(elements.exit());
        this._createTileLabels(elements.enter(), _properties);
        this._updateTileLabels(elements, _properties);
      }
    }, {
      key: "_removeTileLabels",
      value: function _removeTileLabels(_selection) {
        return _selection.remove();
      }
    }, {
      key: "_createTileLabels",
      value: function _createTileLabels(_selection, _properties) {
        // TODO: hide labels if they don't fit anymore
        var labels = _selection.append("text").attr("class", "label").attr("dy", "0.4em").text(function (d) {
          return d.childrenCount;
        }).style("text-anchor", "middle");

        // For all created elements: Call update as well.
        this._updateTileLabels(labels, _properties);
      }
    }, {
      key: "_getContrastLabelColor",
      value: function _getContrastLabelColor(d, labelColor) {
        var tileColor = this.getFillColor(d.riskRating);
        return getContrastColor(tileColor, labelColor !== null && labelColor !== void 0 ? labelColor : tileColor);
      }
    }, {
      key: "_updateTileLabels",
      value: function _updateTileLabels(_selection, _properties) {
        var _this3 = this;
        var bottomScale = this._axesComponent.getScale(Orientation.Bottom);
        var leftScale = this._axesComponent.getScale(Orientation.Left);
        var font = _properties.get("valueLabels.font");
        var contrastColorProp = _properties.get("contrast.label.color");
        _selection.attr("x", function (d) {
          return bottomScale(d.impactCaption) + bottomScale.bandwidth() / 2;
        }).attr("y", function (d) {
          return leftScale(d.probabilityCaption) + leftScale.bandwidth() / 2;
        }).style("fill", function (d) {
          if (contrastColorProp) return _this3._getContrastLabelColor(d, _properties.get("valueLabels.color").toString());else return _properties.get("valueLabels.color").toString();
        });
        if (font) _selection.style("font-size", font.size ? font.size.toString() : null).style("font-family", font.family ? font.family.toString() : null).style("font-style", font.style ? font.style.toString() : null).style("font-weight", font.weight ? font.weight.toString() : null);
      }
    }, {
      key: "_updateProperties",
      value: function _updateProperties(_properties) {
        this._padding = {
          left: _properties.get("visualization.padding.left").value,
          right: _properties.get("visualization.padding.right").value,
          top: _properties.get("visualization.padding.top").value,
          bottom: _properties.get("visualization.padding.bottom").value
        };
      }
    }, {
      key: "_updateAxisProperty",
      value: function _updateAxisProperty(_axisProperties, _prefix, _properties, _axisTitle) {
        var titleProp = _properties.get(_prefix + ".title");
        _axisProperties.title(titleProp !== "" ? titleProp : _axisTitle).showTitle(_properties.get(_prefix + ".title.visible")).showTicks(_properties.get(_prefix + ".ticks.visible")).ticksColor(_properties.get(_prefix + ".ticks.color").toString()).showTickLabels(_properties.get(_prefix + ".ticks.labels.visible")).tickLabelMode(_prefix === "left" || _prefix === "right" ? "horizontal" : _properties.get(_prefix + ".ticks.labels.layoutMode")).showAxisLine(_properties.get(_prefix + ".line.visible")).axisLineColor(_properties.get(_prefix + ".line.color")).tickLabelFont(this._createFontCss(_properties.get(_prefix + ".ticks.labels.font"))).tickLabelColor(_properties.get(_prefix + ".ticks.labels.color").toString()).titleFont(this._createFontCss(_properties.get(_prefix + ".title.font"))).titleColor(_properties.get(_prefix + ".title.color").toString());
      }
    }, {
      key: "_createFontCss",
      value: function _createFontCss(_font) {
        var _font$size, _font$family, _font$style, _font$weight;
        if (!_font) return {
          "font-size": "0.75em",
          "font-family": "",
          "font-style": "",
          "font-weight": ""
        };
        var fontSize = (_font$size = _font.size) === null || _font$size === void 0 ? void 0 : _font$size.toString();
        var fontFamily = (_font$family = _font.family) === null || _font$family === void 0 ? void 0 : _font$family.toString();
        var fontStyle = (_font$style = _font.style) === null || _font$style === void 0 ? void 0 : _font$style.toString();
        var fontWeight = (_font$weight = _font.weight) === null || _font$weight === void 0 ? void 0 : _font$weight.toString();
        return {
          "font-size": fontSize,
          "font-family": fontFamily,
          "font-style": fontStyle,
          "font-weight": fontWeight
        };
      }
    }, {
      key: "_updateAxes",
      value: function _updateAxes(_data, _properties) {
        if (!_data) return;
        var leftAxisTitle = "";
        var bottomAxisTitle = "";
        var bottomAxis;
        var leftAxis;
        if (_data) {
          var domain = Array.from(scaleStepsMap.keys());
          var bottomScale = band().domain(domain);
          var leftScale = band().domain(domain);
          bottomAxis = axisBottom(bottomScale);
          leftAxis = axisLeft(leftScale);
          leftAxisTitle = _data.probabilityCaption;
          bottomAxisTitle = _data.impactCaption;
        } else {
          var _bottomScale = band().padding(TILE_GUTTER_WIDTH);
          var _leftScale = band().padding(TILE_GUTTER_WIDTH);
          bottomAxis = axisBottom(_bottomScale);
          leftAxis = axisLeft(_leftScale);
        }
        this._axesComponent.axes([leftAxis, bottomAxis]);
        this._updateAxisProperty(this._leftAxisProperties, "left", _properties, leftAxisTitle);
        this._updateAxisProperty(this._bottomAxisProperties, "bottom", _properties, bottomAxisTitle);
      }
    }, {
      key: "_applySize",
      value: function _applySize(_node) {
        var margin = {
          left: this._padding ? this._padding.left : 20,
          right: this._padding ? this._padding.right : 20,
          top: this._padding ? this._padding.top : 10,
          bottom: this._padding ? this._padding.bottom : 10
        };
        this._chartNode.attr("transform", "translate(".concat(margin.left, ", ").concat(margin.top, ")"));
        var clientHeight = _node.clientHeight,
          clientWidth = _node.clientWidth;
        this._axesComponent.bounds({
          width: clientWidth - margin.left - margin.right,
          height: clientHeight - margin.top - margin.bottom
        });
      }
    }, {
      key: "_updateDecorations",
      value: function _updateDecorations(_data, _properties) {
        var _this4 = this;
        var tiles = this._tilesLayer.selectAll(".tile");
        var tileLabels = this._labelsLayer.selectAll(".label");
        var hasSelection = _data.hasSelection;
        tiles.style("stroke-opacity", function (d) {
          if (hasSelection === false) return 0.8;
          return d.selected || d.highlighted ? 0.8 : 0.15;
        });
        tiles.style("fill-opacity", function (d) {
          return hasSelection && !d.selected ? 0.3 : 0.9;
        }).style("stroke", function (d) {
          return S.darker(S.fromString(_this4.getFillColor(d.riskRating)));
        }).style("stroke-width", function (d) {
          // The border should be applied in case the data is either highlighted or selected
          if (d.highlighted || hasSelection && d.selected) return 2;
          return 0;
        });
        tileLabels.style("fill-opacity", function (d) {
          return hasSelection && !d.selected ? 0.3 : 1;
        });
      }
    }, {
      key: "hitTest",
      value: function hitTest(_element, _client, _viewport) {
        var selection = select(_element);
        return RiskData.getHittestData(selection.datum());
      }
    }]);
    return _default;
  }(ct);

  return _default;

}));
