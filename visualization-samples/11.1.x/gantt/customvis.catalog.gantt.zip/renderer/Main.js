define(['require', 'https://d3js.org/d3.v5.min.js'], (function (requirejs, d3) { 'use strict';

  function _typeof$1(o) {
    "@babel/helpers - typeof";

    return _typeof$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
      return typeof o;
    } : function (o) {
      return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof$1(o);
  }
  function _classCallCheck$1(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties$1(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass$1(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties$1(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    Object.defineProperty(subClass, "prototype", {
      writable: false
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;
    try {
      Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    } else if (call !== void 0) {
      throw new TypeError("Derived constructors may only return object or undefined");
    }
    return _assertThisInitialized(self);
  }
  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();
    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
        result;
      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;
        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }
      return _possibleConstructorReturn(this, result);
    };
  }
  function _toPrimitive(input, hint) {
    if (typeof input !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
      var res = prim.call(input, hint || "default");
      if (typeof res !== "object") return res;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
  }
  function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return typeof key === "symbol" ? key : String(key);
  }

  var e = function () {
      function t(t, e) {
        this.name = t, this.slot = e || null, this.attributes = new Map();
      }
      return t.prototype.getName = function () {
        return this.name;
      }, t.prototype.getSlot = function () {
        return this.slot;
      }, t.prototype.getAttributes = function () {
        return this.attributes;
      }, t.slotLimit = function (e, n) {
        return new t("limit", e).attr("n", n);
      }, t.dataLimit = function (e) {
        return new t("limit").attr("n", e);
      }, t.prototype.attr = function (t, e) {
        return this.attributes.set(t, e), this;
      }, t;
    }(),
    _n = function n(t, e) {
      return _n = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (t, e) {
        t.__proto__ = e;
      } || function (t, e) {
        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
      }, _n(t, e);
    };
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */
  function r(t, e) {
    function r() {
      this.constructor = t;
    }
    _n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r());
  }
  function o(t, e, n) {
    return t.getDecoration(e, n);
  }
  function i(t) {
    return t.hasDecoration("hasSelection") ? o(t, "hasSelection", !1) : !!function (t) {
      return "getSlot" in t && "hasDecorationOnDataPoints" in t;
    }(t) && t.hasDecorationOnDataPoints("selected");
  }
  var u,
    s = function () {
      function t(t, e) {
        this.min = t, this.max = e;
      }
      return t.prototype.asArray = function () {
        return [this.min, this.max];
      }, t.empty = new t(0, 0), t;
    }(),
    a = function (t) {
      function e(e, n) {
        return t.call(this, e, n) || this;
      }
      return r(e, t), e.fromRS = function (t) {
        return new s(t.min, t.max);
      }, e;
    }(s),
    l = function () {
      function t(t, e) {
        this.source = t, this.index = e, this.key = t.getKey(!1), this.caption = t.getCaption("label") || "";
        var n = t.getItems() || [];
        this.segments = n.map(function (t) {
          return new p(t);
        });
      }
      return Object.defineProperty(t.prototype, "selected", {
        get: function get() {
          return o(this.source, "selected", !1);
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(t.prototype, "highlighted", {
        get: function get() {
          return o(this.source, "highlighted", !1);
        },
        enumerable: !1,
        configurable: !0
      }), t;
    }(),
    c = function (t) {
      function e(e, n) {
        return t.call(this, e, n) || this;
      }
      return r(e, t), e;
    }(l),
    h = function () {
      function t(t) {
        this.source = t, this.key = this.source.getUniqueName() || "", this.caption = this.source.getCaption("label") || "";
      }
      return Object.defineProperty(t.prototype, "selected", {
        get: function get() {
          return o(this.source, "selected", !1);
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(t.prototype, "highlighted", {
        get: function get() {
          return o(this.source, "highlighted", !1);
        },
        enumerable: !1,
        configurable: !0
      }), t;
    }(),
    p = function (t) {
      function e(e) {
        return t.call(this, e) || this;
      }
      return r(e, t), e;
    }(h),
    f = new (function () {
      function t() {}
      return t.prototype.format = function (t) {
        return t ? t.toString() : "";
      }, t;
    }())();
  !function (t) {
    t.label = "label", t.data = "data";
  }(u || (u = {}));
  var g = function () {
      function t(t, e, n, r, o) {
        this.source = t, this.tuples = e, this.segments = n, this.domain = r, this.caption = o;
        var i = t.dataItems || [],
          u = i.length > 0 ? i[0] : null,
          s = u && u.asCont();
        s ? (this._labelFormatter = s.getFormatter("label") || f, this._dataFormatter = s.getFormatter("data") || f) : this._labelFormatter = this._dataFormatter = f;
      }
      return Object.defineProperty(t.prototype, "mapped", {
        get: function get() {
          return this.source.mapped;
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(t.prototype, "dataType", {
        get: function get() {
          var t = this.source.getDataItem(0);
          return this.mapped && t ? t.type : "none";
        },
        enumerable: !1,
        configurable: !0
      }), t.prototype.format = function (t, e) {
        return function (t, e) {
          return t.format(e);
        }(e === u.data ? this._dataFormatter : this._labelFormatter, t);
      }, t;
    }(),
    d = function (t) {
      function e(e, n, r, o, i) {
        return t.call(this, e, n, r, o, i) || this;
      }
      return r(e, t), e;
    }(g),
    m = function () {
      function t(t, e) {
        this.source = t, this.key = t.getKey(!1), this.dataSet = e;
      }
      return Object.defineProperty(t.prototype, "selected", {
        get: function get() {
          return o(this.source, "selected", !1);
        },
        enumerable: !1,
        configurable: !0
      }), Object.defineProperty(t.prototype, "highlighted", {
        get: function get() {
          return o(this.source, "highlighted", !1);
        },
        enumerable: !1,
        configurable: !0
      }), t.prototype.tuple = function (t) {
        var e = this._getSlot(t);
        if (!e || 0 === e.tuples.length) return null;
        var n = this.source.get(e.source);
        if (!n) return null;
        var r = n.asCat();
        return r ? e.tuples[r.index] : null;
      }, t.prototype.value = function (t) {
        var e = this._getSlot(t),
          n = e && this.source.get(e.source);
        if (!n) return null;
        var r = n.asCont();
        return r && "numeric" === r.valueType ? r.value : null;
      }, t.prototype.caption = function (t) {
        var e = this._getSlot(t),
          n = e && this.source.get(e.source);
        return n && n.getCaption("data") || "";
      }, t.prototype._getSlot = function (t) {
        return "string" == typeof t ? this.dataSet.slotMap.get(t) || null : this.dataSet.cols[t] || null;
      }, t;
    }(),
    y = function (t) {
      function e(e, n) {
        return t.call(this, e, n) || this;
      }
      return r(e, t), e;
    }(m),
    v = function () {
      function t(t, e, n) {
        var r = this;
        this.source = t, this.rows = t.dataPoints.map(function (t) {
          return new y(t, r);
        }), this.cols = e, this.slotMap = n;
      }
      return t.filterRows = function (t, e, n) {
        return t.filter(function (t) {
          var r = t.tuple(e);
          return !!r && r.key === n;
        });
      }, Object.defineProperty(t.prototype, "hasSelections", {
        get: function get() {
          return i(this.source);
        },
        enumerable: !1,
        configurable: !0
      }), t;
    }(),
    _ = function (t) {
      function e(e, n, r) {
        return t.call(this, e, n, r) || this;
      }
      return r(e, t), e;
    }(v);
  function b(t) {
    var e = new Map(),
      n = t.getSlots().map(function (t, n) {
        var r = [],
          o = [],
          i = s.empty,
          u = "";
        if (t.isMapped()) {
          var l = t.getDataItem(0);
          if (u = l.getCaption("label"), "cat" === l.getRSType()) r = l.getTuples().map(function (t, e) {
            return new c(t, e);
          }), o = l.getItemClassSet(0).getItemClasses().map(function (t) {
            return new p(t);
          });else i = a.fromRS(l.getDomain()), o.push(new p(l.getItemClass()));
        }
        var h = new d(t, r, o, i, u);
        return e.set(t.name, h), h;
      });
    return new _(t, n, e);
  }
  function w(t) {
    return t < 0 ? 0 : t > 255 ? 255 : Math.floor(t);
  }
  var C = function () {
    function t(t, e, n, r) {
      var o;
      this.r = w(t), this.g = w(e), this.b = w(n), this.a = (o = r) < 0 ? 0 : o > 1 ? 1 : o;
    }
    return t.fromObject = function (e) {
      return new t(e.r, e.g, e.b, void 0 === e.a ? 1 : e.a);
    }, t.prototype.toString = function () {
      return 1 === this.a ? "rgb(" + this.r + "," + this.g + "," + this.b + ")" : "rgba(" + this.r + "," + this.g + "," + this.b + "," + this.a + ")";
    }, t;
  }();
  function S(t, e) {
    var n = null;
    if (t instanceof m) n = t.source.getDataSet(e);else {
      var r = t.source.getDataItem(e);
      n = r && r.getDataSet(e);
    }
    return !!n && i(n);
  }
  var P = function P(t) {
      return "rgba(" + t.r + "," + t.g + "," + t.b + ",0.4)";
    },
    j = function j(t) {
      return "rgba(" + Math.round(.7 * t.r) + "," + Math.round(.7 * t.g) + "," + Math.round(.7 * t.b) + "," + t.a + ")";
    },
    O = function () {
      function t(t, e, n) {
        this.source = t, this._dataContext = e, this._slotResolver = n;
      }
      return Object.defineProperty(t.prototype, "slot", {
        get: function get() {
          return this.source.slot;
        },
        enumerable: !1,
        configurable: !0
      }), t.prototype.getColor = function (t) {
        return t ? C.fromObject(this.source.getTupleColor(t.source, -1)) : C.fromObject(this.source.getColor(null));
      }, t.prototype._getTuple = function (t) {
        if (t instanceof l) return t;
        var e = this.slot || this._slotResolver(t.dataSet, this.source.name);
        return e ? t.tuple(e) : null;
      }, t.prototype.getFillColor = function (t) {
        if (null === t) return this.source.getColor(null).toString();
        var e,
          n = this._getTuple(t);
        return e = n ? this.source.getTupleColor(n.source, -1) : this.source.getColor(t.source), !t.selected && S(t, this._dataContext) ? P(e) : e.toString();
      }, t.prototype.getOutlineColor = function (t) {
        if (null === t) return this.source.getColor(null).toString();
        var e,
          n = this._getTuple(t);
        return e = n ? this.source.getTupleColor(n.source, -1) : this.source.getColor(t.source), t.highlighted || t.selected && S(t, this._dataContext) ? j(e) : null;
      }, t;
    }(),
    x = function x(t, e, n) {
      this.color = t, this.at = e, this.value = n;
    };
  function I(t) {
    return t.map(function (t) {
      return new x(C.fromObject(t.color), t.at, t.value);
    });
  }
  var D = function () {
      function t(t, e, n) {
        this.source = t, this._slot = e, this._dataContext = n, this.stops = I(t.stops), this.aligned = I(t.aligned), this.interpolate = t.interpolate;
      }
      return t.prototype.getColor = function (t) {
        return C.fromObject(this.source.getColor(t));
      }, t.prototype.getFillColor = function (t) {
        var e = this._slot ? Number(t.value(this._slot)) : 0,
          n = this.source.getColor(e);
        return !t.selected && S(t, this._dataContext) ? P(n) : n.toString();
      }, t.prototype.getOutlineColor = function (t) {
        var e = this._slot ? Number(t.value(this._slot)) : 0,
          n = this.source.getColor(e);
        return t.highlighted || t.selected && S(t, this._dataContext) ? j(n) : null;
      }, t;
    }(),
    E = function () {
      function t(t, e, n) {
        this.source = t, this._dataContext = e, this._lastDataItem = null, this._cachedStops = null, this._slotResolver = n;
      }
      return Object.defineProperty(t.prototype, "slot", {
        get: function get() {
          return this.source.slot;
        },
        enumerable: !1,
        configurable: !0
      }), t.prototype.getColorStops = function (t) {
        var e = t ? t.source.getDataItem(0) : null,
          n = e && e.asCont(),
          r = n ? n.getDomain(null) : null,
          o = this.source.getColorStops(n, r),
          i = t ? t.source.name : null;
        return new D(o, i, this._dataContext);
      }, t.prototype._fetchColorStops = function (t) {
        var e = t.source.getDataSet(this._dataContext),
          n = this.slot || this._slotResolver(t.dataSet, this.source.name),
          r = n ? e.getSlot(n) : null,
          o = r ? r.getDataItem(0) : null,
          i = o ? o.asCont() : null;
        if (this.source.dirty || !this._cachedStops || i !== this._lastDataItem) {
          var u = i ? i.getDomain(null) : null,
            s = this.source.getColorStops(i, u);
          this._cachedStops = new D(s, r && r.name, this._dataContext), this._lastDataItem = i;
        }
        return this._cachedStops;
      }, t.prototype.getFillColor = function (t) {
        return this._fetchColorStops(t).getFillColor(t);
      }, t.prototype.getOutlineColor = function (t) {
        return this._fetchColorStops(t).getOutlineColor(t);
      }, t;
    }(),
    T = function (t) {
      function e(e) {
        var n = t.call(this, e.r, e.g, e.b, e.a) || this;
        return n._color = e, n;
      }
      return r(e, t), e.prototype.getRed = function () {
        return this.r;
      }, e.prototype.getGreen = function () {
        return this.g;
      }, e.prototype.getBlue = function () {
        return this.b;
      }, e.prototype.getAlpha = function () {
        return this.a;
      }, e;
    }(C),
    R = Object.freeze({
      min: 0,
      max: 0,
      empty: !0,
      explicit: !1,
      getMin: function getMin() {
        return 0;
      },
      getMax: function getMax() {
        return 0;
      },
      isEmpty: function isEmpty() {
        return !0;
      },
      isExplicit: function isExplicit() {
        return !1;
      }
    }),
    F = function () {
      function t(t, e, n, r, o, i) {
        this.caption = t, this.color = e, this.shape = n, this.selected = r, this.highlighted = o, this.ref = i;
      }
      return t.prototype.getCaption = function () {
        return this.caption;
      }, t.prototype.getColor = function () {
        return this.color ? new T(this.color) : null;
      }, t.prototype.getShape = function () {
        return this.shape;
      }, t.prototype.isSelected = function () {
        return this.selected;
      }, t.prototype.isHighlighted = function () {
        return this.highlighted;
      }, t.prototype.getRef = function () {
        return this.ref;
      }, t;
    }(),
    M = function () {
      function t(t, e, n, r, o, i) {
        this.type = t, this.channel = e, this.slot = n, this.caption = r, this.subCaption = o, this.ref = i;
      }
      return t.prototype.getRSType = function () {
        return this.type;
      }, t.prototype.getChannel = function () {
        return this.channel;
      }, t.prototype.getSlot = function () {
        return this.slot;
      }, t.prototype.getCaption = function () {
        return this.caption;
      }, t.prototype.getSubCaption = function () {
        return this.subCaption;
      }, t.prototype.getRef = function () {
        return this.ref;
      }, t;
    }(),
    L = function (t) {
      function e(e, n, r, i, u) {
        var s = this,
          a = n && n.source,
          l = a && a.name,
          c = a && a.getDataItem(0),
          h = c && c.asCat();
        s = t.call(this, "cat", e, l, r, "", h) || this;
        var p = h ? h.tuples : [];
        return s.entries = p.map(function (t) {
          var e = t.getCaption("label") || "",
            n = u && u.source.getTupleColor(t, -1),
            r = o(t, "selected", !1),
            s = o(t, "highlighted", !1);
          return new F(e, n ? C.fromObject(n) : null, i, r, s, t);
        }), s;
      }
      return r(e, t), e.prototype.getEntries = function () {
        return this.entries;
      }, e;
    }(M),
    A = function (t) {
      function e(e, n, r, o) {
        var i = this,
          u = n && n.source,
          s = u && u.name,
          a = u && u.getDataItem(0),
          l = a && a.asCont();
        if ((i = t.call(this, "cont", e, s, r, "", l) || this).domain = l ? l.getDomain(null) : R, o && "color" === e) {
          var c = o.source.getColorStops(l, null);
          i.stops = c.stops, i.interpolate = c.interpolate;
        } else i.stops = null, i.interpolate = !1;
        return i;
      }
      return r(e, t), e.prototype.getDomain = function () {
        return this.domain;
      }, e.prototype.getInterpolate = function () {
        return this.interpolate;
      }, e.prototype.getStops = function () {
        return this.stops;
      }, e;
    }(M);
  function z(t, e, n, r) {
    if (!t) return [];
    var o = new Map(),
      i = new Map();
    e.palettes.forEach(function (e) {
      var n = e.slot || r && r(t, e.source.name);
      n && (e instanceof O ? o.set(n, e) : e instanceof E && i.set(n, e));
    });
    var u = [];
    return t.cols.forEach(function (t) {
      var e = t.source;
      if (e.mapped) {
        var r = e.getDataItem(0);
        if (r) switch (r.type) {
          case "cat":
            if (-1 === e.channels.indexOf("color")) return;
            var s = o.get(e.name);
            s && u.push(new L("color", t, t.caption, n.legendShape, s));
            break;
          case "cont":
            if (-1 !== e.channels.indexOf("color")) {
              var a = i.get(e.name);
              a && u.push(new A("color", t, t.caption, a));
            }
            -1 !== e.channels.indexOf("size") && u.push(new A("size", t, t.caption, null));
        }
      }
    }), u;
  }
  var N,
    k = function k() {
      this.legendShape = null, this.slotLimits = new Map(), this.dataLimit = -1;
    };
  !function (t) {
    t.Em = "em", t.Percentage = "%", t.Centimeter = "cm", t.Millimeter = "mm", t.Inch = "in", t.Pica = "pc", t.Point = "pt", t.Pixel = "px";
  }(N || (N = {}));
  var H,
    U,
    V = function () {
      function t(t, e) {
        this.value = t, this.unit = e;
      }
      return t.fromObject = function (e) {
        return new t(e.value, function (t) {
          switch (t) {
            case "em":
              return N.Em;
            case "%":
              return N.Percentage;
            case "cm":
              return N.Centimeter;
            case "mm":
              return N.Millimeter;
            case "in":
              return N.Inch;
            case "pc":
              return N.Pica;
            case "pt":
              return N.Point;
            case "px":
              return N.Pixel;
            default:
              throw new Error("Invalid length unit '" + t + "' specified");
          }
        }(e.unit));
      }, t.prototype.toString = function () {
        return "" + this.value + this.unit;
      }, t;
    }();
  !function (t) {
    t.Normal = "normal", t.Italic = "italic";
  }(H || (H = {})), function (t) {
    t[t.Thin = 100] = "Thin", t[t.ExtraLight = 200] = "ExtraLight", t[t.Light = 300] = "Light", t[t.Normal = 400] = "Normal", t[t.Medium = 500] = "Medium", t[t.SemiBold = 600] = "SemiBold", t[t.Bold = 700] = "Bold", t[t.ExtraBold = 800] = "ExtraBold", t[t.Heavy = 900] = "Heavy";
  }(U || (U = {}));
  var q = /\s+/g;
  function K(t) {
    switch (t) {
      case U.Normal:
        return "normal";
      case U.Bold:
        return "bold";
      case U.Thin:
      case U.ExtraLight:
      case U.Light:
      case U.Medium:
      case U.SemiBold:
      case U.ExtraBold:
      case U.Heavy:
        return t.toString();
      default:
        return "";
    }
  }
  function G(t) {
    var e = [];
    if (t) for (var n = 0, r = t.length; n < r; ++n) {
      var o = t[n],
        i = q.test(o);
      e.push(i ? '"' + o + '"' : o);
    }
    return e.join(", ");
  }
  var J = function () {
      function t(t, e, n, r) {
        this.family = t, this.size = e, this.style = n, this.weight = r;
      }
      return t.fromObject = function (e) {
        return new t(e.family || null, e.size ? V.fromObject(e.size) : null, e.style ? function (t) {
          switch (t) {
            case "normal":
              return H.Normal;
            case "italic":
              return H.Italic;
            default:
              throw new Error("Invalid font style '" + t + "' specified");
          }
        }(e.style) : null, void 0 !== e.weight && null !== e.weight ? e.weight : null);
      }, t.prototype.toString = function () {
        if (this.style !== H.Normal && this.weight !== U.Normal || this.style === H.Normal && this.weight === U.Normal) {
          var t = [];
          return this.style === H.Normal ? t.push("normal") : (this.style && t.push(this.style), this.weight && t.push(K(this.weight))), this.size && t.push(this.size.toString()), this.family && t.push(G(this.family)), t.join(" ");
        }
        return function (t) {
          var e,
            n = [],
            r = G(t.family);
          return r.length > 0 && n.push("font-family: " + r + ";"), (r = t.size ? t.size.toString() : "").length > 0 && n.push("font-size: " + r + ";"), (r = (e = t.style) ? e.toString() : "").length > 0 && n.push("font-style: " + r + ";"), (r = K(t.weight)).length > 0 && n.push("font-weight: " + r + ";"), n.join(" ");
        }(this);
      }, t;
    }(),
    Q = function () {
      function t(t, e, n) {
        var r = new Map();
        null !== t && t.forEach(function (t, o) {
          if ("palette" === t.type) {
            var i = t;
            switch (i.paletteType) {
              case "cat":
                r.set(o, new O(i, e, n));
                break;
              case "cont":
                r.set(o, new E(i, e, n));
            }
          }
        }), this.source = t, this.palettes = r;
      }
      return t.prototype.get = function (t) {
        return this._getValue(t, !1);
      }, t.prototype.peek = function (t) {
        return this._getValue(t, !0);
      }, t.prototype._getValue = function (t, e) {
        var n = this.source && this.source.get(t);
        if (!n) return null;
        switch (n.type) {
          case "string":
          case "number":
          case "boolean":
          case "enum":
            return e ? n.peek : n.value;
          case "length":
            var r = e ? n.peek : n.value;
            return r ? V.fromObject(r) : null;
          case "font":
            var o = e ? n.peek : n.value;
            return o ? J.fromObject(o) : null;
          case "color":
            var i = e ? n.peek : n.value;
            return i ? C.fromObject(i) : null;
          case "palette":
            return this.palettes.get(t) || null;
          default:
            return null;
        }
      }, t.prototype.isActive = function (t) {
        var e = this.source && this.source.get(t);
        return !!e && e.active;
      }, t.prototype.setActive = function (t, e) {
        var n = this.source && this.source.get(t);
        n && n.setActive(e);
      }, t.prototype.isDirty = function (t) {
        var e = this.source && this.source.get(t);
        return !!e && e.dirty;
      }, t;
    }();
  var W = setTimeout;
  function X(t) {
    return Boolean(t && void 0 !== t.length);
  }
  function Y() {}
  function Z(t) {
    if (!(this instanceof Z)) throw new TypeError("Promises must be constructed via new");
    if ("function" != typeof t) throw new TypeError("not a function");
    this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], ot(t, this);
  }
  function $(t, e) {
    for (; 3 === t._state;) t = t._value;
    0 !== t._state ? (t._handled = !0, Z._immediateFn(function () {
      var n = 1 === t._state ? e.onFulfilled : e.onRejected;
      if (null !== n) {
        var r;
        try {
          r = n(t._value);
        } catch (t) {
          return void et(e.promise, t);
        }
        tt(e.promise, r);
      } else (1 === t._state ? tt : et)(e.promise, t._value);
    })) : t._deferreds.push(e);
  }
  function tt(t, e) {
    try {
      if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
      if (e && ("object" == _typeof$1(e) || "function" == typeof e)) {
        var n = e.then;
        if (e instanceof Z) return t._state = 3, t._value = e, void nt(t);
        if ("function" == typeof n) return void ot((r = n, o = e, function () {
          r.apply(o, arguments);
        }), t);
      }
      t._state = 1, t._value = e, nt(t);
    } catch (e) {
      et(t, e);
    }
    var r, o;
  }
  function et(t, e) {
    t._state = 2, t._value = e, nt(t);
  }
  function nt(t) {
    2 === t._state && 0 === t._deferreds.length && Z._immediateFn(function () {
      t._handled || Z._unhandledRejectionFn(t._value);
    });
    for (var e = 0, n = t._deferreds.length; e < n; e++) $(t, t._deferreds[e]);
    t._deferreds = null;
  }
  function rt(t, e, n) {
    this.onFulfilled = "function" == typeof t ? t : null, this.onRejected = "function" == typeof e ? e : null, this.promise = n;
  }
  function ot(t, e) {
    var n = !1;
    try {
      t(function (t) {
        n || (n = !0, tt(e, t));
      }, function (t) {
        n || (n = !0, et(e, t));
      });
    } catch (t) {
      if (n) return;
      n = !0, et(e, t);
    }
  }
  Z.prototype["catch"] = function (t) {
    return this.then(null, t);
  }, Z.prototype.then = function (t, e) {
    var n = new this.constructor(Y);
    return $(this, new rt(t, e, n)), n;
  }, Z.prototype["finally"] = function (t) {
    var e = this.constructor;
    return this.then(function (n) {
      return e.resolve(t()).then(function () {
        return n;
      });
    }, function (n) {
      return e.resolve(t()).then(function () {
        return e.reject(n);
      });
    });
  }, Z.all = function (t) {
    return new Z(function (e, n) {
      if (!X(t)) return n(new TypeError("Promise.all accepts an array"));
      var r = Array.prototype.slice.call(t);
      if (0 === r.length) return e([]);
      var o = r.length;
      function i(t, u) {
        try {
          if (u && ("object" == _typeof$1(u) || "function" == typeof u)) {
            var s = u.then;
            if ("function" == typeof s) return void s.call(u, function (e) {
              i(t, e);
            }, n);
          }
          r[t] = u, 0 == --o && e(r);
        } catch (t) {
          n(t);
        }
      }
      for (var u = 0; u < r.length; u++) i(u, r[u]);
    });
  }, Z.resolve = function (t) {
    return t && "object" == _typeof$1(t) && t.constructor === Z ? t : new Z(function (e) {
      e(t);
    });
  }, Z.reject = function (t) {
    return new Z(function (e, n) {
      n(t);
    });
  }, Z.race = function (t) {
    return new Z(function (e, n) {
      if (!X(t)) return n(new TypeError("Promise.race accepts an array"));
      for (var r = 0, o = t.length; r < o; r++) Z.resolve(t[r]).then(e, n);
    });
  }, Z._immediateFn = "function" == typeof setImmediate && function (t) {
    setImmediate(t);
  } || function (t) {
    W(t, 0);
  }, Z._unhandledRejectionFn = function (t) {
    "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", t);
  };
  var it = function it(t, e, n, r) {
      this.data = t, this.decorations = e, this.properties = n, this.size = r;
    },
    ut = function ut(t, e, n, r, o) {
      this.reason = t, this.data = e, this.node = n, this.props = r, this.locale = o;
    };
  var st = function () {
    function n() {
      this._data = null, this._elem = null, this._nls = null, this._locale = "en-us", this._slotResolver = this.getSlotForPalette.bind(this), this.properties = new Q(null, null, this._slotResolver), this.meta = new k();
    }
    return n.prototype.init = function (t, e) {
      var n = this,
        r = t.surface.appendChild(document.createElement("div"));
      r.setAttribute("style", "left: 0; top: 0; width: 100%; height: 100%; position: absolute"), r.setAttribute("data-charttype", "custom-viz"), this.properties = new Q(t.properties, t.dataContext, this._slotResolver), this._nls = t.nls, this._locale = t.locale, Z.resolve(this.create(r)).then(function (o) {
        n._elem = o || r, t.properties.forEach(function (t, e) {
          return n.updateProperty(e, t.value);
        }), e.complete();
      })["catch"](function (t) {
        e.fail(t);
      });
    }, n.prototype.destroy = function () {}, n.prototype.getPropertyApi = function () {
      return null;
    }, n.prototype.setData = function (t) {
      t && t.dataSets && t.dataSets[0] ? this._data = b(t.dataSets[0]) : this._data = null;
    }, n.prototype.setProperty = function (t, e) {
      this.updateProperty(t, this.properties.peek(t));
    }, n.prototype.getBlockingRequests = function () {
      return null;
    }, n.prototype.render = function (t, e, n) {
      if (!this._elem) return n.complete(null, null, null), null;
      if (!(e.data || e.decorations || e.properties || e.size)) return n.complete(null, null, null), null;
      try {
        var r = this.update(new ut(function (t) {
          return new it(t.data, t.decorations, t.properties, t.size);
        }(e), this._data, this._elem, this.properties, this._locale));
        Z.resolve(r).then(function () {
          return n.complete(null, null, null);
        })["catch"](n.error);
      } catch (t) {
        n.error(t);
      }
      return null;
    }, n.prototype.getEncodings = function () {
      return this._data ? this.updateLegend(this._data) : [];
    }, n.prototype.getCapabilities = function () {
      var t = [];
      return this.meta.slotLimits.forEach(function (n, r) {
        t.push(e.slotLimit(r, n));
      }), this.meta.dataLimit >= 0 && t.push(e.dataLimit(this.meta.dataLimit)), t;
    }, n.prototype.getInteractivity = function () {
      return null;
    }, n.prototype.getVisCoordinate = function (t, e) {
      return e;
    }, n.prototype.getRegionAtPoint = function (t, e) {
      return null;
    }, n.prototype.getItemsAtPoint = function (t, e, n) {
      if (!t || !t.hasOwnProperty("x") || !t.hasOwnProperty("y")) return null;
      var r = t,
        o = document.elementFromPoint(r.x, r.y),
        i = this.hitTest(o, r, e);
      return i && i.source ? [i.source] : [];
    }, n.prototype.getItemsInPolygon = function (t, e) {
      return [];
    }, n.prototype.getAxisItemsAtPoint = function (t, e, n) {
      return [];
    }, n.prototype.getState = function () {
      return null;
    }, n.prototype.setState = function (t) {}, n.prototype.loadCss = function (t) {
      var e = document.createElement("link");
      e.type = "text/css", e.rel = "stylesheet", e.href = this.toUrl(t), document.getElementsByTagName("head")[0].appendChild(e);
    }, n.prototype.toUrl = function (e) {
      return requirejs.toUrl(e);
    }, n.prototype.update = function (t) {}, n.prototype.create = function (t) {}, n.prototype.updateProperty = function (t, e) {}, n.prototype.updateLegend = function (t) {
      return z(t, this.properties, this.meta, this._slotResolver);
    }, n.prototype.getSlotForPalette = function (t, e) {
      return null;
    }, n.prototype.hitTest = function (t, e, n) {
      var r = t && t.__data__;
      return r && r.source ? r : null;
    }, n.prototype.nls = function (t) {
      return this._nls && this._nls.get(t) || "";
    }, n;
  }();

  function ascending$1(a, b) {
    return a < b ? -1 : a > b ? 1 : a >= b ? 0 : NaN;
  }

  function bisector(compare) {
    if (compare.length === 1) compare = ascendingComparator(compare);
    return {
      left: function(a, x, lo, hi) {
        if (lo == null) lo = 0;
        if (hi == null) hi = a.length;
        while (lo < hi) {
          var mid = lo + hi >>> 1;
          if (compare(a[mid], x) < 0) lo = mid + 1;
          else hi = mid;
        }
        return lo;
      },
      right: function(a, x, lo, hi) {
        if (lo == null) lo = 0;
        if (hi == null) hi = a.length;
        while (lo < hi) {
          var mid = lo + hi >>> 1;
          if (compare(a[mid], x) > 0) hi = mid;
          else lo = mid + 1;
        }
        return lo;
      }
    };
  }

  function ascendingComparator(f) {
    return function(d, x) {
      return ascending$1(f(d), x);
    };
  }

  var ascendingBisect = bisector(ascending$1);
  var bisectRight = ascendingBisect.right;

  function sequence(start, stop, step) {
    start = +start, stop = +stop, step = (n = arguments.length) < 2 ? (stop = start, start = 0, 1) : n < 3 ? 1 : +step;

    var i = -1,
        n = Math.max(0, Math.ceil((stop - start) / step)) | 0,
        range = new Array(n);

    while (++i < n) {
      range[i] = start + i * step;
    }

    return range;
  }

  var e10 = Math.sqrt(50),
      e5 = Math.sqrt(10),
      e2 = Math.sqrt(2);

  function tickStep(start, stop, count) {
    var step0 = Math.abs(stop - start) / Math.max(0, count),
        step1 = Math.pow(10, Math.floor(Math.log(step0) / Math.LN10)),
        error = step0 / step1;
    if (error >= e10) step1 *= 10;
    else if (error >= e5) step1 *= 5;
    else if (error >= e2) step1 *= 2;
    return stop < start ? -step1 : step1;
  }

  var slice$1 = Array.prototype.slice;

  function identity$3(x) {
    return x;
  }

  var top = 1,
      right = 2,
      bottom = 3,
      left = 4,
      epsilon = 1e-6;

  function translateX(x) {
    return "translate(" + (x + 0.5) + ",0)";
  }

  function translateY(y) {
    return "translate(0," + (y + 0.5) + ")";
  }

  function number$2(scale) {
    return function(d) {
      return +scale(d);
    };
  }

  function center(scale) {
    var offset = Math.max(0, scale.bandwidth() - 1) / 2; // Adjust for 0.5px offset.
    if (scale.round()) offset = Math.round(offset);
    return function(d) {
      return +scale(d) + offset;
    };
  }

  function entering() {
    return !this.__axis;
  }

  function axis(orient, scale) {
    var tickArguments = [],
        tickValues = null,
        tickFormat = null,
        tickSizeInner = 6,
        tickSizeOuter = 6,
        tickPadding = 3,
        k = orient === top || orient === left ? -1 : 1,
        x = orient === left || orient === right ? "x" : "y",
        transform = orient === top || orient === bottom ? translateX : translateY;

    function axis(context) {
      var values = tickValues == null ? (scale.ticks ? scale.ticks.apply(scale, tickArguments) : scale.domain()) : tickValues,
          format = tickFormat == null ? (scale.tickFormat ? scale.tickFormat.apply(scale, tickArguments) : identity$3) : tickFormat,
          spacing = Math.max(tickSizeInner, 0) + tickPadding,
          range = scale.range(),
          range0 = +range[0] + 0.5,
          range1 = +range[range.length - 1] + 0.5,
          position = (scale.bandwidth ? center : number$2)(scale.copy()),
          selection = context.selection ? context.selection() : context,
          path = selection.selectAll(".domain").data([null]),
          tick = selection.selectAll(".tick").data(values, scale).order(),
          tickExit = tick.exit(),
          tickEnter = tick.enter().append("g").attr("class", "tick"),
          line = tick.select("line"),
          text = tick.select("text");

      path = path.merge(path.enter().insert("path", ".tick")
          .attr("class", "domain")
          .attr("stroke", "currentColor"));

      tick = tick.merge(tickEnter);

      line = line.merge(tickEnter.append("line")
          .attr("stroke", "currentColor")
          .attr(x + "2", k * tickSizeInner));

      text = text.merge(tickEnter.append("text")
          .attr("fill", "currentColor")
          .attr(x, k * spacing)
          .attr("dy", orient === top ? "0em" : orient === bottom ? "0.71em" : "0.32em"));

      if (context !== selection) {
        path = path.transition(context);
        tick = tick.transition(context);
        line = line.transition(context);
        text = text.transition(context);

        tickExit = tickExit.transition(context)
            .attr("opacity", epsilon)
            .attr("transform", function(d) { return isFinite(d = position(d)) ? transform(d) : this.getAttribute("transform"); });

        tickEnter
            .attr("opacity", epsilon)
            .attr("transform", function(d) { var p = this.parentNode.__axis; return transform(p && isFinite(p = p(d)) ? p : position(d)); });
      }

      tickExit.remove();

      path
          .attr("d", orient === left || orient == right
              ? (tickSizeOuter ? "M" + k * tickSizeOuter + "," + range0 + "H0.5V" + range1 + "H" + k * tickSizeOuter : "M0.5," + range0 + "V" + range1)
              : (tickSizeOuter ? "M" + range0 + "," + k * tickSizeOuter + "V0.5H" + range1 + "V" + k * tickSizeOuter : "M" + range0 + ",0.5H" + range1));

      tick
          .attr("opacity", 1)
          .attr("transform", function(d) { return transform(position(d)); });

      line
          .attr(x + "2", k * tickSizeInner);

      text
          .attr(x, k * spacing)
          .text(format);

      selection.filter(entering)
          .attr("fill", "none")
          .attr("font-size", 10)
          .attr("font-family", "sans-serif")
          .attr("text-anchor", orient === right ? "start" : orient === left ? "end" : "middle");

      selection
          .each(function() { this.__axis = position; });
    }

    axis.scale = function(_) {
      return arguments.length ? (scale = _, axis) : scale;
    };

    axis.ticks = function() {
      return tickArguments = slice$1.call(arguments), axis;
    };

    axis.tickArguments = function(_) {
      return arguments.length ? (tickArguments = _ == null ? [] : slice$1.call(_), axis) : tickArguments.slice();
    };

    axis.tickValues = function(_) {
      return arguments.length ? (tickValues = _ == null ? null : slice$1.call(_), axis) : tickValues && tickValues.slice();
    };

    axis.tickFormat = function(_) {
      return arguments.length ? (tickFormat = _, axis) : tickFormat;
    };

    axis.tickSize = function(_) {
      return arguments.length ? (tickSizeInner = tickSizeOuter = +_, axis) : tickSizeInner;
    };

    axis.tickSizeInner = function(_) {
      return arguments.length ? (tickSizeInner = +_, axis) : tickSizeInner;
    };

    axis.tickSizeOuter = function(_) {
      return arguments.length ? (tickSizeOuter = +_, axis) : tickSizeOuter;
    };

    axis.tickPadding = function(_) {
      return arguments.length ? (tickPadding = +_, axis) : tickPadding;
    };

    return axis;
  }

  function axisTop(scale) {
    return axis(top, scale);
  }

  function axisBottom(scale) {
    return axis(bottom, scale);
  }

  function axisLeft(scale) {
    return axis(left, scale);
  }

  var noop = {value: function() {}};

  function dispatch() {
    for (var i = 0, n = arguments.length, _ = {}, t; i < n; ++i) {
      if (!(t = arguments[i] + "") || (t in _) || /[\s.]/.test(t)) throw new Error("illegal type: " + t);
      _[t] = [];
    }
    return new Dispatch(_);
  }

  function Dispatch(_) {
    this._ = _;
  }

  function parseTypenames$1(typenames, types) {
    return typenames.trim().split(/^|\s+/).map(function(t) {
      var name = "", i = t.indexOf(".");
      if (i >= 0) name = t.slice(i + 1), t = t.slice(0, i);
      if (t && !types.hasOwnProperty(t)) throw new Error("unknown type: " + t);
      return {type: t, name: name};
    });
  }

  Dispatch.prototype = dispatch.prototype = {
    constructor: Dispatch,
    on: function(typename, callback) {
      var _ = this._,
          T = parseTypenames$1(typename + "", _),
          t,
          i = -1,
          n = T.length;

      // If no callback was specified, return the callback of the given type and name.
      if (arguments.length < 2) {
        while (++i < n) if ((t = (typename = T[i]).type) && (t = get$1(_[t], typename.name))) return t;
        return;
      }

      // If a type was specified, set the callback for the given type and name.
      // Otherwise, if a null callback was specified, remove callbacks of the given name.
      if (callback != null && typeof callback !== "function") throw new Error("invalid callback: " + callback);
      while (++i < n) {
        if (t = (typename = T[i]).type) _[t] = set$1(_[t], typename.name, callback);
        else if (callback == null) for (t in _) _[t] = set$1(_[t], typename.name, null);
      }

      return this;
    },
    copy: function() {
      var copy = {}, _ = this._;
      for (var t in _) copy[t] = _[t].slice();
      return new Dispatch(copy);
    },
    call: function(type, that) {
      if ((n = arguments.length - 2) > 0) for (var args = new Array(n), i = 0, n, t; i < n; ++i) args[i] = arguments[i + 2];
      if (!this._.hasOwnProperty(type)) throw new Error("unknown type: " + type);
      for (t = this._[type], i = 0, n = t.length; i < n; ++i) t[i].value.apply(that, args);
    },
    apply: function(type, that, args) {
      if (!this._.hasOwnProperty(type)) throw new Error("unknown type: " + type);
      for (var t = this._[type], i = 0, n = t.length; i < n; ++i) t[i].value.apply(that, args);
    }
  };

  function get$1(type, name) {
    for (var i = 0, n = type.length, c; i < n; ++i) {
      if ((c = type[i]).name === name) {
        return c.value;
      }
    }
  }

  function set$1(type, name, callback) {
    for (var i = 0, n = type.length; i < n; ++i) {
      if (type[i].name === name) {
        type[i] = noop, type = type.slice(0, i).concat(type.slice(i + 1));
        break;
      }
    }
    if (callback != null) type.push({name: name, value: callback});
    return type;
  }

  var xhtml = "http://www.w3.org/1999/xhtml";

  var namespaces = {
    svg: "http://www.w3.org/2000/svg",
    xhtml: xhtml,
    xlink: "http://www.w3.org/1999/xlink",
    xml: "http://www.w3.org/XML/1998/namespace",
    xmlns: "http://www.w3.org/2000/xmlns/"
  };

  function namespace(name) {
    var prefix = name += "", i = prefix.indexOf(":");
    if (i >= 0 && (prefix = name.slice(0, i)) !== "xmlns") name = name.slice(i + 1);
    return namespaces.hasOwnProperty(prefix) ? {space: namespaces[prefix], local: name} : name;
  }

  function creatorInherit(name) {
    return function() {
      var document = this.ownerDocument,
          uri = this.namespaceURI;
      return uri === xhtml && document.documentElement.namespaceURI === xhtml
          ? document.createElement(name)
          : document.createElementNS(uri, name);
    };
  }

  function creatorFixed(fullname) {
    return function() {
      return this.ownerDocument.createElementNS(fullname.space, fullname.local);
    };
  }

  function creator(name) {
    var fullname = namespace(name);
    return (fullname.local
        ? creatorFixed
        : creatorInherit)(fullname);
  }

  function none() {}

  function selector(selector) {
    return selector == null ? none : function() {
      return this.querySelector(selector);
    };
  }

  function selection_select(select) {
    if (typeof select !== "function") select = selector(select);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = new Array(n), node, subnode, i = 0; i < n; ++i) {
        if ((node = group[i]) && (subnode = select.call(node, node.__data__, i, group))) {
          if ("__data__" in node) subnode.__data__ = node.__data__;
          subgroup[i] = subnode;
        }
      }
    }

    return new Selection$1(subgroups, this._parents);
  }

  function empty() {
    return [];
  }

  function selectorAll(selector) {
    return selector == null ? empty : function() {
      return this.querySelectorAll(selector);
    };
  }

  function selection_selectAll(select) {
    if (typeof select !== "function") select = selectorAll(select);

    for (var groups = this._groups, m = groups.length, subgroups = [], parents = [], j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          subgroups.push(select.call(node, node.__data__, i, group));
          parents.push(node);
        }
      }
    }

    return new Selection$1(subgroups, parents);
  }

  function matcher(selector) {
    return function() {
      return this.matches(selector);
    };
  }

  function selection_filter(match) {
    if (typeof match !== "function") match = matcher(match);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = [], node, i = 0; i < n; ++i) {
        if ((node = group[i]) && match.call(node, node.__data__, i, group)) {
          subgroup.push(node);
        }
      }
    }

    return new Selection$1(subgroups, this._parents);
  }

  function sparse(update) {
    return new Array(update.length);
  }

  function selection_enter() {
    return new Selection$1(this._enter || this._groups.map(sparse), this._parents);
  }

  function EnterNode(parent, datum) {
    this.ownerDocument = parent.ownerDocument;
    this.namespaceURI = parent.namespaceURI;
    this._next = null;
    this._parent = parent;
    this.__data__ = datum;
  }

  EnterNode.prototype = {
    constructor: EnterNode,
    appendChild: function(child) { return this._parent.insertBefore(child, this._next); },
    insertBefore: function(child, next) { return this._parent.insertBefore(child, next); },
    querySelector: function(selector) { return this._parent.querySelector(selector); },
    querySelectorAll: function(selector) { return this._parent.querySelectorAll(selector); }
  };

  function constant$3(x) {
    return function() {
      return x;
    };
  }

  var keyPrefix = "$"; // Protect against keys like “__proto__”.

  function bindIndex(parent, group, enter, update, exit, data) {
    var i = 0,
        node,
        groupLength = group.length,
        dataLength = data.length;

    // Put any non-null nodes that fit into update.
    // Put any null nodes into enter.
    // Put any remaining data into enter.
    for (; i < dataLength; ++i) {
      if (node = group[i]) {
        node.__data__ = data[i];
        update[i] = node;
      } else {
        enter[i] = new EnterNode(parent, data[i]);
      }
    }

    // Put any non-null nodes that don’t fit into exit.
    for (; i < groupLength; ++i) {
      if (node = group[i]) {
        exit[i] = node;
      }
    }
  }

  function bindKey(parent, group, enter, update, exit, data, key) {
    var i,
        node,
        nodeByKeyValue = {},
        groupLength = group.length,
        dataLength = data.length,
        keyValues = new Array(groupLength),
        keyValue;

    // Compute the key for each node.
    // If multiple nodes have the same key, the duplicates are added to exit.
    for (i = 0; i < groupLength; ++i) {
      if (node = group[i]) {
        keyValues[i] = keyValue = keyPrefix + key.call(node, node.__data__, i, group);
        if (keyValue in nodeByKeyValue) {
          exit[i] = node;
        } else {
          nodeByKeyValue[keyValue] = node;
        }
      }
    }

    // Compute the key for each datum.
    // If there a node associated with this key, join and add it to update.
    // If there is not (or the key is a duplicate), add it to enter.
    for (i = 0; i < dataLength; ++i) {
      keyValue = keyPrefix + key.call(parent, data[i], i, data);
      if (node = nodeByKeyValue[keyValue]) {
        update[i] = node;
        node.__data__ = data[i];
        nodeByKeyValue[keyValue] = null;
      } else {
        enter[i] = new EnterNode(parent, data[i]);
      }
    }

    // Add any remaining nodes that were not bound to data to exit.
    for (i = 0; i < groupLength; ++i) {
      if ((node = group[i]) && (nodeByKeyValue[keyValues[i]] === node)) {
        exit[i] = node;
      }
    }
  }

  function selection_data(value, key) {
    if (!value) {
      data = new Array(this.size()), j = -1;
      this.each(function(d) { data[++j] = d; });
      return data;
    }

    var bind = key ? bindKey : bindIndex,
        parents = this._parents,
        groups = this._groups;

    if (typeof value !== "function") value = constant$3(value);

    for (var m = groups.length, update = new Array(m), enter = new Array(m), exit = new Array(m), j = 0; j < m; ++j) {
      var parent = parents[j],
          group = groups[j],
          groupLength = group.length,
          data = value.call(parent, parent && parent.__data__, j, parents),
          dataLength = data.length,
          enterGroup = enter[j] = new Array(dataLength),
          updateGroup = update[j] = new Array(dataLength),
          exitGroup = exit[j] = new Array(groupLength);

      bind(parent, group, enterGroup, updateGroup, exitGroup, data, key);

      // Now connect the enter nodes to their following update node, such that
      // appendChild can insert the materialized enter node before this node,
      // rather than at the end of the parent node.
      for (var i0 = 0, i1 = 0, previous, next; i0 < dataLength; ++i0) {
        if (previous = enterGroup[i0]) {
          if (i0 >= i1) i1 = i0 + 1;
          while (!(next = updateGroup[i1]) && ++i1 < dataLength);
          previous._next = next || null;
        }
      }
    }

    update = new Selection$1(update, parents);
    update._enter = enter;
    update._exit = exit;
    return update;
  }

  function selection_exit() {
    return new Selection$1(this._exit || this._groups.map(sparse), this._parents);
  }

  function selection_join(onenter, onupdate, onexit) {
    var enter = this.enter(), update = this, exit = this.exit();
    enter = typeof onenter === "function" ? onenter(enter) : enter.append(onenter + "");
    if (onupdate != null) update = onupdate(update);
    if (onexit == null) exit.remove(); else onexit(exit);
    return enter && update ? enter.merge(update).order() : update;
  }

  function selection_merge(selection) {

    for (var groups0 = this._groups, groups1 = selection._groups, m0 = groups0.length, m1 = groups1.length, m = Math.min(m0, m1), merges = new Array(m0), j = 0; j < m; ++j) {
      for (var group0 = groups0[j], group1 = groups1[j], n = group0.length, merge = merges[j] = new Array(n), node, i = 0; i < n; ++i) {
        if (node = group0[i] || group1[i]) {
          merge[i] = node;
        }
      }
    }

    for (; j < m0; ++j) {
      merges[j] = groups0[j];
    }

    return new Selection$1(merges, this._parents);
  }

  function selection_order() {

    for (var groups = this._groups, j = -1, m = groups.length; ++j < m;) {
      for (var group = groups[j], i = group.length - 1, next = group[i], node; --i >= 0;) {
        if (node = group[i]) {
          if (next && node.compareDocumentPosition(next) ^ 4) next.parentNode.insertBefore(node, next);
          next = node;
        }
      }
    }

    return this;
  }

  function selection_sort(compare) {
    if (!compare) compare = ascending;

    function compareNode(a, b) {
      return a && b ? compare(a.__data__, b.__data__) : !a - !b;
    }

    for (var groups = this._groups, m = groups.length, sortgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, sortgroup = sortgroups[j] = new Array(n), node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          sortgroup[i] = node;
        }
      }
      sortgroup.sort(compareNode);
    }

    return new Selection$1(sortgroups, this._parents).order();
  }

  function ascending(a, b) {
    return a < b ? -1 : a > b ? 1 : a >= b ? 0 : NaN;
  }

  function selection_call() {
    var callback = arguments[0];
    arguments[0] = this;
    callback.apply(null, arguments);
    return this;
  }

  function selection_nodes() {
    var nodes = new Array(this.size()), i = -1;
    this.each(function() { nodes[++i] = this; });
    return nodes;
  }

  function selection_node() {

    for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
      for (var group = groups[j], i = 0, n = group.length; i < n; ++i) {
        var node = group[i];
        if (node) return node;
      }
    }

    return null;
  }

  function selection_size() {
    var size = 0;
    this.each(function() { ++size; });
    return size;
  }

  function selection_empty() {
    return !this.node();
  }

  function selection_each(callback) {

    for (var groups = this._groups, j = 0, m = groups.length; j < m; ++j) {
      for (var group = groups[j], i = 0, n = group.length, node; i < n; ++i) {
        if (node = group[i]) callback.call(node, node.__data__, i, group);
      }
    }

    return this;
  }

  function attrRemove$1(name) {
    return function() {
      this.removeAttribute(name);
    };
  }

  function attrRemoveNS$1(fullname) {
    return function() {
      this.removeAttributeNS(fullname.space, fullname.local);
    };
  }

  function attrConstant$1(name, value) {
    return function() {
      this.setAttribute(name, value);
    };
  }

  function attrConstantNS$1(fullname, value) {
    return function() {
      this.setAttributeNS(fullname.space, fullname.local, value);
    };
  }

  function attrFunction$1(name, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) this.removeAttribute(name);
      else this.setAttribute(name, v);
    };
  }

  function attrFunctionNS$1(fullname, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) this.removeAttributeNS(fullname.space, fullname.local);
      else this.setAttributeNS(fullname.space, fullname.local, v);
    };
  }

  function selection_attr(name, value) {
    var fullname = namespace(name);

    if (arguments.length < 2) {
      var node = this.node();
      return fullname.local
          ? node.getAttributeNS(fullname.space, fullname.local)
          : node.getAttribute(fullname);
    }

    return this.each((value == null
        ? (fullname.local ? attrRemoveNS$1 : attrRemove$1) : (typeof value === "function"
        ? (fullname.local ? attrFunctionNS$1 : attrFunction$1)
        : (fullname.local ? attrConstantNS$1 : attrConstant$1)))(fullname, value));
  }

  function defaultView(node) {
    return (node.ownerDocument && node.ownerDocument.defaultView) // node is a Node
        || (node.document && node) // node is a Window
        || node.defaultView; // node is a Document
  }

  function styleRemove$1(name) {
    return function() {
      this.style.removeProperty(name);
    };
  }

  function styleConstant$1(name, value, priority) {
    return function() {
      this.style.setProperty(name, value, priority);
    };
  }

  function styleFunction$1(name, value, priority) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) this.style.removeProperty(name);
      else this.style.setProperty(name, v, priority);
    };
  }

  function selection_style(name, value, priority) {
    return arguments.length > 1
        ? this.each((value == null
              ? styleRemove$1 : typeof value === "function"
              ? styleFunction$1
              : styleConstant$1)(name, value, priority == null ? "" : priority))
        : styleValue(this.node(), name);
  }

  function styleValue(node, name) {
    return node.style.getPropertyValue(name)
        || defaultView(node).getComputedStyle(node, null).getPropertyValue(name);
  }

  function propertyRemove(name) {
    return function() {
      delete this[name];
    };
  }

  function propertyConstant(name, value) {
    return function() {
      this[name] = value;
    };
  }

  function propertyFunction(name, value) {
    return function() {
      var v = value.apply(this, arguments);
      if (v == null) delete this[name];
      else this[name] = v;
    };
  }

  function selection_property(name, value) {
    return arguments.length > 1
        ? this.each((value == null
            ? propertyRemove : typeof value === "function"
            ? propertyFunction
            : propertyConstant)(name, value))
        : this.node()[name];
  }

  function classArray(string) {
    return string.trim().split(/^|\s+/);
  }

  function classList(node) {
    return node.classList || new ClassList(node);
  }

  function ClassList(node) {
    this._node = node;
    this._names = classArray(node.getAttribute("class") || "");
  }

  ClassList.prototype = {
    add: function(name) {
      var i = this._names.indexOf(name);
      if (i < 0) {
        this._names.push(name);
        this._node.setAttribute("class", this._names.join(" "));
      }
    },
    remove: function(name) {
      var i = this._names.indexOf(name);
      if (i >= 0) {
        this._names.splice(i, 1);
        this._node.setAttribute("class", this._names.join(" "));
      }
    },
    contains: function(name) {
      return this._names.indexOf(name) >= 0;
    }
  };

  function classedAdd(node, names) {
    var list = classList(node), i = -1, n = names.length;
    while (++i < n) list.add(names[i]);
  }

  function classedRemove(node, names) {
    var list = classList(node), i = -1, n = names.length;
    while (++i < n) list.remove(names[i]);
  }

  function classedTrue(names) {
    return function() {
      classedAdd(this, names);
    };
  }

  function classedFalse(names) {
    return function() {
      classedRemove(this, names);
    };
  }

  function classedFunction(names, value) {
    return function() {
      (value.apply(this, arguments) ? classedAdd : classedRemove)(this, names);
    };
  }

  function selection_classed(name, value) {
    var names = classArray(name + "");

    if (arguments.length < 2) {
      var list = classList(this.node()), i = -1, n = names.length;
      while (++i < n) if (!list.contains(names[i])) return false;
      return true;
    }

    return this.each((typeof value === "function"
        ? classedFunction : value
        ? classedTrue
        : classedFalse)(names, value));
  }

  function textRemove() {
    this.textContent = "";
  }

  function textConstant$1(value) {
    return function() {
      this.textContent = value;
    };
  }

  function textFunction$1(value) {
    return function() {
      var v = value.apply(this, arguments);
      this.textContent = v == null ? "" : v;
    };
  }

  function selection_text(value) {
    return arguments.length
        ? this.each(value == null
            ? textRemove : (typeof value === "function"
            ? textFunction$1
            : textConstant$1)(value))
        : this.node().textContent;
  }

  function htmlRemove() {
    this.innerHTML = "";
  }

  function htmlConstant(value) {
    return function() {
      this.innerHTML = value;
    };
  }

  function htmlFunction(value) {
    return function() {
      var v = value.apply(this, arguments);
      this.innerHTML = v == null ? "" : v;
    };
  }

  function selection_html(value) {
    return arguments.length
        ? this.each(value == null
            ? htmlRemove : (typeof value === "function"
            ? htmlFunction
            : htmlConstant)(value))
        : this.node().innerHTML;
  }

  function raise() {
    if (this.nextSibling) this.parentNode.appendChild(this);
  }

  function selection_raise() {
    return this.each(raise);
  }

  function lower() {
    if (this.previousSibling) this.parentNode.insertBefore(this, this.parentNode.firstChild);
  }

  function selection_lower() {
    return this.each(lower);
  }

  function selection_append(name) {
    var create = typeof name === "function" ? name : creator(name);
    return this.select(function() {
      return this.appendChild(create.apply(this, arguments));
    });
  }

  function constantNull() {
    return null;
  }

  function selection_insert(name, before) {
    var create = typeof name === "function" ? name : creator(name),
        select = before == null ? constantNull : typeof before === "function" ? before : selector(before);
    return this.select(function() {
      return this.insertBefore(create.apply(this, arguments), select.apply(this, arguments) || null);
    });
  }

  function remove() {
    var parent = this.parentNode;
    if (parent) parent.removeChild(this);
  }

  function selection_remove() {
    return this.each(remove);
  }

  function selection_cloneShallow() {
    var clone = this.cloneNode(false), parent = this.parentNode;
    return parent ? parent.insertBefore(clone, this.nextSibling) : clone;
  }

  function selection_cloneDeep() {
    var clone = this.cloneNode(true), parent = this.parentNode;
    return parent ? parent.insertBefore(clone, this.nextSibling) : clone;
  }

  function selection_clone(deep) {
    return this.select(deep ? selection_cloneDeep : selection_cloneShallow);
  }

  function selection_datum(value) {
    return arguments.length
        ? this.property("__data__", value)
        : this.node().__data__;
  }

  var filterEvents = {};

  var event = null;

  if (typeof document !== "undefined") {
    var element = document.documentElement;
    if (!("onmouseenter" in element)) {
      filterEvents = {mouseenter: "mouseover", mouseleave: "mouseout"};
    }
  }

  function filterContextListener(listener, index, group) {
    listener = contextListener(listener, index, group);
    return function(event) {
      var related = event.relatedTarget;
      if (!related || (related !== this && !(related.compareDocumentPosition(this) & 8))) {
        listener.call(this, event);
      }
    };
  }

  function contextListener(listener, index, group) {
    return function(event1) {
      var event0 = event; // Events can be reentrant (e.g., focus).
      event = event1;
      try {
        listener.call(this, this.__data__, index, group);
      } finally {
        event = event0;
      }
    };
  }

  function parseTypenames(typenames) {
    return typenames.trim().split(/^|\s+/).map(function(t) {
      var name = "", i = t.indexOf(".");
      if (i >= 0) name = t.slice(i + 1), t = t.slice(0, i);
      return {type: t, name: name};
    });
  }

  function onRemove(typename) {
    return function() {
      var on = this.__on;
      if (!on) return;
      for (var j = 0, i = -1, m = on.length, o; j < m; ++j) {
        if (o = on[j], (!typename.type || o.type === typename.type) && o.name === typename.name) {
          this.removeEventListener(o.type, o.listener, o.capture);
        } else {
          on[++i] = o;
        }
      }
      if (++i) on.length = i;
      else delete this.__on;
    };
  }

  function onAdd(typename, value, capture) {
    var wrap = filterEvents.hasOwnProperty(typename.type) ? filterContextListener : contextListener;
    return function(d, i, group) {
      var on = this.__on, o, listener = wrap(value, i, group);
      if (on) for (var j = 0, m = on.length; j < m; ++j) {
        if ((o = on[j]).type === typename.type && o.name === typename.name) {
          this.removeEventListener(o.type, o.listener, o.capture);
          this.addEventListener(o.type, o.listener = listener, o.capture = capture);
          o.value = value;
          return;
        }
      }
      this.addEventListener(typename.type, listener, capture);
      o = {type: typename.type, name: typename.name, value: value, listener: listener, capture: capture};
      if (!on) this.__on = [o];
      else on.push(o);
    };
  }

  function selection_on(typename, value, capture) {
    var typenames = parseTypenames(typename + ""), i, n = typenames.length, t;

    if (arguments.length < 2) {
      var on = this.node().__on;
      if (on) for (var j = 0, m = on.length, o; j < m; ++j) {
        for (i = 0, o = on[j]; i < n; ++i) {
          if ((t = typenames[i]).type === o.type && t.name === o.name) {
            return o.value;
          }
        }
      }
      return;
    }

    on = value ? onAdd : onRemove;
    if (capture == null) capture = false;
    for (i = 0; i < n; ++i) this.each(on(typenames[i], value, capture));
    return this;
  }

  function customEvent(event1, listener, that, args) {
    var event0 = event;
    event1.sourceEvent = event;
    event = event1;
    try {
      return listener.apply(that, args);
    } finally {
      event = event0;
    }
  }

  function dispatchEvent(node, type, params) {
    var window = defaultView(node),
        event = window.CustomEvent;

    if (typeof event === "function") {
      event = new event(type, params);
    } else {
      event = window.document.createEvent("Event");
      if (params) event.initEvent(type, params.bubbles, params.cancelable), event.detail = params.detail;
      else event.initEvent(type, false, false);
    }

    node.dispatchEvent(event);
  }

  function dispatchConstant(type, params) {
    return function() {
      return dispatchEvent(this, type, params);
    };
  }

  function dispatchFunction(type, params) {
    return function() {
      return dispatchEvent(this, type, params.apply(this, arguments));
    };
  }

  function selection_dispatch(type, params) {
    return this.each((typeof params === "function"
        ? dispatchFunction
        : dispatchConstant)(type, params));
  }

  var root = [null];

  function Selection$1(groups, parents) {
    this._groups = groups;
    this._parents = parents;
  }

  function selection() {
    return new Selection$1([[document.documentElement]], root);
  }

  Selection$1.prototype = selection.prototype = {
    constructor: Selection$1,
    select: selection_select,
    selectAll: selection_selectAll,
    filter: selection_filter,
    data: selection_data,
    enter: selection_enter,
    exit: selection_exit,
    join: selection_join,
    merge: selection_merge,
    order: selection_order,
    sort: selection_sort,
    call: selection_call,
    nodes: selection_nodes,
    node: selection_node,
    size: selection_size,
    empty: selection_empty,
    each: selection_each,
    attr: selection_attr,
    style: selection_style,
    property: selection_property,
    classed: selection_classed,
    text: selection_text,
    html: selection_html,
    raise: selection_raise,
    lower: selection_lower,
    append: selection_append,
    insert: selection_insert,
    remove: selection_remove,
    clone: selection_clone,
    datum: selection_datum,
    on: selection_on,
    dispatch: selection_dispatch
  };

  function select(selector) {
    return typeof selector === "string"
        ? new Selection$1([[document.querySelector(selector)]], [document.documentElement])
        : new Selection$1([[selector]], root);
  }

  function sourceEvent() {
    var current = event, source;
    while (source = current.sourceEvent) current = source;
    return current;
  }

  function point(node, event) {
    var svg = node.ownerSVGElement || node;

    if (svg.createSVGPoint) {
      var point = svg.createSVGPoint();
      point.x = event.clientX, point.y = event.clientY;
      point = point.matrixTransform(node.getScreenCTM().inverse());
      return [point.x, point.y];
    }

    var rect = node.getBoundingClientRect();
    return [event.clientX - rect.left - node.clientLeft, event.clientY - rect.top - node.clientTop];
  }

  function mouse(node) {
    var event = sourceEvent();
    if (event.changedTouches) event = event.changedTouches[0];
    return point(node, event);
  }

  function touch(node, touches, identifier) {
    if (arguments.length < 3) identifier = touches, touches = sourceEvent().changedTouches;

    for (var i = 0, n = touches ? touches.length : 0, touch; i < n; ++i) {
      if ((touch = touches[i]).identifier === identifier) {
        return point(node, touch);
      }
    }

    return null;
  }

  function noevent$1() {
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  function dragDisable(view) {
    var root = view.document.documentElement,
        selection = select(view).on("dragstart.drag", noevent$1, true);
    if ("onselectstart" in root) {
      selection.on("selectstart.drag", noevent$1, true);
    } else {
      root.__noselect = root.style.MozUserSelect;
      root.style.MozUserSelect = "none";
    }
  }

  function yesdrag(view, noclick) {
    var root = view.document.documentElement,
        selection = select(view).on("dragstart.drag", null);
    if (noclick) {
      selection.on("click.drag", noevent$1, true);
      setTimeout(function() { selection.on("click.drag", null); }, 0);
    }
    if ("onselectstart" in root) {
      selection.on("selectstart.drag", null);
    } else {
      root.style.MozUserSelect = root.__noselect;
      delete root.__noselect;
    }
  }

  function define(constructor, factory, prototype) {
    constructor.prototype = factory.prototype = prototype;
    prototype.constructor = constructor;
  }

  function extend(parent, definition) {
    var prototype = Object.create(parent.prototype);
    for (var key in definition) prototype[key] = definition[key];
    return prototype;
  }

  function Color() {}

  var darker = 0.7;
  var brighter = 1 / darker;

  var reI = "\\s*([+-]?\\d+)\\s*",
      reN = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
      reP = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
      reHex = /^#([0-9a-f]{3,8})$/,
      reRgbInteger = new RegExp("^rgb\\(" + [reI, reI, reI] + "\\)$"),
      reRgbPercent = new RegExp("^rgb\\(" + [reP, reP, reP] + "\\)$"),
      reRgbaInteger = new RegExp("^rgba\\(" + [reI, reI, reI, reN] + "\\)$"),
      reRgbaPercent = new RegExp("^rgba\\(" + [reP, reP, reP, reN] + "\\)$"),
      reHslPercent = new RegExp("^hsl\\(" + [reN, reP, reP] + "\\)$"),
      reHslaPercent = new RegExp("^hsla\\(" + [reN, reP, reP, reN] + "\\)$");

  var named = {
    aliceblue: 0xf0f8ff,
    antiquewhite: 0xfaebd7,
    aqua: 0x00ffff,
    aquamarine: 0x7fffd4,
    azure: 0xf0ffff,
    beige: 0xf5f5dc,
    bisque: 0xffe4c4,
    black: 0x000000,
    blanchedalmond: 0xffebcd,
    blue: 0x0000ff,
    blueviolet: 0x8a2be2,
    brown: 0xa52a2a,
    burlywood: 0xdeb887,
    cadetblue: 0x5f9ea0,
    chartreuse: 0x7fff00,
    chocolate: 0xd2691e,
    coral: 0xff7f50,
    cornflowerblue: 0x6495ed,
    cornsilk: 0xfff8dc,
    crimson: 0xdc143c,
    cyan: 0x00ffff,
    darkblue: 0x00008b,
    darkcyan: 0x008b8b,
    darkgoldenrod: 0xb8860b,
    darkgray: 0xa9a9a9,
    darkgreen: 0x006400,
    darkgrey: 0xa9a9a9,
    darkkhaki: 0xbdb76b,
    darkmagenta: 0x8b008b,
    darkolivegreen: 0x556b2f,
    darkorange: 0xff8c00,
    darkorchid: 0x9932cc,
    darkred: 0x8b0000,
    darksalmon: 0xe9967a,
    darkseagreen: 0x8fbc8f,
    darkslateblue: 0x483d8b,
    darkslategray: 0x2f4f4f,
    darkslategrey: 0x2f4f4f,
    darkturquoise: 0x00ced1,
    darkviolet: 0x9400d3,
    deeppink: 0xff1493,
    deepskyblue: 0x00bfff,
    dimgray: 0x696969,
    dimgrey: 0x696969,
    dodgerblue: 0x1e90ff,
    firebrick: 0xb22222,
    floralwhite: 0xfffaf0,
    forestgreen: 0x228b22,
    fuchsia: 0xff00ff,
    gainsboro: 0xdcdcdc,
    ghostwhite: 0xf8f8ff,
    gold: 0xffd700,
    goldenrod: 0xdaa520,
    gray: 0x808080,
    green: 0x008000,
    greenyellow: 0xadff2f,
    grey: 0x808080,
    honeydew: 0xf0fff0,
    hotpink: 0xff69b4,
    indianred: 0xcd5c5c,
    indigo: 0x4b0082,
    ivory: 0xfffff0,
    khaki: 0xf0e68c,
    lavender: 0xe6e6fa,
    lavenderblush: 0xfff0f5,
    lawngreen: 0x7cfc00,
    lemonchiffon: 0xfffacd,
    lightblue: 0xadd8e6,
    lightcoral: 0xf08080,
    lightcyan: 0xe0ffff,
    lightgoldenrodyellow: 0xfafad2,
    lightgray: 0xd3d3d3,
    lightgreen: 0x90ee90,
    lightgrey: 0xd3d3d3,
    lightpink: 0xffb6c1,
    lightsalmon: 0xffa07a,
    lightseagreen: 0x20b2aa,
    lightskyblue: 0x87cefa,
    lightslategray: 0x778899,
    lightslategrey: 0x778899,
    lightsteelblue: 0xb0c4de,
    lightyellow: 0xffffe0,
    lime: 0x00ff00,
    limegreen: 0x32cd32,
    linen: 0xfaf0e6,
    magenta: 0xff00ff,
    maroon: 0x800000,
    mediumaquamarine: 0x66cdaa,
    mediumblue: 0x0000cd,
    mediumorchid: 0xba55d3,
    mediumpurple: 0x9370db,
    mediumseagreen: 0x3cb371,
    mediumslateblue: 0x7b68ee,
    mediumspringgreen: 0x00fa9a,
    mediumturquoise: 0x48d1cc,
    mediumvioletred: 0xc71585,
    midnightblue: 0x191970,
    mintcream: 0xf5fffa,
    mistyrose: 0xffe4e1,
    moccasin: 0xffe4b5,
    navajowhite: 0xffdead,
    navy: 0x000080,
    oldlace: 0xfdf5e6,
    olive: 0x808000,
    olivedrab: 0x6b8e23,
    orange: 0xffa500,
    orangered: 0xff4500,
    orchid: 0xda70d6,
    palegoldenrod: 0xeee8aa,
    palegreen: 0x98fb98,
    paleturquoise: 0xafeeee,
    palevioletred: 0xdb7093,
    papayawhip: 0xffefd5,
    peachpuff: 0xffdab9,
    peru: 0xcd853f,
    pink: 0xffc0cb,
    plum: 0xdda0dd,
    powderblue: 0xb0e0e6,
    purple: 0x800080,
    rebeccapurple: 0x663399,
    red: 0xff0000,
    rosybrown: 0xbc8f8f,
    royalblue: 0x4169e1,
    saddlebrown: 0x8b4513,
    salmon: 0xfa8072,
    sandybrown: 0xf4a460,
    seagreen: 0x2e8b57,
    seashell: 0xfff5ee,
    sienna: 0xa0522d,
    silver: 0xc0c0c0,
    skyblue: 0x87ceeb,
    slateblue: 0x6a5acd,
    slategray: 0x708090,
    slategrey: 0x708090,
    snow: 0xfffafa,
    springgreen: 0x00ff7f,
    steelblue: 0x4682b4,
    tan: 0xd2b48c,
    teal: 0x008080,
    thistle: 0xd8bfd8,
    tomato: 0xff6347,
    turquoise: 0x40e0d0,
    violet: 0xee82ee,
    wheat: 0xf5deb3,
    white: 0xffffff,
    whitesmoke: 0xf5f5f5,
    yellow: 0xffff00,
    yellowgreen: 0x9acd32
  };

  define(Color, color, {
    copy: function(channels) {
      return Object.assign(new this.constructor, this, channels);
    },
    displayable: function() {
      return this.rgb().displayable();
    },
    hex: color_formatHex, // Deprecated! Use color.formatHex.
    formatHex: color_formatHex,
    formatHsl: color_formatHsl,
    formatRgb: color_formatRgb,
    toString: color_formatRgb
  });

  function color_formatHex() {
    return this.rgb().formatHex();
  }

  function color_formatHsl() {
    return hslConvert(this).formatHsl();
  }

  function color_formatRgb() {
    return this.rgb().formatRgb();
  }

  function color(format) {
    var m, l;
    format = (format + "").trim().toLowerCase();
    return (m = reHex.exec(format)) ? (l = m[1].length, m = parseInt(m[1], 16), l === 6 ? rgbn(m) // #ff0000
        : l === 3 ? new Rgb((m >> 8 & 0xf) | (m >> 4 & 0xf0), (m >> 4 & 0xf) | (m & 0xf0), ((m & 0xf) << 4) | (m & 0xf), 1) // #f00
        : l === 8 ? rgba(m >> 24 & 0xff, m >> 16 & 0xff, m >> 8 & 0xff, (m & 0xff) / 0xff) // #ff000000
        : l === 4 ? rgba((m >> 12 & 0xf) | (m >> 8 & 0xf0), (m >> 8 & 0xf) | (m >> 4 & 0xf0), (m >> 4 & 0xf) | (m & 0xf0), (((m & 0xf) << 4) | (m & 0xf)) / 0xff) // #f000
        : null) // invalid hex
        : (m = reRgbInteger.exec(format)) ? new Rgb(m[1], m[2], m[3], 1) // rgb(255, 0, 0)
        : (m = reRgbPercent.exec(format)) ? new Rgb(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, 1) // rgb(100%, 0%, 0%)
        : (m = reRgbaInteger.exec(format)) ? rgba(m[1], m[2], m[3], m[4]) // rgba(255, 0, 0, 1)
        : (m = reRgbaPercent.exec(format)) ? rgba(m[1] * 255 / 100, m[2] * 255 / 100, m[3] * 255 / 100, m[4]) // rgb(100%, 0%, 0%, 1)
        : (m = reHslPercent.exec(format)) ? hsla(m[1], m[2] / 100, m[3] / 100, 1) // hsl(120, 50%, 50%)
        : (m = reHslaPercent.exec(format)) ? hsla(m[1], m[2] / 100, m[3] / 100, m[4]) // hsla(120, 50%, 50%, 1)
        : named.hasOwnProperty(format) ? rgbn(named[format]) // eslint-disable-line no-prototype-builtins
        : format === "transparent" ? new Rgb(NaN, NaN, NaN, 0)
        : null;
  }

  function rgbn(n) {
    return new Rgb(n >> 16 & 0xff, n >> 8 & 0xff, n & 0xff, 1);
  }

  function rgba(r, g, b, a) {
    if (a <= 0) r = g = b = NaN;
    return new Rgb(r, g, b, a);
  }

  function rgbConvert(o) {
    if (!(o instanceof Color)) o = color(o);
    if (!o) return new Rgb;
    o = o.rgb();
    return new Rgb(o.r, o.g, o.b, o.opacity);
  }

  function rgb(r, g, b, opacity) {
    return arguments.length === 1 ? rgbConvert(r) : new Rgb(r, g, b, opacity == null ? 1 : opacity);
  }

  function Rgb(r, g, b, opacity) {
    this.r = +r;
    this.g = +g;
    this.b = +b;
    this.opacity = +opacity;
  }

  define(Rgb, rgb, extend(Color, {
    brighter: function(k) {
      k = k == null ? brighter : Math.pow(brighter, k);
      return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
    },
    darker: function(k) {
      k = k == null ? darker : Math.pow(darker, k);
      return new Rgb(this.r * k, this.g * k, this.b * k, this.opacity);
    },
    rgb: function() {
      return this;
    },
    displayable: function() {
      return (-0.5 <= this.r && this.r < 255.5)
          && (-0.5 <= this.g && this.g < 255.5)
          && (-0.5 <= this.b && this.b < 255.5)
          && (0 <= this.opacity && this.opacity <= 1);
    },
    hex: rgb_formatHex, // Deprecated! Use color.formatHex.
    formatHex: rgb_formatHex,
    formatRgb: rgb_formatRgb,
    toString: rgb_formatRgb
  }));

  function rgb_formatHex() {
    return "#" + hex(this.r) + hex(this.g) + hex(this.b);
  }

  function rgb_formatRgb() {
    var a = this.opacity; a = isNaN(a) ? 1 : Math.max(0, Math.min(1, a));
    return (a === 1 ? "rgb(" : "rgba(")
        + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", "
        + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", "
        + Math.max(0, Math.min(255, Math.round(this.b) || 0))
        + (a === 1 ? ")" : ", " + a + ")");
  }

  function hex(value) {
    value = Math.max(0, Math.min(255, Math.round(value) || 0));
    return (value < 16 ? "0" : "") + value.toString(16);
  }

  function hsla(h, s, l, a) {
    if (a <= 0) h = s = l = NaN;
    else if (l <= 0 || l >= 1) h = s = NaN;
    else if (s <= 0) h = NaN;
    return new Hsl(h, s, l, a);
  }

  function hslConvert(o) {
    if (o instanceof Hsl) return new Hsl(o.h, o.s, o.l, o.opacity);
    if (!(o instanceof Color)) o = color(o);
    if (!o) return new Hsl;
    if (o instanceof Hsl) return o;
    o = o.rgb();
    var r = o.r / 255,
        g = o.g / 255,
        b = o.b / 255,
        min = Math.min(r, g, b),
        max = Math.max(r, g, b),
        h = NaN,
        s = max - min,
        l = (max + min) / 2;
    if (s) {
      if (r === max) h = (g - b) / s + (g < b) * 6;
      else if (g === max) h = (b - r) / s + 2;
      else h = (r - g) / s + 4;
      s /= l < 0.5 ? max + min : 2 - max - min;
      h *= 60;
    } else {
      s = l > 0 && l < 1 ? 0 : h;
    }
    return new Hsl(h, s, l, o.opacity);
  }

  function hsl(h, s, l, opacity) {
    return arguments.length === 1 ? hslConvert(h) : new Hsl(h, s, l, opacity == null ? 1 : opacity);
  }

  function Hsl(h, s, l, opacity) {
    this.h = +h;
    this.s = +s;
    this.l = +l;
    this.opacity = +opacity;
  }

  define(Hsl, hsl, extend(Color, {
    brighter: function(k) {
      k = k == null ? brighter : Math.pow(brighter, k);
      return new Hsl(this.h, this.s, this.l * k, this.opacity);
    },
    darker: function(k) {
      k = k == null ? darker : Math.pow(darker, k);
      return new Hsl(this.h, this.s, this.l * k, this.opacity);
    },
    rgb: function() {
      var h = this.h % 360 + (this.h < 0) * 360,
          s = isNaN(h) || isNaN(this.s) ? 0 : this.s,
          l = this.l,
          m2 = l + (l < 0.5 ? l : 1 - l) * s,
          m1 = 2 * l - m2;
      return new Rgb(
        hsl2rgb(h >= 240 ? h - 240 : h + 120, m1, m2),
        hsl2rgb(h, m1, m2),
        hsl2rgb(h < 120 ? h + 240 : h - 120, m1, m2),
        this.opacity
      );
    },
    displayable: function() {
      return (0 <= this.s && this.s <= 1 || isNaN(this.s))
          && (0 <= this.l && this.l <= 1)
          && (0 <= this.opacity && this.opacity <= 1);
    },
    formatHsl: function() {
      var a = this.opacity; a = isNaN(a) ? 1 : Math.max(0, Math.min(1, a));
      return (a === 1 ? "hsl(" : "hsla(")
          + (this.h || 0) + ", "
          + (this.s || 0) * 100 + "%, "
          + (this.l || 0) * 100 + "%"
          + (a === 1 ? ")" : ", " + a + ")");
    }
  }));

  /* From FvD 13.37, CSS Color Module Level 3 */
  function hsl2rgb(h, m1, m2) {
    return (h < 60 ? m1 + (m2 - m1) * h / 60
        : h < 180 ? m2
        : h < 240 ? m1 + (m2 - m1) * (240 - h) / 60
        : m1) * 255;
  }

  function constant$2(x) {
    return function() {
      return x;
    };
  }

  function linear(a, d) {
    return function(t) {
      return a + t * d;
    };
  }

  function exponential(a, b, y) {
    return a = Math.pow(a, y), b = Math.pow(b, y) - a, y = 1 / y, function(t) {
      return Math.pow(a + t * b, y);
    };
  }

  function gamma(y) {
    return (y = +y) === 1 ? nogamma : function(a, b) {
      return b - a ? exponential(a, b, y) : constant$2(isNaN(a) ? b : a);
    };
  }

  function nogamma(a, b) {
    var d = b - a;
    return d ? linear(a, d) : constant$2(isNaN(a) ? b : a);
  }

  var interpolateRgb = (function rgbGamma(y) {
    var color = gamma(y);

    function rgb$1(start, end) {
      var r = color((start = rgb(start)).r, (end = rgb(end)).r),
          g = color(start.g, end.g),
          b = color(start.b, end.b),
          opacity = nogamma(start.opacity, end.opacity);
      return function(t) {
        start.r = r(t);
        start.g = g(t);
        start.b = b(t);
        start.opacity = opacity(t);
        return start + "";
      };
    }

    rgb$1.gamma = rgbGamma;

    return rgb$1;
  })(1);

  function numberArray(a, b) {
    if (!b) b = [];
    var n = a ? Math.min(b.length, a.length) : 0,
        c = b.slice(),
        i;
    return function(t) {
      for (i = 0; i < n; ++i) c[i] = a[i] * (1 - t) + b[i] * t;
      return c;
    };
  }

  function isNumberArray(x) {
    return ArrayBuffer.isView(x) && !(x instanceof DataView);
  }

  function genericArray(a, b) {
    var nb = b ? b.length : 0,
        na = a ? Math.min(nb, a.length) : 0,
        x = new Array(na),
        c = new Array(nb),
        i;

    for (i = 0; i < na; ++i) x[i] = interpolateValue(a[i], b[i]);
    for (; i < nb; ++i) c[i] = b[i];

    return function(t) {
      for (i = 0; i < na; ++i) c[i] = x[i](t);
      return c;
    };
  }

  function date$1(a, b) {
    var d = new Date;
    return a = +a, b = +b, function(t) {
      return d.setTime(a * (1 - t) + b * t), d;
    };
  }

  function interpolateNumber(a, b) {
    return a = +a, b = +b, function(t) {
      return a * (1 - t) + b * t;
    };
  }

  function object(a, b) {
    var i = {},
        c = {},
        k;

    if (a === null || typeof a !== "object") a = {};
    if (b === null || typeof b !== "object") b = {};

    for (k in b) {
      if (k in a) {
        i[k] = interpolateValue(a[k], b[k]);
      } else {
        c[k] = b[k];
      }
    }

    return function(t) {
      for (k in i) c[k] = i[k](t);
      return c;
    };
  }

  var reA = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
      reB = new RegExp(reA.source, "g");

  function zero(b) {
    return function() {
      return b;
    };
  }

  function one(b) {
    return function(t) {
      return b(t) + "";
    };
  }

  function interpolateString(a, b) {
    var bi = reA.lastIndex = reB.lastIndex = 0, // scan index for next number in b
        am, // current match in a
        bm, // current match in b
        bs, // string preceding current number in b, if any
        i = -1, // index in s
        s = [], // string constants and placeholders
        q = []; // number interpolators

    // Coerce inputs to strings.
    a = a + "", b = b + "";

    // Interpolate pairs of numbers in a & b.
    while ((am = reA.exec(a))
        && (bm = reB.exec(b))) {
      if ((bs = bm.index) > bi) { // a string precedes the next number in b
        bs = b.slice(bi, bs);
        if (s[i]) s[i] += bs; // coalesce with previous string
        else s[++i] = bs;
      }
      if ((am = am[0]) === (bm = bm[0])) { // numbers in a & b match
        if (s[i]) s[i] += bm; // coalesce with previous string
        else s[++i] = bm;
      } else { // interpolate non-matching numbers
        s[++i] = null;
        q.push({i: i, x: interpolateNumber(am, bm)});
      }
      bi = reB.lastIndex;
    }

    // Add remains of b.
    if (bi < b.length) {
      bs = b.slice(bi);
      if (s[i]) s[i] += bs; // coalesce with previous string
      else s[++i] = bs;
    }

    // Special optimization for only a single match.
    // Otherwise, interpolate each of the numbers and rejoin the string.
    return s.length < 2 ? (q[0]
        ? one(q[0].x)
        : zero(b))
        : (b = q.length, function(t) {
            for (var i = 0, o; i < b; ++i) s[(o = q[i]).i] = o.x(t);
            return s.join("");
          });
  }

  function interpolateValue(a, b) {
    var t = typeof b, c;
    return b == null || t === "boolean" ? constant$2(b)
        : (t === "number" ? interpolateNumber
        : t === "string" ? ((c = color(b)) ? (b = c, interpolateRgb) : interpolateString)
        : b instanceof color ? interpolateRgb
        : b instanceof Date ? date$1
        : isNumberArray(b) ? numberArray
        : Array.isArray(b) ? genericArray
        : typeof b.valueOf !== "function" && typeof b.toString !== "function" || isNaN(b) ? object
        : interpolateNumber)(a, b);
  }

  function interpolateRound(a, b) {
    return a = +a, b = +b, function(t) {
      return Math.round(a * (1 - t) + b * t);
    };
  }

  var degrees = 180 / Math.PI;

  var identity$2 = {
    translateX: 0,
    translateY: 0,
    rotate: 0,
    skewX: 0,
    scaleX: 1,
    scaleY: 1
  };

  function decompose(a, b, c, d, e, f) {
    var scaleX, scaleY, skewX;
    if (scaleX = Math.sqrt(a * a + b * b)) a /= scaleX, b /= scaleX;
    if (skewX = a * c + b * d) c -= a * skewX, d -= b * skewX;
    if (scaleY = Math.sqrt(c * c + d * d)) c /= scaleY, d /= scaleY, skewX /= scaleY;
    if (a * d < b * c) a = -a, b = -b, skewX = -skewX, scaleX = -scaleX;
    return {
      translateX: e,
      translateY: f,
      rotate: Math.atan2(b, a) * degrees,
      skewX: Math.atan(skewX) * degrees,
      scaleX: scaleX,
      scaleY: scaleY
    };
  }

  var cssNode,
      cssRoot,
      cssView,
      svgNode;

  function parseCss(value) {
    if (value === "none") return identity$2;
    if (!cssNode) cssNode = document.createElement("DIV"), cssRoot = document.documentElement, cssView = document.defaultView;
    cssNode.style.transform = value;
    value = cssView.getComputedStyle(cssRoot.appendChild(cssNode), null).getPropertyValue("transform");
    cssRoot.removeChild(cssNode);
    value = value.slice(7, -1).split(",");
    return decompose(+value[0], +value[1], +value[2], +value[3], +value[4], +value[5]);
  }

  function parseSvg(value) {
    if (value == null) return identity$2;
    if (!svgNode) svgNode = document.createElementNS("http://www.w3.org/2000/svg", "g");
    svgNode.setAttribute("transform", value);
    if (!(value = svgNode.transform.baseVal.consolidate())) return identity$2;
    value = value.matrix;
    return decompose(value.a, value.b, value.c, value.d, value.e, value.f);
  }

  function interpolateTransform(parse, pxComma, pxParen, degParen) {

    function pop(s) {
      return s.length ? s.pop() + " " : "";
    }

    function translate(xa, ya, xb, yb, s, q) {
      if (xa !== xb || ya !== yb) {
        var i = s.push("translate(", null, pxComma, null, pxParen);
        q.push({i: i - 4, x: interpolateNumber(xa, xb)}, {i: i - 2, x: interpolateNumber(ya, yb)});
      } else if (xb || yb) {
        s.push("translate(" + xb + pxComma + yb + pxParen);
      }
    }

    function rotate(a, b, s, q) {
      if (a !== b) {
        if (a - b > 180) b += 360; else if (b - a > 180) a += 360; // shortest path
        q.push({i: s.push(pop(s) + "rotate(", null, degParen) - 2, x: interpolateNumber(a, b)});
      } else if (b) {
        s.push(pop(s) + "rotate(" + b + degParen);
      }
    }

    function skewX(a, b, s, q) {
      if (a !== b) {
        q.push({i: s.push(pop(s) + "skewX(", null, degParen) - 2, x: interpolateNumber(a, b)});
      } else if (b) {
        s.push(pop(s) + "skewX(" + b + degParen);
      }
    }

    function scale(xa, ya, xb, yb, s, q) {
      if (xa !== xb || ya !== yb) {
        var i = s.push(pop(s) + "scale(", null, ",", null, ")");
        q.push({i: i - 4, x: interpolateNumber(xa, xb)}, {i: i - 2, x: interpolateNumber(ya, yb)});
      } else if (xb !== 1 || yb !== 1) {
        s.push(pop(s) + "scale(" + xb + "," + yb + ")");
      }
    }

    return function(a, b) {
      var s = [], // string constants and placeholders
          q = []; // number interpolators
      a = parse(a), b = parse(b);
      translate(a.translateX, a.translateY, b.translateX, b.translateY, s, q);
      rotate(a.rotate, b.rotate, s, q);
      skewX(a.skewX, b.skewX, s, q);
      scale(a.scaleX, a.scaleY, b.scaleX, b.scaleY, s, q);
      a = b = null; // gc
      return function(t) {
        var i = -1, n = q.length, o;
        while (++i < n) s[(o = q[i]).i] = o.x(t);
        return s.join("");
      };
    };
  }

  var interpolateTransformCss = interpolateTransform(parseCss, "px, ", "px)", "deg)");
  var interpolateTransformSvg = interpolateTransform(parseSvg, ", ", ")", ")");

  var rho = Math.SQRT2,
      rho2 = 2,
      rho4 = 4,
      epsilon2 = 1e-12;

  function cosh(x) {
    return ((x = Math.exp(x)) + 1 / x) / 2;
  }

  function sinh(x) {
    return ((x = Math.exp(x)) - 1 / x) / 2;
  }

  function tanh(x) {
    return ((x = Math.exp(2 * x)) - 1) / (x + 1);
  }

  // p0 = [ux0, uy0, w0]
  // p1 = [ux1, uy1, w1]
  function interpolateZoom(p0, p1) {
    var ux0 = p0[0], uy0 = p0[1], w0 = p0[2],
        ux1 = p1[0], uy1 = p1[1], w1 = p1[2],
        dx = ux1 - ux0,
        dy = uy1 - uy0,
        d2 = dx * dx + dy * dy,
        i,
        S;

    // Special case for u0 ≅ u1.
    if (d2 < epsilon2) {
      S = Math.log(w1 / w0) / rho;
      i = function(t) {
        return [
          ux0 + t * dx,
          uy0 + t * dy,
          w0 * Math.exp(rho * t * S)
        ];
      };
    }

    // General case.
    else {
      var d1 = Math.sqrt(d2),
          b0 = (w1 * w1 - w0 * w0 + rho4 * d2) / (2 * w0 * rho2 * d1),
          b1 = (w1 * w1 - w0 * w0 - rho4 * d2) / (2 * w1 * rho2 * d1),
          r0 = Math.log(Math.sqrt(b0 * b0 + 1) - b0),
          r1 = Math.log(Math.sqrt(b1 * b1 + 1) - b1);
      S = (r1 - r0) / rho;
      i = function(t) {
        var s = t * S,
            coshr0 = cosh(r0),
            u = w0 / (rho2 * d1) * (coshr0 * tanh(rho * s + r0) - sinh(r0));
        return [
          ux0 + u * dx,
          uy0 + u * dy,
          w0 * coshr0 / cosh(rho * s + r0)
        ];
      };
    }

    i.duration = S * 1000;

    return i;
  }

  var frame = 0, // is an animation frame pending?
      timeout$1 = 0, // is a timeout pending?
      interval = 0, // are any timers active?
      pokeDelay = 1000, // how frequently we check for clock skew
      taskHead,
      taskTail,
      clockLast = 0,
      clockNow = 0,
      clockSkew = 0,
      clock = typeof performance === "object" && performance.now ? performance : Date,
      setFrame = typeof window === "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(f) { setTimeout(f, 17); };

  function now() {
    return clockNow || (setFrame(clearNow), clockNow = clock.now() + clockSkew);
  }

  function clearNow() {
    clockNow = 0;
  }

  function Timer() {
    this._call =
    this._time =
    this._next = null;
  }

  Timer.prototype = timer.prototype = {
    constructor: Timer,
    restart: function(callback, delay, time) {
      if (typeof callback !== "function") throw new TypeError("callback is not a function");
      time = (time == null ? now() : +time) + (delay == null ? 0 : +delay);
      if (!this._next && taskTail !== this) {
        if (taskTail) taskTail._next = this;
        else taskHead = this;
        taskTail = this;
      }
      this._call = callback;
      this._time = time;
      sleep();
    },
    stop: function() {
      if (this._call) {
        this._call = null;
        this._time = Infinity;
        sleep();
      }
    }
  };

  function timer(callback, delay, time) {
    var t = new Timer;
    t.restart(callback, delay, time);
    return t;
  }

  function timerFlush() {
    now(); // Get the current time, if not already set.
    ++frame; // Pretend we’ve set an alarm, if we haven’t already.
    var t = taskHead, e;
    while (t) {
      if ((e = clockNow - t._time) >= 0) t._call.call(null, e);
      t = t._next;
    }
    --frame;
  }

  function wake() {
    clockNow = (clockLast = clock.now()) + clockSkew;
    frame = timeout$1 = 0;
    try {
      timerFlush();
    } finally {
      frame = 0;
      nap();
      clockNow = 0;
    }
  }

  function poke() {
    var now = clock.now(), delay = now - clockLast;
    if (delay > pokeDelay) clockSkew -= delay, clockLast = now;
  }

  function nap() {
    var t0, t1 = taskHead, t2, time = Infinity;
    while (t1) {
      if (t1._call) {
        if (time > t1._time) time = t1._time;
        t0 = t1, t1 = t1._next;
      } else {
        t2 = t1._next, t1._next = null;
        t1 = t0 ? t0._next = t2 : taskHead = t2;
      }
    }
    taskTail = t0;
    sleep(time);
  }

  function sleep(time) {
    if (frame) return; // Soonest alarm already set, or will be.
    if (timeout$1) timeout$1 = clearTimeout(timeout$1);
    var delay = time - clockNow; // Strictly less than if we recomputed clockNow.
    if (delay > 24) {
      if (time < Infinity) timeout$1 = setTimeout(wake, time - clock.now() - clockSkew);
      if (interval) interval = clearInterval(interval);
    } else {
      if (!interval) clockLast = clock.now(), interval = setInterval(poke, pokeDelay);
      frame = 1, setFrame(wake);
    }
  }

  function timeout(callback, delay, time) {
    var t = new Timer;
    delay = delay == null ? 0 : +delay;
    t.restart(function(elapsed) {
      t.stop();
      callback(elapsed + delay);
    }, delay, time);
    return t;
  }

  var emptyOn = dispatch("start", "end", "cancel", "interrupt");
  var emptyTween = [];

  var CREATED = 0;
  var SCHEDULED = 1;
  var STARTING = 2;
  var STARTED = 3;
  var RUNNING = 4;
  var ENDING = 5;
  var ENDED = 6;

  function schedule(node, name, id, index, group, timing) {
    var schedules = node.__transition;
    if (!schedules) node.__transition = {};
    else if (id in schedules) return;
    create(node, id, {
      name: name,
      index: index, // For context during callback.
      group: group, // For context during callback.
      on: emptyOn,
      tween: emptyTween,
      time: timing.time,
      delay: timing.delay,
      duration: timing.duration,
      ease: timing.ease,
      timer: null,
      state: CREATED
    });
  }

  function init(node, id) {
    var schedule = get(node, id);
    if (schedule.state > CREATED) throw new Error("too late; already scheduled");
    return schedule;
  }

  function set(node, id) {
    var schedule = get(node, id);
    if (schedule.state > STARTED) throw new Error("too late; already running");
    return schedule;
  }

  function get(node, id) {
    var schedule = node.__transition;
    if (!schedule || !(schedule = schedule[id])) throw new Error("transition not found");
    return schedule;
  }

  function create(node, id, self) {
    var schedules = node.__transition,
        tween;

    // Initialize the self timer when the transition is created.
    // Note the actual delay is not known until the first callback!
    schedules[id] = self;
    self.timer = timer(schedule, 0, self.time);

    function schedule(elapsed) {
      self.state = SCHEDULED;
      self.timer.restart(start, self.delay, self.time);

      // If the elapsed delay is less than our first sleep, start immediately.
      if (self.delay <= elapsed) start(elapsed - self.delay);
    }

    function start(elapsed) {
      var i, j, n, o;

      // If the state is not SCHEDULED, then we previously errored on start.
      if (self.state !== SCHEDULED) return stop();

      for (i in schedules) {
        o = schedules[i];
        if (o.name !== self.name) continue;

        // While this element already has a starting transition during this frame,
        // defer starting an interrupting transition until that transition has a
        // chance to tick (and possibly end); see d3/d3-transition#54!
        if (o.state === STARTED) return timeout(start);

        // Interrupt the active transition, if any.
        if (o.state === RUNNING) {
          o.state = ENDED;
          o.timer.stop();
          o.on.call("interrupt", node, node.__data__, o.index, o.group);
          delete schedules[i];
        }

        // Cancel any pre-empted transitions.
        else if (+i < id) {
          o.state = ENDED;
          o.timer.stop();
          o.on.call("cancel", node, node.__data__, o.index, o.group);
          delete schedules[i];
        }
      }

      // Defer the first tick to end of the current frame; see d3/d3#1576.
      // Note the transition may be canceled after start and before the first tick!
      // Note this must be scheduled before the start event; see d3/d3-transition#16!
      // Assuming this is successful, subsequent callbacks go straight to tick.
      timeout(function() {
        if (self.state === STARTED) {
          self.state = RUNNING;
          self.timer.restart(tick, self.delay, self.time);
          tick(elapsed);
        }
      });

      // Dispatch the start event.
      // Note this must be done before the tween are initialized.
      self.state = STARTING;
      self.on.call("start", node, node.__data__, self.index, self.group);
      if (self.state !== STARTING) return; // interrupted
      self.state = STARTED;

      // Initialize the tween, deleting null tween.
      tween = new Array(n = self.tween.length);
      for (i = 0, j = -1; i < n; ++i) {
        if (o = self.tween[i].value.call(node, node.__data__, self.index, self.group)) {
          tween[++j] = o;
        }
      }
      tween.length = j + 1;
    }

    function tick(elapsed) {
      var t = elapsed < self.duration ? self.ease.call(null, elapsed / self.duration) : (self.timer.restart(stop), self.state = ENDING, 1),
          i = -1,
          n = tween.length;

      while (++i < n) {
        tween[i].call(node, t);
      }

      // Dispatch the end event.
      if (self.state === ENDING) {
        self.on.call("end", node, node.__data__, self.index, self.group);
        stop();
      }
    }

    function stop() {
      self.state = ENDED;
      self.timer.stop();
      delete schedules[id];
      for (var i in schedules) return; // eslint-disable-line no-unused-vars
      delete node.__transition;
    }
  }

  function interrupt(node, name) {
    var schedules = node.__transition,
        schedule,
        active,
        empty = true,
        i;

    if (!schedules) return;

    name = name == null ? null : name + "";

    for (i in schedules) {
      if ((schedule = schedules[i]).name !== name) { empty = false; continue; }
      active = schedule.state > STARTING && schedule.state < ENDING;
      schedule.state = ENDED;
      schedule.timer.stop();
      schedule.on.call(active ? "interrupt" : "cancel", node, node.__data__, schedule.index, schedule.group);
      delete schedules[i];
    }

    if (empty) delete node.__transition;
  }

  function selection_interrupt(name) {
    return this.each(function() {
      interrupt(this, name);
    });
  }

  function tweenRemove(id, name) {
    var tween0, tween1;
    return function() {
      var schedule = set(this, id),
          tween = schedule.tween;

      // If this node shared tween with the previous node,
      // just assign the updated shared tween and we’re done!
      // Otherwise, copy-on-write.
      if (tween !== tween0) {
        tween1 = tween0 = tween;
        for (var i = 0, n = tween1.length; i < n; ++i) {
          if (tween1[i].name === name) {
            tween1 = tween1.slice();
            tween1.splice(i, 1);
            break;
          }
        }
      }

      schedule.tween = tween1;
    };
  }

  function tweenFunction(id, name, value) {
    var tween0, tween1;
    if (typeof value !== "function") throw new Error;
    return function() {
      var schedule = set(this, id),
          tween = schedule.tween;

      // If this node shared tween with the previous node,
      // just assign the updated shared tween and we’re done!
      // Otherwise, copy-on-write.
      if (tween !== tween0) {
        tween1 = (tween0 = tween).slice();
        for (var t = {name: name, value: value}, i = 0, n = tween1.length; i < n; ++i) {
          if (tween1[i].name === name) {
            tween1[i] = t;
            break;
          }
        }
        if (i === n) tween1.push(t);
      }

      schedule.tween = tween1;
    };
  }

  function transition_tween(name, value) {
    var id = this._id;

    name += "";

    if (arguments.length < 2) {
      var tween = get(this.node(), id).tween;
      for (var i = 0, n = tween.length, t; i < n; ++i) {
        if ((t = tween[i]).name === name) {
          return t.value;
        }
      }
      return null;
    }

    return this.each((value == null ? tweenRemove : tweenFunction)(id, name, value));
  }

  function tweenValue(transition, name, value) {
    var id = transition._id;

    transition.each(function() {
      var schedule = set(this, id);
      (schedule.value || (schedule.value = {}))[name] = value.apply(this, arguments);
    });

    return function(node) {
      return get(node, id).value[name];
    };
  }

  function interpolate(a, b) {
    var c;
    return (typeof b === "number" ? interpolateNumber
        : b instanceof color ? interpolateRgb
        : (c = color(b)) ? (b = c, interpolateRgb)
        : interpolateString)(a, b);
  }

  function attrRemove(name) {
    return function() {
      this.removeAttribute(name);
    };
  }

  function attrRemoveNS(fullname) {
    return function() {
      this.removeAttributeNS(fullname.space, fullname.local);
    };
  }

  function attrConstant(name, interpolate, value1) {
    var string00,
        string1 = value1 + "",
        interpolate0;
    return function() {
      var string0 = this.getAttribute(name);
      return string0 === string1 ? null
          : string0 === string00 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, value1);
    };
  }

  function attrConstantNS(fullname, interpolate, value1) {
    var string00,
        string1 = value1 + "",
        interpolate0;
    return function() {
      var string0 = this.getAttributeNS(fullname.space, fullname.local);
      return string0 === string1 ? null
          : string0 === string00 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, value1);
    };
  }

  function attrFunction(name, interpolate, value) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0, value1 = value(this), string1;
      if (value1 == null) return void this.removeAttribute(name);
      string0 = this.getAttribute(name);
      string1 = value1 + "";
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : (string10 = string1, interpolate0 = interpolate(string00 = string0, value1));
    };
  }

  function attrFunctionNS(fullname, interpolate, value) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0, value1 = value(this), string1;
      if (value1 == null) return void this.removeAttributeNS(fullname.space, fullname.local);
      string0 = this.getAttributeNS(fullname.space, fullname.local);
      string1 = value1 + "";
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : (string10 = string1, interpolate0 = interpolate(string00 = string0, value1));
    };
  }

  function transition_attr(name, value) {
    var fullname = namespace(name), i = fullname === "transform" ? interpolateTransformSvg : interpolate;
    return this.attrTween(name, typeof value === "function"
        ? (fullname.local ? attrFunctionNS : attrFunction)(fullname, i, tweenValue(this, "attr." + name, value))
        : value == null ? (fullname.local ? attrRemoveNS : attrRemove)(fullname)
        : (fullname.local ? attrConstantNS : attrConstant)(fullname, i, value));
  }

  function attrInterpolate(name, i) {
    return function(t) {
      this.setAttribute(name, i.call(this, t));
    };
  }

  function attrInterpolateNS(fullname, i) {
    return function(t) {
      this.setAttributeNS(fullname.space, fullname.local, i.call(this, t));
    };
  }

  function attrTweenNS(fullname, value) {
    var t0, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t0 = (i0 = i) && attrInterpolateNS(fullname, i);
      return t0;
    }
    tween._value = value;
    return tween;
  }

  function attrTween(name, value) {
    var t0, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t0 = (i0 = i) && attrInterpolate(name, i);
      return t0;
    }
    tween._value = value;
    return tween;
  }

  function transition_attrTween(name, value) {
    var key = "attr." + name;
    if (arguments.length < 2) return (key = this.tween(key)) && key._value;
    if (value == null) return this.tween(key, null);
    if (typeof value !== "function") throw new Error;
    var fullname = namespace(name);
    return this.tween(key, (fullname.local ? attrTweenNS : attrTween)(fullname, value));
  }

  function delayFunction(id, value) {
    return function() {
      init(this, id).delay = +value.apply(this, arguments);
    };
  }

  function delayConstant(id, value) {
    return value = +value, function() {
      init(this, id).delay = value;
    };
  }

  function transition_delay(value) {
    var id = this._id;

    return arguments.length
        ? this.each((typeof value === "function"
            ? delayFunction
            : delayConstant)(id, value))
        : get(this.node(), id).delay;
  }

  function durationFunction(id, value) {
    return function() {
      set(this, id).duration = +value.apply(this, arguments);
    };
  }

  function durationConstant(id, value) {
    return value = +value, function() {
      set(this, id).duration = value;
    };
  }

  function transition_duration(value) {
    var id = this._id;

    return arguments.length
        ? this.each((typeof value === "function"
            ? durationFunction
            : durationConstant)(id, value))
        : get(this.node(), id).duration;
  }

  function easeConstant(id, value) {
    if (typeof value !== "function") throw new Error;
    return function() {
      set(this, id).ease = value;
    };
  }

  function transition_ease(value) {
    var id = this._id;

    return arguments.length
        ? this.each(easeConstant(id, value))
        : get(this.node(), id).ease;
  }

  function transition_filter(match) {
    if (typeof match !== "function") match = matcher(match);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = [], node, i = 0; i < n; ++i) {
        if ((node = group[i]) && match.call(node, node.__data__, i, group)) {
          subgroup.push(node);
        }
      }
    }

    return new Transition(subgroups, this._parents, this._name, this._id);
  }

  function transition_merge(transition) {
    if (transition._id !== this._id) throw new Error;

    for (var groups0 = this._groups, groups1 = transition._groups, m0 = groups0.length, m1 = groups1.length, m = Math.min(m0, m1), merges = new Array(m0), j = 0; j < m; ++j) {
      for (var group0 = groups0[j], group1 = groups1[j], n = group0.length, merge = merges[j] = new Array(n), node, i = 0; i < n; ++i) {
        if (node = group0[i] || group1[i]) {
          merge[i] = node;
        }
      }
    }

    for (; j < m0; ++j) {
      merges[j] = groups0[j];
    }

    return new Transition(merges, this._parents, this._name, this._id);
  }

  function start(name) {
    return (name + "").trim().split(/^|\s+/).every(function(t) {
      var i = t.indexOf(".");
      if (i >= 0) t = t.slice(0, i);
      return !t || t === "start";
    });
  }

  function onFunction(id, name, listener) {
    var on0, on1, sit = start(name) ? init : set;
    return function() {
      var schedule = sit(this, id),
          on = schedule.on;

      // If this node shared a dispatch with the previous node,
      // just assign the updated shared dispatch and we’re done!
      // Otherwise, copy-on-write.
      if (on !== on0) (on1 = (on0 = on).copy()).on(name, listener);

      schedule.on = on1;
    };
  }

  function transition_on(name, listener) {
    var id = this._id;

    return arguments.length < 2
        ? get(this.node(), id).on.on(name)
        : this.each(onFunction(id, name, listener));
  }

  function removeFunction(id) {
    return function() {
      var parent = this.parentNode;
      for (var i in this.__transition) if (+i !== id) return;
      if (parent) parent.removeChild(this);
    };
  }

  function transition_remove() {
    return this.on("end.remove", removeFunction(this._id));
  }

  function transition_select(select) {
    var name = this._name,
        id = this._id;

    if (typeof select !== "function") select = selector(select);

    for (var groups = this._groups, m = groups.length, subgroups = new Array(m), j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, subgroup = subgroups[j] = new Array(n), node, subnode, i = 0; i < n; ++i) {
        if ((node = group[i]) && (subnode = select.call(node, node.__data__, i, group))) {
          if ("__data__" in node) subnode.__data__ = node.__data__;
          subgroup[i] = subnode;
          schedule(subgroup[i], name, id, i, subgroup, get(node, id));
        }
      }
    }

    return new Transition(subgroups, this._parents, name, id);
  }

  function transition_selectAll(select) {
    var name = this._name,
        id = this._id;

    if (typeof select !== "function") select = selectorAll(select);

    for (var groups = this._groups, m = groups.length, subgroups = [], parents = [], j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          for (var children = select.call(node, node.__data__, i, group), child, inherit = get(node, id), k = 0, l = children.length; k < l; ++k) {
            if (child = children[k]) {
              schedule(child, name, id, k, children, inherit);
            }
          }
          subgroups.push(children);
          parents.push(node);
        }
      }
    }

    return new Transition(subgroups, parents, name, id);
  }

  var Selection = selection.prototype.constructor;

  function transition_selection() {
    return new Selection(this._groups, this._parents);
  }

  function styleNull(name, interpolate) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0 = styleValue(this, name),
          string1 = (this.style.removeProperty(name), styleValue(this, name));
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, string10 = string1);
    };
  }

  function styleRemove(name) {
    return function() {
      this.style.removeProperty(name);
    };
  }

  function styleConstant(name, interpolate, value1) {
    var string00,
        string1 = value1 + "",
        interpolate0;
    return function() {
      var string0 = styleValue(this, name);
      return string0 === string1 ? null
          : string0 === string00 ? interpolate0
          : interpolate0 = interpolate(string00 = string0, value1);
    };
  }

  function styleFunction(name, interpolate, value) {
    var string00,
        string10,
        interpolate0;
    return function() {
      var string0 = styleValue(this, name),
          value1 = value(this),
          string1 = value1 + "";
      if (value1 == null) string1 = value1 = (this.style.removeProperty(name), styleValue(this, name));
      return string0 === string1 ? null
          : string0 === string00 && string1 === string10 ? interpolate0
          : (string10 = string1, interpolate0 = interpolate(string00 = string0, value1));
    };
  }

  function styleMaybeRemove(id, name) {
    var on0, on1, listener0, key = "style." + name, event = "end." + key, remove;
    return function() {
      var schedule = set(this, id),
          on = schedule.on,
          listener = schedule.value[key] == null ? remove || (remove = styleRemove(name)) : undefined;

      // If this node shared a dispatch with the previous node,
      // just assign the updated shared dispatch and we’re done!
      // Otherwise, copy-on-write.
      if (on !== on0 || listener0 !== listener) (on1 = (on0 = on).copy()).on(event, listener0 = listener);

      schedule.on = on1;
    };
  }

  function transition_style(name, value, priority) {
    var i = (name += "") === "transform" ? interpolateTransformCss : interpolate;
    return value == null ? this
        .styleTween(name, styleNull(name, i))
        .on("end.style." + name, styleRemove(name))
      : typeof value === "function" ? this
        .styleTween(name, styleFunction(name, i, tweenValue(this, "style." + name, value)))
        .each(styleMaybeRemove(this._id, name))
      : this
        .styleTween(name, styleConstant(name, i, value), priority)
        .on("end.style." + name, null);
  }

  function styleInterpolate(name, i, priority) {
    return function(t) {
      this.style.setProperty(name, i.call(this, t), priority);
    };
  }

  function styleTween(name, value, priority) {
    var t, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t = (i0 = i) && styleInterpolate(name, i, priority);
      return t;
    }
    tween._value = value;
    return tween;
  }

  function transition_styleTween(name, value, priority) {
    var key = "style." + (name += "");
    if (arguments.length < 2) return (key = this.tween(key)) && key._value;
    if (value == null) return this.tween(key, null);
    if (typeof value !== "function") throw new Error;
    return this.tween(key, styleTween(name, value, priority == null ? "" : priority));
  }

  function textConstant(value) {
    return function() {
      this.textContent = value;
    };
  }

  function textFunction(value) {
    return function() {
      var value1 = value(this);
      this.textContent = value1 == null ? "" : value1;
    };
  }

  function transition_text(value) {
    return this.tween("text", typeof value === "function"
        ? textFunction(tweenValue(this, "text", value))
        : textConstant(value == null ? "" : value + ""));
  }

  function textInterpolate(i) {
    return function(t) {
      this.textContent = i.call(this, t);
    };
  }

  function textTween(value) {
    var t0, i0;
    function tween() {
      var i = value.apply(this, arguments);
      if (i !== i0) t0 = (i0 = i) && textInterpolate(i);
      return t0;
    }
    tween._value = value;
    return tween;
  }

  function transition_textTween(value) {
    var key = "text";
    if (arguments.length < 1) return (key = this.tween(key)) && key._value;
    if (value == null) return this.tween(key, null);
    if (typeof value !== "function") throw new Error;
    return this.tween(key, textTween(value));
  }

  function transition_transition() {
    var name = this._name,
        id0 = this._id,
        id1 = newId();

    for (var groups = this._groups, m = groups.length, j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          var inherit = get(node, id0);
          schedule(node, name, id1, i, group, {
            time: inherit.time + inherit.delay + inherit.duration,
            delay: 0,
            duration: inherit.duration,
            ease: inherit.ease
          });
        }
      }
    }

    return new Transition(groups, this._parents, name, id1);
  }

  function transition_end() {
    var on0, on1, that = this, id = that._id, size = that.size();
    return new Promise(function(resolve, reject) {
      var cancel = {value: reject},
          end = {value: function() { if (--size === 0) resolve(); }};

      that.each(function() {
        var schedule = set(this, id),
            on = schedule.on;

        // If this node shared a dispatch with the previous node,
        // just assign the updated shared dispatch and we’re done!
        // Otherwise, copy-on-write.
        if (on !== on0) {
          on1 = (on0 = on).copy();
          on1._.cancel.push(cancel);
          on1._.interrupt.push(cancel);
          on1._.end.push(end);
        }

        schedule.on = on1;
      });
    });
  }

  var id = 0;

  function Transition(groups, parents, name, id) {
    this._groups = groups;
    this._parents = parents;
    this._name = name;
    this._id = id;
  }

  function newId() {
    return ++id;
  }

  var selection_prototype = selection.prototype;

  Transition.prototype = {
    constructor: Transition,
    select: transition_select,
    selectAll: transition_selectAll,
    filter: transition_filter,
    merge: transition_merge,
    selection: transition_selection,
    transition: transition_transition,
    call: selection_prototype.call,
    nodes: selection_prototype.nodes,
    node: selection_prototype.node,
    size: selection_prototype.size,
    empty: selection_prototype.empty,
    each: selection_prototype.each,
    on: transition_on,
    attr: transition_attr,
    attrTween: transition_attrTween,
    style: transition_style,
    styleTween: transition_styleTween,
    text: transition_text,
    textTween: transition_textTween,
    remove: transition_remove,
    tween: transition_tween,
    delay: transition_delay,
    duration: transition_duration,
    ease: transition_ease,
    end: transition_end
  };

  function cubicInOut(t) {
    return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2;
  }

  var defaultTiming = {
    time: null, // Set on use.
    delay: 0,
    duration: 250,
    ease: cubicInOut
  };

  function inherit(node, id) {
    var timing;
    while (!(timing = node.__transition) || !(timing = timing[id])) {
      if (!(node = node.parentNode)) {
        return defaultTiming.time = now(), defaultTiming;
      }
    }
    return timing;
  }

  function selection_transition(name) {
    var id,
        timing;

    if (name instanceof Transition) {
      id = name._id, name = name._name;
    } else {
      id = newId(), (timing = defaultTiming).time = now(), name = name == null ? null : name + "";
    }

    for (var groups = this._groups, m = groups.length, j = 0; j < m; ++j) {
      for (var group = groups[j], n = group.length, node, i = 0; i < n; ++i) {
        if (node = group[i]) {
          schedule(node, name, id, i, group, timing || inherit(node, id));
        }
      }
    }

    return new Transition(groups, this._parents, name, id);
  }

  selection.prototype.interrupt = selection_interrupt;
  selection.prototype.transition = selection_transition;

  var prefix = "$";

  function Map$1() {}

  Map$1.prototype = map$1.prototype = {
    constructor: Map$1,
    has: function(key) {
      return (prefix + key) in this;
    },
    get: function(key) {
      return this[prefix + key];
    },
    set: function(key, value) {
      this[prefix + key] = value;
      return this;
    },
    remove: function(key) {
      var property = prefix + key;
      return property in this && delete this[property];
    },
    clear: function() {
      for (var property in this) if (property[0] === prefix) delete this[property];
    },
    keys: function() {
      var keys = [];
      for (var property in this) if (property[0] === prefix) keys.push(property.slice(1));
      return keys;
    },
    values: function() {
      var values = [];
      for (var property in this) if (property[0] === prefix) values.push(this[property]);
      return values;
    },
    entries: function() {
      var entries = [];
      for (var property in this) if (property[0] === prefix) entries.push({key: property.slice(1), value: this[property]});
      return entries;
    },
    size: function() {
      var size = 0;
      for (var property in this) if (property[0] === prefix) ++size;
      return size;
    },
    empty: function() {
      for (var property in this) if (property[0] === prefix) return false;
      return true;
    },
    each: function(f) {
      for (var property in this) if (property[0] === prefix) f(this[property], property.slice(1), this);
    }
  };

  function map$1(object, f) {
    var map = new Map$1;

    // Copy constructor.
    if (object instanceof Map$1) object.each(function(value, key) { map.set(key, value); });

    // Index array by numeric index or specified key function.
    else if (Array.isArray(object)) {
      var i = -1,
          n = object.length,
          o;

      if (f == null) while (++i < n) map.set(i, object[i]);
      else while (++i < n) map.set(f(o = object[i], i, object), o);
    }

    // Convert object to map.
    else if (object) for (var key in object) map.set(key, object[key]);

    return map;
  }

  function Set$1() {}

  var proto = map$1.prototype;

  Set$1.prototype = {
    constructor: Set$1,
    has: proto.has,
    add: function(value) {
      value += "";
      this[prefix + value] = value;
      return this;
    },
    remove: proto.remove,
    clear: proto.clear,
    values: proto.keys,
    size: proto.size,
    empty: proto.empty,
    each: proto.each
  };

  function initRange(domain, range) {
    switch (arguments.length) {
      case 0: break;
      case 1: this.range(domain); break;
      default: this.range(range).domain(domain); break;
    }
    return this;
  }

  var array = Array.prototype;

  var map = array.map;
  var slice = array.slice;

  var implicit = {name: "implicit"};

  function ordinal() {
    var index = map$1(),
        domain = [],
        range = [],
        unknown = implicit;

    function scale(d) {
      var key = d + "", i = index.get(key);
      if (!i) {
        if (unknown !== implicit) return unknown;
        index.set(key, i = domain.push(d));
      }
      return range[(i - 1) % range.length];
    }

    scale.domain = function(_) {
      if (!arguments.length) return domain.slice();
      domain = [], index = map$1();
      var i = -1, n = _.length, d, key;
      while (++i < n) if (!index.has(key = (d = _[i]) + "")) index.set(key, domain.push(d));
      return scale;
    };

    scale.range = function(_) {
      return arguments.length ? (range = slice.call(_), scale) : range.slice();
    };

    scale.unknown = function(_) {
      return arguments.length ? (unknown = _, scale) : unknown;
    };

    scale.copy = function() {
      return ordinal(domain, range).unknown(unknown);
    };

    initRange.apply(scale, arguments);

    return scale;
  }

  function band() {
    var scale = ordinal().unknown(undefined),
        domain = scale.domain,
        ordinalRange = scale.range,
        range = [0, 1],
        step,
        bandwidth,
        round = false,
        paddingInner = 0,
        paddingOuter = 0,
        align = 0.5;

    delete scale.unknown;

    function rescale() {
      var n = domain().length,
          reverse = range[1] < range[0],
          start = range[reverse - 0],
          stop = range[1 - reverse];
      step = (stop - start) / Math.max(1, n - paddingInner + paddingOuter * 2);
      if (round) step = Math.floor(step);
      start += (stop - start - step * (n - paddingInner)) * align;
      bandwidth = step * (1 - paddingInner);
      if (round) start = Math.round(start), bandwidth = Math.round(bandwidth);
      var values = sequence(n).map(function(i) { return start + step * i; });
      return ordinalRange(reverse ? values.reverse() : values);
    }

    scale.domain = function(_) {
      return arguments.length ? (domain(_), rescale()) : domain();
    };

    scale.range = function(_) {
      return arguments.length ? (range = [+_[0], +_[1]], rescale()) : range.slice();
    };

    scale.rangeRound = function(_) {
      return range = [+_[0], +_[1]], round = true, rescale();
    };

    scale.bandwidth = function() {
      return bandwidth;
    };

    scale.step = function() {
      return step;
    };

    scale.round = function(_) {
      return arguments.length ? (round = !!_, rescale()) : round;
    };

    scale.padding = function(_) {
      return arguments.length ? (paddingInner = Math.min(1, paddingOuter = +_), rescale()) : paddingInner;
    };

    scale.paddingInner = function(_) {
      return arguments.length ? (paddingInner = Math.min(1, _), rescale()) : paddingInner;
    };

    scale.paddingOuter = function(_) {
      return arguments.length ? (paddingOuter = +_, rescale()) : paddingOuter;
    };

    scale.align = function(_) {
      return arguments.length ? (align = Math.max(0, Math.min(1, _)), rescale()) : align;
    };

    scale.copy = function() {
      return band(domain(), range)
          .round(round)
          .paddingInner(paddingInner)
          .paddingOuter(paddingOuter)
          .align(align);
    };

    return initRange.apply(rescale(), arguments);
  }

  function constant$1(x) {
    return function() {
      return x;
    };
  }

  function number$1(x) {
    return +x;
  }

  var unit = [0, 1];

  function identity$1(x) {
    return x;
  }

  function normalize(a, b) {
    return (b -= (a = +a))
        ? function(x) { return (x - a) / b; }
        : constant$1(isNaN(b) ? NaN : 0.5);
  }

  function clamper(domain) {
    var a = domain[0], b = domain[domain.length - 1], t;
    if (a > b) t = a, a = b, b = t;
    return function(x) { return Math.max(a, Math.min(b, x)); };
  }

  // normalize(a, b)(x) takes a domain value x in [a,b] and returns the corresponding parameter t in [0,1].
  // interpolate(a, b)(t) takes a parameter t in [0,1] and returns the corresponding range value x in [a,b].
  function bimap(domain, range, interpolate) {
    var d0 = domain[0], d1 = domain[1], r0 = range[0], r1 = range[1];
    if (d1 < d0) d0 = normalize(d1, d0), r0 = interpolate(r1, r0);
    else d0 = normalize(d0, d1), r0 = interpolate(r0, r1);
    return function(x) { return r0(d0(x)); };
  }

  function polymap(domain, range, interpolate) {
    var j = Math.min(domain.length, range.length) - 1,
        d = new Array(j),
        r = new Array(j),
        i = -1;

    // Reverse descending domains.
    if (domain[j] < domain[0]) {
      domain = domain.slice().reverse();
      range = range.slice().reverse();
    }

    while (++i < j) {
      d[i] = normalize(domain[i], domain[i + 1]);
      r[i] = interpolate(range[i], range[i + 1]);
    }

    return function(x) {
      var i = bisectRight(domain, x, 1, j) - 1;
      return r[i](d[i](x));
    };
  }

  function copy(source, target) {
    return target
        .domain(source.domain())
        .range(source.range())
        .interpolate(source.interpolate())
        .clamp(source.clamp())
        .unknown(source.unknown());
  }

  function transformer() {
    var domain = unit,
        range = unit,
        interpolate = interpolateValue,
        transform,
        untransform,
        unknown,
        clamp = identity$1,
        piecewise,
        output,
        input;

    function rescale() {
      piecewise = Math.min(domain.length, range.length) > 2 ? polymap : bimap;
      output = input = null;
      return scale;
    }

    function scale(x) {
      return isNaN(x = +x) ? unknown : (output || (output = piecewise(domain.map(transform), range, interpolate)))(transform(clamp(x)));
    }

    scale.invert = function(y) {
      return clamp(untransform((input || (input = piecewise(range, domain.map(transform), interpolateNumber)))(y)));
    };

    scale.domain = function(_) {
      return arguments.length ? (domain = map.call(_, number$1), clamp === identity$1 || (clamp = clamper(domain)), rescale()) : domain.slice();
    };

    scale.range = function(_) {
      return arguments.length ? (range = slice.call(_), rescale()) : range.slice();
    };

    scale.rangeRound = function(_) {
      return range = slice.call(_), interpolate = interpolateRound, rescale();
    };

    scale.clamp = function(_) {
      return arguments.length ? (clamp = _ ? clamper(domain) : identity$1, scale) : clamp !== identity$1;
    };

    scale.interpolate = function(_) {
      return arguments.length ? (interpolate = _, rescale()) : interpolate;
    };

    scale.unknown = function(_) {
      return arguments.length ? (unknown = _, scale) : unknown;
    };

    return function(t, u) {
      transform = t, untransform = u;
      return rescale();
    };
  }

  function continuous(transform, untransform) {
    return transformer()(transform, untransform);
  }

  function nice(domain, interval) {
    domain = domain.slice();

    var i0 = 0,
        i1 = domain.length - 1,
        x0 = domain[i0],
        x1 = domain[i1],
        t;

    if (x1 < x0) {
      t = i0, i0 = i1, i1 = t;
      t = x0, x0 = x1, x1 = t;
    }

    domain[i0] = interval.floor(x0);
    domain[i1] = interval.ceil(x1);
    return domain;
  }

  var t0 = new Date,
      t1 = new Date;

  function newInterval(floori, offseti, count, field) {

    function interval(date) {
      return floori(date = arguments.length === 0 ? new Date : new Date(+date)), date;
    }

    interval.floor = function(date) {
      return floori(date = new Date(+date)), date;
    };

    interval.ceil = function(date) {
      return floori(date = new Date(date - 1)), offseti(date, 1), floori(date), date;
    };

    interval.round = function(date) {
      var d0 = interval(date),
          d1 = interval.ceil(date);
      return date - d0 < d1 - date ? d0 : d1;
    };

    interval.offset = function(date, step) {
      return offseti(date = new Date(+date), step == null ? 1 : Math.floor(step)), date;
    };

    interval.range = function(start, stop, step) {
      var range = [], previous;
      start = interval.ceil(start);
      step = step == null ? 1 : Math.floor(step);
      if (!(start < stop) || !(step > 0)) return range; // also handles Invalid Date
      do range.push(previous = new Date(+start)), offseti(start, step), floori(start);
      while (previous < start && start < stop);
      return range;
    };

    interval.filter = function(test) {
      return newInterval(function(date) {
        if (date >= date) while (floori(date), !test(date)) date.setTime(date - 1);
      }, function(date, step) {
        if (date >= date) {
          if (step < 0) while (++step <= 0) {
            while (offseti(date, -1), !test(date)) {} // eslint-disable-line no-empty
          } else while (--step >= 0) {
            while (offseti(date, +1), !test(date)) {} // eslint-disable-line no-empty
          }
        }
      });
    };

    if (count) {
      interval.count = function(start, end) {
        t0.setTime(+start), t1.setTime(+end);
        floori(t0), floori(t1);
        return Math.floor(count(t0, t1));
      };

      interval.every = function(step) {
        step = Math.floor(step);
        return !isFinite(step) || !(step > 0) ? null
            : !(step > 1) ? interval
            : interval.filter(field
                ? function(d) { return field(d) % step === 0; }
                : function(d) { return interval.count(0, d) % step === 0; });
      };
    }

    return interval;
  }

  var millisecond = newInterval(function() {
    // noop
  }, function(date, step) {
    date.setTime(+date + step);
  }, function(start, end) {
    return end - start;
  });

  // An optimized implementation for this simple case.
  millisecond.every = function(k) {
    k = Math.floor(k);
    if (!isFinite(k) || !(k > 0)) return null;
    if (!(k > 1)) return millisecond;
    return newInterval(function(date) {
      date.setTime(Math.floor(date / k) * k);
    }, function(date, step) {
      date.setTime(+date + step * k);
    }, function(start, end) {
      return (end - start) / k;
    });
  };

  var utcMillisecond = millisecond;

  var durationSecond$1 = 1e3;
  var durationMinute$1 = 6e4;
  var durationHour$1 = 36e5;
  var durationDay$1 = 864e5;
  var durationWeek$1 = 6048e5;

  var second = newInterval(function(date) {
    date.setTime(date - date.getMilliseconds());
  }, function(date, step) {
    date.setTime(+date + step * durationSecond$1);
  }, function(start, end) {
    return (end - start) / durationSecond$1;
  }, function(date) {
    return date.getUTCSeconds();
  });

  var utcSecond = second;

  var minute = newInterval(function(date) {
    date.setTime(date - date.getMilliseconds() - date.getSeconds() * durationSecond$1);
  }, function(date, step) {
    date.setTime(+date + step * durationMinute$1);
  }, function(start, end) {
    return (end - start) / durationMinute$1;
  }, function(date) {
    return date.getMinutes();
  });

  var timeMinute = minute;

  var hour = newInterval(function(date) {
    date.setTime(date - date.getMilliseconds() - date.getSeconds() * durationSecond$1 - date.getMinutes() * durationMinute$1);
  }, function(date, step) {
    date.setTime(+date + step * durationHour$1);
  }, function(start, end) {
    return (end - start) / durationHour$1;
  }, function(date) {
    return date.getHours();
  });

  var timeHour = hour;

  var day = newInterval(function(date) {
    date.setHours(0, 0, 0, 0);
  }, function(date, step) {
    date.setDate(date.getDate() + step);
  }, function(start, end) {
    return (end - start - (end.getTimezoneOffset() - start.getTimezoneOffset()) * durationMinute$1) / durationDay$1;
  }, function(date) {
    return date.getDate() - 1;
  });

  var timeDay = day;

  function weekday(i) {
    return newInterval(function(date) {
      date.setDate(date.getDate() - (date.getDay() + 7 - i) % 7);
      date.setHours(0, 0, 0, 0);
    }, function(date, step) {
      date.setDate(date.getDate() + step * 7);
    }, function(start, end) {
      return (end - start - (end.getTimezoneOffset() - start.getTimezoneOffset()) * durationMinute$1) / durationWeek$1;
    });
  }

  var sunday = weekday(0);
  var monday = weekday(1);
  weekday(2);
  weekday(3);
  var thursday = weekday(4);
  weekday(5);
  weekday(6);

  var month = newInterval(function(date) {
    date.setDate(1);
    date.setHours(0, 0, 0, 0);
  }, function(date, step) {
    date.setMonth(date.getMonth() + step);
  }, function(start, end) {
    return end.getMonth() - start.getMonth() + (end.getFullYear() - start.getFullYear()) * 12;
  }, function(date) {
    return date.getMonth();
  });

  var timeMonth = month;

  var year = newInterval(function(date) {
    date.setMonth(0, 1);
    date.setHours(0, 0, 0, 0);
  }, function(date, step) {
    date.setFullYear(date.getFullYear() + step);
  }, function(start, end) {
    return end.getFullYear() - start.getFullYear();
  }, function(date) {
    return date.getFullYear();
  });

  // An optimized implementation for this simple case.
  year.every = function(k) {
    return !isFinite(k = Math.floor(k)) || !(k > 0) ? null : newInterval(function(date) {
      date.setFullYear(Math.floor(date.getFullYear() / k) * k);
      date.setMonth(0, 1);
      date.setHours(0, 0, 0, 0);
    }, function(date, step) {
      date.setFullYear(date.getFullYear() + step * k);
    });
  };

  var timeYear = year;

  var utcDay = newInterval(function(date) {
    date.setUTCHours(0, 0, 0, 0);
  }, function(date, step) {
    date.setUTCDate(date.getUTCDate() + step);
  }, function(start, end) {
    return (end - start) / durationDay$1;
  }, function(date) {
    return date.getUTCDate() - 1;
  });

  var utcDay$1 = utcDay;

  function utcWeekday(i) {
    return newInterval(function(date) {
      date.setUTCDate(date.getUTCDate() - (date.getUTCDay() + 7 - i) % 7);
      date.setUTCHours(0, 0, 0, 0);
    }, function(date, step) {
      date.setUTCDate(date.getUTCDate() + step * 7);
    }, function(start, end) {
      return (end - start) / durationWeek$1;
    });
  }

  var utcSunday = utcWeekday(0);
  var utcMonday = utcWeekday(1);
  utcWeekday(2);
  utcWeekday(3);
  var utcThursday = utcWeekday(4);
  utcWeekday(5);
  utcWeekday(6);

  var utcYear = newInterval(function(date) {
    date.setUTCMonth(0, 1);
    date.setUTCHours(0, 0, 0, 0);
  }, function(date, step) {
    date.setUTCFullYear(date.getUTCFullYear() + step);
  }, function(start, end) {
    return end.getUTCFullYear() - start.getUTCFullYear();
  }, function(date) {
    return date.getUTCFullYear();
  });

  // An optimized implementation for this simple case.
  utcYear.every = function(k) {
    return !isFinite(k = Math.floor(k)) || !(k > 0) ? null : newInterval(function(date) {
      date.setUTCFullYear(Math.floor(date.getUTCFullYear() / k) * k);
      date.setUTCMonth(0, 1);
      date.setUTCHours(0, 0, 0, 0);
    }, function(date, step) {
      date.setUTCFullYear(date.getUTCFullYear() + step * k);
    });
  };

  var utcYear$1 = utcYear;

  function localDate(d) {
    if (0 <= d.y && d.y < 100) {
      var date = new Date(-1, d.m, d.d, d.H, d.M, d.S, d.L);
      date.setFullYear(d.y);
      return date;
    }
    return new Date(d.y, d.m, d.d, d.H, d.M, d.S, d.L);
  }

  function utcDate(d) {
    if (0 <= d.y && d.y < 100) {
      var date = new Date(Date.UTC(-1, d.m, d.d, d.H, d.M, d.S, d.L));
      date.setUTCFullYear(d.y);
      return date;
    }
    return new Date(Date.UTC(d.y, d.m, d.d, d.H, d.M, d.S, d.L));
  }

  function newDate(y, m, d) {
    return {y: y, m: m, d: d, H: 0, M: 0, S: 0, L: 0};
  }

  function formatLocale(locale) {
    var locale_dateTime = locale.dateTime,
        locale_date = locale.date,
        locale_time = locale.time,
        locale_periods = locale.periods,
        locale_weekdays = locale.days,
        locale_shortWeekdays = locale.shortDays,
        locale_months = locale.months,
        locale_shortMonths = locale.shortMonths;

    var periodRe = formatRe(locale_periods),
        periodLookup = formatLookup(locale_periods),
        weekdayRe = formatRe(locale_weekdays),
        weekdayLookup = formatLookup(locale_weekdays),
        shortWeekdayRe = formatRe(locale_shortWeekdays),
        shortWeekdayLookup = formatLookup(locale_shortWeekdays),
        monthRe = formatRe(locale_months),
        monthLookup = formatLookup(locale_months),
        shortMonthRe = formatRe(locale_shortMonths),
        shortMonthLookup = formatLookup(locale_shortMonths);

    var formats = {
      "a": formatShortWeekday,
      "A": formatWeekday,
      "b": formatShortMonth,
      "B": formatMonth,
      "c": null,
      "d": formatDayOfMonth,
      "e": formatDayOfMonth,
      "f": formatMicroseconds,
      "g": formatYearISO,
      "G": formatFullYearISO,
      "H": formatHour24,
      "I": formatHour12,
      "j": formatDayOfYear,
      "L": formatMilliseconds,
      "m": formatMonthNumber,
      "M": formatMinutes,
      "p": formatPeriod,
      "q": formatQuarter,
      "Q": formatUnixTimestamp,
      "s": formatUnixTimestampSeconds,
      "S": formatSeconds,
      "u": formatWeekdayNumberMonday,
      "U": formatWeekNumberSunday,
      "V": formatWeekNumberISO,
      "w": formatWeekdayNumberSunday,
      "W": formatWeekNumberMonday,
      "x": null,
      "X": null,
      "y": formatYear,
      "Y": formatFullYear,
      "Z": formatZone,
      "%": formatLiteralPercent
    };

    var utcFormats = {
      "a": formatUTCShortWeekday,
      "A": formatUTCWeekday,
      "b": formatUTCShortMonth,
      "B": formatUTCMonth,
      "c": null,
      "d": formatUTCDayOfMonth,
      "e": formatUTCDayOfMonth,
      "f": formatUTCMicroseconds,
      "g": formatUTCYearISO,
      "G": formatUTCFullYearISO,
      "H": formatUTCHour24,
      "I": formatUTCHour12,
      "j": formatUTCDayOfYear,
      "L": formatUTCMilliseconds,
      "m": formatUTCMonthNumber,
      "M": formatUTCMinutes,
      "p": formatUTCPeriod,
      "q": formatUTCQuarter,
      "Q": formatUnixTimestamp,
      "s": formatUnixTimestampSeconds,
      "S": formatUTCSeconds,
      "u": formatUTCWeekdayNumberMonday,
      "U": formatUTCWeekNumberSunday,
      "V": formatUTCWeekNumberISO,
      "w": formatUTCWeekdayNumberSunday,
      "W": formatUTCWeekNumberMonday,
      "x": null,
      "X": null,
      "y": formatUTCYear,
      "Y": formatUTCFullYear,
      "Z": formatUTCZone,
      "%": formatLiteralPercent
    };

    var parses = {
      "a": parseShortWeekday,
      "A": parseWeekday,
      "b": parseShortMonth,
      "B": parseMonth,
      "c": parseLocaleDateTime,
      "d": parseDayOfMonth,
      "e": parseDayOfMonth,
      "f": parseMicroseconds,
      "g": parseYear,
      "G": parseFullYear,
      "H": parseHour24,
      "I": parseHour24,
      "j": parseDayOfYear,
      "L": parseMilliseconds,
      "m": parseMonthNumber,
      "M": parseMinutes,
      "p": parsePeriod,
      "q": parseQuarter,
      "Q": parseUnixTimestamp,
      "s": parseUnixTimestampSeconds,
      "S": parseSeconds,
      "u": parseWeekdayNumberMonday,
      "U": parseWeekNumberSunday,
      "V": parseWeekNumberISO,
      "w": parseWeekdayNumberSunday,
      "W": parseWeekNumberMonday,
      "x": parseLocaleDate,
      "X": parseLocaleTime,
      "y": parseYear,
      "Y": parseFullYear,
      "Z": parseZone,
      "%": parseLiteralPercent
    };

    // These recursive directive definitions must be deferred.
    formats.x = newFormat(locale_date, formats);
    formats.X = newFormat(locale_time, formats);
    formats.c = newFormat(locale_dateTime, formats);
    utcFormats.x = newFormat(locale_date, utcFormats);
    utcFormats.X = newFormat(locale_time, utcFormats);
    utcFormats.c = newFormat(locale_dateTime, utcFormats);

    function newFormat(specifier, formats) {
      return function(date) {
        var string = [],
            i = -1,
            j = 0,
            n = specifier.length,
            c,
            pad,
            format;

        if (!(date instanceof Date)) date = new Date(+date);

        while (++i < n) {
          if (specifier.charCodeAt(i) === 37) {
            string.push(specifier.slice(j, i));
            if ((pad = pads[c = specifier.charAt(++i)]) != null) c = specifier.charAt(++i);
            else pad = c === "e" ? " " : "0";
            if (format = formats[c]) c = format(date, pad);
            string.push(c);
            j = i + 1;
          }
        }

        string.push(specifier.slice(j, i));
        return string.join("");
      };
    }

    function newParse(specifier, Z) {
      return function(string) {
        var d = newDate(1900, undefined, 1),
            i = parseSpecifier(d, specifier, string += "", 0),
            week, day;
        if (i != string.length) return null;

        // If a UNIX timestamp is specified, return it.
        if ("Q" in d) return new Date(d.Q);
        if ("s" in d) return new Date(d.s * 1000 + ("L" in d ? d.L : 0));

        // If this is utcParse, never use the local timezone.
        if (Z && !("Z" in d)) d.Z = 0;

        // The am-pm flag is 0 for AM, and 1 for PM.
        if ("p" in d) d.H = d.H % 12 + d.p * 12;

        // If the month was not specified, inherit from the quarter.
        if (d.m === undefined) d.m = "q" in d ? d.q : 0;

        // Convert day-of-week and week-of-year to day-of-year.
        if ("V" in d) {
          if (d.V < 1 || d.V > 53) return null;
          if (!("w" in d)) d.w = 1;
          if ("Z" in d) {
            week = utcDate(newDate(d.y, 0, 1)), day = week.getUTCDay();
            week = day > 4 || day === 0 ? utcMonday.ceil(week) : utcMonday(week);
            week = utcDay$1.offset(week, (d.V - 1) * 7);
            d.y = week.getUTCFullYear();
            d.m = week.getUTCMonth();
            d.d = week.getUTCDate() + (d.w + 6) % 7;
          } else {
            week = localDate(newDate(d.y, 0, 1)), day = week.getDay();
            week = day > 4 || day === 0 ? monday.ceil(week) : monday(week);
            week = timeDay.offset(week, (d.V - 1) * 7);
            d.y = week.getFullYear();
            d.m = week.getMonth();
            d.d = week.getDate() + (d.w + 6) % 7;
          }
        } else if ("W" in d || "U" in d) {
          if (!("w" in d)) d.w = "u" in d ? d.u % 7 : "W" in d ? 1 : 0;
          day = "Z" in d ? utcDate(newDate(d.y, 0, 1)).getUTCDay() : localDate(newDate(d.y, 0, 1)).getDay();
          d.m = 0;
          d.d = "W" in d ? (d.w + 6) % 7 + d.W * 7 - (day + 5) % 7 : d.w + d.U * 7 - (day + 6) % 7;
        }

        // If a time zone is specified, all fields are interpreted as UTC and then
        // offset according to the specified time zone.
        if ("Z" in d) {
          d.H += d.Z / 100 | 0;
          d.M += d.Z % 100;
          return utcDate(d);
        }

        // Otherwise, all fields are in local time.
        return localDate(d);
      };
    }

    function parseSpecifier(d, specifier, string, j) {
      var i = 0,
          n = specifier.length,
          m = string.length,
          c,
          parse;

      while (i < n) {
        if (j >= m) return -1;
        c = specifier.charCodeAt(i++);
        if (c === 37) {
          c = specifier.charAt(i++);
          parse = parses[c in pads ? specifier.charAt(i++) : c];
          if (!parse || ((j = parse(d, string, j)) < 0)) return -1;
        } else if (c != string.charCodeAt(j++)) {
          return -1;
        }
      }

      return j;
    }

    function parsePeriod(d, string, i) {
      var n = periodRe.exec(string.slice(i));
      return n ? (d.p = periodLookup[n[0].toLowerCase()], i + n[0].length) : -1;
    }

    function parseShortWeekday(d, string, i) {
      var n = shortWeekdayRe.exec(string.slice(i));
      return n ? (d.w = shortWeekdayLookup[n[0].toLowerCase()], i + n[0].length) : -1;
    }

    function parseWeekday(d, string, i) {
      var n = weekdayRe.exec(string.slice(i));
      return n ? (d.w = weekdayLookup[n[0].toLowerCase()], i + n[0].length) : -1;
    }

    function parseShortMonth(d, string, i) {
      var n = shortMonthRe.exec(string.slice(i));
      return n ? (d.m = shortMonthLookup[n[0].toLowerCase()], i + n[0].length) : -1;
    }

    function parseMonth(d, string, i) {
      var n = monthRe.exec(string.slice(i));
      return n ? (d.m = monthLookup[n[0].toLowerCase()], i + n[0].length) : -1;
    }

    function parseLocaleDateTime(d, string, i) {
      return parseSpecifier(d, locale_dateTime, string, i);
    }

    function parseLocaleDate(d, string, i) {
      return parseSpecifier(d, locale_date, string, i);
    }

    function parseLocaleTime(d, string, i) {
      return parseSpecifier(d, locale_time, string, i);
    }

    function formatShortWeekday(d) {
      return locale_shortWeekdays[d.getDay()];
    }

    function formatWeekday(d) {
      return locale_weekdays[d.getDay()];
    }

    function formatShortMonth(d) {
      return locale_shortMonths[d.getMonth()];
    }

    function formatMonth(d) {
      return locale_months[d.getMonth()];
    }

    function formatPeriod(d) {
      return locale_periods[+(d.getHours() >= 12)];
    }

    function formatQuarter(d) {
      return 1 + ~~(d.getMonth() / 3);
    }

    function formatUTCShortWeekday(d) {
      return locale_shortWeekdays[d.getUTCDay()];
    }

    function formatUTCWeekday(d) {
      return locale_weekdays[d.getUTCDay()];
    }

    function formatUTCShortMonth(d) {
      return locale_shortMonths[d.getUTCMonth()];
    }

    function formatUTCMonth(d) {
      return locale_months[d.getUTCMonth()];
    }

    function formatUTCPeriod(d) {
      return locale_periods[+(d.getUTCHours() >= 12)];
    }

    function formatUTCQuarter(d) {
      return 1 + ~~(d.getUTCMonth() / 3);
    }

    return {
      format: function(specifier) {
        var f = newFormat(specifier += "", formats);
        f.toString = function() { return specifier; };
        return f;
      },
      parse: function(specifier) {
        var p = newParse(specifier += "", false);
        p.toString = function() { return specifier; };
        return p;
      },
      utcFormat: function(specifier) {
        var f = newFormat(specifier += "", utcFormats);
        f.toString = function() { return specifier; };
        return f;
      },
      utcParse: function(specifier) {
        var p = newParse(specifier += "", true);
        p.toString = function() { return specifier; };
        return p;
      }
    };
  }

  var pads = {"-": "", "_": " ", "0": "0"},
      numberRe = /^\s*\d+/, // note: ignores next directive
      percentRe = /^%/,
      requoteRe = /[\\^$*+?|[\]().{}]/g;

  function pad(value, fill, width) {
    var sign = value < 0 ? "-" : "",
        string = (sign ? -value : value) + "",
        length = string.length;
    return sign + (length < width ? new Array(width - length + 1).join(fill) + string : string);
  }

  function requote(s) {
    return s.replace(requoteRe, "\\$&");
  }

  function formatRe(names) {
    return new RegExp("^(?:" + names.map(requote).join("|") + ")", "i");
  }

  function formatLookup(names) {
    var map = {}, i = -1, n = names.length;
    while (++i < n) map[names[i].toLowerCase()] = i;
    return map;
  }

  function parseWeekdayNumberSunday(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 1));
    return n ? (d.w = +n[0], i + n[0].length) : -1;
  }

  function parseWeekdayNumberMonday(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 1));
    return n ? (d.u = +n[0], i + n[0].length) : -1;
  }

  function parseWeekNumberSunday(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.U = +n[0], i + n[0].length) : -1;
  }

  function parseWeekNumberISO(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.V = +n[0], i + n[0].length) : -1;
  }

  function parseWeekNumberMonday(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.W = +n[0], i + n[0].length) : -1;
  }

  function parseFullYear(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 4));
    return n ? (d.y = +n[0], i + n[0].length) : -1;
  }

  function parseYear(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.y = +n[0] + (+n[0] > 68 ? 1900 : 2000), i + n[0].length) : -1;
  }

  function parseZone(d, string, i) {
    var n = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(string.slice(i, i + 6));
    return n ? (d.Z = n[1] ? 0 : -(n[2] + (n[3] || "00")), i + n[0].length) : -1;
  }

  function parseQuarter(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 1));
    return n ? (d.q = n[0] * 3 - 3, i + n[0].length) : -1;
  }

  function parseMonthNumber(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.m = n[0] - 1, i + n[0].length) : -1;
  }

  function parseDayOfMonth(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.d = +n[0], i + n[0].length) : -1;
  }

  function parseDayOfYear(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 3));
    return n ? (d.m = 0, d.d = +n[0], i + n[0].length) : -1;
  }

  function parseHour24(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.H = +n[0], i + n[0].length) : -1;
  }

  function parseMinutes(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.M = +n[0], i + n[0].length) : -1;
  }

  function parseSeconds(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 2));
    return n ? (d.S = +n[0], i + n[0].length) : -1;
  }

  function parseMilliseconds(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 3));
    return n ? (d.L = +n[0], i + n[0].length) : -1;
  }

  function parseMicroseconds(d, string, i) {
    var n = numberRe.exec(string.slice(i, i + 6));
    return n ? (d.L = Math.floor(n[0] / 1000), i + n[0].length) : -1;
  }

  function parseLiteralPercent(d, string, i) {
    var n = percentRe.exec(string.slice(i, i + 1));
    return n ? i + n[0].length : -1;
  }

  function parseUnixTimestamp(d, string, i) {
    var n = numberRe.exec(string.slice(i));
    return n ? (d.Q = +n[0], i + n[0].length) : -1;
  }

  function parseUnixTimestampSeconds(d, string, i) {
    var n = numberRe.exec(string.slice(i));
    return n ? (d.s = +n[0], i + n[0].length) : -1;
  }

  function formatDayOfMonth(d, p) {
    return pad(d.getDate(), p, 2);
  }

  function formatHour24(d, p) {
    return pad(d.getHours(), p, 2);
  }

  function formatHour12(d, p) {
    return pad(d.getHours() % 12 || 12, p, 2);
  }

  function formatDayOfYear(d, p) {
    return pad(1 + timeDay.count(timeYear(d), d), p, 3);
  }

  function formatMilliseconds(d, p) {
    return pad(d.getMilliseconds(), p, 3);
  }

  function formatMicroseconds(d, p) {
    return formatMilliseconds(d, p) + "000";
  }

  function formatMonthNumber(d, p) {
    return pad(d.getMonth() + 1, p, 2);
  }

  function formatMinutes(d, p) {
    return pad(d.getMinutes(), p, 2);
  }

  function formatSeconds(d, p) {
    return pad(d.getSeconds(), p, 2);
  }

  function formatWeekdayNumberMonday(d) {
    var day = d.getDay();
    return day === 0 ? 7 : day;
  }

  function formatWeekNumberSunday(d, p) {
    return pad(sunday.count(timeYear(d) - 1, d), p, 2);
  }

  function dISO(d) {
    var day = d.getDay();
    return (day >= 4 || day === 0) ? thursday(d) : thursday.ceil(d);
  }

  function formatWeekNumberISO(d, p) {
    d = dISO(d);
    return pad(thursday.count(timeYear(d), d) + (timeYear(d).getDay() === 4), p, 2);
  }

  function formatWeekdayNumberSunday(d) {
    return d.getDay();
  }

  function formatWeekNumberMonday(d, p) {
    return pad(monday.count(timeYear(d) - 1, d), p, 2);
  }

  function formatYear(d, p) {
    return pad(d.getFullYear() % 100, p, 2);
  }

  function formatYearISO(d, p) {
    d = dISO(d);
    return pad(d.getFullYear() % 100, p, 2);
  }

  function formatFullYear(d, p) {
    return pad(d.getFullYear() % 10000, p, 4);
  }

  function formatFullYearISO(d, p) {
    var day = d.getDay();
    d = (day >= 4 || day === 0) ? thursday(d) : thursday.ceil(d);
    return pad(d.getFullYear() % 10000, p, 4);
  }

  function formatZone(d) {
    var z = d.getTimezoneOffset();
    return (z > 0 ? "-" : (z *= -1, "+"))
        + pad(z / 60 | 0, "0", 2)
        + pad(z % 60, "0", 2);
  }

  function formatUTCDayOfMonth(d, p) {
    return pad(d.getUTCDate(), p, 2);
  }

  function formatUTCHour24(d, p) {
    return pad(d.getUTCHours(), p, 2);
  }

  function formatUTCHour12(d, p) {
    return pad(d.getUTCHours() % 12 || 12, p, 2);
  }

  function formatUTCDayOfYear(d, p) {
    return pad(1 + utcDay$1.count(utcYear$1(d), d), p, 3);
  }

  function formatUTCMilliseconds(d, p) {
    return pad(d.getUTCMilliseconds(), p, 3);
  }

  function formatUTCMicroseconds(d, p) {
    return formatUTCMilliseconds(d, p) + "000";
  }

  function formatUTCMonthNumber(d, p) {
    return pad(d.getUTCMonth() + 1, p, 2);
  }

  function formatUTCMinutes(d, p) {
    return pad(d.getUTCMinutes(), p, 2);
  }

  function formatUTCSeconds(d, p) {
    return pad(d.getUTCSeconds(), p, 2);
  }

  function formatUTCWeekdayNumberMonday(d) {
    var dow = d.getUTCDay();
    return dow === 0 ? 7 : dow;
  }

  function formatUTCWeekNumberSunday(d, p) {
    return pad(utcSunday.count(utcYear$1(d) - 1, d), p, 2);
  }

  function UTCdISO(d) {
    var day = d.getUTCDay();
    return (day >= 4 || day === 0) ? utcThursday(d) : utcThursday.ceil(d);
  }

  function formatUTCWeekNumberISO(d, p) {
    d = UTCdISO(d);
    return pad(utcThursday.count(utcYear$1(d), d) + (utcYear$1(d).getUTCDay() === 4), p, 2);
  }

  function formatUTCWeekdayNumberSunday(d) {
    return d.getUTCDay();
  }

  function formatUTCWeekNumberMonday(d, p) {
    return pad(utcMonday.count(utcYear$1(d) - 1, d), p, 2);
  }

  function formatUTCYear(d, p) {
    return pad(d.getUTCFullYear() % 100, p, 2);
  }

  function formatUTCYearISO(d, p) {
    d = UTCdISO(d);
    return pad(d.getUTCFullYear() % 100, p, 2);
  }

  function formatUTCFullYear(d, p) {
    return pad(d.getUTCFullYear() % 10000, p, 4);
  }

  function formatUTCFullYearISO(d, p) {
    var day = d.getUTCDay();
    d = (day >= 4 || day === 0) ? utcThursday(d) : utcThursday.ceil(d);
    return pad(d.getUTCFullYear() % 10000, p, 4);
  }

  function formatUTCZone() {
    return "+0000";
  }

  function formatLiteralPercent() {
    return "%";
  }

  function formatUnixTimestamp(d) {
    return +d;
  }

  function formatUnixTimestampSeconds(d) {
    return Math.floor(+d / 1000);
  }

  var locale;
  var timeFormat;

  defaultLocale({
    dateTime: "%x, %X",
    date: "%-m/%-d/%Y",
    time: "%-I:%M:%S %p",
    periods: ["AM", "PM"],
    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  });

  function defaultLocale(definition) {
    locale = formatLocale(definition);
    timeFormat = locale.format;
    return locale;
  }

  var durationSecond = 1000,
      durationMinute = durationSecond * 60,
      durationHour = durationMinute * 60,
      durationDay = durationHour * 24,
      durationWeek = durationDay * 7,
      durationMonth = durationDay * 30,
      durationYear = durationDay * 365;

  function date(t) {
    return new Date(t);
  }

  function number(t) {
    return t instanceof Date ? +t : +new Date(+t);
  }

  function calendar(year, month, week, day, hour, minute, second, millisecond, format) {
    var scale = continuous(identity$1, identity$1),
        invert = scale.invert,
        domain = scale.domain;

    var formatMillisecond = format(".%L"),
        formatSecond = format(":%S"),
        formatMinute = format("%I:%M"),
        formatHour = format("%I %p"),
        formatDay = format("%a %d"),
        formatWeek = format("%b %d"),
        formatMonth = format("%B"),
        formatYear = format("%Y");

    var tickIntervals = [
      [second,  1,      durationSecond],
      [second,  5,  5 * durationSecond],
      [second, 15, 15 * durationSecond],
      [second, 30, 30 * durationSecond],
      [minute,  1,      durationMinute],
      [minute,  5,  5 * durationMinute],
      [minute, 15, 15 * durationMinute],
      [minute, 30, 30 * durationMinute],
      [  hour,  1,      durationHour  ],
      [  hour,  3,  3 * durationHour  ],
      [  hour,  6,  6 * durationHour  ],
      [  hour, 12, 12 * durationHour  ],
      [   day,  1,      durationDay   ],
      [   day,  2,  2 * durationDay   ],
      [  week,  1,      durationWeek  ],
      [ month,  1,      durationMonth ],
      [ month,  3,  3 * durationMonth ],
      [  year,  1,      durationYear  ]
    ];

    function tickFormat(date) {
      return (second(date) < date ? formatMillisecond
          : minute(date) < date ? formatSecond
          : hour(date) < date ? formatMinute
          : day(date) < date ? formatHour
          : month(date) < date ? (week(date) < date ? formatDay : formatWeek)
          : year(date) < date ? formatMonth
          : formatYear)(date);
    }

    function tickInterval(interval, start, stop, step) {
      if (interval == null) interval = 10;

      // If a desired tick count is specified, pick a reasonable tick interval
      // based on the extent of the domain and a rough estimate of tick size.
      // Otherwise, assume interval is already a time interval and use it.
      if (typeof interval === "number") {
        var target = Math.abs(stop - start) / interval,
            i = bisector(function(i) { return i[2]; }).right(tickIntervals, target);
        if (i === tickIntervals.length) {
          step = tickStep(start / durationYear, stop / durationYear, interval);
          interval = year;
        } else if (i) {
          i = tickIntervals[target / tickIntervals[i - 1][2] < tickIntervals[i][2] / target ? i - 1 : i];
          step = i[1];
          interval = i[0];
        } else {
          step = Math.max(tickStep(start, stop, interval), 1);
          interval = millisecond;
        }
      }

      return step == null ? interval : interval.every(step);
    }

    scale.invert = function(y) {
      return new Date(invert(y));
    };

    scale.domain = function(_) {
      return arguments.length ? domain(map.call(_, number)) : domain().map(date);
    };

    scale.ticks = function(interval, step) {
      var d = domain(),
          t0 = d[0],
          t1 = d[d.length - 1],
          r = t1 < t0,
          t;
      if (r) t = t0, t0 = t1, t1 = t;
      t = tickInterval(interval, t0, t1, step);
      t = t ? t.range(t0, t1 + 1) : []; // inclusive stop
      return r ? t.reverse() : t;
    };

    scale.tickFormat = function(count, specifier) {
      return specifier == null ? tickFormat : format(specifier);
    };

    scale.nice = function(interval, step) {
      var d = domain();
      return (interval = tickInterval(interval, d[0], d[d.length - 1], step))
          ? domain(nice(d, interval))
          : scale;
    };

    scale.copy = function() {
      return copy(scale, calendar(year, month, week, day, hour, minute, second, millisecond, format));
    };

    return scale;
  }

  function time() {
    return initRange.apply(calendar(timeYear, timeMonth, sunday, timeDay, timeHour, timeMinute, utcSecond, utcMillisecond, timeFormat).domain([new Date(2000, 0, 1), new Date(2000, 0, 2)]), arguments);
  }

  function constant(x) {
    return function() {
      return x;
    };
  }

  function ZoomEvent(target, type, transform) {
    this.target = target;
    this.type = type;
    this.transform = transform;
  }

  function Transform(k, x, y) {
    this.k = k;
    this.x = x;
    this.y = y;
  }

  Transform.prototype = {
    constructor: Transform,
    scale: function(k) {
      return k === 1 ? this : new Transform(this.k * k, this.x, this.y);
    },
    translate: function(x, y) {
      return x === 0 & y === 0 ? this : new Transform(this.k, this.x + this.k * x, this.y + this.k * y);
    },
    apply: function(point) {
      return [point[0] * this.k + this.x, point[1] * this.k + this.y];
    },
    applyX: function(x) {
      return x * this.k + this.x;
    },
    applyY: function(y) {
      return y * this.k + this.y;
    },
    invert: function(location) {
      return [(location[0] - this.x) / this.k, (location[1] - this.y) / this.k];
    },
    invertX: function(x) {
      return (x - this.x) / this.k;
    },
    invertY: function(y) {
      return (y - this.y) / this.k;
    },
    rescaleX: function(x) {
      return x.copy().domain(x.range().map(this.invertX, this).map(x.invert, x));
    },
    rescaleY: function(y) {
      return y.copy().domain(y.range().map(this.invertY, this).map(y.invert, y));
    },
    toString: function() {
      return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
    }
  };

  var identity = new Transform(1, 0, 0);

  transform.prototype = Transform.prototype;

  function transform(node) {
    while (!node.__zoom) if (!(node = node.parentNode)) return identity;
    return node.__zoom;
  }

  function nopropagation() {
    event.stopImmediatePropagation();
  }

  function noevent() {
    event.preventDefault();
    event.stopImmediatePropagation();
  }

  // Ignore right-click, since that should open the context menu.
  function defaultFilter() {
    return !event.ctrlKey && !event.button;
  }

  function defaultExtent() {
    var e = this;
    if (e instanceof SVGElement) {
      e = e.ownerSVGElement || e;
      if (e.hasAttribute("viewBox")) {
        e = e.viewBox.baseVal;
        return [[e.x, e.y], [e.x + e.width, e.y + e.height]];
      }
      return [[0, 0], [e.width.baseVal.value, e.height.baseVal.value]];
    }
    return [[0, 0], [e.clientWidth, e.clientHeight]];
  }

  function defaultTransform() {
    return this.__zoom || identity;
  }

  function defaultWheelDelta() {
    return -event.deltaY * (event.deltaMode === 1 ? 0.05 : event.deltaMode ? 1 : 0.002);
  }

  function defaultTouchable() {
    return navigator.maxTouchPoints || ("ontouchstart" in this);
  }

  function defaultConstrain(transform, extent, translateExtent) {
    var dx0 = transform.invertX(extent[0][0]) - translateExtent[0][0],
        dx1 = transform.invertX(extent[1][0]) - translateExtent[1][0],
        dy0 = transform.invertY(extent[0][1]) - translateExtent[0][1],
        dy1 = transform.invertY(extent[1][1]) - translateExtent[1][1];
    return transform.translate(
      dx1 > dx0 ? (dx0 + dx1) / 2 : Math.min(0, dx0) || Math.max(0, dx1),
      dy1 > dy0 ? (dy0 + dy1) / 2 : Math.min(0, dy0) || Math.max(0, dy1)
    );
  }

  function zoom() {
    var filter = defaultFilter,
        extent = defaultExtent,
        constrain = defaultConstrain,
        wheelDelta = defaultWheelDelta,
        touchable = defaultTouchable,
        scaleExtent = [0, Infinity],
        translateExtent = [[-Infinity, -Infinity], [Infinity, Infinity]],
        duration = 250,
        interpolate = interpolateZoom,
        listeners = dispatch("start", "zoom", "end"),
        touchstarting,
        touchending,
        touchDelay = 500,
        wheelDelay = 150,
        clickDistance2 = 0;

    function zoom(selection) {
      selection
          .property("__zoom", defaultTransform)
          .on("wheel.zoom", wheeled)
          .on("mousedown.zoom", mousedowned)
          .on("dblclick.zoom", dblclicked)
        .filter(touchable)
          .on("touchstart.zoom", touchstarted)
          .on("touchmove.zoom", touchmoved)
          .on("touchend.zoom touchcancel.zoom", touchended)
          .style("touch-action", "none")
          .style("-webkit-tap-highlight-color", "rgba(0,0,0,0)");
    }

    zoom.transform = function(collection, transform, point) {
      var selection = collection.selection ? collection.selection() : collection;
      selection.property("__zoom", defaultTransform);
      if (collection !== selection) {
        schedule(collection, transform, point);
      } else {
        selection.interrupt().each(function() {
          gesture(this, arguments)
              .start()
              .zoom(null, typeof transform === "function" ? transform.apply(this, arguments) : transform)
              .end();
        });
      }
    };

    zoom.scaleBy = function(selection, k, p) {
      zoom.scaleTo(selection, function() {
        var k0 = this.__zoom.k,
            k1 = typeof k === "function" ? k.apply(this, arguments) : k;
        return k0 * k1;
      }, p);
    };

    zoom.scaleTo = function(selection, k, p) {
      zoom.transform(selection, function() {
        var e = extent.apply(this, arguments),
            t0 = this.__zoom,
            p0 = p == null ? centroid(e) : typeof p === "function" ? p.apply(this, arguments) : p,
            p1 = t0.invert(p0),
            k1 = typeof k === "function" ? k.apply(this, arguments) : k;
        return constrain(translate(scale(t0, k1), p0, p1), e, translateExtent);
      }, p);
    };

    zoom.translateBy = function(selection, x, y) {
      zoom.transform(selection, function() {
        return constrain(this.__zoom.translate(
          typeof x === "function" ? x.apply(this, arguments) : x,
          typeof y === "function" ? y.apply(this, arguments) : y
        ), extent.apply(this, arguments), translateExtent);
      });
    };

    zoom.translateTo = function(selection, x, y, p) {
      zoom.transform(selection, function() {
        var e = extent.apply(this, arguments),
            t = this.__zoom,
            p0 = p == null ? centroid(e) : typeof p === "function" ? p.apply(this, arguments) : p;
        return constrain(identity.translate(p0[0], p0[1]).scale(t.k).translate(
          typeof x === "function" ? -x.apply(this, arguments) : -x,
          typeof y === "function" ? -y.apply(this, arguments) : -y
        ), e, translateExtent);
      }, p);
    };

    function scale(transform, k) {
      k = Math.max(scaleExtent[0], Math.min(scaleExtent[1], k));
      return k === transform.k ? transform : new Transform(k, transform.x, transform.y);
    }

    function translate(transform, p0, p1) {
      var x = p0[0] - p1[0] * transform.k, y = p0[1] - p1[1] * transform.k;
      return x === transform.x && y === transform.y ? transform : new Transform(transform.k, x, y);
    }

    function centroid(extent) {
      return [(+extent[0][0] + +extent[1][0]) / 2, (+extent[0][1] + +extent[1][1]) / 2];
    }

    function schedule(transition, transform, point) {
      transition
          .on("start.zoom", function() { gesture(this, arguments).start(); })
          .on("interrupt.zoom end.zoom", function() { gesture(this, arguments).end(); })
          .tween("zoom", function() {
            var that = this,
                args = arguments,
                g = gesture(that, args),
                e = extent.apply(that, args),
                p = point == null ? centroid(e) : typeof point === "function" ? point.apply(that, args) : point,
                w = Math.max(e[1][0] - e[0][0], e[1][1] - e[0][1]),
                a = that.__zoom,
                b = typeof transform === "function" ? transform.apply(that, args) : transform,
                i = interpolate(a.invert(p).concat(w / a.k), b.invert(p).concat(w / b.k));
            return function(t) {
              if (t === 1) t = b; // Avoid rounding error on end.
              else { var l = i(t), k = w / l[2]; t = new Transform(k, p[0] - l[0] * k, p[1] - l[1] * k); }
              g.zoom(null, t);
            };
          });
    }

    function gesture(that, args, clean) {
      return (!clean && that.__zooming) || new Gesture(that, args);
    }

    function Gesture(that, args) {
      this.that = that;
      this.args = args;
      this.active = 0;
      this.extent = extent.apply(that, args);
      this.taps = 0;
    }

    Gesture.prototype = {
      start: function() {
        if (++this.active === 1) {
          this.that.__zooming = this;
          this.emit("start");
        }
        return this;
      },
      zoom: function(key, transform) {
        if (this.mouse && key !== "mouse") this.mouse[1] = transform.invert(this.mouse[0]);
        if (this.touch0 && key !== "touch") this.touch0[1] = transform.invert(this.touch0[0]);
        if (this.touch1 && key !== "touch") this.touch1[1] = transform.invert(this.touch1[0]);
        this.that.__zoom = transform;
        this.emit("zoom");
        return this;
      },
      end: function() {
        if (--this.active === 0) {
          delete this.that.__zooming;
          this.emit("end");
        }
        return this;
      },
      emit: function(type) {
        customEvent(new ZoomEvent(zoom, type, this.that.__zoom), listeners.apply, listeners, [type, this.that, this.args]);
      }
    };

    function wheeled() {
      if (!filter.apply(this, arguments)) return;
      var g = gesture(this, arguments),
          t = this.__zoom,
          k = Math.max(scaleExtent[0], Math.min(scaleExtent[1], t.k * Math.pow(2, wheelDelta.apply(this, arguments)))),
          p = mouse(this);

      // If the mouse is in the same location as before, reuse it.
      // If there were recent wheel events, reset the wheel idle timeout.
      if (g.wheel) {
        if (g.mouse[0][0] !== p[0] || g.mouse[0][1] !== p[1]) {
          g.mouse[1] = t.invert(g.mouse[0] = p);
        }
        clearTimeout(g.wheel);
      }

      // If this wheel event won’t trigger a transform change, ignore it.
      else if (t.k === k) return;

      // Otherwise, capture the mouse point and location at the start.
      else {
        g.mouse = [p, t.invert(p)];
        interrupt(this);
        g.start();
      }

      noevent();
      g.wheel = setTimeout(wheelidled, wheelDelay);
      g.zoom("mouse", constrain(translate(scale(t, k), g.mouse[0], g.mouse[1]), g.extent, translateExtent));

      function wheelidled() {
        g.wheel = null;
        g.end();
      }
    }

    function mousedowned() {
      if (touchending || !filter.apply(this, arguments)) return;
      var g = gesture(this, arguments, true),
          v = select(event.view).on("mousemove.zoom", mousemoved, true).on("mouseup.zoom", mouseupped, true),
          p = mouse(this),
          x0 = event.clientX,
          y0 = event.clientY;

      dragDisable(event.view);
      nopropagation();
      g.mouse = [p, this.__zoom.invert(p)];
      interrupt(this);
      g.start();

      function mousemoved() {
        noevent();
        if (!g.moved) {
          var dx = event.clientX - x0, dy = event.clientY - y0;
          g.moved = dx * dx + dy * dy > clickDistance2;
        }
        g.zoom("mouse", constrain(translate(g.that.__zoom, g.mouse[0] = mouse(g.that), g.mouse[1]), g.extent, translateExtent));
      }

      function mouseupped() {
        v.on("mousemove.zoom mouseup.zoom", null);
        yesdrag(event.view, g.moved);
        noevent();
        g.end();
      }
    }

    function dblclicked() {
      if (!filter.apply(this, arguments)) return;
      var t0 = this.__zoom,
          p0 = mouse(this),
          p1 = t0.invert(p0),
          k1 = t0.k * (event.shiftKey ? 0.5 : 2),
          t1 = constrain(translate(scale(t0, k1), p0, p1), extent.apply(this, arguments), translateExtent);

      noevent();
      if (duration > 0) select(this).transition().duration(duration).call(schedule, t1, p0);
      else select(this).call(zoom.transform, t1);
    }

    function touchstarted() {
      if (!filter.apply(this, arguments)) return;
      var touches = event.touches,
          n = touches.length,
          g = gesture(this, arguments, event.changedTouches.length === n),
          started, i, t, p;

      nopropagation();
      for (i = 0; i < n; ++i) {
        t = touches[i], p = touch(this, touches, t.identifier);
        p = [p, this.__zoom.invert(p), t.identifier];
        if (!g.touch0) g.touch0 = p, started = true, g.taps = 1 + !!touchstarting;
        else if (!g.touch1 && g.touch0[2] !== p[2]) g.touch1 = p, g.taps = 0;
      }

      if (touchstarting) touchstarting = clearTimeout(touchstarting);

      if (started) {
        if (g.taps < 2) touchstarting = setTimeout(function() { touchstarting = null; }, touchDelay);
        interrupt(this);
        g.start();
      }
    }

    function touchmoved() {
      if (!this.__zooming) return;
      var g = gesture(this, arguments),
          touches = event.changedTouches,
          n = touches.length, i, t, p, l;

      noevent();
      if (touchstarting) touchstarting = clearTimeout(touchstarting);
      g.taps = 0;
      for (i = 0; i < n; ++i) {
        t = touches[i], p = touch(this, touches, t.identifier);
        if (g.touch0 && g.touch0[2] === t.identifier) g.touch0[0] = p;
        else if (g.touch1 && g.touch1[2] === t.identifier) g.touch1[0] = p;
      }
      t = g.that.__zoom;
      if (g.touch1) {
        var p0 = g.touch0[0], l0 = g.touch0[1],
            p1 = g.touch1[0], l1 = g.touch1[1],
            dp = (dp = p1[0] - p0[0]) * dp + (dp = p1[1] - p0[1]) * dp,
            dl = (dl = l1[0] - l0[0]) * dl + (dl = l1[1] - l0[1]) * dl;
        t = scale(t, Math.sqrt(dp / dl));
        p = [(p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2];
        l = [(l0[0] + l1[0]) / 2, (l0[1] + l1[1]) / 2];
      }
      else if (g.touch0) p = g.touch0[0], l = g.touch0[1];
      else return;
      g.zoom("touch", constrain(translate(t, p, l), g.extent, translateExtent));
    }

    function touchended() {
      if (!this.__zooming) return;
      var g = gesture(this, arguments),
          touches = event.changedTouches,
          n = touches.length, i, t;

      nopropagation();
      if (touchending) clearTimeout(touchending);
      touchending = setTimeout(function() { touchending = null; }, touchDelay);
      for (i = 0; i < n; ++i) {
        t = touches[i];
        if (g.touch0 && g.touch0[2] === t.identifier) delete g.touch0;
        else if (g.touch1 && g.touch1[2] === t.identifier) delete g.touch1;
      }
      if (g.touch1 && !g.touch0) g.touch0 = g.touch1, delete g.touch1;
      if (g.touch0) g.touch0[1] = this.__zoom.invert(g.touch0[0]);
      else {
        g.end();
        // If this was a dbltap, reroute to the (optional) dblclick.zoom handler.
        if (g.taps === 2) {
          var p = select(this).on("dblclick.zoom");
          if (p) p.apply(this, arguments);
        }
      }
    }

    zoom.wheelDelta = function(_) {
      return arguments.length ? (wheelDelta = typeof _ === "function" ? _ : constant(+_), zoom) : wheelDelta;
    };

    zoom.filter = function(_) {
      return arguments.length ? (filter = typeof _ === "function" ? _ : constant(!!_), zoom) : filter;
    };

    zoom.touchable = function(_) {
      return arguments.length ? (touchable = typeof _ === "function" ? _ : constant(!!_), zoom) : touchable;
    };

    zoom.extent = function(_) {
      return arguments.length ? (extent = typeof _ === "function" ? _ : constant([[+_[0][0], +_[0][1]], [+_[1][0], +_[1][1]]]), zoom) : extent;
    };

    zoom.scaleExtent = function(_) {
      return arguments.length ? (scaleExtent[0] = +_[0], scaleExtent[1] = +_[1], zoom) : [scaleExtent[0], scaleExtent[1]];
    };

    zoom.translateExtent = function(_) {
      return arguments.length ? (translateExtent[0][0] = +_[0][0], translateExtent[1][0] = +_[1][0], translateExtent[0][1] = +_[0][1], translateExtent[1][1] = +_[1][1], zoom) : [[translateExtent[0][0], translateExtent[0][1]], [translateExtent[1][0], translateExtent[1][1]]];
    };

    zoom.constrain = function(_) {
      return arguments.length ? (constrain = _, zoom) : constrain;
    };

    zoom.duration = function(_) {
      return arguments.length ? (duration = +_, zoom) : duration;
    };

    zoom.interpolate = function(_) {
      return arguments.length ? (interpolate = _, zoom) : interpolate;
    };

    zoom.on = function() {
      var value = listeners.on.apply(listeners, arguments);
      return value === listeners ? zoom : value;
    };

    zoom.clickDistance = function(_) {
      return arguments.length ? (clickDistance2 = (_ = +_) * _, zoom) : Math.sqrt(clickDistance2);
    };

    return zoom;
  }

  function _typeof(obj) {
    if (typeof Symbol === "function" && _typeof$1(Symbol.iterator) === "symbol") {
      _typeof = function _typeof(obj) {
        return _typeof$1(obj);
      };
    } else {
      _typeof = function _typeof(obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : _typeof$1(obj);
      };
    }
    return _typeof(obj);
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }
  var LabelLayoutMode = Object.freeze({
    Automode: "automatic",
    Horizontal: "horizontal",
    Rotate90: "rotate90",
    Rotate45: "rotate45",
    Stagger: "stagger"
  });
  var Orientation = Object.freeze({
    Bottom: "bottom",
    Top: "top",
    Left: "left",
    Right: "right"
  });
  function verifyBounds(_bounds) {
    if (_typeof(_bounds) !== 'object') throw Error("bounds must be an object with width and height property");
    if (_bounds.height === null || _bounds.height === undefined || _bounds.width === null || _bounds.width === undefined) throw Error("bounds must specify height and width");
  }
  function verifyLabelMode(_mode) {
    switch (_mode) {
      case LabelLayoutMode.Automode:
      case LabelLayoutMode.Horizontal:
      case LabelLayoutMode.Rotate45:
      case LabelLayoutMode.Rotate90:
      case LabelLayoutMode.Stagger:
        break;
      default:
        throw Error("Unsupported label layout mode");
    }
  }
  function verifyAxis(_axis) {
    if (!_axis || !_axis.scale || typeof _axis.scale !== "function") throw Error("Unsupported axis");
  }
  function verifyOrientation(_orientation) {
    switch (_orientation) {
      case Orientation.Left:
      case Orientation.Top:
      case Orientation.Right:
      case Orientation.Bottom:
        break;
      default:
        throw Error("Unsupported orientation");
    }
  }
  function calculate45DegreeSpace(_node, _bbox, _orientation, _maxWidth) {
    // - Axis.java: from Axis.axis(g) method ... "Each 'tick' is a group node ... which contains a line (the tick mark)
    //   and a text node (the tick label)."
    // - The incoming node passed here is the text node, to get the x location our text node is displayed at, we lookup
    //   the transform on the parent group node and parse the "translate(x," from it. If anything fails, we return the
    //   incoming maxWidth (length of a 45 degree label that isn't restricted by edge conditions)
    var width = _maxWidth; // consolidate the SVGTransformList containing all transformations
    // to a single SVGTransform of type SVG_TRANSFORM_MATRIX and get
    // its SVGMatrix.

    var matrix = _node.parentNode.transform.baseVal.consolidate().matrix;
    if (matrix) {
      var xLabelPos = matrix.e; // 0.7071 = Math.cos(45)

      var xLabelWidth = _bbox.width * 0.7071;
      var isBottom = _orientation === Orientation.Bottom;
      if (isBottom) {
        // given xLabelPos is baseline, shift slightly to left (want top of text box)
        xLabelPos -= _bbox.height / 4;
        if (xLabelPos - xLabelWidth < 0) {
          xLabelWidth = xLabelPos;
          width = xLabelWidth / 0.7071;
        }
      } // no shift of xLabelPos (as was done for bottom axis), baseline works well for top axis.

      /*if ( xLabelPos + xLabelWidth > bounds.width )
      {
          xLabelWidth = bounds.width - xLabelPos;
          width = xLabelWidth / 0.7071;
      }*/
      // don't make text longer than space available.

      if (width > _maxWidth) width = _maxWidth;
    }
    return Math.abs(width);
  }
  var HORIZONTAL_WEIGHT = 1.1;
  var LabelLayoutCalculator = function LabelLayoutCalculator() {
    // Input needed to do layout.
    var labelBounds, layoutMode, isContinuous, cachedBBoxMap, orientation; // computed output layout values.

    var labelHeight = 0,
      usedSizeForLabels = 0,
      layoutSpillOver = 0;
    var isHorizontal;
    function layout(_textSelection) {
      var cellWidth = labelBounds.width;
      var cellWidth90 = labelBounds.height;
      var horizontalScore = 0;
      var staggerScore = 0;
      var rotate45Score = 0;
      var rotate90Score = 0;
      isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom; // For numeric axis:
      // (1) layout is HORIZONTAL for vertical oriented axis and
      // (2) either HORIZONTAL or ROTATE90 for horizontal oriented axis based on configured _layoutMode.

      if (isContinuous) {
        // _layoutMode can be a bunch of invalid values (categorical axis
        // has more modes), so unless _layoutMode is explicitly
        // ROTATE90, we use HORIZONTAL.
        var _mode2 = LabelLayoutMode.Horizontal;
        if (isHorizontal) _mode2 = layoutMode === LabelLayoutMode.Rotate90 ? LabelLayoutMode.Rotate90 : LabelLayoutMode.Horizontal;
        measureNumericLabel();
        layoutMode = _mode2;
        return _mode2;
      }
      var labelCount = _textSelection.size(); // determine which scores to calculate

      var calcStagger = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Stagger;
      var calcRotate45 = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Rotate45;
      var calcRotate90 = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Rotate90;
      var spaceFor45Label = 0;
      var widestLabel = 0;
      _textSelection.each(function (_data, _index) {
        var labelBounds = cachedBBoxMap.get(_index); // In case of empty label, do not calculate space for each mode, it is zero always.

        if (labelBounds.height > 0 && labelBounds.width > 0) {
          var labelWidth = labelBounds.width;
          if (labelWidth > widestLabel) widestLabel = labelWidth;
          labelHeight = labelBounds.height;
          horizontalScore += labelWidth <= cellWidth ? 1 : cellWidth / labelWidth;
          if (isHorizontal) {
            if (calcStagger) {
              // we don't consider stagger/rotated for left/right axis orientation
              var spaceForLabel = cellWidth * 2; // if only a single label, half normal stagger space

              if (_index === 0 && _index === labelCount - 1) spaceForLabel *= 0.5; // first and last label only get 3/4 normal stagger space
              else if (_index === 0 || _index === labelCount - 1) spaceForLabel *= 0.75;
              staggerScore += labelWidth <= spaceForLabel ? 1 : spaceForLabel / labelWidth;
            }
            if (calcRotate45) {
              // vertical space for 90 degree rotated label is 'cellWidth90'
              // height of tick label is 'labelHeight'
              // longest label at 45 degree rotation is cellWidth90 / Math.cos(45) - labelHeight
              // 0.7071 = Math.cos(45)
              if (spaceFor45Label === 0) spaceFor45Label = cellWidth90 / 0.7071 - labelHeight;
              var space = calculate45DegreeSpace(this, labelBounds, orientation, spaceFor45Label);
              rotate45Score += labelWidth <= space ? 1 : space / labelWidth;
            }
            if (calcRotate90) {
              rotate90Score += labelWidth <= cellWidth90 ? 1 : cellWidth90 / labelWidth;
            }
          }
        }
      });
      var mode = LabelLayoutMode.Horizontal;
      if (layoutMode === LabelLayoutMode.Automode) {
        // Product Management has decided that it is better to truncate a little with horizontal label orientation
        // than to show text rotated with no truncation, so bump up scores if stagger is allowed
        if (isHorizontal) {
          horizontalScore *= HORIZONTAL_WEIGHT;
          staggerScore *= HORIZONTAL_WEIGHT;
        } // determine the winner (highest score), mode is initialized to HORIZONTAL

        if (staggerScore > horizontalScore && staggerScore >= rotate45Score && staggerScore >= rotate90Score) mode = LabelLayoutMode.Stagger;else if (rotate45Score > horizontalScore && rotate45Score >= rotate90Score) mode = LabelLayoutMode.Rotate45;else if (rotate90Score > horizontalScore) mode = LabelLayoutMode.Rotate90;
      } else {
        if (!isHorizontal) mode = LabelLayoutMode.Horizontal;else mode = layoutMode; // forced to one of HORIZONTAL, STAGGER, ROTATE45 or ROTATE90
      }

      if (isHorizontal) {
        switch (mode) {
          case LabelLayoutMode.Stagger:
            usedSizeForLabels = labelHeight * 2;
            break;
          case LabelLayoutMode.Rotate45:
            // 0.7071 = Math.cos(45)
            usedSizeForLabels = (widestLabel + labelHeight) * 0.7071;
            break;
          case LabelLayoutMode.Rotate90:
            usedSizeForLabels = widestLabel;
            break;
          case LabelLayoutMode.Horizontal:
          default:
            usedSizeForLabels = labelHeight;
            break;
        }
      } else {
        usedSizeForLabels = widestLabel;
        layoutSpillOver = labelHeight / 2;
      }
      layoutMode = mode;
      return mode;
    }
    layout.labelBounds = function (_bounds) {
      labelBounds = _bounds;
      return layout;
    };
    layout.cachedBBoxMap = function (_map) {
      cachedBBoxMap = _map;
      return layout;
    };
    layout.layoutMode = function (_mode) {
      if (_mode !== null && _mode !== undefined) {
        layoutMode = _mode;
        return layout;
      } else {
        return layoutMode;
      }
    };
    layout.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return layout;
    };
    layout.isContinuousAxis = function (_isContinuos) {
      isContinuous = _isContinuos;
      return layout;
    };
    layout.labelHeight = function () {
      return labelHeight;
    };
    layout.usedSizeForLabels = function () {
      return usedSizeForLabels;
    };
    layout.layoutSpillOver = function () {
      return layoutSpillOver;
    };
    function measureNumericLabel() {
      layoutSpillOver = 0;
      labelHeight = 0;
      var widestLabel = 0;
      for (var index = 0; index < cachedBBoxMap.size; index++) {
        if (cachedBBoxMap.get(index).width > widestLabel) widestLabel = cachedBBoxMap.get(index).width;
        if (cachedBBoxMap.get(index).height > labelHeight) labelHeight = cachedBBoxMap.get(index).height;
      }
      if (isHorizontal) {
        layoutSpillOver = layoutMode === LabelLayoutMode.Rotate90 ? labelHeight / 2 : widestLabel / 2 + 2;
        usedSizeForLabels = layoutMode === LabelLayoutMode.Rotate90 ? widestLabel : labelHeight;
      } else {
        layoutSpillOver = labelHeight / 2;
        usedSizeForLabels = widestLabel;
      }
    }
    return layout;
  };
  var LabelAnchor = function LabelAnchor() {
    var mode, orientation;
    function anchor(_textSelection) {
      var isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom;
      var anchorVal;
      if (mode === LabelLayoutMode.Rotate45 || mode === LabelLayoutMode.Rotate90) {
        if (isHorizontal) {
          if (orientation === Orientation.Bottom) anchorVal = "end";else if (orientation === Orientation.Top) anchorVal = "start";else anchorVal = "middle";
        }
      } else {
        if (isHorizontal) anchorVal = "middle";else if (orientation === Orientation.Right) anchorVal = "start";else anchorVal = "end";
      }
      _textSelection.style("text-anchor", anchorVal);
    }
    anchor.labelMode = function (_mode) {
      mode = _mode;
      return anchor;
    };
    anchor.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return anchor;
    };
    return anchor;
  };
  var LabelTransform = function LabelTransform() {
    var mode, orientation, cachedBBoxMap;
    function transform(_textSelection) {
      var isBottom = orientation === Orientation.Bottom;
      _textSelection.attr("transform", function (_data, _index, _grouIndex) {
        var bbox = cachedBBoxMap.get(_index);
        var x = 0;
        var y = 0;
        var rotation_cy = 0; // if stagger, every other label is on the second line
        // adjust x for first / last if not doing 'middle' alignment

        if (mode === LabelLayoutMode.Stagger) {
          if (_index % 2 === 1) {
            var staggerDirection = isBottom ? 1 : -1;
            y += bbox.height * staggerDirection;
          }
        } // if rotate 45 degrees, shift x position

        if (mode === LabelLayoutMode.Rotate45) {
          if (isBottom) x -= bbox.height;else x += bbox.height / 2;
        } // if rotate 90 degrees, shift x position.
        else if (mode === LabelLayoutMode.Rotate90) {
          if (isBottom) {
            // assumption is height * 1/4 is descent
            x -= cachedBBoxMap.get(_index).height * 1 / 4; // space to move away from axis

            rotation_cy = 10;
          } else {
            x += cachedBBoxMap.get(_index).height / 2; // space to move away from axis

            rotation_cy = -10;
          }
        }
        var rotationDegrees = mode === LabelLayoutMode.Rotate90 ? -90 : mode === LabelLayoutMode.Rotate45 ? -45 : 0;
        return "translate(" + x + "," + y + ") rotate(" + rotationDegrees + ",0," + rotation_cy + ")";
      });
    }
    transform.labelMode = function (_mode) {
      mode = _mode;
      return transform;
    };
    transform.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return transform;
    };
    transform.cachedBBoxMap = function (_map) {
      cachedBBoxMap = _map;
      return transform;
    };
    return transform;
  };

  /**
   * Set font to a struct of the following 6 properties: font-style
   * font-variant font-weight font-size/line-height font-family. see
   * https://developer.mozilla.org/en-US/docs/Web/CSS/font
   */

  var FontStyleStruct = /*#__PURE__*/
  function () {
    function FontStyleStruct(_textNode) {
      _classCallCheck(this, FontStyleStruct);
      var styles = getComputedStyle(_textNode);
      this.fontStyle = styles["font-style"];
      this.fontVariant = styles["font-variant"];
      this.fontWeight = styles["font-weight"];
      this.fontSize = styles["font-size"];
      this.lineHeight = styles["line-height"];
      this.fontFamily = styles["font-family"];
    }
    _createClass(FontStyleStruct, [{
      key: "toString",
      value: function toString() {
        return this.fontStyle.toString() + " " + this.fontVariant.toString() + " " + this.fontWeight.toString() + " " + this.fontSize.toString() + "/" + this.lineHeight.toString() + " " + this.fontFamily.toString();
      }
    }]);
    return FontStyleStruct;
  }();
  var TextData = /*#__PURE__*/
  function () {
    function TextData() {
      _classCallCheck(this, TextData);

      /**
      * Lines array
      */
      this.lines = [];
    }
    /**
     * @param line line text string
     */

    _createClass(TextData, [{
      key: "add",
      value: function add(_line) {
        if (_line) this.lines.push(_line);
      }
      /**
       * @return number of lines
       */
    }, {
      key: "length",
      value: function length() {
        return this.lines.length;
      }
    }]);
    return TextData;
  }();
  var Canvas = /*#__PURE__*/
  function () {
    function Canvas() {
      _classCallCheck(this, Canvas);
    }
    _createClass(Canvas, null, [{
      key: "create",
      value: function create() {
        if (typeof document !== "undefined") {
          var canvas = document.createElement("canvas");
          return canvas;
        }
        return null;
      }
    }]);
    return Canvas;
  }();
  var LabelWrap = function LabelWrap() {
    var bounds;
    var canvas = Canvas.create();
    var textOverFlow = "...";
    var multiLine = false;
    function wrap(_selection) {
      var height = bounds.height;
      var width = bounds.width; // Read the font style once.
      // Assumption: All axis labels have the same font.

      var fontStyleStruct = new FontStyleStruct(_selection.node());
      var lineHeight = fontStyleStruct.lineHeight || fontStyleStruct.fontSize.value;
      var fontStyle = fontStyleStruct.toString();
      _selection.each(function (_data) {
        var textData = new TextData();
        var n;
        var line = "";
        var space = "";
        var total_height = 0;
        var clipped = false;
        var words = multiLine ? this.textContent.split(' ') : [this.textContent];
        for (n = 0; !clipped && n < words.length && total_height < height; ++n) {
          var testLine = line.concat(space).concat(words[n]);
          space = " ";
          if (_measureText(testLine, fontStyle) > width) {
            // even 1 word could not be wrapped, clip|truncate and exit
            if (_measureText(words[n], fontStyle) > width) {
              // Adds a truncated line to the textData
              textData.add(_truncate(testLine, width, fontStyle)); // If we can't even fit a single ellipse, return immediately

              if (textData.length() <= 0) return; // Otherwise, stop adding lines now

              clipped = true;
              line = "";
            } else {
              textData.add(line); // line could be wider than max width, but if so, it will be truncated.

              line = words[n];
            }
            total_height += lineHeight;
          } else {
            line = testLine;
          }
        } // once we are out we either run out of vertical space or words
        // if we run out of words we have one last line to add
        // we run out of words, add last line if there is anything in it, truncate|clip if needed

        if (n === words.length) {
          if (total_height + lineHeight <= height) {
            // height allows, add last line
            // Don't allow a blank line to be added--it will not change appearance, but
            // it can mess up the flags.
            if (line) textData.add(_truncate(line, width, fontStyle));
          }
        } // now we are back within height bounds
        // step back - remove trailing line to add ellipses and add it back truncated

        var lastAddedLine = "";
        if (textData.length() > 0) lastAddedLine = textData.lines.pop();
        line = lastAddedLine.concat(" ").concat(line);
        textData.add(_truncate(line, width, fontStyle));
        if (textData.length() <= 1) {
          d3.select(this).text(line);
        }
      });
    }
    wrap.bounds = function (_bounds) {
      bounds = _bounds;
      return wrap;
    };
    wrap.multiLine = function (_multiLine) {
      multiLine = _multiLine;
      return wrap;
    };
    function _measureText(_text, _fontStruct) {
      var ctx = canvas.getContext("2d");
      ctx.font = _fontStruct;
      return ctx.measureText(_text).width;
    }
    function _truncate(_text, _width, _fontStruct) {
      // Should optimize by using an educated guess.
      var marker = _text.length;
      var testLine = _text.substring(0, marker) + " ";
      marker = marker + 1;
      var exit = false;
      while (_measureText(testLine.concat(textOverFlow), _fontStruct) > _width && !exit) {
        marker--;
        if (marker <= 0) {
          marker = 0;
          exit = true;
        }
        testLine = testLine.substring(0, marker);
      }
      return testLine.concat(textOverFlow);
    }
    return wrap;
  };
  var DropOverlap = function DropOverlap() {
    var widthRadius = 0;
    var heightRadius = 0;
    var rect;
    var hasCollided = false;
    function drop(_selection) {
      var quadtree$1 = d3.quadtree().x(function (d) {
        return d.x;
      }).y(function (d) {
        return d.y;
      });
      _selection.each(function () {
        rect = this.getBoundingClientRect();
        widthRadius = Math.max(widthRadius, rect.width);
        heightRadius = Math.max(heightRadius, rect.height);
        hasCollided = false;
        quadtree$1.visit(visit);
        if (!hasCollided) {
          quadtree$1.add(rect);
          this.collide = false;
        } else this.collide = true;
      });
      _selection.style("visibility", function () {
        return this.collide ? "hidden" : null;
      });
    }
    function visit(_node, _x1, _y1, _x2, _y2) {
      if (hasCollided) return true;
      if (_node.data === rect) return false; // child node

      if (!_node.length) hasCollided = !(rect.x + rect.width < _node.data.x || _node.data.x + _node.data.width < rect.x || rect.y + rect.height < _node.data.y || _node.data.y + _node.data.height < rect.y);
      return !(rect.x < _x2 + widthRadius && rect.x + rect.width > _x1 - widthRadius && rect.y < _y2 + heightRadius && rect.y + rect.height > _y1 - heightRadius);
    }
    return drop;
  };
  var AxisLabelLayout = function AxisLabelLayout() {
    var bounds, axis;
    var isContinuous, orientation, isHorizontal;
    var labelModeCalculator = LabelLayoutCalculator();
    var labelAnchor = LabelAnchor();
    var labelTransform = LabelTransform();
    var labelWrap = LabelWrap();
    var labelDropOverlap = DropOverlap();
    var cachedBBoxMap = new Map();
    function layout(_selection) {
      cachedBBoxMap.clear();
      var scale = axis.scale();
      isContinuous = !scale.rangeBand && !scale.step;
      isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom;
      var textSelection = _selection.selectAll(".tick text");
      textSelection.each(function (_data, _index) {
        cachedBBoxMap.set(_index, this.getBBox());
      });
      var labelSpace = labelExtent(textSelection);
      labelModeCalculator.labelBounds(labelSpace).isContinuousAxis(isContinuous).cachedBBoxMap(cachedBBoxMap).axisOrientation(orientation);
      textSelection.call(labelModeCalculator);
      labelAnchor.labelMode(labelModeCalculator.layoutMode()).axisOrientation(orientation);
      labelTransform.labelMode(labelModeCalculator.layoutMode()).axisOrientation(orientation).cachedBBoxMap(cachedBBoxMap);
      if (!isContinuous) doLabelWrapping(textSelection, labelSpace);else textSelection.call(labelDropOverlap);
      textSelection.call(labelTransform);
      textSelection.call(labelAnchor);
    }
    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };
    layout.mode = function (_mode) {
      if (_mode) {
        verifyLabelMode(_mode);
        labelModeCalculator.layoutMode(_mode);
        return layout;
      } else {
        return labelModeCalculator.layoutMode();
      }
    };
    layout.axis = function (_axis) {
      verifyAxis(_axis);
      axis = _axis;
      return layout;
    };
    layout.axisOrientation = function (_orientation) {
      verifyOrientation(_orientation);
      orientation = _orientation;
      return layout;
    };
    layout.layoutSpillOver = function () {
      return labelModeCalculator.layoutSpillOver();
    };
    layout.usedSizeForLabels = function () {
      return labelModeCalculator.usedSizeForLabels();
    };
    function labelExtent(_textSelection) {
      var w = bounds.width;
      var h = bounds.height;
      var tickCount = _textSelection.size();
      var range = axis.scale().range();
      var tickSpace = Math.abs(range[range.length - 1] - range[0]) / tickCount; // set w (for top/bottom) or h (for left/right) based on cell size

      if (isHorizontal) w = tickSpace;else h = tickSpace; // reduce space used by ticks, padding and title

      if (isHorizontal) {
        h -= axis.tickSize(); // ticks space always given regardless if they are visible

        h -= axis.tickPadding(); // half the padding goes to labels
      } else {
        w -= axis.tickSize();
        w -= axis.tickPadding();
      }
      return {
        width: w,
        height: h
      };
    }
    function doLabelWrapping(_textSelection, _labelExtent) {
      if (!_labelExtent || _labelExtent.width < 0 || _labelExtent.height < 0) return;
      var mode = labelModeCalculator.layoutMode();
      var w = _labelExtent.width;
      var h = _labelExtent.height;
      if (mode === LabelLayoutMode.Rotate45) {
        w = _labelExtent.height / 0.7071 - labelModeCalculator.labelHeight();
        h = labelModeCalculator.labelHeight() / 0.7071;
      } else if (mode === LabelLayoutMode.Rotate90) {
        var tmp = w;
        w = h;
        h = tmp;
      }
      var cellWidth = w;
      _textSelection.each(function (_data, _index, _groupIndex) {
        var width = cellWidth; // 1.2 magic constant to prevent textFlow removing labels due to height issues.

        if (mode === LabelLayoutMode.Rotate45) {
          width = calculate45DegreeSpace(this, cachedBBoxMap.get(_index), orientation, cellWidth);
        }
        if (mode === LabelLayoutMode.Stagger) {
          width = cellWidth * 2;
        }
        if (cachedBBoxMap.get(_index).width > width) {
          labelWrap.bounds({
            width: width,
            height: h / 2
          });
          d3.select(this).call(labelWrap);
        }
      });
    }
    return layout;
  };
  var AxisProperty = /*#__PURE__*/
  function () {
    function AxisProperty() {
      _classCallCheck(this, AxisProperty);
      this._axisTitle = "";
      this._showTitle = true;
      this._showTicks = true;
      this._showTickLabels = true;
      this._showAxisLine = true;
      this._titleFont = {};
      this._tickLabelFont = {};
      this._tickLabelColor = "currentColor";
      this._titleColor = "currentColor";
      this._lineColor = "currentColor";
      this._tickColor = "currentColor";
      this._labelLayoutMode = "automatic";
    }
    _createClass(AxisProperty, [{
      key: "title",
      value: function title(_axisTitle) {
        if (_axisTitle !== null && _axisTitle !== undefined) {
          this._axisTitle = _axisTitle;
          return this;
        }
        return this._axisTitle;
      }
    }, {
      key: "showTitle",
      value: function showTitle(_showTitle) {
        if (_showTitle !== null && _showTitle !== undefined) {
          this._showTitle = _showTitle;
          return this;
        }
        return this._showTitle;
      }
    }, {
      key: "showTicks",
      value: function showTicks(_showTicks) {
        if (_showTicks !== null && _showTicks !== undefined) {
          this._showTicks = _showTicks;
          return this;
        }
        return this._showTicks;
      }
    }, {
      key: "ticksColor",
      value: function ticksColor(_tickColor) {
        if (_tickColor !== null && _tickColor !== undefined) {
          this._tickColor = _tickColor;
          return this;
        }
        return this._tickColor;
      }
    }, {
      key: "showTickLabels",
      value: function showTickLabels(_showTickLabels) {
        if (_showTickLabels !== null && _showTickLabels !== undefined) {
          this._showTickLabels = _showTickLabels;
          return this;
        }
        return this._showTickLabels;
      }
    }, {
      key: "tickLabelMode",
      value: function tickLabelMode(_labelLayoutMode) {
        if (_labelLayoutMode !== null && _labelLayoutMode !== undefined) {
          this._labelLayoutMode = _labelLayoutMode;
          return this;
        }
        return this._labelLayoutMode;
      }
    }, {
      key: "showAxisLine",
      value: function showAxisLine(_showAxisLine) {
        if (_showAxisLine !== null && _showAxisLine !== undefined) {
          this._showAxisLine = _showAxisLine;
          return this;
        }
        return this._showAxisLine;
      }
    }, {
      key: "axisLineColor",
      value: function axisLineColor(_lineColor) {
        if (_lineColor !== null && _lineColor !== undefined) {
          this._lineColor = _lineColor;
          return this;
        }
        return this._lineColor;
      }
    }, {
      key: "tickLabelFont",
      value: function tickLabelFont(_tickLabelFont) {
        if (_tickLabelFont !== null && _tickLabelFont !== undefined) {
          this._tickLabelFont = _tickLabelFont;
          return this;
        }
        return this._tickLabelFont;
      }
    }, {
      key: "tickLabelColor",
      value: function tickLabelColor(_tickLabelColor) {
        if (_tickLabelColor !== null && _tickLabelColor !== undefined) {
          this._tickLabelColor = _tickLabelColor;
          return this;
        }
        return this._tickLabelColor;
      }
    }, {
      key: "titleFont",
      value: function titleFont(_titleFont) {
        if (_titleFont !== null && _titleFont !== undefined) {
          this._titleFont = _titleFont;
          return this;
        }
        return this._titleFont;
      }
    }, {
      key: "titleColor",
      value: function titleColor(_titleColor) {
        if (_titleColor !== null && _titleColor !== undefined) {
          this._titleColor = _titleColor;
          return this;
        }
        return this._titleColor;
      }
    }]);
    return AxisProperty;
  }();
  function applyAxisProperties(_selector, _axisProperty) {
    _selector.selectAll(".tick text").style("visibility", _axisProperty.showTickLabels() ? null : "hidden").attr("fill", _axisProperty.tickLabelColor());
    var styles = _axisProperty.tickLabelFont();
    for (var property in styles) {
      if (styles.hasOwnProperty(property)) {
        _selector.style(property, styles[property]);
        _selector.attr(property, styles[property]);
      }
    }
    _selector.selectAll(".tick line").style("visibility", _axisProperty.showTicks() ? null : "hidden").attr("stroke", _axisProperty.ticksColor());
    _selector.selectAll("path.domain").style("visibility", _axisProperty.showAxisLine() ? null : "hidden").attr("stroke", _axisProperty.axisLineColor());
  }
  var AxisLayout = function AxisLayout() {
    var bounds;
    var axis;
    var axisTitle;
    var orientation;
    var axisTitleHeight = 0;
    var DEFAULT_TICKS_COUNT = 10;
    var axisLabelLayout = AxisLabelLayout();
    var axisProperty = new AxisProperty();
    function layout(_selector) {
      if (bounds.height <= 0 || bounds.width <= 0) return;
      var scale = axis.scale();
      var range = scale.range();
      var axisExtent = Math.abs(range[range.length - 1] - range[0]);
      var labelHeight = 20; // space the ticks at least to have labelHeight between them to avoid collision.

      var isOrdinal = scale.bandwidth || scale.step;
      if (isOrdinal && axisExtent > 0) {
        var maxTickCount = Math.round(axisExtent / (labelHeight + axis.tickPadding()));
        if (scale.domain().length > maxTickCount) {
          var tickSkipCount = Math.round(scale.domain().length / maxTickCount);
          var tickValues = [];
          var domain = scale.domain();
          for (var i = 0; i < domain.length; i = i + tickSkipCount) {
            tickValues.push(domain[i]);
          }
          axis.tickValues(tickValues);
        }
      } else if (axisExtent > 0) {
        if (axisLabelLayout.mode() === LabelLayoutMode.Horizontal) labelHeight = axisLabelLayout.usedSizeForLabels();
        var tickCount = axisExtent / (labelHeight + axis.tickPadding());
        axis.tickArguments([Math.ceil(Math.min(tickCount, DEFAULT_TICKS_COUNT))]);
      }
      _selector.call(axis);
      applyAxisProperties(_selector, axisProperty); // axis path should contains H command for d.

      var isHorizontal = _selector.select(".domain").attr("d").split("H").length === 2;
      var labelPos;
      if (isHorizontal) {
        labelPos = _selector.select(".tick text").attr("y");
        orientation = labelPos > 0 ? Orientation.Bottom : Orientation.Top;
      } else {
        labelPos = _selector.select(".tick text").attr("x");
        orientation = labelPos > 0 ? Orientation.Right : Orientation.Left;
      }
      if (axisProperty.showTickLabels()) {
        axisLabelLayout.bounds(bounds).mode(axisProperty.tickLabelMode()).axis(axis).axisOrientation(orientation);
        _selector.call(axisLabelLayout);
      }
      drawTitle(_selector);
      drawTitle(_selector, true);
    }
    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };
    layout.axis = function (_axis) {
      verifyAxis(_axis);
      axis = _axis;
      return layout;
    };
    layout.axisProperty = function (_axisProperty) {
      axisProperty = _axisProperty;
      return layout;
    };
    layout.getSpillOver = function () {
      return axisLabelLayout.layoutSpillOver();
    };
    layout.getPreferredSize = function () {
      var layoutPaddingSize = 0;
      var usedSizeForLabels = 0; // axis will by null if the chart has no data

      if (axis) {
        layoutPaddingSize = axis.tickSize();
        usedSizeForLabels = axisLabelLayout.usedSizeForLabels();
        if (usedSizeForLabels !== 0) {
          // Add additional breathing space for the title and the labels.
          // Both the labels and the title will get half of the padding size as additional breathing
          // space at the bottom to leave some space there.
          // Since this is two times half of the padding, we will add padding as breathing space.
          layoutPaddingSize += layoutPaddingSize; // Besides the breathing space we need to add an additional 2px for truncation of doubles to
          // ints in textflow calculations.
          // Please note that this is only applicable if there are labels available.

          layoutPaddingSize += 2;
        } else if (axisTitleHeight !== 0) {
          // In this case no ticks / tick labels are shown. Only the title is visible.
          // Add padding as breathing space.
          layoutPaddingSize += layoutPaddingSize;
        }
      }
      return usedSizeForLabels + axisTitleHeight + layoutPaddingSize;
    };
    function drawTitle(_axisSelector, _usePreferredSize) {
      axisTitle = axisProperty.title();
      if (!axisTitle || !axisProperty.showTitle()) {
        _axisSelector.selectAll("text." + orientation).remove();
        axisTitleHeight = 0;
        return;
      } // Origins for each axis location (T for Top, L for Left, R for Right, B for Bottom)
      //
      // -------L-----------R-------        Unrotated axis orientation @ T,B,L,R
      // |      |    Top    |      |
      // T------+-----------+------|         *----x
      // |      |           |      |         |
      // | Left |  Element  | Right|         y
      // |      |           |      |
      //  B------+-----------+-----|
      // |      |   Bottom  |      |
      // ---------------------------

      var x = 0;
      var y = 0;
      var dy = "";
      var transform = null;
      var axisWidth = 0.0;
      var padding = 16;
      if (orientation === Orientation.Top || orientation === Orientation.Bottom) axisWidth = bounds.height;else axisWidth = bounds.width;
      if (_usePreferredSize) axisWidth = Math.min(layout.getPreferredSize(), axisWidth);
      var axisRange = axis.scale().range();
      var extent = Math.abs(axisRange[0] + axisRange[axisRange.length - 1]);
      if (orientation === Orientation.Top) {
        x = extent / 2;
        y = -axisWidth + padding / 4;
        dy = "0.75em"; // assumption is that text is 0.75em above baseline and 0.25em below baseline
      } else if (orientation === Orientation.Bottom) {
        x = extent / 2;
        y = axisWidth - padding / 4;
        dy = "-0.25em";
      } else if (orientation === Orientation.Left) {
        x = -extent / 2; // Rotated axis orientation

        y = -axisWidth + padding / 4;
        dy = "0.75em";
        transform = "rotate(-90)";
      } else {
        x = extent / 2; // Rotated axis orientation

        y = -axisWidth + padding / 4;
        dy = "0.75em";
        transform = "rotate(90)";
      }
      var titleSelector = _axisSelector.selectAll("text." + orientation);
      if (titleSelector.empty()) {
        // There was no title text, so add it using the final attribute values (to avoid transitions from off-screen)
        titleSelector = _axisSelector.append("text").attr("class", orientation).style("text-anchor", "middle");
      }
      titleSelector.attr("x", x).attr("y", y).attr("transform", transform).attr("dy", dy).style("fill", axisProperty.titleColor()).text(axisTitle).each(function (_d) {
        var styles = axisProperty.titleFont();
        for (var property in styles) {
          if (styles.hasOwnProperty(property)) this.style[property] = styles[property];
        }
      });
      if (!_usePreferredSize) axisTitleHeight = titleSelector.node().getBBox().height;
    }
    return layout;
  };
  function copyRect(_rect) {
    return {
      x: _rect.x || 0,
      y: _rect.y || 0,
      width: _rect.width,
      height: _rect.height
    };
  }
  var ChartLayoutComponent = /*#__PURE__*/
  function () {
    function ChartLayoutComponent() {
      _classCallCheck(this, ChartLayoutComponent);
      this._axisSizable = new Map();
      this._orientationMap = new Map();
    }
    _createClass(ChartLayoutComponent, [{
      key: "chartRect",
      value: function chartRect(_chartBounds) {
        this._chartRect = copyRect(_chartBounds);
        this._elementRect = copyRect(_chartBounds);
      }
    }, {
      key: "add",
      value: function add(_orientation, _axisLabelComp) {
        this._axisSizable.set(_orientation, _axisLabelComp);
      }
    }, {
      key: "getRect",
      value: function getRect(_orientation) {
        return this._orientationMap.get(_orientation);
      }
    }, {
      key: "elementRect",
      value: function elementRect() {
        return this._elementRect;
      }
    }, {
      key: "layout",
      value: function layout() {
        var _this = this;
        if (this._chartRect.width <= 0 || this._chartRect.height <= 0) {
          this._elementRect = copyRect(this._chartRect);
          this._orientationMap.set(Orientation.Left, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });
          this._orientationMap.set(Orientation.Right, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });
          this._orientationMap.set(Orientation.Top, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });
          this._orientationMap.set(Orientation.Bottom, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });
        } else {
          var bottomH = 0;
          var topH = 0;
          var leftW = 0;
          var rightW = 0;
          var tbSO = 0; // top-bottom spill over: amount y1,y2 axes need above and below of the element rectangle

          var lrSO = 0; // left-right spill over: amount x1,x2 axes need left and right of the element rectangle
          // Determine space for top,left,bottom,right rectangles based on the preferred size of each axis

          this._axisSizable.forEach(function (_axisLabelComp, _orientation) {
            var sizable = _axisLabelComp;
            var orientation = _orientation;
            var tbAxis = Orientation.Top === orientation || Orientation.Bottom === orientation;
            var axisDynamicSize = sizable.getPreferredSize();
            var spillOver = sizable.getSpillOver();
            if (tbAxis) {
              if (axisDynamicSize > _this._chartRect.height * 0.5) axisDynamicSize = _this._chartRect.height * 0.5;
              if (Orientation.Top === orientation) topH = axisDynamicSize;else bottomH = axisDynamicSize;
              if (spillOver > lrSO) lrSO = spillOver;
            } else {
              if (axisDynamicSize > _this._chartRect.width * 0.5) axisDynamicSize = _this._chartRect.width * 0.5;
              if (Orientation.Left === orientation) leftW = axisDynamicSize;else rightW = axisDynamicSize;
              if (spillOver > tbSO) tbSO = spillOver;
            }
          });
          if (lrSO > leftW) leftW = lrSO;
          if (lrSO > rightW) rightW = lrSO;
          if (tbSO > topH) topH = tbSO;
          if (tbSO > bottomH) bottomH = tbSO;
          var elementRectW = Math.max(0, this._chartRect.width - (leftW + rightW));
          var elementRectH = Math.max(0, this._chartRect.height - (topH + bottomH));
          var elementRectT = this._chartRect.y + topH;
          this._orientationMap.set(Orientation.Left, {
            x: this._chartRect.x,
            y: elementRectT,
            width: leftW,
            height: elementRectH
          });
          this._orientationMap.set(Orientation.Right, {
            x: this._chartRect.x + this._chartRect.width - rightW,
            y: elementRectT,
            width: rightW,
            height: elementRectH
          });
          this._orientationMap.set(Orientation.Top, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: this._chartRect.width,
            height: topH
          });
          this._orientationMap.set(Orientation.Bottom, {
            x: this._chartRect.x,
            y: this._chartRect.y + this._chartRect.height - bottomH,
            width: this._chartRect.width,
            height: bottomH
          });
          this._elementRect = {
            x: this._chartRect.x + leftW,
            y: elementRectT,
            width: elementRectW,
            height: elementRectH
          };
        }
      }
    }]);
    return ChartLayoutComponent;
  }();

  // 1: vertical numeric; 2: vertical categorical; 3: horizontal numeric; 4: horizontal categorical; 5: axis with no scale

  var AxisScaleScore = Object.freeze({
    VerticalNumeric: 1,
    VerticalCategorical: 2,
    HorizontalNumeric: 3,
    HorizontalCategorical: 4,
    NoScale: 5
  });
  var AxisLayoutOrder = [Orientation.Bottom, Orientation.Top, Orientation.Left, Orientation.Right];
  var AxisLayoutScore = function AxisLayoutScore(_orientation, _score) {
    _classCallCheck(this, AxisLayoutScore);
    this.orientation = _orientation;
    this.score = _score;
  };
  function getOrientation(_axisSelector) {
    var labelPos = 0,
      orientation = null;
    var isHorizontal = _axisSelector.select(".domain").attr("d").split("H").length === 2;
    if (_axisSelector.selectAll(".tick text").size() > 0) {
      if (isHorizontal) {
        labelPos = _axisSelector.select(".tick text").attr("y");
        orientation = labelPos > 0 ? Orientation.Bottom : Orientation.Top;
      } else {
        labelPos = _axisSelector.select(".tick text").attr("x");
        orientation = labelPos > 0 ? Orientation.Right : Orientation.Left;
      }
    }
    return orientation;
  }
  var AxesComponent = function AxesComponent() {
    var selector, axes, bounds;
    var layoutProgress;
    var axesScore;
    var elementRect;
    var axisLayoutComponents = new Map();
    var chartLayoutComponent = new ChartLayoutComponent();
    var axisRects = new Map();
    var axisOrientationMap = new Map();
    var layoutAxisOrder = new Array(4);
    var axesPropertyMap = new Map();
    function draw() {
      for (var index = 0; index < 4; index++) {
        var orientation = layoutAxisOrder[index];
        var axisGroup = selector.select(".axisTransform." + orientation);
        if (!orientation) continue;
        var axis = axisOrientationMap.get(orientation);
        if (!axis) {
          axisGroup.remove();
          continue;
        }
        if (axisGroup.empty()) axisGroup = selector.append("g").attr("class", "axisTransform " + orientation);
        var axisLayoutComp = axisLayoutComponents.get(orientation);
        var axisProperty = axesPropertyMap.get(orientation);
        if (!axisProperty) axisProperty = new AxisProperty();
        if (!axisLayoutComp) {
          axisLayoutComp = AxisLayout().axisProperty(axisProperty);
          axisLayoutComponents.set(orientation, axisLayoutComp);
        }
        setScaleRangePadded(orientation);
        var axisRect = axisRects.get(orientation);
        axisLayoutComp.bounds(axisRect).axis(axis);
        axisGroup.call(axisLayoutComp);
        var transform = getTransform(orientation);
        var axisTransform = "translate(" + transform[0] + "," + transform[1] + ")";
        axisGroup.attr("transform", axisTransform);
        if (layoutProgress) postDraw(orientation);
      }
    }
    function postDraw(_orientation) {
      // chip away at the _elementRect based on how much space the just rendered axis wants
      var axisLayoutComponent = axisLayoutComponents.get(_orientation);
      var size = axisLayoutComponent.getPreferredSize();
      if (_orientation === Orientation.Top || _orientation === Orientation.Bottom) {
        if (size > bounds.height * 0.5) size = bounds.height * 0.5;
        if (_orientation === Orientation.Top) {
          elementRect.y += size;
          elementRect.height -= size;
        } else {
          elementRect.height -= size;
        }
      } else {
        if (size > bounds.width * 0.5) size = bounds.width;
        if (_orientation === Orientation.Left) {
          elementRect.x += size;
          elementRect.width -= size;
        } else {
          elementRect.width -= size;
        }
      }
      chartLayoutComponent.add(_orientation, axisLayoutComponent);
    }
    function layout(_selector) {
      selector = _selector.append("g");
      preLayout();
      selector = _selector; // Update rect bounds to use from chartlayout.

      elementRect = chartLayoutComponent.elementRect();
      axisRects.forEach(function (_rect, _orientation) {
        return axisRects.set(_orientation, chartLayoutComponent.getRect(_orientation));
      });
      draw();
    }
    function preLayout() {
      // extra layer to do prelayout.
      layoutProgress = true;
      axisLayoutComponents.clear();
      chartLayoutComponent.chartRect(bounds);
      if (axes) {
        axes.forEach(function (_axis) {
          var dummyNode = selector.append("g");
          dummyNode.call(_axis);
          axisOrientationMap.set(getOrientation(dummyNode), _axis);
          dummyNode.remove();
        });
      }
      for (var index = 0; index < 4; index++) {
        var orientation = AxisLayoutOrder[index];
        if (axisOrientationMap.get(orientation))
          // initialize all axis 'rects' to the chart area.
          axisRects.set(orientation, {
            x: bounds.x || 0,
            y: bounds.y || 0,
            width: bounds.width,
            height: bounds.height
          });
      }
      elementRect = {
        x: bounds.x || 0,
        y: bounds.y || 0,
        width: bounds.width,
        height: bounds.height
      };
      axesScore = [];
      var score = 0;
      for (var _index = 0; _index < 4; _index++) {
        var _orientation2 = AxisLayoutOrder[_index];
        var isHorz = _orientation2 === Orientation.Top || _orientation2 === Orientation.Bottom;
        var axis = axisOrientationMap.get(_orientation2);
        if (axis) {
          var scale = axis.scale();
          var isContinuousAxis = scale.rangeBand || scale.step ? false : true;
          if (!isContinuousAxis) {
            score = isHorz ? AxisScaleScore.HorizontalCategorical : AxisScaleScore.VerticalCategorical;
            axesScore.push(new AxisLayoutScore(_orientation2, score));
          } else {
            score = isHorz ? AxisScaleScore.HorizontalNumeric : AxisScaleScore.VerticalNumeric;
            axesScore.push(new AxisLayoutScore(_orientation2, score));
          }
        } else {
          axesScore.push(new AxisLayoutScore(_orientation2, AxisScaleScore.NoScale));
        }
      }
      axesScore.sort(function (a1, a2) {
        return a1.score < a2.score ? -1 : a1.score > a2.score ? 1 : 0;
      });
      for (var i = 0; i < 4; i++) {
        layoutAxisOrder[i] = axesScore[i] ? axesScore[i].orientation : null;
      }
      draw();
      chartLayoutComponent.layout();
      selector.remove();
      layoutProgress = false;
    }
    layout.axes = function (_axes) {
      axes = [];
      _axes && _axes.forEach(function (_axis) {
        verifyAxis(_axis);
        axes.push(_axis);
      });
      return layout;
    };
    layout.axisProperty = function (_orientation, _axisProperty) {
      axesPropertyMap.set(_orientation, _axisProperty);
      return this;
    };
    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };
    layout.getRect = function (_orientation) {
      verifyOrientation(_orientation);
      return chartLayoutComponent.getRect(_orientation);
    };
    layout.getScale = function (_orientation) {
      var axis = axisOrientationMap.get(_orientation);
      return axis ? axis.scale() : null;
    };
    function getTransform(_orientation) {
      if (_orientation === Orientation.Left) return [elementRect.x, 0.0];
      if (_orientation === Orientation.Right) return [elementRect.x + elementRect.width, 0.0];
      if (_orientation === Orientation.Top) return [0.0, elementRect.y];
      return [0.0, elementRect.y + elementRect.height];
    }
    function setScaleRangePadded(_orientation) {
      var axis = axisOrientationMap.get(_orientation);
      if (axis) {
        var scale = axis.scale();
        var min, max;
        var isHorizontal = _orientation === Orientation.Bottom || _orientation === Orientation.Top;
        if (isHorizontal) {
          // This axis is on the horizontal
          min = elementRect.x;
          max = elementRect.x + elementRect.width;
        } else {
          min = elementRect.y + elementRect.height;
          max = elementRect.y;
        }
        scale.range([min, max]);
      }
    }
    return layout;
  };

  var DateUtils = /*#__PURE__*/function () {
    function DateUtils() {
      _classCallCheck$1(this, DateUtils);
    }
    _createClass$1(DateUtils, null, [{
      key: "extractDate",
      value:
      // Get date string from tuple key, since some dates are automatically parsed,
      // the caption is formatted and can't be recognized by Date parser
      // Used to parse Date object in CA, since it doens't support temporal slot
      // Also see: VIDA-3623, VIDA-3804, VIDA-4456 and VIDA-6959
      function extractDate(_tupleKey) {
        var numberTupleKey = Number.parseFloat(_tupleKey);
        var date = new Date(isNaN(numberTupleKey) ? _tupleKey : numberTupleKey);
        if (!Number.isNaN(date.getTime())) {
          return date;
        }

        // Try and parse Reporting/Image Service "(idx)(idx)20220131"
        var reportingFormat = /^\(\d+\)\(\d+\).+$/; //(idx)(idx)date
        if (reportingFormat.test(_tupleKey)) {
          var replace = /\(\d+\)\(\d+\)/; // replace (index)(index) with empty string
          var _dateString = _tupleKey.replace(replace, "");
          var _dateNumber = Number(_dateString);
          return isNaN(_dateNumber) ? new Date(_dateString) : new Date(_dateNumber);
        }

        // Try and parse CA or local key ("DATASET.SLOT->[2018-02-18 19:00:00]" or "[ID].[SLOT].[1533959781804]")
        var dateStartIndex = _tupleKey.lastIndexOf("[");
        var dateEndIndex;
        if (dateStartIndex === -1) {
          // Try and parse Reporting key ("SLOT-Nov 04, 2019 3:15:00 PM")
          dateStartIndex = _tupleKey.lastIndexOf("-");
          if (dateStartIndex !== -1) {
            dateStartIndex++;
          }
          dateEndIndex = _tupleKey.length;
        } else {
          // Skip opening bracket and find matching bracket
          dateStartIndex++;
          dateEndIndex = _tupleKey.indexOf("]", dateStartIndex);
        }
        if (dateStartIndex === -1 || dateEndIndex === -1 || dateStartIndex === dateEndIndex) {
          console.warn("Cannot extract date from  ".concat(_tupleKey));
          return null;
        }
        var dateString = _tupleKey.slice(dateStartIndex, dateEndIndex);
        var dateNumber = Number(dateString);
        if (isNaN(dateNumber)) {
          // work around for invalid date issue VIDA-6740
          if (dateString.startsWith("00 ")) {
            dateString = "20" + dateString;
          }
          return new Date(dateString);
        }
        return new Date(dateNumber);
      }
    }]);
    return DateUtils;
  }();

  var TASK = 0,
    START_DATE = 1,
    END_DATE = 2,
    COLOR = 3,
    LABEL = 4,
    COLUMNS = 5; // data column indices
  var DESC_PADDING = 10,
    MIN_ARROW_PADDING = 5,
    MAX_ARROW_PADDING = 15;
  function setColorOpacity(color) {
    var opacity = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
    return new C(color.r, color.g, color.b, opacity);
  }
  function addDays(_date, _days) {
    var result = new Date(_date);
    result.setDate(result.getDate() + _days);
    return result;
  }
  function calculateArrowPadding(_svgWidth) {
    return Math.max(MIN_ARROW_PADDING, Math.min(_svgWidth * 0.02, MAX_ARROW_PADDING));
  }

  /**
   * Check if _date is either null or an "Invalid Date" Date object
   * @param _date
   * @returns True if date is invalid
   */
  function isInvalidDate(_date) {
    return _date === null || isNaN(_date.getTime());
  }

  /**
  * Compute the date domain based on the rows start and end date value/caption.
  * In case of cat date slot tuple caption is used to parse Data otherwise vale.
  * @param _rows
  * @param _getStartDate Function to get start date
  * @param _getEndDate Function to get end date
  */
  function computeDateDomain(_rows, _getStartDate, _getEndDate) {
    var startDateMin = null,
      startDateMax = null;
    var endDateMin = null,
      endDateMax = null;
    _rows.forEach(function (_dataPoint) {
      var startDateVal = _getStartDate(_dataPoint);
      if (startDateVal) {
        if (isInvalidDate(startDateMin) && isInvalidDate(startDateMax)) {
          startDateMin = startDateVal;
          startDateMax = startDateVal;
        } else if (startDateVal < startDateMin) {
          startDateMin = startDateVal;
        } else if (startDateVal > startDateMax) {
          startDateMax = startDateVal;
        }
      }
      var endDateVal = _getEndDate(_dataPoint);
      if (endDateVal) {
        if (isInvalidDate(endDateMin) && isInvalidDate(endDateMax)) {
          endDateMin = endDateVal;
          endDateMax = endDateVal;
        } else if (endDateVal < endDateMin) {
          endDateMin = endDateVal;
        } else if (endDateVal > endDateMax) {
          endDateMax = endDateVal;
        }
      }
    });

    // If all start date is null, set minDate to endDateMin - 2 weeks
    var minDate = startDateMin ? startDateMin : addDays(endDateMin, -14);
    var maxDate = endDateMax;
    /* If all end date is null or later than startDateMax,
     * set maxDate to startDateMax + 2 weeks */
    if (startDateMax > maxDate) maxDate = addDays(startDateMax, 14);
    return [minDate, maxDate];
  }

  /**
  * Create function that get either Start date or End date of a data point
  * @param startOrEnd Slot number of start date or end date
  */
  function createGetDateFn(startOrEnd) {
    return function (_dataPoint) {
      var caption = _dataPoint.tuple(startOrEnd).caption;
      if (!caption) return null;
      var date = _dataPoint.tuple(startOrEnd).source.value;
      return date ? date : DateUtils.extractDate(_dataPoint.tuple(startOrEnd).key);
    };
  }

  /**
  * Create function to calculate label background width
  * @param _svgElem Dummy SVGTextElement having font-size equal to label's
  */
  function createCalLabelWidthFn(_svgElem) {
    return function (_d) {
      var caption = _d.tuple(LABEL).caption;
      if (!caption || caption === "") return 0;
      _svgElem.textContent = _d.tuple(LABEL).caption;
      return _svgElem.getComputedTextLength() + DESC_PADDING;
    };
  }

  /**
  * Calculate path's coordinate of a connection
  * @param _calArrowPathX Function that calculate all x coordinates of path
  * @param _calArrowPathY Function that calculate all y coordinates of path
  */
  function createCalArrowPathFn(_calArrowPathX, _calArrowPathY) {
    return function (connection, _arrowPadding) {
      var x = _calArrowPathX(connection, _arrowPadding);
      var y = _calArrowPathY(connection);
      connection.path = "M";
      for (var _i = 0; _i < x.length; ++_i) connection.path += "".concat(x[_i], ",").concat(y[_i], " ");
      connection.path = connection.path.slice(0, -1);
      return connection;
    };
  }

  /**
  * Recalculate only x coordinates of a path
  * Used for zoom handling
  * @param _calArrowPathX Function that calculate all x coordinates of path
  */
  function createRecalArrowPathXFn(_calArrowPathX) {
    return function (connection, _arrowPadding) {
      var path = connection.path;
      var newPathX = _calArrowPathX(connection, _arrowPadding);
      var pathY = path.substring(1) // Remove "M" from path
      .split(" ") // Get x,y pair
      .map(function (e) {
        return e.split(",")[1];
      }); // Get y
      connection.path = "M";
      for (var _i2 = 0; _i2 < newPathX.length; ++_i2) connection.path += "".concat(newPathX[_i2], ",").concat(pathY[_i2], " ");
      connection.path = connection.path.slice(0, -1);
      return connection;
    };
  }
  function applyFont(_selection, _font) {
    _selection.style("font-size", _font.size ? _font.size.toString() : null).style("font-family", _font.family ? _font.family.toString() : null).style("font-style", _font.style ? _font.style.toString() : null).style("font-weight", _font.weight ? _font.weight.toString() : null);
  }
  function areRowsOverlap(_row1, _row2, _getStartDate, _getEndDate) {
    function dateToTime(_date, startOrEnd) {
      if (startOrEnd === "start") return _date ? _date.getTime() : 0;else return _date ? _date.getTime() : Number.MAX_SAFE_INTEGER;
    }
    var start1 = dateToTime(_getStartDate(_row1), "start");
    var end1 = dateToTime(_getEndDate(_row1), "end");
    var start2 = dateToTime(_getStartDate(_row2), "start");
    var end2 = dateToTime(_getEndDate(_row2), "end");
    return end2 < start1 || start2 > end1 ? false : true;
  }
  var _default = /*#__PURE__*/function (_RenderBase) {
    _inherits(_default, _RenderBase);
    var _super = _createSuper(_default);
    function _default() {
      var _this;
      _classCallCheck$1(this, _default);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _super.call.apply(_super, [this].concat(args));
      _defineProperty(_assertThisInitialized(_this), "_chartContainer", void 0);
      _defineProperty(_assertThisInitialized(_this), "_x1Axis", void 0);
      _defineProperty(_assertThisInitialized(_this), "_x1Scale", void 0);
      _defineProperty(_assertThisInitialized(_this), "_y0Scale", void 0);
      _defineProperty(_assertThisInitialized(_this), "_zoom", void 0);
      _defineProperty(_assertThisInitialized(_this), "_clip", void 0);
      _defineProperty(_assertThisInitialized(_this), "_axesComponent", void 0);
      _defineProperty(_assertThisInitialized(_this), "_bundleUniqueId", void 0);
      _defineProperty(_assertThisInitialized(_this), "_xAxisPlace", void 0);
      _defineProperty(_assertThisInitialized(_this), "_palette", void 0);
      _defineProperty(_assertThisInitialized(_this), "_rowTaskMap", void 0);
      return _this;
    }
    _createClass$1(_default, [{
      key: "create",
      value: function create(_node) {
        this._bundleUniqueId = Math.random() * 1000000;
        var svg = select(_node).append("svg").attr("width", "100%").attr("height", "100%").attr("class", "gantt").style("position", "absolute");
        this.loadCss("../static/gantt.css");
        var defs = svg.append("defs").attr("id", "defs");
        this._clip = defs.append("svg:clipPath").attr("id", "chartClip".concat(this._bundleUniqueId)).append("svg:rect");
        var chart = svg.append("g").attr("class", "chart");
        chart.append("g").attr("class", "axes");
        chart.append("g").attr("class", "columns");
        var chartContent = chart.append("g").attr("class", "chartContent").attr("clip-path", "url('#chartClip".concat(this._bundleUniqueId, "')"));
        chartContent.append("g").attr("class", "ganttBars");
        chartContent.append("g").attr("class", "arrows");
        chartContent.append("g").attr("class", "labelBackground");
        chartContent.append("g").attr("class", "labels");
        this._chartContainer = select(svg.node());
        return svg.node();
      }

      // Update is called during new data, property change, resizing, etc.
    }, {
      key: "update",
      value: function update(_info) {
        var _this2 = this;
        var width = _info.node.clientWidth;
        var height = _info.node.clientHeight;
        var data = _info.data;
        var margin = {
          top: 10,
          right: 0,
          bottom: 10,
          left: 0
        };
        var props = _info.props;
        var showLabelBg = props.get("text.background.show");
        this._xAxisPlace = props.get("axis.xAxisPlace");
        var axisLabelFont = props.get("axis.label.font");
        var axisLabelColor = props.get("axis.label.color");
        if (!data || data.rows.length === 0) {
          this._chartContainer.select(".axes").selectAll("*").remove();
          this._chartContainer.select(".chartContent").selectAll("*").selectAll("*").remove();
          this._chartContainer.select(".columns").selectAll("*").remove();
          return;
        }
        this._updateProperties(_info);
        var rows = data.rows;
        var getStartDate = createGetDateFn(START_DATE);
        var getEndDate = createGetDateFn(END_DATE);
        var getX = this._createGetXFn(getStartDate);
        var getWidth = this._createGetWidthFn(getX, getEndDate);
        var calculateArrowPathX = this._createCalArrowPathXFn(getX, getWidth);
        var calculateArrowPathY = this._createCalArrowPathYFn();
        var calculateArrowPath = createCalArrowPathFn(calculateArrowPathX, calculateArrowPathY);
        var recalculateArrowPathX = createRecalArrowPathXFn(calculateArrowPathX);
        var arrowPadding = calculateArrowPadding(width);
        var xAxis = this._chartContainer.select(".axes").select("." + this._xAxisPlace);
        this._zoom = zoom().scaleExtent([1, 10]).translateExtent([[0, 0], [width, height]]).extent([[0, 0], [width, height]]).on("zoom", function () {
          _this2._x1Scale.domain(computeDateDomain(rows, getStartDate, getEndDate)).nice();
          _this2._x1Scale = event.transform.rescaleX(_this2._x1Scale);
          _this2._chartContainer.select(".axisTransform." + _this2._xAxisPlace).call(_this2._x1Axis.scale(_this2._x1Scale));
          _this2._chartContainer.selectAll(".bar").attr("x", function (d) {
            return getX(d);
          }).attr("width", function (d) {
            return getWidth(d);
          });
          _this2._chartContainer.selectAll(".arrow").attr("d", function (d) {
            return recalculateArrowPathX(d, arrowPadding).path;
          });
          _this2._chartContainer.selectAll(".labelBg").attr("x", function (d) {
            return getX(d) + DESC_PADDING / 2;
          });
          _this2._chartContainer.selectAll(".description").attr("x", function (d) {
            return getX(d) + DESC_PADDING;
          });
          _this2._chartContainer.selectAll(".startEmpty").style("visibility", function (d) {
            return getWidth(d) > 0 ? "visible" : "hidden";
          });
          var ticks = xAxis.selectAll(".tick");
          ticks.selectAll("text").attr("fill", props.get("axis.label.color"));
          ticks.selectAll("line").style("stroke", props.get("axis.grid.color"));
          _this2._chartContainer.select(".axes").selectAll(".axisTransform").selectAll("path").raise();
        });
        this._chartContainer.select(".chart").attr("transform", "translate( ".concat(margin.left, " , ").concat(margin.top, ")"));
        if (_info.reason.data || _info.reason.size || _info.reason.properties) {
          this._createRadialGradients(data);
          // Use a set to avoid duplicate items
          var taskOrder = new Set();
          rows.forEach(function (_row) {
            taskOrder.add(_row.caption(TASK));
          });
          var restructureTasks = this._mapRowToTaskArray(this._restructureTasks(rows, getStartDate, getEndDate), taskOrder);
          this._rowTaskMap = restructureTasks.rowMap;
          var numberedTaskArray = restructureTasks.numberedTaskArray.reverse();
          this._x1Scale = time().domain(computeDateDomain(rows, getStartDate, getEndDate)).nice();
          this._y0Scale = band().domain(numberedTaskArray).paddingInner(0.2).paddingOuter(0.4);
          var leftColumnsSize = Math.min(data.cols[COLUMNS].segments.length * 0.1, 0.4);
          var axesBound = {
            x: (width - margin.left - margin.right) * leftColumnsSize,
            width: (width - margin.left - margin.right) * (1 - leftColumnsSize),
            height: height - margin.top - margin.bottom
          };
          this._axesComponent = this._drawAxes(axesBound, props);
          this._clip.attr("x", axesBound.x + this._axesComponent.getRect("left").width).attr("y", 0).attr("width", Math.max(axesBound.width - this._axesComponent.getRect("left").width - 20, 0)).attr("height", axesBound.height);
          var barHeight = this._y0Scale.bandwidth();
          var dummySvg = select("#defs").selectAll("text").data([null]).join("text").style("visibility", "hidden");
          if (data.cols[COLUMNS].mapped) {
            // Draw Column headers
            dummySvg.call(applyFont, axisLabelFont);
            var maxColumnWidth = (width - margin.left - margin.right) * leftColumnsSize / data.cols[COLUMNS].segments.length - 10;
            this._chartContainer.select(".columns").selectAll(".column").data(data.cols[COLUMNS].segments).join(function (_enterSel) {
              var g = _enterSel.append("g").attr("class", "column");
              g.append("text");
              return g;
            }).attr("transform", function (d, i) {
              return "translate( ".concat((width - margin.left - margin.right) * leftColumnsSize * i / data.cols[COLUMNS].segments.length, ", ").concat(_this2._axesComponent.getRect("top").y, " )");
            }).select("text").call(applyFont, axisLabelFont).style("fill", axisLabelColor).text(function (d) {
              return d.caption;
            }).attr("dy", "0.3em");

            // Draw Column content.
            var getColumnValue = this._createGetColumnValueFn(restructureTasks.taskMap, maxColumnWidth, data.cols[COLUMNS].segments.length, dummySvg.node());
            this._chartContainer.select(".columns").selectAll(".row").data(rows).join("g").attr("class", "row").attr("transform", function (d) {
              return "translate( 0, ".concat(_this2._axesComponent.getRect("top").y + _this2._y0Scale(_this2._rowTaskMap[d.key]) + _this2._y0Scale.bandwidth() * 0.5, " )");
            }).selectAll(".colVal").data(function (d) {
              var results = [];
              d.tuple(COLUMNS).segments.forEach(function (segment) {
                return results.push({
                  segment: segment,
                  dataPointKey: d.key
                });
              });
              return results;
            }).join("text").attr("class", "colVal").attr("dy", "0.3em").call(applyFont, axisLabelFont).style("fill", axisLabelColor).text(function (d, i) {
              return getColumnValue(d.dataPointKey, i).text;
            }).attr("transform", function (d, i) {
              return "translate( ".concat((width - margin.left - margin.right) * leftColumnsSize * i / data.cols[COLUMNS].segments.length + getColumnValue(d.dataPointKey, i).x, ", 0)");
            });
          } else {
            this._chartContainer.select(".columns").selectAll("*").remove();
          }

          // Draw bars.
          this._chartContainer.select(".ganttBars").selectAll(".bar").data(rows).join("rect").attr("class", "bar").attr("x", function (d) {
            return getX(d);
          }).attr("width", function (d) {
            return getWidth(d);
          }).attr("y", function (d) {
            return _this2._y0Scale(_this2._rowTaskMap[d.key]);
          }).attr("height", barHeight).attr("rx", barHeight * 0.1).style("stroke-width", "2px");
          if (data.cols[LABEL].mapped && barHeight > 20) {
            var labelFont = props.get("text.font");
            if (showLabelBg) {
              var labelBgColor = props.get("text.background.color");
              var labelBgOpacity = props.get("text.background.opacity");
              dummySvg.call(applyFont, labelFont);
              var getLabelWidth = createCalLabelWidthFn(dummySvg.node());
              this._chartContainer.select(".labelBackground").selectAll("rect").data(rows).join("rect").attr("class", "labelBg").classed("startEmpty", function (d) {
                return getStartDate(d) ? false : true;
              }).attr("x", function (d) {
                return getX(d) + DESC_PADDING / 2;
              }).attr("y", function (d) {
                return _this2._y0Scale(_this2._rowTaskMap[d.key]) + barHeight / 4;
              }).attr("width", function (d) {
                return getLabelWidth(d);
              }).attr("height", barHeight / 2).attr("fill-opacity", labelBgOpacity).attr("fill", labelBgColor.toString());
            } else {
              this._chartContainer.select(".labelBackground").html(null);
            }
            var labelColor = props.get("text.color");
            this._chartContainer.select(".labels").selectAll("text").data(rows).join("text").attr("class", "description").classed("startEmpty", function (d) {
              return getStartDate(d) ? false : true;
            }).attr("x", function (d) {
              return getX(d) + DESC_PADDING;
            }).attr("y", function (d) {
              return _this2._y0Scale(_this2._rowTaskMap[d.key]) + barHeight / 2 + DESC_PADDING / 2;
            }).attr("fill", labelColor.toString()).call(applyFont, labelFont).text(function (d) {
              return d.tuple(LABEL).caption;
            });
            this._chartContainer.selectAll(".startEmpty").style("visibility", function (d) {
              return getWidth(d) > 0 ? "visible" : "hidden";
            });
          } else {
            this._chartContainer.select(".labels").html(null);
            this._chartContainer.select(".labelBackground").html(null);
          }
          var connections = this._getConnectingRows(data.rows, getStartDate).map(function (e) {
            return calculateArrowPath(e, arrowPadding);
          });
          this._chartContainer.select(".arrows").selectAll(".arrow").data(connections).join("path").attr("class", "arrow").attr("d", function (_d) {
            return _d.path;
          }).attr("stroke-width", 1.5).attr("fill", "none");
        }
        var getFillColor = this._createGetFillColorFn(getStartDate, getEndDate, data.cols[COLOR]);
        this._chartContainer.select(".ganttBars").selectAll(".bar").style("fill", function (_d) {
          return getFillColor(_d);
        }).style("fill-opacity", function (_d) {
          return data.hasSelections && !_d.selected && (isInvalidDate(getEndDate(_d)) || isInvalidDate(getStartDate(_d))) ? "0.4" : "1";
        }).style("stroke", function (_d) {
          return _this2._palette.getOutlineColor(_d);
        });
        this._chartContainer.select(".arrows").selectAll(".arrow").attr("marker-end", function (_d) {
          return "url(#".concat(_this2._getTriangleId(_this2._palette.getFillColor(_d.from).toString()), ")");
        }).style("stroke", function (_d) {
          return _this2._palette.getFillColor(_d.from);
        });
        this._chartContainer.select(".labels").selectAll("text").attr("fill-opacity", function (_d) {
          return !data.hasSelections || _d.highlighted || _d.selected ? 1 : 0.4;
        });
        xAxis.selectAll(".tick").selectAll("line").style("stroke", props.get("axis.grid.color"));
        this._chartContainer.select(".axes").selectAll(".axisTransform").selectAll("path").raise();
      }

      /**
       * Draw axes using generic axis
       * @param _bounds Axes bound
       */
    }, {
      key: "_drawAxes",
      value: function _drawAxes(_bounds, _props) {
        var axisLabelFont = _props.get("axis.label.font");
        var defaultFont = {
          "font-size": axisLabelFont.size ? axisLabelFont.size.toString() : "",
          "font-family": axisLabelFont.family ? axisLabelFont.family.toString() : "",
          "font-style": axisLabelFont.style ? axisLabelFont.style.toString() : "",
          "font-weight": axisLabelFont.weight ? axisLabelFont.weight.toString() : ""
        };
        var axisProperty = new AxisProperty().tickLabelFont(defaultFont);
        axisProperty.axisLineColor(_props.get("axis.line.color")).tickLabelColor(_props.get("axis.label.color"));
        var axisFn = this._xAxisPlace === "top" ? axisTop : axisBottom;
        this._x1Axis = axisFn(this._x1Scale).tickSize(-_bounds.height);
        var y0Axis = axisLeft(this._y0Scale);
        var axesComponent = AxesComponent().axes([this._x1Axis, y0Axis]).bounds(_bounds).axisProperty(this._xAxisPlace, axisProperty).axisProperty("left", axisProperty);
        this._chartContainer.selectAll(".axes").call(axesComponent);
        this._chartContainer.selectAll(".axisTransform").attr("font-family", axisLabelFont.family ? axisLabelFont.family.toString() : null).attr("font-style", axisLabelFont.style ? axisLabelFont.style.toString() : null);
        return axesComponent;
      }

      /**
       * Create gradients for start empty and end empty bar
       * @param _col
       * @param _palette
       */
    }, {
      key: "_createRadialGradients",
      value: function _createRadialGradients(_data) {
        if (_data.cols[COLOR].mapped) {
          if (_data.cols[COLOR].dataType === "cat") this._createRadialGradientsCat(_data.cols[COLOR]);else this._createRadialGradientsCont(_data);
        } else {
          var defs = this._chartContainer.select("#defs");
          var defaultColor = this._palette.getColor(null);
          var transparentDefaultColor = setColorOpacity(defaultColor);
          defs.selectAll("linearGradient").remove();
          var gradients = defs.append("linearGradient").attr("id", "startEmpty_noStatus").attr("class", "startempty");
          gradients.append("stop").attr("offset", "10%").attr("stop-color", transparentDefaultColor.toString());
          gradients.append("stop").attr("offset", "80%").attr("stop-color", defaultColor.toString());
          gradients = defs.append("linearGradient").attr("id", "endEmpty_noStatus").attr("class", "endempty");
          gradients.append("stop").attr("offset", "20%").attr("stop-color", defaultColor.toString());
          gradients.append("stop").attr("offset", "90%").attr("stop-color", transparentDefaultColor.toString());
        }
      }
    }, {
      key: "_createRadialGradientsCat",
      value: function _createRadialGradientsCat(_col) {
        var _this3 = this;
        var defs = this._chartContainer.select("#defs");
        defs.selectAll("linearGradient").remove();
        var tuples = _col.tuples;
        var gradients = defs.selectAll("linearGradient .startempty").data(tuples).join(function (_enter) {
          return _enter.append("linearGradient");
        }).attr("id", function (_tuple) {
          return "startEmpty_".concat(_tuple.key, "_").concat(_this3._bundleUniqueId);
        }).attr("class", "startempty");
        gradients.selectAll("stop").remove();
        gradients.append("stop").attr("offset", "10%").attr("stop-color", function (_d) {
          return setColorOpacity(_this3._palette.getColor(_d)).toString();
        });
        gradients.append("stop").attr("offset", "80%").attr("stop-color", function (_d) {
          return _this3._palette.getColor(_d).toString();
        });
        gradients = defs.selectAll("linearGradient .endempty").data(tuples).join(function (_enter) {
          return _enter.append("linearGradient");
        }).attr("class", "endempty").attr("id", function (_tuple) {
          return "endEmpty_".concat(_tuple.key, "_").concat(_this3._bundleUniqueId);
        });
        gradients.selectAll("stop").remove();
        gradients.append("stop").attr("offset", "20%").attr("stop-color", function (_d) {
          return _this3._palette.getColor(_d).toString();
        });
        gradients.append("stop").attr("offset", "90%").attr("stop-color", function (_d) {
          return setColorOpacity(_this3._palette.getColor(_d)).toString();
        });
      }
    }, {
      key: "_createRadialGradientsCont",
      value: function _createRadialGradientsCont(_data) {
        var _this4 = this;
        var defs = this._chartContainer.select("#defs");
        defs.selectAll("linearGradient").remove();
        var values = _data.rows.map(function (row) {
          return row.value(COLOR);
        });
        values = values.filter(function (item, index) {
          return values.indexOf(item) === index;
        }); // Remove duplicate items

        var gradients = defs.selectAll("linearGradient .startempty").data(values).join(function (_enter) {
          return _enter.append("linearGradient");
        }).attr("id", function (_value) {
          return "startEmpty_".concat(_value.toFixed(2), "_").concat(_this4._bundleUniqueId);
        }).attr("class", "startempty");
        gradients.selectAll("stop").remove();
        var colorStops = this._palette.getColorStops(_data.cols[COLOR]);
        gradients.append("stop").attr("offset", "10%").attr("stop-color", function (_d) {
          return setColorOpacity(colorStops.getColor(_d)).toString();
        });
        gradients.append("stop").attr("offset", "80%").attr("stop-color", function (_d) {
          return colorStops.getColor(_d).toString();
        });
        gradients = defs.selectAll("linearGradient .endempty").data(values).join(function (_enter) {
          return _enter.append("linearGradient");
        }).attr("class", "endempty").attr("id", function (_value) {
          return "endEmpty_".concat(_value.toFixed(2), "_").concat(_this4._bundleUniqueId);
        });
        gradients.selectAll("stop").remove();
        gradients.append("stop").attr("offset", "20%").attr("stop-color", function (_d) {
          return colorStops.getColor(_d).toString();
        });
        gradients.append("stop").attr("offset", "90%").attr("stop-color", function (_d) {
          return setColorOpacity(colorStops.getColor(_d)).toString();
        });
      }
    }, {
      key: "_createGetFillColorFn",
      value: function _createGetFillColorFn(_getStartDate, _getEndDate, _col) {
        var _this5 = this;
        var getValue;
        if (_col.dataType === "cat") getValue = function getValue(_d) {
          return _d.tuple(COLOR).key;
        };else getValue = function getValue(_d) {
          return _d.value(COLOR).toFixed(2).toString();
        };
        return function (_d) {
          var startDate = _getStartDate(_d);
          var endDate = _getEndDate(_d);
          if (isInvalidDate(startDate) && isInvalidDate(endDate)) return "none";
          if (!_col.mapped) {
            if (isInvalidDate(startDate)) return "url('#startEmpty_noStatus')";
            if (isInvalidDate(endDate)) return "url('#endEmpty_noStatus')";
          }
          if (isInvalidDate(startDate)) return "url('#startEmpty_".concat(getValue(_d), "_").concat(_this5._bundleUniqueId, "')");
          if (isInvalidDate(endDate)) return "url('#endEmpty_".concat(getValue(_d), "_").concat(_this5._bundleUniqueId, "')");
          return _this5._palette.getFillColor(_d);
        };
      }

      /**
       * Enable/disable properties based on data mapping
       * @param _info
       */
    }, {
      key: "_updateProperties",
      value: function _updateProperties(_info) {
        var isColorMapped = _info.data.cols[COLOR].mapped;
        var isColorCont = _info.data.cols[COLOR].dataType === "cont";
        this.properties.setActive("colors.cont", isColorMapped && isColorCont);
        this.properties.setActive("colors.cat", !isColorMapped || !isColorCont);
        this._palette = _info.props.get(isColorCont ? "colors.cont" : "colors.cat");
        var isLabelMapped = _info.data.cols[LABEL].mapped;
        var isShowBackgroundChecked = this.properties.get("text.background.show");
        this.properties.setActive("text.background.show", isLabelMapped);
        this.properties.setActive("text.background.color", isLabelMapped && isShowBackgroundChecked);
        this.properties.setActive("text.background.opacity", isLabelMapped && isShowBackgroundChecked);
        this.properties.setActive("text.color", isLabelMapped);
        this.properties.setActive("text.font", isLabelMapped);
      }

      /**
      * Create function that get x coordinate for gantt bar of a data point
      * @param _startDateCol
      * @param _getStartDate
      */
    }, {
      key: "_createGetXFn",
      value: function _createGetXFn(_getStartDate) {
        var _this6 = this;
        return function (_dataPoint) {
          var xVal = _getStartDate(_dataPoint);
          if (isInvalidDate(xVal)) return _this6._x1Scale.range()[0];
          return _this6._x1Scale(xVal);
        };
      }

      /**
      * Create function that calculate width of gantt bar of a data point
      * @param _startDateCol
      * @param _endDateCol
      * @param _getX
      * @param _getEndDate
      */
    }, {
      key: "_createGetWidthFn",
      value: function _createGetWidthFn(_getX, _getEndDate) {
        var _this7 = this;
        return function (_dataPoint) {
          var start = _getX(_dataPoint);
          var end;
          var endVal = _getEndDate(_dataPoint);
          if (isInvalidDate(endVal)) end = _this7._x1Scale.range()[1];else end = _this7._x1Scale(endVal);
          return Math.max(end - start, 0);
        };
      }

      /**
       * Create object whose key is task names
       * Each task contains an array of array, where each (small) array contains rows that don't overlap eachother
       * If a new overlapping row is found, it will be pushed to a new (small) array
       * @param _rows
       * @param _getStartDate
       * @param _getEndDate
       */
    }, {
      key: "_restructureTasks",
      value: function _restructureTasks(_rows, _getStartDate, _getEndDate) {
        var tasks = {};
        _rows.forEach(function (row) {
          var taskName = row.tuple(TASK).caption;
          if (!(taskName in tasks))
            // Task name not in object, initiate it with row
            {
              tasks[taskName] = [[row]];
            } else {
            var task = tasks[taskName];
            var targetArrayFound = false;
            for (var _i3 = 0; _i3 < task.length; ++_i3)
            // Iterate through candidate arrays
            {
              var taskArray = task[_i3];
              var overlap = false;
              for (var j = 0; j < taskArray.length; ++j) {
                var existingRow = taskArray[j];
                if (areRowsOverlap(row, existingRow, _getStartDate, _getEndDate)) {
                  overlap = true; // Row overlaps another row, move on to next array
                  break;
                }
              }
              if (!overlap)
                // An array that can fit the row is found, break loop
                {
                  targetArrayFound = true;
                  taskArray.push(row);
                  break;
                }
            }
            if (!targetArrayFound) task.push([row]); // No suitable array found, create a new array
          }
        });

        return tasks;
      }

      /**
       * Map row to its "new" task
       * @param _taskArray Object contains tasks, generated from this._restructureTasks
       * @param _taskOrder Order of tasks since taskArray cannot reserve the original order of rows
       */
    }, {
      key: "_mapRowToTaskArray",
      value: function _mapRowToTaskArray(_taskArray, _taskOrder) {
        var result = {
          rowMap: {},
          numberedTaskArray: [],
          taskMap: {}
        };
        _taskOrder.forEach(function (taskName) {
          var task = _taskArray[taskName];
          var i = 0;
          var _loop = function _loop() {
            var numberedTaskName = "";
            for (var j = 0; j < i; ++j) {
              numberedTaskName += " ";
            }
            numberedTaskName += taskName;
            result.numberedTaskArray.push(numberedTaskName);
            task[i].forEach(function (row) {
              result.rowMap[row.key] = numberedTaskName;
              if (!result.taskMap[numberedTaskName]) result.taskMap[numberedTaskName] = [row];else result.taskMap[numberedTaskName].push(row);
            });
          };
          for (; i < task.length; ++i) {
            _loop();
          }
        });
        return result;
      }

      /**
       * Create function to get column starting x and trimmed text
       * @param _taskMap Object map from numbered task to its rows, generated from this._restructureTasks
       * @param _maxColumnWidth Maximum width of a column
       * @param _columnSegments Number of column segments
       * @param _svgElem SVGTextElement object to measure text width
       * @returns A function that returns ColumnValue object from datapoint key and index of column segment
       */
    }, {
      key: "_createGetColumnValueFn",
      value: function _createGetColumnValueFn(_taskMap, _maxColumnWidth, _columnSegments, _svgElem) {
        function trimText(_text, _maxWidth) {
          if (_maxWidth <= 0) return null;
          _svgElem.textContent = _text;
          var i;
          for (i = _text.length; i > 0 && _svgElem.getSubStringLength(0, i) > _maxWidth; i = i - 3);
          for (i; i < _text.length && _svgElem.getSubStringLength(0, i + 1) <= _maxWidth; ++i);
          return i < _text.length ? _text.substr(0, Math.max(0, i - 1)) + "..." : _text;
        }
        var padding = 10;
        var result = {};
        Object.keys(_taskMap).forEach(function (taskName) {
          var _loop2 = function _loop2(segmentIndex) {
            var x = 0;
            _taskMap[taskName].forEach(function (row) {
              if (!(row.key in result)) result[row.key] = new Array(_columnSegments);
              var trimmedText = trimText(row.tuple(COLUMNS).segments[segmentIndex].caption, _maxColumnWidth - x);
              result[row.key][segmentIndex] = {
                x: x,
                text: trimmedText
              };
              _svgElem.textContent = trimmedText;
              x = _svgElem.getComputedTextLength() + padding;
            });
          };
          for (var segmentIndex = 0; segmentIndex < _columnSegments; ++segmentIndex) {
            _loop2(segmentIndex);
          }
        });
        return function (dataPointKey, i) {
          return result[dataPointKey][i];
        };
      }

      /**
       * Create function that return arrows, which connects rows belonging to the same task
       * @param _rows All rows
       * @param _getStartDate Get start date function of DataPoint
       */
    }, {
      key: "_getConnectingRows",
      value: function _getConnectingRows(_rows, _getStartDate) {
        var connections = [];
        var tasks = {};
        _rows.forEach(function (_row) {
          var taskName = _row.tuple(TASK).caption;
          if (!(taskName in tasks)) tasks[taskName] = [_row];else tasks[taskName].push(_row);
        });
        for (var _i4 = 0, _Object$keys = Object.keys(tasks); _i4 < _Object$keys.length; _i4++) {
          var taskName = _Object$keys[_i4];
          var task = tasks[taskName];
          task.sort(function (a, b) {
            return +_getStartDate(a) - +_getStartDate(b);
          });
          for (var _i5 = 1; _i5 < task.length; ++_i5) if (this._rowTaskMap[task[_i5 - 1].key] !== this._rowTaskMap[task[_i5].key]) connections.push({
            from: task[_i5 - 1],
            to: task[_i5],
            path: ""
          });
        }
        return connections;
      }

      /**
       * Create function that calculates all X coordinates of a path
       * @param _getX Get x of gantt bar function
       * @param _getWidth Get width of gantt bar function
       */
    }, {
      key: "_createCalArrowPathXFn",
      value: function _createCalArrowPathXFn(_getX, _getWidth) {
        return function (_connection, _arrowPadding) {
          var x = [];
          var fromNode = _connection.from;
          var toNode = _connection.to;
          var startPointX = _getX(fromNode) + _getWidth(fromNode);
          var endPointX = _getX(toNode);
          x[0] = startPointX;
          x[1] = startPointX + _arrowPadding;
          x[2] = startPointX + _arrowPadding;
          x[3] = endPointX - _arrowPadding;
          x[4] = endPointX - _arrowPadding;
          x[5] = endPointX;
          return x;
        };
      }

      /**
       * Create function that calculates all Y coordinates of a path
       */
    }, {
      key: "_createCalArrowPathYFn",
      value: function _createCalArrowPathYFn() {
        var _this8 = this;
        return function (_connection) {
          var y = [];
          var fromNode = _connection.from;
          var toNode = _connection.to;
          var barHeight = _this8._y0Scale.bandwidth();
          var firstLevelY = _this8._y0Scale(_this8._rowTaskMap[fromNode.key]) + barHeight / 2;
          var thirdLevelY = _this8._y0Scale(_this8._rowTaskMap[toNode.key]) + barHeight / 2;
          var secondLevelY = (firstLevelY + thirdLevelY) / 2;
          y[0] = firstLevelY;
          y[1] = firstLevelY;
          y[2] = secondLevelY;
          y[3] = secondLevelY;
          y[4] = thirdLevelY;
          y[5] = thirdLevelY;
          return y;
        };
      }

      /**
       * Get triangle ( svg marker ) id from color
       * Used for arrow
       * If the wanted triangle does not exist, create one
       * @param color
       */
    }, {
      key: "_getTriangleId",
      value: function _getTriangleId(color) {
        var colorId = color.replace("#", "").split(",").join("_").replace(".", "").replace("(", "").replace(")", "");
        var defs = this._chartContainer.select("#defs");
        if (defs.select("#triangle_".concat(colorId)).empty()) defs.append("svg:marker").attr("id", "triangle_".concat(colorId)).attr("refX", 5).attr("refY", 2.5).attr("markerWidth", 30).attr("markerHeight", 30).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M0,0 5,2.5 0,5").attr("fill", color);
        return "triangle_".concat(colorId);
      }
    }, {
      key: "getInteractivity",
      value: function getInteractivity() {
        return this;
      }
    }, {
      key: "startInteractivity",
      value: function startInteractivity() {}
    }, {
      key: "cancelInteractivity",
      value: function cancelInteractivity(_visCoord, _viewPortPoint) {}
    }, {
      key: "endInteractivity",
      value: function endInteractivity(_visCoord, _viewPortPoint) {}
    }, {
      key: "canTranslate",
      value: function canTranslate() {
        return true;
      }
    }, {
      key: "canZoom",
      value: function canZoom() {
        return true;
      }
    }, {
      key: "translate",
      value: function translate(_visCoord, _viewPortPoint, _viewDelta) {
        var currenttransform = transform(this._chartContainer.select(".chart").node());
        var dx = currenttransform.x + _viewDelta.x;
        var xScaleRange = this._x1Scale.range();
        var rightLimit = xScaleRange[1] - xScaleRange[1] * currenttransform.k;
        var leftLimit = xScaleRange[0] - xScaleRange[0] * currenttransform.k;
        // reached the limits on left and right.
        if (currenttransform.x <= rightLimit && _viewDelta.x < 0 || currenttransform.x >= leftLimit && _viewDelta.x > 0) return;
        dx = Math.max(rightLimit, Math.min(leftLimit, dx));
        this._zoom.translateBy(this._chartContainer.select(".chart"), dx - currenttransform.x, 0);
      }
    }, {
      key: "zoom",
      value: function zoom(_visCoord, _viewPortPoint, _zoom) {
        var currenttransform = transform(this._chartContainer.select(".chart").node());
        var zoomScale = Math.max(1, currenttransform.k * _zoom);
        zoomScale = Math.min(zoomScale, 20);
        var left = _viewPortPoint.x - (_viewPortPoint.x - currenttransform.x) * zoomScale / currenttransform.k;
        if (zoomScale === 1) left = 0;
        this._chartContainer.select(".chart").call(this._zoom.transform, identity.translate(left, 0).scale(zoomScale));
      }
    }, {
      key: "hitTest",
      value: function hitTest(_elem) {
        // Retrieve the d3 datum of the element that was hit.
        var elem = select(_elem);
        var node = elem.empty() ? null : elem.datum();
        if (node instanceof Object && "segment" in node) return node.segment;
        return node;
      }
    }]);
    return _default;
  }(st);

  return _default;

}));
