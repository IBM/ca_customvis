define(['require', 'https://d3js.org/d3.v7.min.js'], (function (requirejs, d3) { 'use strict';

  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = Object.create(null);
    if (e) {
      Object.keys(e).forEach(function (k) {
        if (k !== 'default') {
          var d = Object.getOwnPropertyDescriptor(e, k);
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      });
    }
    n["default"] = e;
    return Object.freeze(n);
  }

  var d3__namespace = /*#__PURE__*/_interopNamespace(d3);

  function _regeneratorRuntime() {
    _regeneratorRuntime = function () {
      return e;
    };
    var t,
      e = {},
      r = Object.prototype,
      n = r.hasOwnProperty,
      o = Object.defineProperty || function (t, e, r) {
        t[e] = r.value;
      },
      i = "function" == typeof Symbol ? Symbol : {},
      a = i.iterator || "@@iterator",
      c = i.asyncIterator || "@@asyncIterator",
      u = i.toStringTag || "@@toStringTag";
    function define(t, e, r) {
      return Object.defineProperty(t, e, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }), t[e];
    }
    try {
      define({}, "");
    } catch (t) {
      define = function (t, e, r) {
        return t[e] = r;
      };
    }
    function wrap(t, e, r, n) {
      var i = e && e.prototype instanceof Generator ? e : Generator,
        a = Object.create(i.prototype),
        c = new Context(n || []);
      return o(a, "_invoke", {
        value: makeInvokeMethod(t, r, c)
      }), a;
    }
    function tryCatch(t, e, r) {
      try {
        return {
          type: "normal",
          arg: t.call(e, r)
        };
      } catch (t) {
        return {
          type: "throw",
          arg: t
        };
      }
    }
    e.wrap = wrap;
    var h = "suspendedStart",
      l = "suspendedYield",
      f = "executing",
      s = "completed",
      y = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var p = {};
    define(p, a, function () {
      return this;
    });
    var d = Object.getPrototypeOf,
      v = d && d(d(values([])));
    v && v !== r && n.call(v, a) && (p = v);
    var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p);
    function defineIteratorMethods(t) {
      ["next", "throw", "return"].forEach(function (e) {
        define(t, e, function (t) {
          return this._invoke(e, t);
        });
      });
    }
    function AsyncIterator(t, e) {
      function invoke(r, o, i, a) {
        var c = tryCatch(t[r], t, o);
        if ("throw" !== c.type) {
          var u = c.arg,
            h = u.value;
          return h && "object" == typeof h && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) {
            invoke("next", t, i, a);
          }, function (t) {
            invoke("throw", t, i, a);
          }) : e.resolve(h).then(function (t) {
            u.value = t, i(u);
          }, function (t) {
            return invoke("throw", t, i, a);
          });
        }
        a(c.arg);
      }
      var r;
      o(this, "_invoke", {
        value: function (t, n) {
          function callInvokeWithMethodAndArg() {
            return new e(function (e, r) {
              invoke(t, n, e, r);
            });
          }
          return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
        }
      });
    }
    function makeInvokeMethod(e, r, n) {
      var o = h;
      return function (i, a) {
        if (o === f) throw new Error("Generator is already running");
        if (o === s) {
          if ("throw" === i) throw a;
          return {
            value: t,
            done: !0
          };
        }
        for (n.method = i, n.arg = a;;) {
          var c = n.delegate;
          if (c) {
            var u = maybeInvokeDelegate(c, n);
            if (u) {
              if (u === y) continue;
              return u;
            }
          }
          if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) {
            if (o === h) throw o = s, n.arg;
            n.dispatchException(n.arg);
          } else "return" === n.method && n.abrupt("return", n.arg);
          o = f;
          var p = tryCatch(e, r, n);
          if ("normal" === p.type) {
            if (o = n.done ? s : l, p.arg === y) continue;
            return {
              value: p.arg,
              done: n.done
            };
          }
          "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg);
        }
      };
    }
    function maybeInvokeDelegate(e, r) {
      var n = r.method,
        o = e.iterator[n];
      if (o === t) return r.delegate = null, "throw" === n && e.iterator.return && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y;
      var i = tryCatch(o, e.iterator, r.arg);
      if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y;
      var a = i.arg;
      return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y);
    }
    function pushTryEntry(t) {
      var e = {
        tryLoc: t[0]
      };
      1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e);
    }
    function resetTryEntry(t) {
      var e = t.completion || {};
      e.type = "normal", delete e.arg, t.completion = e;
    }
    function Context(t) {
      this.tryEntries = [{
        tryLoc: "root"
      }], t.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(e) {
      if (e || "" === e) {
        var r = e[a];
        if (r) return r.call(e);
        if ("function" == typeof e.next) return e;
        if (!isNaN(e.length)) {
          var o = -1,
            i = function next() {
              for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next;
              return next.value = t, next.done = !0, next;
            };
          return i.next = i;
        }
      }
      throw new TypeError(typeof e + " is not iterable");
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", {
      value: GeneratorFunctionPrototype,
      configurable: !0
    }), o(GeneratorFunctionPrototype, "constructor", {
      value: GeneratorFunction,
      configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) {
      var e = "function" == typeof t && t.constructor;
      return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name));
    }, e.mark = function (t) {
      return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t;
    }, e.awrap = function (t) {
      return {
        __await: t
      };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () {
      return this;
    }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) {
      void 0 === i && (i = Promise);
      var a = new AsyncIterator(wrap(t, r, n, o), i);
      return e.isGeneratorFunction(r) ? a : a.next().then(function (t) {
        return t.done ? t.value : a.next();
      });
    }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () {
      return this;
    }), define(g, "toString", function () {
      return "[object Generator]";
    }), e.keys = function (t) {
      var e = Object(t),
        r = [];
      for (var n in e) r.push(n);
      return r.reverse(), function next() {
        for (; r.length;) {
          var t = r.pop();
          if (t in e) return next.value = t, next.done = !1, next;
        }
        return next.done = !0, next;
      };
    }, e.values = values, Context.prototype = {
      constructor: Context,
      reset: function (e) {
        if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t);
      },
      stop: function () {
        this.done = !0;
        var t = this.tryEntries[0].completion;
        if ("throw" === t.type) throw t.arg;
        return this.rval;
      },
      dispatchException: function (e) {
        if (this.done) throw e;
        var r = this;
        function handle(n, o) {
          return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o;
        }
        for (var o = this.tryEntries.length - 1; o >= 0; --o) {
          var i = this.tryEntries[o],
            a = i.completion;
          if ("root" === i.tryLoc) return handle("end");
          if (i.tryLoc <= this.prev) {
            var c = n.call(i, "catchLoc"),
              u = n.call(i, "finallyLoc");
            if (c && u) {
              if (this.prev < i.catchLoc) return handle(i.catchLoc, !0);
              if (this.prev < i.finallyLoc) return handle(i.finallyLoc);
            } else if (c) {
              if (this.prev < i.catchLoc) return handle(i.catchLoc, !0);
            } else {
              if (!u) throw new Error("try statement without catch or finally");
              if (this.prev < i.finallyLoc) return handle(i.finallyLoc);
            }
          }
        }
      },
      abrupt: function (t, e) {
        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
          var o = this.tryEntries[r];
          if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
            var i = o;
            break;
          }
        }
        i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null);
        var a = i ? i.completion : {};
        return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a);
      },
      complete: function (t, e) {
        if ("throw" === t.type) throw t.arg;
        return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y;
      },
      finish: function (t) {
        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
          var r = this.tryEntries[e];
          if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y;
        }
      },
      catch: function (t) {
        for (var e = this.tryEntries.length - 1; e >= 0; --e) {
          var r = this.tryEntries[e];
          if (r.tryLoc === t) {
            var n = r.completion;
            if ("throw" === n.type) {
              var o = n.arg;
              resetTryEntry(r);
            }
            return o;
          }
        }
        throw new Error("illegal catch attempt");
      },
      delegateYield: function (e, r, n) {
        return this.delegate = {
          iterator: values(e),
          resultName: r,
          nextLoc: n
        }, "next" === this.method && (this.arg = t), y;
      }
    }, e;
  }
  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
      var info = gen[key](arg);
      var value = info.value;
    } catch (error) {
      reject(error);
      return;
    }
    if (info.done) {
      resolve(value);
    } else {
      Promise.resolve(value).then(_next, _throw);
    }
  }
  function _asyncToGenerator(fn) {
    return function () {
      var self = this,
        args = arguments;
      return new Promise(function (resolve, reject) {
        var gen = fn.apply(self, args);
        function _next(value) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
        }
        function _throw(err) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
        }
        _next(undefined);
      });
    };
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    Object.defineProperty(subClass, "prototype", {
      writable: false
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;
    try {
      Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    } else if (call !== void 0) {
      throw new TypeError("Derived constructors may only return object or undefined");
    }
    return _assertThisInitialized(self);
  }
  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();
    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
        result;
      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;
        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }
      return _possibleConstructorReturn(this, result);
    };
  }
  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
  }
  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
  }
  function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
  }
  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }
  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
    return arr2;
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _createForOfIteratorHelper(o, allowArrayLike) {
    var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
    if (!it) {
      if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
        if (it) o = it;
        var i = 0;
        var F = function () {};
        return {
          s: F,
          n: function () {
            if (i >= o.length) return {
              done: true
            };
            return {
              done: false,
              value: o[i++]
            };
          },
          e: function (e) {
            throw e;
          },
          f: F
        };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var normalCompletion = true,
      didErr = false,
      err;
    return {
      s: function () {
        it = it.call(o);
      },
      n: function () {
        var step = it.next();
        normalCompletion = step.done;
        return step;
      },
      e: function (e) {
        didErr = true;
        err = e;
      },
      f: function () {
        try {
          if (!normalCompletion && it.return != null) it.return();
        } finally {
          if (didErr) throw err;
        }
      }
    };
  }
  function _toPrimitive(input, hint) {
    if (typeof input !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
      var res = prim.call(input, hint || "default");
      if (typeof res !== "object") return res;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
  }
  function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return typeof key === "symbol" ? key : String(key);
  }

  class e{constructor(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}getName(){return this.name}getSlot(){return this.slot}getAttributes(){return this.attributes}static slotLimit(t,s){return new e("limit",t).attr("n",s)}static dataLimit(t){return new e("limit").attr("n",t)}attr(t,e){return this.attributes.set(t,e),this}}function s(t,e,s){return t.getDecoration(e,s)}function r(t){return t.hasDecoration("hasSelection")?s(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}class n{constructor(t,e){this.min=t,this.max=e;}asArray(){return [this.min,this.max]}}n.empty=new n(0,0);class o extends n{static fromRS(t){return new n(t.min,t.max)}constructor(t,e){super(t,e);}}class i{constructor(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";const s=t.getItems()||[];this.segments=s.map((t=>new c(t)));}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class l extends i{constructor(t,e){super(t,e);}}class a{constructor(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class c extends a{constructor(t){super(t);}}const u=new class{format(t){return t?t.toString():""}};var h;!function(t){t.label="label",t.data="data";}(h||(h={}));class p{constructor(t,e,s,r,n){this.source=t,this.tuples=e,this.segments=s,this.domain=r,this.caption=n;const o=t.dataItems||[],i=o.length>0?o[0]:null,l=i&&i.asCont();l?(this._labelFormatter=l.getFormatter("label")||u,this._dataFormatter=l.getFormatter("data")||u):this._labelFormatter=this._dataFormatter=u;}get mapped(){return this.source.mapped}get dataType(){const t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"}format(t,e){return function(t,e){return t.format(e)}(e===h.data?this._dataFormatter:this._labelFormatter,t)}}class g extends p{constructor(t,e,s,r,n){super(t,e,s,r,n);}}class f{constructor(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}tuple(t){const e=this._getSlot(t);if(!e||0===e.tuples.length)return null;const s=this.source.get(e.source);if(!s)return null;const r=s.asCat();return r?e.tuples[r.index]:null}value(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);if(!s)return null;const r=s.asCont();return r&&"numeric"===r.valueType?r.value:null}caption(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);return s&&s.getCaption("data")||""}_getSlot(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null}}class d extends f{constructor(t,e){super(t,e);}}class m{constructor(t,e,s){this.source=t,this.rows=t.dataPoints.map((t=>new d(t,this))),this.cols=e,this.slotMap=s;}static filterRows(t,e,s){return t.filter((t=>{const r=t.tuple(e);return !!r&&r.key===s}))}get hasSelections(){return r(this.source)}}class y extends m{constructor(t,e,s){super(t,e,s);}}function _(t){const e=new Map,s=t.getSlots().map(((t,s)=>{let r=[],i=[],a=n.empty,u="";if(t.isMapped()){const e=t.getDataItem(0);if(u=e.getCaption("label"),"cat"===e.getRSType()){r=e.getTuples().map(((t,e)=>new l(t,e)));i=e.getItemClassSet(0).getItemClasses().map((t=>new c(t)));}else a=o.fromRS(e.getDomain()),i.push(new c(e.getItemClass()));}const h=new g(t,r,i,a,u);return e.set(t.name,h),h}));return new y(t,s,e)}const w=/^\s*#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{0,2})\s*$/,C=/^\s*rgba?\s*\(\s*(\d+\%?)\s*,\s*(\d+\%?)\s*,\s*(\d+\%?)\s*(?:,\s*(\d+(?:\.\d+)?\%?)\s*)?\)\s*/;function b(t){return t<0?0:t>255?255:Math.floor(t)}class S{constructor(t,e,s,r){var n;this.r=b(t),this.g=b(e),this.b=b(s),this.a=(n=r)<0?0:n>1?1:n;}static darker(t,e){const s=e?Math.pow(.7,e):.7;return new S(t.r*s,t.g*s,t.b*s,t.a)}static fromObject(t){return new S(t.r,t.g,t.b,void 0===t.a?1:t.a)}static fromString(t){const e=C.exec(t);let s=e||w.exec(t);const r=e?void 0:16;if(!s)return null;const n=parseInt(s[1],r),o=parseInt(s[2],r),i=parseInt(s[3],r);let l;return s[4]&&(l=e?parseFloat(s[4]):Math.round(parseInt(s[4],r)/255*100)/100),this.fromObject({r:n,g:o,b:i,a:l})}toString(){return 1===this.a?`rgb(${this.r},${this.g},${this.b})`:`rgba(${this.r},${this.g},${this.b},${this.a})`}}function x(t,e){let s=null;if(t instanceof f)s=t.source.getDataSet(e);else {const r=t.source.getDataItem(e);s=r&&r.getDataSet(e);}return !!s&&r(s)}const I=t=>`rgba(${t.r},${t.g},${t.b},0.4)`,j=t=>`rgba(${Math.round(.7*t.r)},${Math.round(.7*t.g)},${Math.round(.7*t.b)},${t.a})`;class E{constructor(t,e,s){this.source=t,this._dataContext=e,this._slotResolver=s;}get slot(){return this.source.slot}getColor(t){return t?S.fromObject(this.source.getTupleColor(t.source,-1)):S.fromObject(this.source.getColor(null))}_getTuple(t){if(t instanceof i)return t;let e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null}getFillColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),!t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class P{constructor(t,e,s){this.color=t,this.at=e,this.value=s;}}function D(t){return t.map((t=>new P(S.fromObject(t.color),t.at,t.value)))}class F{constructor(t,e,s){this.source=t,this._slot=e,this._dataContext=s,this.stops=D(t.stops),this.aligned=D(t.aligned),this.interpolate=t.interpolate;}getColor(t){return S.fromObject(this.source.getColor(t))}getFillColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return !t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class T{constructor(t,e,s){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=s;}get slot(){return this.source.slot}getColorStops(t){const e=t?t.source.getDataItem(0):null,s=e&&e.asCont();let r=s?s.getDomain(null):null;const n=this.source.getColorStops(s,r),o=t?t.source.name:null;return new F(n,o,this._dataContext)}_fetchColorStops(t){const e=t.source.getDataSet(this._dataContext),s=this.slot||this._slotResolver(t.dataSet,this.source.name),r=s?e.getSlot(s):null,n=r?r.getDataItem(0):null,o=n?n.asCont():null;if(this.source.dirty||!this._cachedStops||o!==this._lastDataItem){const t=o?o.getDomain(null):null,e=this.source.getColorStops(o,t);this._cachedStops=new F(e,r&&r.name,this._dataContext),this._lastDataItem=o;}return this._cachedStops}getFillColor(t){return this._fetchColorStops(t).getFillColor(t)}getOutlineColor(t){return this._fetchColorStops(t).getOutlineColor(t)}}class A extends S{constructor(t){super(t.r,t.g,t.b,t.a),this._color=t;}getRed(){return this.r}getGreen(){return this.g}getBlue(){return this.b}getAlpha(){return this.a}}const O=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:()=>0,getMax:()=>0,isEmpty:()=>!0,isExplicit:()=>!1});class ${constructor(t,e,s,r,n,o){this.caption=t,this.color=e,this.shape=s,this.selected=r,this.highlighted=n,this.ref=o;}getCaption(){return this.caption}getColor(){return this.color?new A(this.color):null}getShape(){return this.shape}isSelected(){return this.selected}isHighlighted(){return this.highlighted}getRef(){return this.ref}}class R{constructor(t,e,s,r,n,o){this.type=t,this.channel=e,this.slot=s,this.caption=r,this.subCaption=n,this.ref=o;}getRSType(){return this.type}getChannel(){return this.channel}getSlot(){return this.slot}getCaption(){return this.caption}getSubCaption(){return this.subCaption}getRef(){return this.ref}}class M extends R{constructor(t,e,r,n,o){const i=e&&e.source,l=i&&i.name,a=i&&i.getDataItem(0),c=a&&a.asCat();super("cat",t,l,r,"",c);const u=c?c.tuples:[];this.entries=u.map((t=>{const e=t.getCaption("label")||"",r=o&&o.source.getTupleColor(t,-1),i=s(t,"selected",!1),l=s(t,"highlighted",!1);return new $(e,r?S.fromObject(r):null,n,i,l,t)}));}getEntries(){return this.entries}}class L extends R{constructor(t,e,s,r){const n=e&&e.source,o=n&&n.name,i=n&&n.getDataItem(0),l=i&&i.asCont();if(super("cont",t,o,s,"",l),this.domain=l?l.getDomain(null):O,r&&"color"===t){const t=r.source.getColorStops(l,null);this.stops=t.stops,this.interpolate=t.interpolate;}else this.stops=null,this.interpolate=!1;}getDomain(){return this.domain}getInterpolate(){return this.interpolate}getStops(){return this.stops}}function k(t,e,s,r){if(!t)return [];const n=new Map,o=new Map;e.palettes.forEach((e=>{const s=e.slot||r&&r(t,e.source.name);s&&(e instanceof E?n.set(s,e):e instanceof T&&o.set(s,e));}));const i=[];return t.cols.forEach((t=>{const e=t.source;if(!e.mapped)return;const r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;const r=n.get(e.name);r&&i.push(new M("color",t,t.caption,s.legendShape,r));break;case"cont":if(-1!==e.channels.indexOf("color")){const s=o.get(e.name);s&&i.push(new L("color",t,t.caption,s));}-1!==e.channels.indexOf("size")&&i.push(new L("size",t,t.caption,null));}})),i}class z{constructor(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;}}var B,H,U;!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(B||(B={}));class V{constructor(t,e){this.value=t,this.unit=e;}static fromObject(t){return new V(t.value,function(t){switch(t){case"em":return B.Em;case"%":return B.Percentage;case"cm":return B.Centimeter;case"mm":return B.Millimeter;case"in":return B.Inch;case"pc":return B.Pica;case"pt":return B.Point;case"px":return B.Pixel;default:throw new Error(`Invalid length unit '${t}' specified`)}}(t.unit))}toString(){return `${this.value}${this.unit}`}}!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));const q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){let e=[];if(t)for(let s=0,r=t.length;s<r;++s){const r=t[s],n=q.test(r);e.push(n?`"${r}"`:r);}return e.join(", ")}class J{constructor(t,e,s,r){this.family=t,this.size=e,this.style=s,this.weight=r;}static fromObject(t){const e=t.family||null,s=t.size?V.fromObject(t.size):null,r=t.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error(`Invalid font style '${t}' specified`)}}(t.style):null,n=void 0!==t.weight&&null!==t.weight?t.weight:null;return new J(e,s,r,n)}toString(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){const t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){const e=[];let s=G(t.family);var r;return s.length>0&&e.push(`font-family: ${s};`),s=t.size?t.size.toString():"",s.length>0&&e.push(`font-size: ${s};`),s=(r=t.style)?r.toString():"",s.length>0&&e.push(`font-style: ${s};`),s=K(t.weight),s.length>0&&e.push(`font-weight: ${s};`),e.join(" ")}(this)}}class Q{constructor(t,e,s){const r=new Map;null!==t&&t.forEach(((t,n)=>{if("palette"===t.type){const o=t;switch(o.paletteType){case"cat":r.set(n,new E(o,e,s));break;case"cont":r.set(n,new T(o,e,s));}}})),this.source=t,this.palettes=r;}get(t){return this._getValue(t,!1)}peek(t){return this._getValue(t,!0)}_getValue(t,e){const s=this.source&&this.source.get(t);if(!s)return null;switch(s.type){case"string":case"number":case"boolean":case"enum":return e?s.peek:s.value;case"length":const r=e?s.peek:s.value;return r?V.fromObject(r):null;case"font":const n=e?s.peek:s.value;return n?J.fromObject(n):null;case"color":const o=e?s.peek:s.value;return o?S.fromObject(o):null;case"palette":return this.palettes.get(t)||null;default:return null}}isActive(t){const e=this.source&&this.source.get(t);return !!e&&e.active}setActive(t,e){const s=this.source&&this.source.get(t);s&&s.setActive(e);}isDirty(t){const e=this.source&&this.source.get(t);return !!e&&e.dirty}}function W(t,e){this.name="AggregateError",this.errors=t,this.message=e||"";}W.prototype=Error.prototype;var X=setTimeout;function Y(t){return Boolean(t&&void 0!==t.length)}function Z(){}function tt(t){if(!(this instanceof tt))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],it(t,this);}function et(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,tt._immediateFn((function(){var s=1===t._state?e.onFulfilled:e.onRejected;if(null!==s){var r;try{r=s(t._value);}catch(t){return void rt(e.promise,t)}st(e.promise,r);}else (1===t._state?st:rt)(e.promise,t._value);}))):t._deferreds.push(e);}function st(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var s=e.then;if(e instanceof tt)return t._state=3,t._value=e,void nt(t);if("function"==typeof s)return void it((r=s,n=e,function(){r.apply(n,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){rt(t,e);}var r,n;}function rt(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&tt._immediateFn((function(){t._handled||tt._unhandledRejectionFn(t._value);}));for(var e=0,s=t._deferreds.length;e<s;e++)et(t,t._deferreds[e]);t._deferreds=null;}function ot(t,e,s){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=s;}function it(t,e){var s=!1;try{t((function(t){s||(s=!0,st(e,t));}),(function(t){s||(s=!0,rt(e,t));}));}catch(t){if(s)return;s=!0,rt(e,t);}}tt.prototype.catch=function(t){return this.then(null,t)},tt.prototype.then=function(t,e){var s=new this.constructor(Z);return et(this,new ot(t,e,s)),s},tt.prototype.finally=function(t){var e=this.constructor;return this.then((function(s){return e.resolve(t()).then((function(){return s}))}),(function(s){return e.resolve(t()).then((function(){return e.reject(s)}))}))},tt.all=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,i){try{if(i&&("object"==typeof i||"function"==typeof i)){var l=i.then;if("function"==typeof l)return void l.call(i,(function(e){o(t,e);}),s)}r[t]=i,0==--n&&e(r);}catch(t){s(t);}}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.any=function(t){var e=this;return new e((function(s,r){if(!t||void 0===t.length)return r(new TypeError("Promise.any accepts an array"));var n=Array.prototype.slice.call(t);if(0===n.length)return r();for(var o=[],i=0;i<n.length;i++)try{e.resolve(n[i]).then(s).catch((function(t){o.push(t),o.length===n.length&&r(new W(o,"All promises were rejected"));}));}catch(t){r(t);}}))},tt.allSettled=function(t){return new this((function(e,s){if(!t||void 0===t.length)return s(new TypeError(typeof t+" "+t+" is not iterable(cannot read property Symbol(Symbol.iterator))"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,s){if(s&&("object"==typeof s||"function"==typeof s)){var i=s.then;if("function"==typeof i)return void i.call(s,(function(e){o(t,e);}),(function(s){r[t]={status:"rejected",reason:s},0==--n&&e(r);}))}r[t]={status:"fulfilled",value:s},0==--n&&e(r);}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.resolve=function(t){return t&&"object"==typeof t&&t.constructor===tt?t:new tt((function(e){e(t);}))},tt.reject=function(t){return new tt((function(e,s){s(t);}))},tt.race=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.race accepts an array"));for(var r=0,n=t.length;r<n;r++)tt.resolve(t[r]).then(e,s);}))},tt._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){X(t,0);},tt._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};class lt{constructor(t,e,s,r){this.data=t,this.decorations=e,this.properties=s,this.size=r;}}class at{constructor(t,e,s,r,n){this.reason=t,this.data=e,this.node=s,this.props=r,this.locale=n;}}class ct{constructor(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new z;}init(t,e){const s=t.surface.appendChild(document.createElement("div"));s.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),s.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,tt.resolve(this.create(s)).then((r=>{this._elem=r||s;t.properties.forEach(((t,e)=>this.updateProperty(e,t.value))),e.complete();})).catch((t=>{e.fail(t);}));}destroy(){}getPropertyApi(){return null}setData(t){t&&t.dataSets&&t.dataSets[0]?this._data=_(t.dataSets[0]):this._data=null;}setProperty(t,e){this.updateProperty(t,this.properties.peek(t));}getBlockingRequests(){return null}render(t,e,s){if(!this._elem)return s.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return s.complete(null,null,null),null;try{const t=this.update(new at(function(t){return new lt(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));tt.resolve(t).then((()=>s.complete(null,null,null))).catch(s.error);}catch(t){s.error(t);}return null}getEncodings(){return this._data?this.updateLegend(this._data):[]}getCapabilities(){const t=[];return this.meta.slotLimits.forEach(((s,r)=>{t.push(e.slotLimit(r,s));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t}getInteractivity(){return null}getVisCoordinate(t,e){return e}getRegionAtPoint(t,e){return null}getItemsAtPoint(t,e,s){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;const r=t,n=document.elementFromPoint(r.x,r.y),o=this.hitTest(n,r,e);return Array.isArray(o)?o.length?[...o.map((t=>t.source))]:[]:o&&o.source?[o.source]:[]}getItemsInPolygon(t,e){return []}getAxisItemsAtPoint(t,e,s){return []}getState(){return null}setState(t){}loadCss(t){const e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);}toUrl(e){return requirejs.toUrl(e)}update(t){}create(t){}updateProperty(t,e){}updateLegend(t){return k(t,this.properties,this.meta,this._slotResolver)}getSlotForPalette(t,e){return null}hitTest(t,e,s){const r=t&&t.__data__;return r&&r.source?r:null}nls(t){return this._nls&&this._nls.get(t)||""}}

  // Licensed Materials - Property of IBM
  //
  // IBM Watson Analytics
  //
  // (C) Copyright IBM Corp. 2023
  //
  // US Government Users Restricted Rights - Use, duplication or
  // disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

  var LABEL_FORMAT_KIND = "label";
  var CATEGORIES_SLOT = "categories";
  var VALUE_SLOT$1 = "value";
  var TreeNode = /*#__PURE__*/function () {
    //main root of tree

    function TreeNode(_id) {
      var _children = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
      var _value = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : undefined;
      var _caption = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : undefined;
      _classCallCheck(this, TreeNode);
      _defineProperty(this, "id", void 0);
      _defineProperty(this, "children", void 0);
      _defineProperty(this, "caption", void 0);
      _defineProperty(this, "dataPoint", void 0);
      _defineProperty(this, "tuple", void 0);
      _defineProperty(this, "parent", void 0);
      _defineProperty(this, "depth", 0);
      _defineProperty(this, "value", void 0);
      _defineProperty(this, "treeRoot", false);
      this.id = _id;
      this.children = _children;
      this.value = _value;
      this.caption = _caption;
    }
    _createClass(TreeNode, [{
      key: "isRoot",
      value: function isRoot() {
        return !!this.parent;
      }
    }, {
      key: "isTreeRoot",
      value: function isTreeRoot() {
        return this.treeRoot;
      }
    }, {
      key: "isLeaf",
      value: function isLeaf() {
        return this.children.length === 0;
      }
    }, {
      key: "setParent",
      value: function setParent(_parent) {
        if (!this.parent) {
          this.depth = _parent.getDepth() + 1;
          this.parent = _parent;
        }
      }
    }, {
      key: "getDepth",
      value: function getDepth() {
        return this.depth;
      }

      /**
       * Add a node to children list
       * @param _children
       */
    }, {
      key: "addChild",
      value: function addChild(_children) {
        var _this$children;
        (_this$children = this.children) === null || _this$children === void 0 || _this$children.push(_children);
      }
    }, {
      key: "getValue",
      value: function getValue() {
        if (!this.value) {
          var childrenValues = this.children.map(function (treeNode) {
            return treeNode.getValue();
          });
          this.value = childrenValues.length > 0 ? childrenValues.reduce(function (a, b) {
            return a + b;
          }) : null;
        }
        return this.value;
      }
    }, {
      key: "getColumnTotal",
      value: function getColumnTotal() {
        return this.parent ? this.parent.getValue() : -1;
      }
    }, {
      key: "getColumnMaximum",
      value: function getColumnMaximum() {
        if (!this.isTreeRoot()) {
          var childrenValues = this.parent.children.map(function (treeNode) {
            return treeNode.getValue();
          });
          return childrenValues.length > 0 ? Math.max.apply(Math, _toConsumableArray(childrenValues)) : null;
        } else return null;
      }

      /**
       * Find a node in children list by its name
       * @param name Name to find the children node
       * @returns The children node with matching name, undefined if not found
       */
    }, {
      key: "findChild",
      value: function findChild(_name) {
        var _this$children2;
        return (_this$children2 = this.children) === null || _this$children2 === void 0 ? void 0 : _this$children2.find(function (_child) {
          return _child.id === _name;
        });
      }
    }]);
    return TreeNode;
  }();
  var TreeNodeRoot = /*#__PURE__*/function (_TreeNode) {
    _inherits(TreeNodeRoot, _TreeNode);
    var _super = _createSuper(TreeNodeRoot);
    function TreeNodeRoot(_id) {
      var _this;
      var _children = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
      var _value = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : undefined;
      _classCallCheck(this, TreeNodeRoot);
      _this = _super.call(this, _id, _children, _value, _id);
      _this.treeRoot = true;
      return _this;
    }
    return _createClass(TreeNodeRoot);
  }(TreeNode);
  var LeafNode = /*#__PURE__*/function (_TreeNode2) {
    _inherits(LeafNode, _TreeNode2);
    var _super2 = _createSuper(LeafNode);
    function LeafNode(_id, _dataPoint, _caption) {
      var _this2;
      _classCallCheck(this, LeafNode);
      var value = TreeMapData.getSize(_dataPoint);
      var caption = _caption || TreeMapData.getSizeCaption(_dataPoint);
      _this2 = _super2.call(this, _id, undefined, value, caption);
      _defineProperty(_assertThisInitialized(_this2), "dataPoint", void 0);
      _defineProperty(_assertThisInitialized(_this2), "_leafIndex", void 0);
      _this2.dataPoint = _dataPoint;
      _this2._leafIndex = 0;
      return _this2;
    }
    _createClass(LeafNode, [{
      key: "leafIndex",
      get: function get() {
        return this._leafIndex;
      },
      set: function set(_index) {
        this._leafIndex = _index;
      }
    }, {
      key: "getValue",
      value: function getValue() {
        return this.value;
      }
    }]);
    return LeafNode;
  }(TreeNode);
  var TreeMapData = /*#__PURE__*/function () {
    function TreeMapData() {
      _classCallCheck(this, TreeMapData);
    }
    _createClass(TreeMapData, null, [{
      key: "getSize",
      value: function getSize(_dataPoint) {
        var _dataPoint$get;
        var datum = (_dataPoint$get = _dataPoint.get(VALUE_SLOT$1)) === null || _dataPoint$get === void 0 ? void 0 : _dataPoint$get.asCont();
        return datum ? Number(datum.getValue()) : 0;
      }
    }, {
      key: "getCategory",
      value: function getCategory(_dataPoint) {
        var dataItem = _dataPoint.get(CATEGORIES_SLOT);
        return dataItem && dataItem.asCat();
      }
    }, {
      key: "getSizeCaption",
      value: function getSizeCaption(_dataPoint) {
        var _dataPoint$get2;
        var datum = (_dataPoint$get2 = _dataPoint.get(VALUE_SLOT$1)) === null || _dataPoint$get2 === void 0 ? void 0 : _dataPoint$get2.asCont();
        var caption = datum ? datum.getCaption(LABEL_FORMAT_KIND) : "";
        return caption.length ? caption : null;
      }
    }]);
    return TreeMapData;
  }();

  /**
   * Form a hierarchy tree
   * @param _dataPoints List of input data points
   * @returns Root node
   */
  function buildTree(data) {
    var rows = data.rows;
    var dataPoints = rows.map(function (row) {
      return row.source;
    });
    if (dataPoints.length === 0) return null;
    var rootNodeName = data.slotMap.get(VALUE_SLOT$1).caption;
    var root = new TreeNodeRoot(rootNodeName);
    var _iterator = _createForOfIteratorHelper(dataPoints),
      _step;
    try {
      var _loop = function _loop() {
        var dataPoint = _step.value;
        var parent = root;
        var hierarchy = TreeMapData.getCategory(dataPoint).getItems().slice();

        // Remove the latest tuple item, as leaf node should be data point
        var item = hierarchy.pop();
        if (!item) return 1; // continue

        // Iterate treeLevel as pointer through each level of hierarchy
        hierarchy.forEach(function (_tupleItem) {
          var caption = _tupleItem.source.getCaption(LABEL_FORMAT_KIND);
          var key = parent.id + _tupleItem.uniqueName;
          var child = parent.findChild(key);
          if (!child) {
            child = new TreeNode(key, [], null, caption);
            child.setParent(parent);
            child.tuple = _tupleItem;
            parent.addChild(child);
          }
          parent = child;
        });
        var itemCaption = item.getCaption(LABEL_FORMAT_KIND);
        var itemName = parent.id + item.uniqueName;
        var treeMapLeaf = new LeafNode(itemName, dataPoint, itemCaption);
        treeMapLeaf.setParent(parent);
        parent.addChild(treeMapLeaf);
      };
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        if (_loop()) continue;
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    return root;
  }
  function getDepthRecursive(tree) {
    if (!tree.children) return tree.depth;
    if (tree.children.length === 0) return tree.depth;
    var childDepths = tree.children.map(function (children) {
      return getDepthRecursive(children);
    });
    return Math.max.apply(Math, _toConsumableArray(childDepths));
  }
  function getTreeRoot(tree) {
    if (tree.parent) {
      return getTreeRoot(tree.parent);
    } else return tree;
  }
  function setSelection(root, selection) {
    root.selected = selection;
    if (root.children) {
      root.children.forEach(function (children) {
        setSelection(children, selection);
      });
    }
  }
  function closeOtherRoots(root) {
    var parent = root.parent;
    if (parent) {
      parent.children.forEach(function (children) {
        if (children.id !== root.id) {
          children.children = null;
        }
      });
    }
  }

  var CONTAINER_SVG_CLASS = "svg-chart-container";
  var SVG_GROUP = "svg-group";
  var LINKS_CLASS = "links";
  var NODES_CLASS = "nodes";
  var CATEGORIES_CLASS = "categories";
  var ROOT_TITLE_CLASS = "rootTitle";
  var ROOT_SUBTITLE_CLASS = "rootSubtitle";
  var BAR_TARGET_CLASS = "nodeRectTarget";
  var BAR_ACTUAL_CLASS = "nodeRectActual";
  var VALUE_SLOT = 1;
  var X_OFFSET = 10;
  var Y_OFFSET = 25;
  var MIN_ZOOM = 0.5;
  var MAX_ZOOM = 4;
  function transposeCoordinates(_point, _direction) {
    var horizontal = _direction === "left" || _direction === "right";
    var x = _point[horizontal ? 1 : 0];
    var y = _point[horizontal ? 0 : 1];
    if (_direction === "left" || _direction === "up") {
      x *= -1;
      y *= -1;
    }
    return [x, y];
  }
  var NodesAlignment = /*#__PURE__*/function (NodesAlignment) {
    NodesAlignment["AUTO"] = "Auto";
    NodesAlignment["CENTER"] = "Center";
    NodesAlignment["CURRENT"] = "Current";
    NodesAlignment["TOP"] = "Top";
    return NodesAlignment;
  }(NodesAlignment || {});
  var TransitionManager = /*#__PURE__*/function () {
    function TransitionManager() {
      _classCallCheck(this, TransitionManager);
      _defineProperty(this, "transtionPromises", []);
    }
    _createClass(TransitionManager, [{
      key: "register",
      value: function register(transition) {
        if (transition.end !== undefined) this.transtionPromises.push(transition.end());
      }
    }, {
      key: "clear",
      value: function clear() {
        this.transtionPromises = [];
      }
    }, {
      key: "resolveAll",
      value: function resolveAll() {
        return Promise.all(this.transtionPromises);
      }
    }]);
    return TransitionManager;
  }();
  /**
   * Based on collapsable tree from https://observablehq.com/@d3/collapsible-tree
   */
  var _default = /*#__PURE__*/function (_RenderBase) {
    _inherits(_default, _RenderBase);
    var _super = _createSuper(_default);
    function _default() {
      var _this;
      _classCallCheck(this, _default);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _super.call.apply(_super, [this].concat(args));
      _defineProperty(_assertThisInitialized(_this), "_chartContainer", void 0);
      _defineProperty(_assertThisInitialized(_this), "root", void 0);
      _defineProperty(_assertThisInitialized(_this), "svg", void 0);
      _defineProperty(_assertThisInitialized(_this), "treeFn", void 0);
      _defineProperty(_assertThisInitialized(_this), "locale", void 0);
      _defineProperty(_assertThisInitialized(_this), "width", void 0);
      _defineProperty(_assertThisInitialized(_this), "height", void 0);
      _defineProperty(_assertThisInitialized(_this), "marginTop", void 0);
      _defineProperty(_assertThisInitialized(_this), "marginRight", void 0);
      _defineProperty(_assertThisInitialized(_this), "marginBottom", void 0);
      _defineProperty(_assertThisInitialized(_this), "marginLeft", void 0);
      _defineProperty(_assertThisInitialized(_this), "minimumNodeSpace", void 0);
      _defineProperty(_assertThisInitialized(_this), "svgGroup", void 0);
      _defineProperty(_assertThisInitialized(_this), "gLink", void 0);
      _defineProperty(_assertThisInitialized(_this), "gNode", void 0);
      _defineProperty(_assertThisInitialized(_this), "gCategories", void 0);
      _defineProperty(_assertThisInitialized(_this), "_zoom", void 0);
      _defineProperty(_assertThisInitialized(_this), "zoomState", void 0);
      _defineProperty(_assertThisInitialized(_this), "categories", void 0);
      _defineProperty(_assertThisInitialized(_this), "selectionState", new Map());
      _defineProperty(_assertThisInitialized(_this), "transitionManager", new TransitionManager());
      _defineProperty(_assertThisInitialized(_this), "valueFormatter", void 0);
      _defineProperty(_assertThisInitialized(_this), "props", {
        transitionDuration: 100,
        barWidth: 100,
        barHeight: 15,
        siblingFactor: 3.5,
        labelOption: "ValueAndPercentage",
        pathCurve: 25,
        labelColor: new S(255, 0, 0, 1),
        labelFont: "bold 15px \"IBM Plex Sans\"",
        valueLabelFont: "15px IBM Plex Sans",
        categoryLabelFont: "bold 15px \"IBM Plex Sans\"",
        categorySubLabelFont: "15px \"IBM Plex Sans\"",
        categorySubLabelColor: new S(0, 0, 0, 1),
        categoryLabelColor: new S(0, 0, 0, 1),
        barActualColor: new S(0, 0, 0, 1),
        barTargetColor: new S(0, 0, 0, 1),
        pathColor: new S(0, 0, 0, 1),
        selectedPathColor: new S(0, 0, 0, 1),
        nodesAlignment: NodesAlignment.AUTO
      });
      return _this;
    }
    _createClass(_default, [{
      key: "create",
      value: function create(_node) {
        this._chartContainer = _node;
        this._zoom = d3__namespace.zoom();
        return this._chartContainer;
      }
    }, {
      key: "_updateProps",
      value: function _updateProps(props) {
        this.props.transitionDuration = props.get("transitionDuration");
        this.props.barWidth = props.get("barWidth");
        this.props.barHeight = props.get("barHeight");
        this.props.siblingFactor = props.get("siblingFactor");
        this.props.labelOption = props.get("labelOption");
        this.props.pathCurve = props.get("pathCurve");
        this.props.labelColor = props.get("labelColor");
        this.props.labelFont = props.get("labelFont");
        this.props.valueLabelFont = props.get("valueLabelFont");
        this.props.categoryLabelFont = props.get("categoryLabelFont");
        this.props.categoryLabelColor = props.get("categoryLabelColor");
        this.props.categorySubLabelFont = props.get("categorySubLabelFont");
        this.props.categorySubLabelColor = props.get("categorySubLabelColor");
        this.props.barActualColor = props.get("colorActual");
        this.props.barTargetColor = props.get("colorTarget");
        this.props.pathColor = props.get("pathColor");
        this.props.selectedPathColor = props.get("selectedPathColor");
        this.props.nodesAlignment = props.get("nodesAlignment");
      }
    }, {
      key: "_clear",
      value: function _clear() {
        d3__namespace.select(this._chartContainer).selectAll(".".concat(CONTAINER_SVG_CLASS, ">*")).remove();
      }
    }, {
      key: "handleZoom",
      value: function handleZoom(transform) {
        var zoomTriggeredManually = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
        this.zoomState = transform;
        this.svgGroup.attr("transform", "translate(".concat(transform.x, ", ").concat(transform.y, ") scale(").concat(transform.k, ")"));
        if (zoomTriggeredManually) {
          this._updateZoomState(transform);
        }
      }
    }, {
      key: "_updateZoomState",
      value: function _updateZoomState(transform) {
        var zoomIdentity = d3__namespace.zoomTransform(d3__namespace.select(this._chartContainer).node());
        zoomIdentity.x = transform.x;
        zoomIdentity.y = transform.y;
        zoomIdentity.k = transform.k;
        d3__namespace.select(this._chartContainer).call(this._zoom.transform, zoomIdentity);
      }
    }, {
      key: "_createDOM",
      value: function _createDOM() {
        var _this2 = this;
        // Create the SVG container, a layer for the links and a layer for the nodes.
        this._zoom.scaleExtent([MIN_ZOOM, MAX_ZOOM]).on("zoom", function (event) {
          return _this2.handleZoom(event.transform);
        });
        var container = d3__namespace.select(this._chartContainer).attr("width", this.width).attr("height", this.height).call(this._zoom).on("dblclick.zoom", null);
        this.svg = container.selectAll(".".concat(CONTAINER_SVG_CLASS)).data([CONTAINER_SVG_CLASS]).join("svg").attr("class", CONTAINER_SVG_CLASS).attr("width", this.width).attr("height", this.height);
        this.svgGroup = this.svg.selectAll(".".concat(SVG_GROUP)).data([SVG_GROUP]).join("g").attr("class", SVG_GROUP);
        this.gCategories = this.svgGroup.selectAll(".".concat(CATEGORIES_CLASS)).data([CATEGORIES_CLASS]).join("g").attr("class", CATEGORIES_CLASS).attr("fill", this.props.categoryLabelColor.toString());
        this.gLink = this.svgGroup.selectAll(".".concat(LINKS_CLASS)).data([LINKS_CLASS]).join("g").attr("class", LINKS_CLASS).attr("fill", "none").attr("stroke", "#777").attr("stroke-opacity", 0.4).attr("stroke-width", 1.5);
        this.gNode = this.svgGroup.selectAll(".".concat(NODES_CLASS)).data([NODES_CLASS]).join("g").attr("class", NODES_CLASS).attr("cursor", "pointer").attr("pointer-events", "all");
      }
    }, {
      key: "update",
      value: function update(_info) {
        if (!_info.reason.data && !_info.reason.properties && !_info.reason.size) {
          return;
        }
        var props = _info.props;
        this.locale = _info.locale;
        this._updateProps(props);

        // Specify the charts’ dimensions. The height is variable, depending on the layout.
        this.width = this._chartContainer.clientWidth;
        this.height = this._chartContainer.clientHeight;
        this.marginTop = 50;
        this.marginRight = 50;
        this.marginBottom = 50;
        this.marginLeft = 10;
        if (!_info.data || !_info.data.rows.length) {
          this._clear();
          return;
        }
        if (_info.reason.properties || _info.reason.decorations) {
          this._clear();
          this._createDOM();
          this._center();
        }

        // Create or update the tree
        if (_info.reason.data) {
          var data = _info.data;
          this.categories = data.slotMap.get("categories");
          this.root = this.stratify(data);
          this._center();
          this._createDOM();
        }
        this.valueFormatter = function (_value, _type) {
          return _info.data.cols[VALUE_SLOT].format(_value, _type);
        };
        var animate = _info.reason.properties || _info.reason.decorations ? false : true;
        return this._update(animate);
      }
    }, {
      key: "_update",
      value: function _update(animate) {
        var _this3 = this;
        this.transitionManager.clear();
        var dx = this.props.barHeight;
        var visibleTreeDepth = getDepthRecursive(this.root);
        var dy = (this.width - this.marginRight - this.marginLeft) / (1 + visibleTreeDepth);
        var minimumSpace = this.props.barWidth + this.props.barWidth / 2;
        if (dy < minimumSpace) dy = minimumSpace;
        this.minimumNodeSpace = dy;
        this.treeFn = d3__namespace.tree().nodeSize([dx, this.minimumNodeSpace]).separation(function () {
          return _this3.props.siblingFactor;
        });

        // Compute the new tree layout.
        this.treeFn(this.root);
        var leftNode = this.root;
        var rightNode = this.root;
        this.root.eachBefore(function (node) {
          if (node.x < leftNode.x) leftNode = node;
          if (node.x > rightNode.x) rightNode = node;
        });
        this._alignNodes(leftNode, this.root.descendants());
        this._drawCategories();
        this._drawNodes(animate);
        this._drawPaths(animate);

        // Stash the old positions for transition.
        this.root.eachBefore(function (datum) {
          datum.x0 = datum.x;
          datum.y0 = datum.y;
        });
        return this.transitionManager.resolveAll();
      }
    }, {
      key: "_drawCategories",
      value: function _drawCategories() {
        var _this4 = this;
        var nodes = this.root.descendants().reverse();
        var nodeDepthArray = [];
        var depthMap = nodes.reduce(function (map, node) {
          map.set(node.depth, node.y);
          nodeDepthArray.push({
            depth: node.depth,
            node: node
          });
          return map;
        }, new Map());
        var groupOnClickFn = function groupOnClickFn(_event, index) {
          var parents = nodeDepthArray.filter(function (node) {
            return node.depth === index;
          });
          var ids = parents.map(function (parent) {
            return parent.node.id;
          });
          ids.forEach(function (id) {
            _this4.root.descendants().reverse().forEach(function (node) {
              if (node.id === id) node.children = null;
            });
          });
          _this4._update(true);
        };
        var visibleTreeDepth = getDepthRecursive(this.root);
        var segments = this.categories.segments.slice(0, visibleTreeDepth);
        var getCrossPosition = function getCrossPosition(_datum, index, label) {
          var labelWidth = label ? label.getBoundingClientRect().width : 0;
          var labelOffset = labelWidth + X_OFFSET;
          if (labelWidth < _this4.props.barWidth - X_OFFSET) {
            labelOffset = _this4.props.barWidth;
          }
          var x = depthMap.get(index + 1) + labelOffset;
          var y = Y_OFFSET;
          return "translate(".concat(x, ",").concat(y, ") rotate(45)");
        };
        var getSelectedNodeCaption = function getSelectedNodeCaption(index) {
          var selectedNode = _this4.selectionState.get(index);
          return selectedNode ? selectedNode.data.caption : "";
        };
        var updateCategories = function updateCategories() {
          var text = _this4.gCategories.selectAll("text").attr("x", function (_datum, index) {
            return depthMap.get(index + 1);
          }).attr("y", Y_OFFSET);
          text.each(function (_datum, index) {
            d3__namespace.select(this).selectAll("tspan").attr("x", depthMap.get(index + 1)).attr("y", Y_OFFSET);
          });
          _this4.gCategories.selectAll("tspan.selectedNodeCaption").text(function (_datum, index) {
            return getSelectedNodeCaption(index + 1);
          });
          _this4.gCategories.selectAll("path").attr("transform", function (datum, index) {
            return getCrossPosition(datum, index, _this4.gCategories.selectAll("text").nodes()[index]);
          });
        };
        this.gCategories.selectAll("g").data(segments).join(function (enter) {
          var group = enter.append("g").attr("class", "categoryLabel").attr("data-index", function (_datum, index) {
            return index;
          });
          var text = group.append("text").attr("x", function (_datum, index) {
            return depthMap.get(index + 1);
          }).attr("y", Y_OFFSET);
          text.append("tspan").attr("class", "categoryCaption").text(function (datum) {
            return datum.caption;
          }).attr("text-anchor", "start").attr("cursor", "pointer").attr("fill", _this4.props.categoryLabelColor.toString()).attr("dominant-baseline", "middle").style("font", _this4.props.categoryLabelFont.toString()).attr("x", function (_datum, index) {
            return depthMap.get(index + 1);
          }).attr("dy", "0");
          text.append("tspan").attr("class", "selectedNodeCaption").text(function (_datum, index) {
            return getSelectedNodeCaption(index + 1);
          }).attr("dy", "".concat(Y_OFFSET, "px")).attr("text-anchor", "start").attr("cursor", "pointer").attr("fill", _this4.props.categorySubLabelColor.toString()).attr("dominant-baseline", "middle").style("font", _this4.props.categorySubLabelFont.toString()).attr("x", function (_datum, index) {
            return depthMap.get(index + 1);
          }).attr("dy", "1.2em");
          group.each(function (_datum, index) {
            d3__namespace.select(this).on("click", function (event) {
              return groupOnClickFn(event, index);
            });
          });
          var symbolGenerator = d3__namespace.symbol().type(d3__namespace.symbolCross).size(65);
          group.append("path").attr("d", symbolGenerator).attr("fill", _this4.props.categoryLabelColor.toString()).attr("cursor", "pointer").attr("transform", function (datum, index) {
            return getCrossPosition(datum, index, group.select("text").node());
          }).attr("stroke", "none");
          return group;
        }, function (update) {
          updateCategories();
          return update;
        }, function (exit) {
          updateCategories();
          return exit.remove();
        });
      }
    }, {
      key: "getCategoryNodeHeight",
      value: function getCategoryNodeHeight() {
        return this.gCategories ? this.gCategories.node().getBBox().height : 0;
      }
    }, {
      key: "applySelectionForParents",
      value: function applySelectionForParents(root, selection) {
        root.selected = selection;
        this.selectionState.set(root.depth, root);
        var parent = root.parent;
        if (parent) {
          this.applySelectionForParents(parent, selection);
        }
      }
    }, {
      key: "_alignNodes",
      value: function _alignNodes(leftNode, _nodes) {
        var _this5 = this;
        var leftNodeX = leftNode.x;
        if (this.props.nodesAlignment === NodesAlignment.CENTER) {
          _nodes.forEach(function (d) {
            d.x += Math.abs(leftNodeX) + Y_OFFSET;
          });
          return;
        }
        _nodes.forEach(function (d) {
          var currentLength = 1;
          d.downset = 0;
          if (d.parent !== null) {
            currentLength = d.parent.children.length;
            for (var i = 0; i < currentLength; i++) {
              if (d.parent.children[i].id === d.id) {
                d.downset = i;
              }
            }
            if (_this5.props.nodesAlignment === NodesAlignment.AUTO) d.downset += Math.max(0, d.parent.downset - currentLength + 1);else if (_this5.props.nodesAlignment === NodesAlignment.CURRENT) d.downset += d.parent.downset;
          }
          d.x = d.downset * 80 + 20;
          var treeHeight = 1 + _this5.root.height;
          var availableSpace = (1 + _this5.root.height) * _this5.minimumNodeSpace;
          d.y = d.depth * availableSpace / treeHeight;
        });
      }
    }, {
      key: "_center",
      value: function _center() {
        if (this.svg && this.svgGroup) {
          var container = this.svg.node().getBoundingClientRect();
          var tree = this.svgGroup.node().getBoundingClientRect();
          var currentScale = this.zoomState ? this.zoomState.k : 1;
          var treeHeight = (tree.height + X_OFFSET) * currentScale;
          var treeWidth = (tree.width + Y_OFFSET) * currentScale;
          var isTreeBiggerThanContainer = container.height < treeHeight || container.width < treeWidth;
          var bestScaleFactor = Math.min.apply(Math, [container.height / treeHeight, container.width / treeWidth]);
          var scale = isTreeBiggerThanContainer ? bestScaleFactor : currentScale;
          scale = scale < MIN_ZOOM ? MIN_ZOOM : scale;
          var newZoomState = {
            x: 0,
            y: 0,
            k: scale
          };
          this.handleZoom(newZoomState, true);
        }
      }
    }, {
      key: "_drawNodes",
      value: function _drawNodes(animate) {
        var _this6 = this;
        var nodes = this.root.descendants().reverse();
        var transition = this._getTransition(animate);
        var nodeOnClickFn = /*#__PURE__*/function () {
          var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee(_event, datum) {
            var treeRoot;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
              while (1) switch (_context.prev = _context.next) {
                case 0:
                  treeRoot = getTreeRoot(datum);
                  setSelection(treeRoot, false);
                  closeOtherRoots(datum);
                  datum.children = datum.children ? null : datum._children;
                  datum.selected = !datum.selected;
                  _this6.applySelectionForParents(datum, datum.selected);
                  _this6.selectionState.forEach(function (_value, key) {
                    if (key > datum.depth) _this6.selectionState.set(key, null);
                  });
                  _context.next = 9;
                  return _this6._update(true);
                case 9:
                  _this6._center();
                case 10:
                case "end":
                  return _context.stop();
              }
            }, _callee);
          }));
          return function nodeOnClickFn(_x, _x2) {
            return _ref.apply(this, arguments);
          };
        }();
        this.gNode.selectAll("g").data(nodes, function (datum) {
          return datum.id;
        }).attr("dy", "3em").on("click", function (event, datum) {
          return nodeOnClickFn(event, datum);
        }).join(function (enter) {
          var group = enter.append("g").attr("transform", function (datum) {
            return "translate(".concat(datum.y0, ",").concat(datum.x0 + _this6.getCategoryNodeHeight(), ")");
          }).attr("fill-opacity", 0).attr("class", function (datum) {
            return datum.data.isTreeRoot() ? "treeRootGroup" : "treeGroup";
          }).attr("stroke-opacity", 0).on("click", function (event, datum) {
            return nodeOnClickFn(event, datum);
          });
          group.append("rect").attr("class", BAR_TARGET_CLASS);
          group.select(".".concat(BAR_TARGET_CLASS)).attr("y", _this6.props.barHeight).attr("rx", 0).attr("y", 0).attr("width", function (datum) {
            var columnMaximum = datum.data.isTreeRoot() ? datum.data.getValue() : datum.data.getColumnMaximum();
            var x = d3__namespace.scaleLinear().domain([0, columnMaximum]).range([0, _this6.props.barWidth]);
            return x(columnMaximum);
          }).attr("height", _this6.props.barHeight).attr("fill", _this6.props.barTargetColor.toString()).style("display", function (datum) {
            return datum.data.isTreeRoot() ? "none" : "";
          });
          group.append("rect").attr("class", BAR_ACTUAL_CLASS);
          group.select(".".concat(BAR_ACTUAL_CLASS)).attr("y", _this6.props.barHeight).attr("rx", 0).attr("y", 0).attr("width", function (datum) {
            var dataValue = datum.data.getValue();
            var columnMaximum = datum.data.isTreeRoot() ? dataValue : datum.data.getColumnMaximum();
            var x = d3__namespace.scaleLinear().domain([0, columnMaximum]).range([0, _this6.props.barWidth]);
            return x(dataValue);
          }).attr("height", _this6.props.barHeight).attr("fill", _this6.props.barActualColor.toString());
          var text = group.append("text").attr("y", _this6.props.barHeight).attr("dy", "3em");
          text.append("tspan").attr("class", ROOT_TITLE_CLASS).style("font", _this6.props.labelFont.toString()).attr("fill", _this6.props.labelColor.toString()).text(function (datum) {
            return "".concat(datum.data.caption);
          }).attr("x", 0).attr("dy", "1.2em");
          text.append("tspan").attr("class", ROOT_SUBTITLE_CLASS).attr("fill", _this6.props.labelColor.toString()).text(function (datum) {
            return _this6._valueLabelAccesor(datum);
          }).attr("x", 0).attr("dy", "1.2em").style("font", _this6.props.valueLabelFont.toString());
          var nodeTransition = group.call(function (group) {
            return group.transition(transition).attr("transform", function (datum) {
              return "translate(".concat(datum.y, ",").concat(datum.x + _this6.getCategoryNodeHeight(), ")");
            }).attr("fill-opacity", 1).attr("stroke-opacity", 1);
          });
          _this6.transitionManager.register(nodeTransition);
          return nodeTransition;
        }, function (update) {
          var nodeTransition = update.transition(transition).attr("transform", function (datum) {
            return "translate(".concat(datum.y, ",").concat(datum.x + _this6.getCategoryNodeHeight(), ")");
          }).attr("fill-opacity", 1).attr("stroke-opacity", 1);
          _this6.transitionManager.register(nodeTransition);
          return nodeTransition;
        }, function (exit) {
          var nodeTransition = exit.transition(transition).remove().attr("transform", function (datum) {
            return "translate(".concat(datum.y, ",").concat(datum.x + _this6.getCategoryNodeHeight(), ")");
          }).attr("fill-opacity", 0).attr("stroke-opacity", 0);
          _this6.transitionManager.register(nodeTransition);
          return nodeTransition;
        });
      }
    }, {
      key: "_valueLabelAccesor",
      value: function _valueLabelAccesor(datum) {
        // Use localized number format
        var percentFormatter = new Intl.NumberFormat(this.locale, {
          style: "percent",
          minimumSignificantDigits: 2,
          maximumSignificantDigits: 3
        });
        var value = datum.data.getValue();
        if (!datum.data.isRoot()) return "".concat(this.valueFormatter(value, h.label));
        var total = datum.data.getColumnTotal();
        var percentage = value / total;
        if (this.props.labelOption === "ValueAndPercentage") {
          return "".concat(this.valueFormatter(value, h.label), " (").concat(percentFormatter.format(percentage), ")");
        }
        if (this.props.labelOption === "Value") {
          return this.valueFormatter(value, h.label);
        }
        if (this.props.labelOption === "Percentage") {
          return percentFormatter.format(percentage);
        }
      }
    }, {
      key: "_drawPaths",
      value: function _drawPaths(animate) {
        var _this7 = this;
        var links = this.root.links();
        var transition = this._getTransition(animate);
        this.gLink.selectAll("path").data(links, function (datum) {
          return datum;
        }).join(function (enter) {
          var links = enter.append("path").attr("d", function (datum) {
            var source = {
              x: datum.source.x0 + _this7.getCategoryNodeHeight(),
              y: datum.target.y0
            };
            return _this7.diagonal(source, source, "right");
          }).attr("stroke", function (datum) {
            return datum.target.selected ? _this7.props.selectedPathColor.toString() : _this7.props.pathColor.toString();
          }).attr("stroke-width", function (datum) {
            return datum.target.selected ? "3px" : "1px";
          }).attr("stroke-opacity", function (datum) {
            return datum.target.selected ? 1 : 0.4;
          });
          return links.attr("d", function (datum) {
            return _this7.diagonal(datum.source, datum.target, "right");
          });
        }, function (update) {
          var pathTransition = update.transition(transition).attr("stroke", function (datum) {
            return datum.target.selected ? _this7.props.selectedPathColor.toString() : _this7.props.pathColor.toString();
          }).attr("stroke-width", function (datum) {
            return datum.target.selected ? "3px" : "1px";
          }).attr("stroke-opacity", function (datum) {
            return datum.target.selected ? 1 : 0.4;
          }).attr("d", function (datum) {
            return _this7.diagonal(datum.source, datum.target, "right");
          });
          _this7.transitionManager.register(pathTransition);
          return pathTransition;
        }, function (exit) {
          var pathTransition = exit.transition(transition).remove().attr("stroke-opacity", 0);
          _this7.transitionManager.register(pathTransition);
          return pathTransition;
        });
      }
    }, {
      key: "_getTransition",
      value: function _getTransition(animate) {
        return this.svgGroup.transition().duration(animate ? this.props.transitionDuration : 0).attr("height", this.height);
      }

      // Generate custom link connector line
    }, {
      key: "diagonal",
      value: function diagonal(_source, _target, _direction) {
        var width = _source.data && _source.data.width || 0;
        var height = _source.data && _source.data.height || 0;

        // Input values
        var horizontal = _direction === "left" || _direction === "right";
        var sourceCurveValue = this.props.pathCurve;
        var targetCurveValue = this.props.pathCurve;

        // Translated to ratios
        var sourceRatio1 = Math.min(1, sourceCurveValue / 50);
        var sourceRatio2 = Math.max(0, (sourceCurveValue - 50) / 50);
        var targetRatio1 = Math.min(1, targetCurveValue / 50);
        var targetRatio2 = Math.max(0, (targetCurveValue - 50) / 50);

        // Node point and offset
        var xOffset = this.props.barWidth;
        var yOffset = this.props.barHeight / 2;
        var sourcePoint = transposeCoordinates([_source.x + yOffset + this.getCategoryNodeHeight(), _source.y + xOffset], _direction);
        var sourceSize = transposeCoordinates([width / 2, height / 2], _direction);
        var targetPoint = transposeCoordinates([_target.x + yOffset + this.getCategoryNodeHeight(), _target.y], _direction);
        var targetSize = transposeCoordinates([width / 2, height / 2], _direction);

        // Fixed line points
        if (horizontal) {
          sourcePoint[0] -= sourceSize[1];
          targetPoint[0] += targetSize[1];
        } else {
          sourcePoint[1] -= sourceSize[1];
          targetPoint[1] += targetSize[1];
        }
        var centerPoint = [(sourcePoint[0] + targetPoint[0]) / 2, (sourcePoint[1] + targetPoint[1]) / 2];

        // Dynamic line points
        var sourceCurve = [sourcePoint[0], sourcePoint[1]];
        var targetCurve = [targetPoint[0], targetPoint[1]];
        var sourceCenterOffset = [centerPoint[0], centerPoint[1]];
        var targetCenterOffset = [centerPoint[0], centerPoint[1]];
        if (horizontal) {
          sourceCurve[0] = sourceRatio1 * centerPoint[0] + (1 - sourceRatio1) * sourcePoint[0];
          targetCurve[0] = targetRatio1 * centerPoint[0] + (1 - targetRatio1) * targetPoint[0];
          sourceCenterOffset[1] = sourceRatio2 * sourcePoint[1] + (1 - sourceRatio2) * centerPoint[1];
          targetCenterOffset[1] = targetRatio2 * targetPoint[1] + (1 - targetRatio2) * centerPoint[1];
        } else {
          sourceCurve[1] = sourceRatio1 * centerPoint[1] + (1 - sourceRatio1) * sourcePoint[1];
          targetCurve[1] = targetRatio1 * centerPoint[1] + (1 - targetRatio1) * targetPoint[1];
          sourceCenterOffset[0] = sourceRatio2 * sourcePoint[0] + (1 - sourceRatio2) * centerPoint[0];
          targetCenterOffset[0] = targetRatio2 * targetPoint[0] + (1 - targetRatio2) * centerPoint[0];
        }
        return "M".concat(sourcePoint, " Q").concat(sourceCurve, " ").concat(sourceCenterOffset, " L").concat(targetCenterOffset, " Q").concat(targetCurve, " ").concat(targetPoint);
      }
    }, {
      key: "stratify",
      value: function stratify(data) {
        var root = d3__namespace.hierarchy(buildTree(data));
        var visibleDepth = 1; //Number of visible categories on render

        root.sort(function (nodeA, nodeB) {
          var aValue = nodeA.data.getValue();
          var bValue = nodeB.data.getValue();
          return nodeA.height - nodeB.height || bValue - aValue;
        });
        root.descendants().forEach(function (datum) {
          datum.id = datum.data.id;
          datum._children = datum.children;
          datum.selected = false;
        });
        root.descendants().forEach(function (datum, index) {
          if (datum.data.getDepth() >= visibleDepth) {
            if (index !== 0) datum.children = null;
          }
        });
        return root;
      }
    }, {
      key: "hitTest",
      value: function hitTest(_element) {
        // Retrieve the d3 datum of the element that was hit.
        var element = d3__namespace.select(_element);
        var node = element.empty() ? null : element.datum();
        if (node instanceof Object && "segment" in node) return node.segment;
        if (node instanceof Object && "data" in node) {
          if (node.data.dataPoint) {
            return {
              source: node.data.dataPoint,
              key: node.key,
              caption: node.caption
            };
          }
          if (node.data.tuple) {
            return {
              source: node.data.tuple,
              key: node.key,
              caption: node.value
            };
          }
        }
        return null;
      }
    }]);
    return _default;
  }(ct);

  return _default;

}));
