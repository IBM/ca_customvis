define(['require', 'https://d3js.org/d3.v5.min.js'], function (requirejs, d3) { 'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }

    return obj;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;

    try {
      Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized(self);
  }

  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();

    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
          result;

      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;

        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }

      return _possibleConstructorReturn(this, result);
    };
  }

  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
  }

  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
  }

  function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
  }

  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }

  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;

    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

    return arr2;
  }

  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var e=function(){function t(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}return t.prototype.getName=function(){return this.name},t.prototype.getSlot=function(){return this.slot},t.prototype.getAttributes=function(){return this.attributes},t.slotLimit=function(e,n){return new t("limit",e).attr("n",n)},t.dataLimit=function(e){return new t("limit").attr("n",e)},t.prototype.attr=function(t,e){return this.attributes.set(t,e),this},t}(),n=function(t,e){return (n=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e;}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n]);})(t,e)};
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0

  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.

  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */function r(t,e){function r(){this.constructor=t;}n(t,e),t.prototype=null===e?Object.create(e):(r.prototype=e.prototype,new r);}function o(t,e,n){return t.getDecoration(e,n)}function i(t){return t.hasDecoration("hasSelection")?o(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}var u,s=function(){function t(t,e){this.min=t,this.max=e;}return t.prototype.asArray=function(){return [this.min,this.max]},t.empty=new t(0,0),t}(),a=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e.fromRS=function(t){return new s(t.min,t.max)},e}(s),l=function(){function t(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";var n=t.getItems()||[];this.segments=n.map((function(t){return new p(t)}));}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),c=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(l),h=function(){function t(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),p=function(t){function e(e){return t.call(this,e)||this}return r(e,t),e}(h),f=new(function(){function t(){}return t.prototype.format=function(t){return t?t.toString():""},t}());!function(t){t.label="label",t.data="data";}(u||(u={}));var g=function(){function t(t,e,n,r,o){this.source=t,this.tuples=e,this.segments=n,this.domain=r,this.caption=o;var i=t.dataItems||[],u=i.length>0?i[0]:null,s=u&&u.asCont();s?(this._labelFormatter=s.getFormatter("label")||f,this._dataFormatter=s.getFormatter("data")||f):this._labelFormatter=this._dataFormatter=f;}return Object.defineProperty(t.prototype,"mapped",{get:function(){return this.source.mapped},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"dataType",{get:function(){var t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"},enumerable:!0,configurable:!0}),t.prototype.format=function(t,e){return function(t,e){return t.format(e)}(e===u.data?this._dataFormatter:this._labelFormatter,t)},t}(),d=function(t){function e(e,n,r,o,i){return t.call(this,e,n,r,o,i)||this}return r(e,t),e}(g),m=function(){function t(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t.prototype.tuple=function(t){var e=this._getSlot(t);if(!e||0===e.tuples.length)return null;var n=this.source.get(e.source);if(!n)return null;var r=n.asCat();return r?e.tuples[r.index]:null},t.prototype.value=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);if(!n)return null;var r=n.asCont();return r&&"numeric"===r.valueType?r.value:null},t.prototype.caption=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);return n&&n.getCaption("data")||""},t.prototype._getSlot=function(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null},t}(),y=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(m),v=function(){function t(t,e,n){var r=this;this.source=t,this.rows=t.dataPoints.map((function(t){return new y(t,r)})),this.cols=e,this.slotMap=n;}return t.filterRows=function(t,e,n){return t.filter((function(t){var r=t.tuple(e);return !!r&&r.key===n}))},Object.defineProperty(t.prototype,"hasSelections",{get:function(){return i(this.source)},enumerable:!0,configurable:!0}),t}(),_=function(t){function e(e,n,r){return t.call(this,e,n,r)||this}return r(e,t),e}(v);function b(t){var e=new Map,n=t.getSlots().map((function(t,n){var r=[],o=[],i=s.empty,u="";if(t.isMapped()){var l=t.getDataItem(0);if(u=l.getCaption("label"),"cat"===l.getRSType())r=l.getTuples().map((function(t,e){return new c(t,e)})),o=l.getItemClassSet(0).getItemClasses().map((function(t){return new p(t)}));else i=a.fromRS(l.getDomain()),o.push(new p(l.getItemClass()));}var h=new d(t,r,o,i,u);return e.set(t.name,h),h}));return new _(t,n,e)}function w(t){return t<0?0:t>255?255:Math.floor(t)}var C=function(){function t(t,e,n,r){var o;this.r=w(t),this.g=w(e),this.b=w(n),this.a=(o=r)<0?0:o>1?1:o;}return t.fromObject=function(e){return new t(e.r,e.g,e.b,void 0===e.a?1:e.a)},t.prototype.toString=function(){return 1===this.a?"rgb("+this.r+","+this.g+","+this.b+")":"rgba("+this.r+","+this.g+","+this.b+","+this.a+")"},t}();function S(t,e){var n=null;if(t instanceof m)n=t.source.getDataSet(e);else{var r=t.source.getDataItem(e);n=r&&r.getDataSet(e);}return !!n&&i(n)}var P=function(t){return "rgba("+t.r+","+t.g+","+t.b+",0.4)"},j=function(t){return "rgba("+Math.round(.7*t.r)+","+Math.round(.7*t.g)+","+Math.round(.7*t.b)+","+t.a+")"},x=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColor=function(t){return t?C.fromObject(this.source.getTupleColor(t.source,-1)):C.fromObject(this.source.getColor(null))},t.prototype._getTuple=function(t){if(t instanceof l)return t;var e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null},t.prototype.getFillColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),!t.selected&&S(t,this._dataContext)?P(e):e.toString()},t.prototype.getOutlineColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&S(t,this._dataContext)?j(e):null},t}(),O=function(t,e,n){this.color=t,this.at=e,this.value=n;};function I(t){return t.map((function(t){return new O(C.fromObject(t.color),t.at,t.value)}))}var D=function(){function t(t,e,n){this.source=t,this._slot=e,this._dataContext=n,this.stops=I(t.stops),this.aligned=I(t.aligned),this.interpolate=t.interpolate;}return t.prototype.getColor=function(t){return C.fromObject(this.source.getColor(t))},t.prototype.getFillColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return !t.selected&&S(t,this._dataContext)?P(n):n.toString()},t.prototype.getOutlineColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return t.highlighted||t.selected&&S(t,this._dataContext)?j(n):null},t}(),E=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColorStops=function(t){var e=t?t.source.getDataItem(0):null,n=e&&e.asCont(),r=n?n.getDomain(null):null,o=this.source.getColorStops(n,r),i=t?t.source.name:null;return new D(o,i,this._dataContext)},t.prototype._fetchColorStops=function(t){var e=t.source.getDataSet(this._dataContext),n=this.slot||this._slotResolver(t.dataSet,this.source.name),r=n?e.getSlot(n):null,o=r?r.getDataItem(0):null,i=o?o.asCont():null;if(this.source.dirty||!this._cachedStops||i!==this._lastDataItem){var u=i?i.getDomain(null):null,s=this.source.getColorStops(i,u);this._cachedStops=new D(s,r&&r.name,this._dataContext),this._lastDataItem=i;}return this._cachedStops},t.prototype.getFillColor=function(t){return this._fetchColorStops(t).getFillColor(t)},t.prototype.getOutlineColor=function(t){return this._fetchColorStops(t).getOutlineColor(t)},t}(),T=function(t){function e(e){var n=t.call(this,e.r,e.g,e.b,e.a)||this;return n._color=e,n}return r(e,t),e.prototype.getRed=function(){return this.r},e.prototype.getGreen=function(){return this.g},e.prototype.getBlue=function(){return this.b},e.prototype.getAlpha=function(){return this.a},e}(C),R=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:function(){return 0},getMax:function(){return 0},isEmpty:function(){return !0},isExplicit:function(){return !1}}),F=function(){function t(t,e,n,r,o,i){this.caption=t,this.color=e,this.shape=n,this.selected=r,this.highlighted=o,this.ref=i;}return t.prototype.getCaption=function(){return this.caption},t.prototype.getColor=function(){return this.color?new T(this.color):null},t.prototype.getShape=function(){return this.shape},t.prototype.isSelected=function(){return this.selected},t.prototype.isHighlighted=function(){return this.highlighted},t.prototype.getRef=function(){return this.ref},t}(),M=function(){function t(t,e,n,r,o,i){this.type=t,this.channel=e,this.slot=n,this.caption=r,this.subCaption=o,this.ref=i;}return t.prototype.getRSType=function(){return this.type},t.prototype.getChannel=function(){return this.channel},t.prototype.getSlot=function(){return this.slot},t.prototype.getCaption=function(){return this.caption},t.prototype.getSubCaption=function(){return this.subCaption},t.prototype.getRef=function(){return this.ref},t}(),L=function(t){function e(e,n,r,i,u){var s=this,a=n&&n.source,l=a&&a.name,c=a&&a.getDataItem(0),h=c&&c.asCat();s=t.call(this,"cat",e,l,r,"",h)||this;var p=h?h.tuples:[];return s.entries=p.map((function(t){var e=t.getCaption("label")||"",n=u&&u.source.getTupleColor(t,-1),r=o(t,"selected",!1),s=o(t,"highlighted",!1);return new F(e,n?C.fromObject(n):null,i,r,s,t)})),s}return r(e,t),e.prototype.getEntries=function(){return this.entries},e}(M),A=function(t){function e(e,n,r,o){var i=this,u=n&&n.source,s=u&&u.name,a=u&&u.getDataItem(0),l=a&&a.asCont();if((i=t.call(this,"cont",e,s,r,"",l)||this).domain=l?l.getDomain(null):R,o&&"color"===e){var c=o.source.getColorStops(l,null);i.stops=c.stops,i.interpolate=c.interpolate;}else i.stops=null,i.interpolate=!1;return i}return r(e,t),e.prototype.getDomain=function(){return this.domain},e.prototype.getInterpolate=function(){return this.interpolate},e.prototype.getStops=function(){return this.stops},e}(M);function z(t,e,n,r){if(!t)return [];var o=new Map,i=new Map;e.palettes.forEach((function(e){var n=e.slot||r&&r(t,e.source.name);n&&(e instanceof x?o.set(n,e):e instanceof E&&i.set(n,e));}));var u=[];return t.cols.forEach((function(t){var e=t.source;if(e.mapped){var r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;var s=o.get(e.name);s&&u.push(new L("color",t,t.caption,n.legendShape,s));break;case"cont":if(-1!==e.channels.indexOf("color")){var a=i.get(e.name);a&&u.push(new A("color",t,t.caption,a));}-1!==e.channels.indexOf("size")&&u.push(new A("size",t,t.caption,null));}}})),u}var N,k=function(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;};!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(N||(N={}));var H,U,V=function(){function t(t,e){this.value=t,this.unit=e;}return t.fromObject=function(e){return new t(e.value,function(t){switch(t){case"em":return N.Em;case"%":return N.Percentage;case"cm":return N.Centimeter;case"mm":return N.Millimeter;case"in":return N.Inch;case"pc":return N.Pica;case"pt":return N.Point;case"px":return N.Pixel;default:throw new Error("Invalid length unit '"+t+"' specified")}}(e.unit))},t.prototype.toString=function(){return ""+this.value+this.unit},t}();!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));var q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){var e=[];if(t)for(var n=0,r=t.length;n<r;++n){var o=t[n],i=q.test(o);e.push(i?'"'+o+'"':o);}return e.join(", ")}var J=function(){function t(t,e,n,r){this.family=t,this.size=e,this.style=n,this.weight=r;}return t.fromObject=function(e){return new t(e.family||null,e.size?V.fromObject(e.size):null,e.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error("Invalid font style '"+t+"' specified")}}(e.style):null,void 0!==e.weight&&null!==e.weight?e.weight:null)},t.prototype.toString=function(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){var t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){var e,n=[],r=G(t.family);return r.length>0&&n.push("font-family: "+r+";"),(r=t.size?t.size.toString():"").length>0&&n.push("font-size: "+r+";"),(r=(e=t.style)?e.toString():"").length>0&&n.push("font-style: "+r+";"),(r=K(t.weight)).length>0&&n.push("font-weight: "+r+";"),n.join(" ")}(this)},t}(),Q=function(){function t(t,e,n){var r=new Map;null!==t&&t.forEach((function(t,o){if("palette"===t.type){var i=t;switch(i.paletteType){case"cat":r.set(o,new x(i,e,n));break;case"cont":r.set(o,new E(i,e,n));}}})),this.source=t,this.palettes=r;}return t.prototype.get=function(t){return this._getValue(t,!1)},t.prototype.peek=function(t){return this._getValue(t,!0)},t.prototype._getValue=function(t,e){var n=this.source&&this.source.get(t);if(!n)return null;switch(n.type){case"string":case"number":case"boolean":case"enum":return e?n.peek:n.value;case"length":var r=e?n.peek:n.value;return r?V.fromObject(r):null;case"font":var o=e?n.peek:n.value;return o?J.fromObject(o):null;case"color":var i=e?n.peek:n.value;return i?C.fromObject(i):null;case"palette":return this.palettes.get(t)||null;default:return null}},t.prototype.isActive=function(t){var e=this.source&&this.source.get(t);return !!e&&e.active},t.prototype.setActive=function(t,e){var n=this.source&&this.source.get(t);n&&n.setActive(e);},t.prototype.isDirty=function(t){var e=this.source&&this.source.get(t);return !!e&&e.dirty},t}();var W=setTimeout;function X(t){return Boolean(t&&void 0!==t.length)}function Y(){}function Z(t){if(!(this instanceof Z))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],ot(t,this);}function $(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,Z._immediateFn((function(){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var r;try{r=n(t._value);}catch(t){return void et(e.promise,t)}tt(e.promise,r);}else(1===t._state?tt:et)(e.promise,t._value);}))):t._deferreds.push(e);}function tt(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var n=e.then;if(e instanceof Z)return t._state=3,t._value=e,void nt(t);if("function"==typeof n)return void ot((r=n,o=e,function(){r.apply(o,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){et(t,e);}var r,o;}function et(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&Z._immediateFn((function(){t._handled||Z._unhandledRejectionFn(t._value);}));for(var e=0,n=t._deferreds.length;e<n;e++)$(t,t._deferreds[e]);t._deferreds=null;}function rt(t,e,n){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=n;}function ot(t,e){var n=!1;try{t((function(t){n||(n=!0,tt(e,t));}),(function(t){n||(n=!0,et(e,t));}));}catch(t){if(n)return;n=!0,et(e,t);}}Z.prototype.catch=function(t){return this.then(null,t)},Z.prototype.then=function(t,e){var n=new this.constructor(Y);return $(this,new rt(t,e,n)),n},Z.prototype.finally=function(t){var e=this.constructor;return this.then((function(n){return e.resolve(t()).then((function(){return n}))}),(function(n){return e.resolve(t()).then((function(){return e.reject(n)}))}))},Z.all=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var o=r.length;function i(t,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var s=u.then;if("function"==typeof s)return void s.call(u,(function(e){i(t,e);}),n)}r[t]=u,0==--o&&e(r);}catch(t){n(t);}}for(var u=0;u<r.length;u++)i(u,r[u]);}))},Z.resolve=function(t){return t&&"object"==typeof t&&t.constructor===Z?t:new Z((function(e){e(t);}))},Z.reject=function(t){return new Z((function(e,n){n(t);}))},Z.race=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.race accepts an array"));for(var r=0,o=t.length;r<o;r++)Z.resolve(t[r]).then(e,n);}))},Z._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){W(t,0);},Z._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};var it=function(t,e,n,r){this.data=t,this.decorations=e,this.properties=n,this.size=r;},ut=function(t,e,n,r,o){this.reason=t,this.data=e,this.node=n,this.props=r,this.locale=o;};var st=function(){function n(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new k;}return n.prototype.init=function(t,e){var n=this,r=t.surface.appendChild(document.createElement("div"));r.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),r.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,Z.resolve(this.create(r)).then((function(o){n._elem=o||r,t.properties.forEach((function(t,e){return n.updateProperty(e,t.value)})),e.complete();})).catch((function(t){e.fail(t);}));},n.prototype.destroy=function(){},n.prototype.getPropertyApi=function(){return null},n.prototype.setData=function(t){t&&t.dataSets&&t.dataSets[0]?this._data=b(t.dataSets[0]):this._data=null;},n.prototype.setProperty=function(t,e){this.updateProperty(t,this.properties.peek(t));},n.prototype.getBlockingRequests=function(){return null},n.prototype.render=function(t,e,n){if(!this._elem)return n.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return n.complete(null,null,null),null;try{var r=this.update(new ut(function(t){return new it(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));Z.resolve(r).then((function(){return n.complete(null,null,null)})).catch(n.error);}catch(t){n.error(t);}return null},n.prototype.getEncodings=function(){return this._data?this.updateLegend(this._data):[]},n.prototype.getCapabilities=function(){var t=[];return this.meta.slotLimits.forEach((function(n,r){t.push(e.slotLimit(r,n));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t},n.prototype.getInteractivity=function(){return null},n.prototype.getVisCoordinate=function(t,e){return e},n.prototype.getRegionAtPoint=function(t,e){return null},n.prototype.getItemsAtPoint=function(t,e,n){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;var r=t,o=document.elementFromPoint(r.x,r.y),i=this.hitTest(o,r,e);return i&&i.source?[i.source]:[]},n.prototype.getItemsInPolygon=function(t,e){return []},n.prototype.getAxisItemsAtPoint=function(t,e,n){return []},n.prototype.getState=function(){return null},n.prototype.setState=function(t){},n.prototype.loadCss=function(t){var e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);},n.prototype.toUrl=function(e){return requirejs.toUrl(e)},n.prototype.update=function(t){},n.prototype.create=function(t){},n.prototype.updateProperty=function(t,e){},n.prototype.updateLegend=function(t){return z(t,this.properties,this.meta,this._slotResolver)},n.prototype.getSlotForPalette=function(t,e){return null},n.prototype.hitTest=function(t,e,n){var r=t&&t.__data__;return r&&r.source?r:null},n.prototype.nls=function(t){return this._nls&&this._nls.get(t)||""},n}();

  function max(values, valueof) {
    let max;
    if (valueof === undefined) {
      for (const value of values) {
        if (value != null
            && (max < value || (max === undefined && value >= value))) {
          max = value;
        }
      }
    } else {
      let index = -1;
      for (let value of values) {
        if ((value = valueof(value, ++index, values)) != null
            && (max < value || (max === undefined && value >= value))) {
          max = value;
        }
      }
    }
    return max;
  }

  function min(values, valueof) {
    let min;
    if (valueof === undefined) {
      for (const value of values) {
        if (value != null
            && (min > value || (min === undefined && value >= value))) {
          min = value;
        }
      }
    } else {
      let index = -1;
      for (let value of values) {
        if ((value = valueof(value, ++index, values)) != null
            && (min > value || (min === undefined && value >= value))) {
          min = value;
        }
      }
    }
    return min;
  }

  function sum(values, valueof) {
    let sum = 0;
    if (valueof === undefined) {
      for (let value of values) {
        if (value = +value) {
          sum += value;
        }
      }
    } else {
      let index = -1;
      for (let value of values) {
        if (value = +valueof(value, ++index, values)) {
          sum += value;
        }
      }
    }
    return sum;
  }

  function targetDepth(d) {
    return d.target.depth;
  }

  function left(node) {
    return node.depth;
  }

  function right(node, n) {
    return n - 1 - node.height;
  }

  function justify(node, n) {
    return node.sourceLinks.length ? node.depth : n - 1;
  }

  function center(node) {
    return node.targetLinks.length ? node.depth
        : node.sourceLinks.length ? min(node.sourceLinks, targetDepth) - 1
        : 0;
  }

  function constant(x) {
    return function() {
      return x;
    };
  }

  function ascendingSourceBreadth(a, b) {
    return ascendingBreadth(a.source, b.source) || a.index - b.index;
  }

  function ascendingTargetBreadth(a, b) {
    return ascendingBreadth(a.target, b.target) || a.index - b.index;
  }

  function ascendingBreadth(a, b) {
    return a.y0 - b.y0;
  }

  function value(d) {
    return d.value;
  }

  function defaultId(d) {
    return d.index;
  }

  function defaultNodes(graph) {
    return graph.nodes;
  }

  function defaultLinks(graph) {
    return graph.links;
  }

  function find(nodeById, id) {
    const node = nodeById.get(id);
    if (!node) throw new Error("missing: " + id);
    return node;
  }

  function computeLinkBreadths({nodes}) {
    for (const node of nodes) {
      let y0 = node.y0;
      let y1 = y0;
      for (const link of node.sourceLinks) {
        link.y0 = y0 + link.width / 2;
        y0 += link.width;
      }
      for (const link of node.targetLinks) {
        link.y1 = y1 + link.width / 2;
        y1 += link.width;
      }
    }
  }

  function Sankey() {
    let x0 = 0, y0 = 0, x1 = 1, y1 = 1; // extent
    let dx = 24; // nodeWidth
    let dy = 8, py; // nodePadding
    let id = defaultId;
    let align = justify;
    let sort;
    let linkSort;
    let nodes = defaultNodes;
    let links = defaultLinks;
    let iterations = 6;

    function sankey() {
      const graph = {nodes: nodes.apply(null, arguments), links: links.apply(null, arguments)};
      computeNodeLinks(graph);
      computeNodeValues(graph);
      computeNodeDepths(graph);
      computeNodeHeights(graph);
      computeNodeBreadths(graph);
      computeLinkBreadths(graph);
      return graph;
    }

    sankey.update = function(graph) {
      computeLinkBreadths(graph);
      return graph;
    };

    sankey.nodeId = function(_) {
      return arguments.length ? (id = typeof _ === "function" ? _ : constant(_), sankey) : id;
    };

    sankey.nodeAlign = function(_) {
      return arguments.length ? (align = typeof _ === "function" ? _ : constant(_), sankey) : align;
    };

    sankey.nodeSort = function(_) {
      return arguments.length ? (sort = _, sankey) : sort;
    };

    sankey.nodeWidth = function(_) {
      return arguments.length ? (dx = +_, sankey) : dx;
    };

    sankey.nodePadding = function(_) {
      return arguments.length ? (dy = py = +_, sankey) : dy;
    };

    sankey.nodes = function(_) {
      return arguments.length ? (nodes = typeof _ === "function" ? _ : constant(_), sankey) : nodes;
    };

    sankey.links = function(_) {
      return arguments.length ? (links = typeof _ === "function" ? _ : constant(_), sankey) : links;
    };

    sankey.linkSort = function(_) {
      return arguments.length ? (linkSort = _, sankey) : linkSort;
    };

    sankey.size = function(_) {
      return arguments.length ? (x0 = y0 = 0, x1 = +_[0], y1 = +_[1], sankey) : [x1 - x0, y1 - y0];
    };

    sankey.extent = function(_) {
      return arguments.length ? (x0 = +_[0][0], x1 = +_[1][0], y0 = +_[0][1], y1 = +_[1][1], sankey) : [[x0, y0], [x1, y1]];
    };

    sankey.iterations = function(_) {
      return arguments.length ? (iterations = +_, sankey) : iterations;
    };

    function computeNodeLinks({nodes, links}) {
      for (const [i, node] of nodes.entries()) {
        node.index = i;
        node.sourceLinks = [];
        node.targetLinks = [];
      }
      const nodeById = new Map(nodes.map((d, i) => [id(d, i, nodes), d]));
      for (const [i, link] of links.entries()) {
        link.index = i;
        let {source, target} = link;
        if (typeof source !== "object") source = link.source = find(nodeById, source);
        if (typeof target !== "object") target = link.target = find(nodeById, target);
        source.sourceLinks.push(link);
        target.targetLinks.push(link);
      }
      if (linkSort != null) {
        for (const {sourceLinks, targetLinks} of nodes) {
          sourceLinks.sort(linkSort);
          targetLinks.sort(linkSort);
        }
      }
    }

    function computeNodeValues({nodes}) {
      for (const node of nodes) {
        node.value = node.fixedValue === undefined
            ? Math.max(sum(node.sourceLinks, value), sum(node.targetLinks, value))
            : node.fixedValue;
      }
    }

    function computeNodeDepths({nodes}) {
      const n = nodes.length;
      let current = new Set(nodes);
      let next = new Set;
      let x = 0;
      while (current.size) {
        for (const node of current) {
          node.depth = x;
          for (const {target} of node.sourceLinks) {
            next.add(target);
          }
        }
        if (++x > n) throw new Error("circular link");
        current = next;
        next = new Set;
      }
    }

    function computeNodeHeights({nodes}) {
      const n = nodes.length;
      let current = new Set(nodes);
      let next = new Set;
      let x = 0;
      while (current.size) {
        for (const node of current) {
          node.height = x;
          for (const {source} of node.targetLinks) {
            next.add(source);
          }
        }
        if (++x > n) throw new Error("circular link");
        current = next;
        next = new Set;
      }
    }

    function computeNodeLayers({nodes}) {
      const x = max(nodes, d => d.depth) + 1;
      const kx = (x1 - x0 - dx) / (x - 1);
      const columns = new Array(x);
      for (const node of nodes) {
        const i = Math.max(0, Math.min(x - 1, Math.floor(align.call(null, node, x))));
        node.layer = i;
        node.x0 = x0 + i * kx;
        node.x1 = node.x0 + dx;
        if (columns[i]) columns[i].push(node);
        else columns[i] = [node];
      }
      if (sort) for (const column of columns) {
        column.sort(sort);
      }
      return columns;
    }

    function initializeNodeBreadths(columns) {
      const ky = min(columns, c => (y1 - y0 - (c.length - 1) * py) / sum(c, value));
      for (const nodes of columns) {
        let y = y0;
        for (const node of nodes) {
          node.y0 = y;
          node.y1 = y + node.value * ky;
          y = node.y1 + py;
          for (const link of node.sourceLinks) {
            link.width = link.value * ky;
          }
        }
        y = (y1 - y + py) / (nodes.length + 1);
        for (let i = 0; i < nodes.length; ++i) {
          const node = nodes[i];
          node.y0 += y * (i + 1);
          node.y1 += y * (i + 1);
        }
        reorderLinks(nodes);
      }
    }

    function computeNodeBreadths(graph) {
      const columns = computeNodeLayers(graph);
      py = Math.min(dy, (y1 - y0) / (max(columns, c => c.length) - 1));
      initializeNodeBreadths(columns);
      for (let i = 0; i < iterations; ++i) {
        const alpha = Math.pow(0.99, i);
        const beta = Math.max(1 - alpha, (i + 1) / iterations);
        relaxRightToLeft(columns, alpha, beta);
        relaxLeftToRight(columns, alpha, beta);
      }
    }

    // Reposition each node based on its incoming (target) links.
    function relaxLeftToRight(columns, alpha, beta) {
      for (let i = 1, n = columns.length; i < n; ++i) {
        const column = columns[i];
        for (const target of column) {
          let y = 0;
          let w = 0;
          for (const {source, value} of target.targetLinks) {
            let v = value * (target.layer - source.layer);
            y += targetTop(source, target) * v;
            w += v;
          }
          if (!(w > 0)) continue;
          let dy = (y / w - target.y0) * alpha;
          target.y0 += dy;
          target.y1 += dy;
          reorderNodeLinks(target);
        }
        if (sort === undefined) column.sort(ascendingBreadth);
        resolveCollisions(column, beta);
      }
    }

    // Reposition each node based on its outgoing (source) links.
    function relaxRightToLeft(columns, alpha, beta) {
      for (let n = columns.length, i = n - 2; i >= 0; --i) {
        const column = columns[i];
        for (const source of column) {
          let y = 0;
          let w = 0;
          for (const {target, value} of source.sourceLinks) {
            let v = value * (target.layer - source.layer);
            y += sourceTop(source, target) * v;
            w += v;
          }
          if (!(w > 0)) continue;
          let dy = (y / w - source.y0) * alpha;
          source.y0 += dy;
          source.y1 += dy;
          reorderNodeLinks(source);
        }
        if (sort === undefined) column.sort(ascendingBreadth);
        resolveCollisions(column, beta);
      }
    }

    function resolveCollisions(nodes, alpha) {
      const i = nodes.length >> 1;
      const subject = nodes[i];
      resolveCollisionsBottomToTop(nodes, subject.y0 - py, i - 1, alpha);
      resolveCollisionsTopToBottom(nodes, subject.y1 + py, i + 1, alpha);
      resolveCollisionsBottomToTop(nodes, y1, nodes.length - 1, alpha);
      resolveCollisionsTopToBottom(nodes, y0, 0, alpha);
    }

    // Push any overlapping nodes down.
    function resolveCollisionsTopToBottom(nodes, y, i, alpha) {
      for (; i < nodes.length; ++i) {
        const node = nodes[i];
        const dy = (y - node.y0) * alpha;
        if (dy > 1e-6) node.y0 += dy, node.y1 += dy;
        y = node.y1 + py;
      }
    }

    // Push any overlapping nodes up.
    function resolveCollisionsBottomToTop(nodes, y, i, alpha) {
      for (; i >= 0; --i) {
        const node = nodes[i];
        const dy = (node.y1 - y) * alpha;
        if (dy > 1e-6) node.y0 -= dy, node.y1 -= dy;
        y = node.y0 - py;
      }
    }

    function reorderNodeLinks({sourceLinks, targetLinks}) {
      if (linkSort === undefined) {
        for (const {source: {sourceLinks}} of targetLinks) {
          sourceLinks.sort(ascendingTargetBreadth);
        }
        for (const {target: {targetLinks}} of sourceLinks) {
          targetLinks.sort(ascendingSourceBreadth);
        }
      }
    }

    function reorderLinks(nodes) {
      if (linkSort === undefined) {
        for (const {sourceLinks, targetLinks} of nodes) {
          sourceLinks.sort(ascendingTargetBreadth);
          targetLinks.sort(ascendingSourceBreadth);
        }
      }
    }

    // Returns the target.y0 that would produce an ideal link from source to target.
    function targetTop(source, target) {
      let y = source.y0 - (source.sourceLinks.length - 1) * py / 2;
      for (const {target: node, width} of source.sourceLinks) {
        if (node === target) break;
        y += width + py;
      }
      for (const {source: node, width} of target.targetLinks) {
        if (node === source) break;
        y -= width;
      }
      return y;
    }

    // Returns the source.y0 that would produce an ideal link from source to target.
    function sourceTop(source, target) {
      let y = target.y0 - (target.targetLinks.length - 1) * py / 2;
      for (const {source: node, width} of target.targetLinks) {
        if (node === source) break;
        y += width + py;
      }
      for (const {target: node, width} of source.sourceLinks) {
        if (node === target) break;
        y -= width;
      }
      return y;
    }

    return sankey;
  }

  var pi = Math.PI,
      tau = 2 * pi,
      epsilon = 1e-6,
      tauEpsilon = tau - epsilon;

  function Path() {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null; // end of current subpath
    this._ = "";
  }

  function path() {
    return new Path;
  }

  Path.prototype = path.prototype = {
    constructor: Path,
    moveTo: function(x, y) {
      this._ += "M" + (this._x0 = this._x1 = +x) + "," + (this._y0 = this._y1 = +y);
    },
    closePath: function() {
      if (this._x1 !== null) {
        this._x1 = this._x0, this._y1 = this._y0;
        this._ += "Z";
      }
    },
    lineTo: function(x, y) {
      this._ += "L" + (this._x1 = +x) + "," + (this._y1 = +y);
    },
    quadraticCurveTo: function(x1, y1, x, y) {
      this._ += "Q" + (+x1) + "," + (+y1) + "," + (this._x1 = +x) + "," + (this._y1 = +y);
    },
    bezierCurveTo: function(x1, y1, x2, y2, x, y) {
      this._ += "C" + (+x1) + "," + (+y1) + "," + (+x2) + "," + (+y2) + "," + (this._x1 = +x) + "," + (this._y1 = +y);
    },
    arcTo: function(x1, y1, x2, y2, r) {
      x1 = +x1, y1 = +y1, x2 = +x2, y2 = +y2, r = +r;
      var x0 = this._x1,
          y0 = this._y1,
          x21 = x2 - x1,
          y21 = y2 - y1,
          x01 = x0 - x1,
          y01 = y0 - y1,
          l01_2 = x01 * x01 + y01 * y01;

      // Is the radius negative? Error.
      if (r < 0) throw new Error("negative radius: " + r);

      // Is this path empty? Move to (x1,y1).
      if (this._x1 === null) {
        this._ += "M" + (this._x1 = x1) + "," + (this._y1 = y1);
      }

      // Or, is (x1,y1) coincident with (x0,y0)? Do nothing.
      else if (!(l01_2 > epsilon));

      // Or, are (x0,y0), (x1,y1) and (x2,y2) collinear?
      // Equivalently, is (x1,y1) coincident with (x2,y2)?
      // Or, is the radius zero? Line to (x1,y1).
      else if (!(Math.abs(y01 * x21 - y21 * x01) > epsilon) || !r) {
        this._ += "L" + (this._x1 = x1) + "," + (this._y1 = y1);
      }

      // Otherwise, draw an arc!
      else {
        var x20 = x2 - x0,
            y20 = y2 - y0,
            l21_2 = x21 * x21 + y21 * y21,
            l20_2 = x20 * x20 + y20 * y20,
            l21 = Math.sqrt(l21_2),
            l01 = Math.sqrt(l01_2),
            l = r * Math.tan((pi - Math.acos((l21_2 + l01_2 - l20_2) / (2 * l21 * l01))) / 2),
            t01 = l / l01,
            t21 = l / l21;

        // If the start tangent is not coincident with (x0,y0), line to.
        if (Math.abs(t01 - 1) > epsilon) {
          this._ += "L" + (x1 + t01 * x01) + "," + (y1 + t01 * y01);
        }

        this._ += "A" + r + "," + r + ",0,0," + (+(y01 * x20 > x01 * y20)) + "," + (this._x1 = x1 + t21 * x21) + "," + (this._y1 = y1 + t21 * y21);
      }
    },
    arc: function(x, y, r, a0, a1, ccw) {
      x = +x, y = +y, r = +r, ccw = !!ccw;
      var dx = r * Math.cos(a0),
          dy = r * Math.sin(a0),
          x0 = x + dx,
          y0 = y + dy,
          cw = 1 ^ ccw,
          da = ccw ? a0 - a1 : a1 - a0;

      // Is the radius negative? Error.
      if (r < 0) throw new Error("negative radius: " + r);

      // Is this path empty? Move to (x0,y0).
      if (this._x1 === null) {
        this._ += "M" + x0 + "," + y0;
      }

      // Or, is (x0,y0) not coincident with the previous point? Line to (x0,y0).
      else if (Math.abs(this._x1 - x0) > epsilon || Math.abs(this._y1 - y0) > epsilon) {
        this._ += "L" + x0 + "," + y0;
      }

      // Is this arc empty? We’re done.
      if (!r) return;

      // Does the angle go the wrong way? Flip the direction.
      if (da < 0) da = da % tau + tau;

      // Is this a complete circle? Draw two arcs to complete the circle.
      if (da > tauEpsilon) {
        this._ += "A" + r + "," + r + ",0,1," + cw + "," + (x - dx) + "," + (y - dy) + "A" + r + "," + r + ",0,1," + cw + "," + (this._x1 = x0) + "," + (this._y1 = y0);
      }

      // Is this arc non-empty? Draw an arc!
      else if (da > epsilon) {
        this._ += "A" + r + "," + r + ",0," + (+(da >= pi)) + "," + cw + "," + (this._x1 = x + r * Math.cos(a1)) + "," + (this._y1 = y + r * Math.sin(a1));
      }
    },
    rect: function(x, y, w, h) {
      this._ += "M" + (this._x0 = this._x1 = +x) + "," + (this._y0 = this._y1 = +y) + "h" + (+w) + "v" + (+h) + "h" + (-w) + "Z";
    },
    toString: function() {
      return this._;
    }
  };

  function constant$1(x) {
    return function constant() {
      return x;
    };
  }

  function x$1(p) {
    return p[0];
  }

  function y$1(p) {
    return p[1];
  }

  var slice = Array.prototype.slice;

  function linkSource(d) {
    return d.source;
  }

  function linkTarget(d) {
    return d.target;
  }

  function link(curve) {
    var source = linkSource,
        target = linkTarget,
        x = x$1,
        y = y$1,
        context = null;

    function link() {
      var buffer, argv = slice.call(arguments), s = source.apply(this, argv), t = target.apply(this, argv);
      if (!context) context = buffer = path();
      curve(context, +x.apply(this, (argv[0] = s, argv)), +y.apply(this, argv), +x.apply(this, (argv[0] = t, argv)), +y.apply(this, argv));
      if (buffer) return context = null, buffer + "" || null;
    }

    link.source = function(_) {
      return arguments.length ? (source = _, link) : source;
    };

    link.target = function(_) {
      return arguments.length ? (target = _, link) : target;
    };

    link.x = function(_) {
      return arguments.length ? (x = typeof _ === "function" ? _ : constant$1(+_), link) : x;
    };

    link.y = function(_) {
      return arguments.length ? (y = typeof _ === "function" ? _ : constant$1(+_), link) : y;
    };

    link.context = function(_) {
      return arguments.length ? ((context = _ == null ? null : _), link) : context;
    };

    return link;
  }

  function curveHorizontal(context, x0, y0, x1, y1) {
    context.moveTo(x0, y0);
    context.bezierCurveTo(x0 = (x0 + x1) / 2, y0, x0, y1, x1, y1);
  }

  function linkHorizontal() {
    return link(curveHorizontal);
  }

  function horizontalSource(d) {
    return [d.source.x1, d.y0];
  }

  function horizontalTarget(d) {
    return [d.target.x0, d.y1];
  }

  function sankeyLinkHorizontal() {
    return linkHorizontal()
        .source(horizontalSource)
        .target(horizontalTarget);
  }

  function quickselect(arr, k, left, right, compare) {
      quickselectStep(arr, k, left || 0, right || (arr.length - 1), compare || defaultCompare);
  }

  function quickselectStep(arr, k, left, right, compare) {

      while (right > left) {
          if (right - left > 600) {
              var n = right - left + 1;
              var m = k - left + 1;
              var z = Math.log(n);
              var s = 0.5 * Math.exp(2 * z / 3);
              var sd = 0.5 * Math.sqrt(z * s * (n - s) / n) * (m - n / 2 < 0 ? -1 : 1);
              var newLeft = Math.max(left, Math.floor(k - m * s / n + sd));
              var newRight = Math.min(right, Math.floor(k + (n - m) * s / n + sd));
              quickselectStep(arr, k, newLeft, newRight, compare);
          }

          var t = arr[k];
          var i = left;
          var j = right;

          swap(arr, left, k);
          if (compare(arr[right], t) > 0) swap(arr, left, right);

          while (i < j) {
              swap(arr, i, j);
              i++;
              j--;
              while (compare(arr[i], t) < 0) i++;
              while (compare(arr[j], t) > 0) j--;
          }

          if (compare(arr[left], t) === 0) swap(arr, left, j);
          else {
              j++;
              swap(arr, j, right);
          }

          if (j <= k) left = j + 1;
          if (k <= j) right = j - 1;
      }
  }

  function swap(arr, i, j) {
      var tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
  }

  function defaultCompare(a, b) {
      return a < b ? -1 : a > b ? 1 : 0;
  }

  class RBush {
      constructor(maxEntries = 9) {
          // max entries in a node is 9 by default; min node fill is 40% for best performance
          this._maxEntries = Math.max(4, maxEntries);
          this._minEntries = Math.max(2, Math.ceil(this._maxEntries * 0.4));
          this.clear();
      }

      all() {
          return this._all(this.data, []);
      }

      search(bbox) {
          let node = this.data;
          const result = [];

          if (!intersects(bbox, node)) return result;

          const toBBox = this.toBBox;
          const nodesToSearch = [];

          while (node) {
              for (let i = 0; i < node.children.length; i++) {
                  const child = node.children[i];
                  const childBBox = node.leaf ? toBBox(child) : child;

                  if (intersects(bbox, childBBox)) {
                      if (node.leaf) result.push(child);
                      else if (contains(bbox, childBBox)) this._all(child, result);
                      else nodesToSearch.push(child);
                  }
              }
              node = nodesToSearch.pop();
          }

          return result;
      }

      collides(bbox) {
          let node = this.data;

          if (!intersects(bbox, node)) return false;

          const nodesToSearch = [];
          while (node) {
              for (let i = 0; i < node.children.length; i++) {
                  const child = node.children[i];
                  const childBBox = node.leaf ? this.toBBox(child) : child;

                  if (intersects(bbox, childBBox)) {
                      if (node.leaf || contains(bbox, childBBox)) return true;
                      nodesToSearch.push(child);
                  }
              }
              node = nodesToSearch.pop();
          }

          return false;
      }

      load(data) {
          if (!(data && data.length)) return this;

          if (data.length < this._minEntries) {
              for (let i = 0; i < data.length; i++) {
                  this.insert(data[i]);
              }
              return this;
          }

          // recursively build the tree with the given data from scratch using OMT algorithm
          let node = this._build(data.slice(), 0, data.length - 1, 0);

          if (!this.data.children.length) {
              // save as is if tree is empty
              this.data = node;

          } else if (this.data.height === node.height) {
              // split root if trees have the same height
              this._splitRoot(this.data, node);

          } else {
              if (this.data.height < node.height) {
                  // swap trees if inserted one is bigger
                  const tmpNode = this.data;
                  this.data = node;
                  node = tmpNode;
              }

              // insert the small tree into the large tree at appropriate level
              this._insert(node, this.data.height - node.height - 1, true);
          }

          return this;
      }

      insert(item) {
          if (item) this._insert(item, this.data.height - 1);
          return this;
      }

      clear() {
          this.data = createNode([]);
          return this;
      }

      remove(item, equalsFn) {
          if (!item) return this;

          let node = this.data;
          const bbox = this.toBBox(item);
          const path = [];
          const indexes = [];
          let i, parent, goingUp;

          // depth-first iterative tree traversal
          while (node || path.length) {

              if (!node) { // go up
                  node = path.pop();
                  parent = path[path.length - 1];
                  i = indexes.pop();
                  goingUp = true;
              }

              if (node.leaf) { // check current node
                  const index = findItem(item, node.children, equalsFn);

                  if (index !== -1) {
                      // item found, remove the item and condense tree upwards
                      node.children.splice(index, 1);
                      path.push(node);
                      this._condense(path);
                      return this;
                  }
              }

              if (!goingUp && !node.leaf && contains(node, bbox)) { // go down
                  path.push(node);
                  indexes.push(i);
                  i = 0;
                  parent = node;
                  node = node.children[0];

              } else if (parent) { // go right
                  i++;
                  node = parent.children[i];
                  goingUp = false;

              } else node = null; // nothing found
          }

          return this;
      }

      toBBox(item) { return item; }

      compareMinX(a, b) { return a.minX - b.minX; }
      compareMinY(a, b) { return a.minY - b.minY; }

      toJSON() { return this.data; }

      fromJSON(data) {
          this.data = data;
          return this;
      }

      _all(node, result) {
          const nodesToSearch = [];
          while (node) {
              if (node.leaf) result.push(...node.children);
              else nodesToSearch.push(...node.children);

              node = nodesToSearch.pop();
          }
          return result;
      }

      _build(items, left, right, height) {

          const N = right - left + 1;
          let M = this._maxEntries;
          let node;

          if (N <= M) {
              // reached leaf level; return leaf
              node = createNode(items.slice(left, right + 1));
              calcBBox(node, this.toBBox);
              return node;
          }

          if (!height) {
              // target height of the bulk-loaded tree
              height = Math.ceil(Math.log(N) / Math.log(M));

              // target number of root entries to maximize storage utilization
              M = Math.ceil(N / Math.pow(M, height - 1));
          }

          node = createNode([]);
          node.leaf = false;
          node.height = height;

          // split the items into M mostly square tiles

          const N2 = Math.ceil(N / M);
          const N1 = N2 * Math.ceil(Math.sqrt(M));

          multiSelect(items, left, right, N1, this.compareMinX);

          for (let i = left; i <= right; i += N1) {

              const right2 = Math.min(i + N1 - 1, right);

              multiSelect(items, i, right2, N2, this.compareMinY);

              for (let j = i; j <= right2; j += N2) {

                  const right3 = Math.min(j + N2 - 1, right2);

                  // pack each entry recursively
                  node.children.push(this._build(items, j, right3, height - 1));
              }
          }

          calcBBox(node, this.toBBox);

          return node;
      }

      _chooseSubtree(bbox, node, level, path) {
          while (true) {
              path.push(node);

              if (node.leaf || path.length - 1 === level) break;

              let minArea = Infinity;
              let minEnlargement = Infinity;
              let targetNode;

              for (let i = 0; i < node.children.length; i++) {
                  const child = node.children[i];
                  const area = bboxArea(child);
                  const enlargement = enlargedArea(bbox, child) - area;

                  // choose entry with the least area enlargement
                  if (enlargement < minEnlargement) {
                      minEnlargement = enlargement;
                      minArea = area < minArea ? area : minArea;
                      targetNode = child;

                  } else if (enlargement === minEnlargement) {
                      // otherwise choose one with the smallest area
                      if (area < minArea) {
                          minArea = area;
                          targetNode = child;
                      }
                  }
              }

              node = targetNode || node.children[0];
          }

          return node;
      }

      _insert(item, level, isNode) {
          const bbox = isNode ? item : this.toBBox(item);
          const insertPath = [];

          // find the best node for accommodating the item, saving all nodes along the path too
          const node = this._chooseSubtree(bbox, this.data, level, insertPath);

          // put the item into the node
          node.children.push(item);
          extend(node, bbox);

          // split on node overflow; propagate upwards if necessary
          while (level >= 0) {
              if (insertPath[level].children.length > this._maxEntries) {
                  this._split(insertPath, level);
                  level--;
              } else break;
          }

          // adjust bboxes along the insertion path
          this._adjustParentBBoxes(bbox, insertPath, level);
      }

      // split overflowed node into two
      _split(insertPath, level) {
          const node = insertPath[level];
          const M = node.children.length;
          const m = this._minEntries;

          this._chooseSplitAxis(node, m, M);

          const splitIndex = this._chooseSplitIndex(node, m, M);

          const newNode = createNode(node.children.splice(splitIndex, node.children.length - splitIndex));
          newNode.height = node.height;
          newNode.leaf = node.leaf;

          calcBBox(node, this.toBBox);
          calcBBox(newNode, this.toBBox);

          if (level) insertPath[level - 1].children.push(newNode);
          else this._splitRoot(node, newNode);
      }

      _splitRoot(node, newNode) {
          // split root node
          this.data = createNode([node, newNode]);
          this.data.height = node.height + 1;
          this.data.leaf = false;
          calcBBox(this.data, this.toBBox);
      }

      _chooseSplitIndex(node, m, M) {
          let index;
          let minOverlap = Infinity;
          let minArea = Infinity;

          for (let i = m; i <= M - m; i++) {
              const bbox1 = distBBox(node, 0, i, this.toBBox);
              const bbox2 = distBBox(node, i, M, this.toBBox);

              const overlap = intersectionArea(bbox1, bbox2);
              const area = bboxArea(bbox1) + bboxArea(bbox2);

              // choose distribution with minimum overlap
              if (overlap < minOverlap) {
                  minOverlap = overlap;
                  index = i;

                  minArea = area < minArea ? area : minArea;

              } else if (overlap === minOverlap) {
                  // otherwise choose distribution with minimum area
                  if (area < minArea) {
                      minArea = area;
                      index = i;
                  }
              }
          }

          return index || M - m;
      }

      // sorts node children by the best axis for split
      _chooseSplitAxis(node, m, M) {
          const compareMinX = node.leaf ? this.compareMinX : compareNodeMinX;
          const compareMinY = node.leaf ? this.compareMinY : compareNodeMinY;
          const xMargin = this._allDistMargin(node, m, M, compareMinX);
          const yMargin = this._allDistMargin(node, m, M, compareMinY);

          // if total distributions margin value is minimal for x, sort by minX,
          // otherwise it's already sorted by minY
          if (xMargin < yMargin) node.children.sort(compareMinX);
      }

      // total margin of all possible split distributions where each node is at least m full
      _allDistMargin(node, m, M, compare) {
          node.children.sort(compare);

          const toBBox = this.toBBox;
          const leftBBox = distBBox(node, 0, m, toBBox);
          const rightBBox = distBBox(node, M - m, M, toBBox);
          let margin = bboxMargin(leftBBox) + bboxMargin(rightBBox);

          for (let i = m; i < M - m; i++) {
              const child = node.children[i];
              extend(leftBBox, node.leaf ? toBBox(child) : child);
              margin += bboxMargin(leftBBox);
          }

          for (let i = M - m - 1; i >= m; i--) {
              const child = node.children[i];
              extend(rightBBox, node.leaf ? toBBox(child) : child);
              margin += bboxMargin(rightBBox);
          }

          return margin;
      }

      _adjustParentBBoxes(bbox, path, level) {
          // adjust bboxes along the given tree path
          for (let i = level; i >= 0; i--) {
              extend(path[i], bbox);
          }
      }

      _condense(path) {
          // go through the path, removing empty nodes and updating bboxes
          for (let i = path.length - 1, siblings; i >= 0; i--) {
              if (path[i].children.length === 0) {
                  if (i > 0) {
                      siblings = path[i - 1].children;
                      siblings.splice(siblings.indexOf(path[i]), 1);

                  } else this.clear();

              } else calcBBox(path[i], this.toBBox);
          }
      }
  }

  function findItem(item, items, equalsFn) {
      if (!equalsFn) return items.indexOf(item);

      for (let i = 0; i < items.length; i++) {
          if (equalsFn(item, items[i])) return i;
      }
      return -1;
  }

  // calculate node's bbox from bboxes of its children
  function calcBBox(node, toBBox) {
      distBBox(node, 0, node.children.length, toBBox, node);
  }

  // min bounding rectangle of node children from k to p-1
  function distBBox(node, k, p, toBBox, destNode) {
      if (!destNode) destNode = createNode(null);
      destNode.minX = Infinity;
      destNode.minY = Infinity;
      destNode.maxX = -Infinity;
      destNode.maxY = -Infinity;

      for (let i = k; i < p; i++) {
          const child = node.children[i];
          extend(destNode, node.leaf ? toBBox(child) : child);
      }

      return destNode;
  }

  function extend(a, b) {
      a.minX = Math.min(a.minX, b.minX);
      a.minY = Math.min(a.minY, b.minY);
      a.maxX = Math.max(a.maxX, b.maxX);
      a.maxY = Math.max(a.maxY, b.maxY);
      return a;
  }

  function compareNodeMinX(a, b) { return a.minX - b.minX; }
  function compareNodeMinY(a, b) { return a.minY - b.minY; }

  function bboxArea(a)   { return (a.maxX - a.minX) * (a.maxY - a.minY); }
  function bboxMargin(a) { return (a.maxX - a.minX) + (a.maxY - a.minY); }

  function enlargedArea(a, b) {
      return (Math.max(b.maxX, a.maxX) - Math.min(b.minX, a.minX)) *
             (Math.max(b.maxY, a.maxY) - Math.min(b.minY, a.minY));
  }

  function intersectionArea(a, b) {
      const minX = Math.max(a.minX, b.minX);
      const minY = Math.max(a.minY, b.minY);
      const maxX = Math.min(a.maxX, b.maxX);
      const maxY = Math.min(a.maxY, b.maxY);

      return Math.max(0, maxX - minX) *
             Math.max(0, maxY - minY);
  }

  function contains(a, b) {
      return a.minX <= b.minX &&
             a.minY <= b.minY &&
             b.maxX <= a.maxX &&
             b.maxY <= a.maxY;
  }

  function intersects(a, b) {
      return b.minX <= a.maxX &&
             b.minY <= a.maxY &&
             b.maxX >= a.minX &&
             b.maxY >= a.minY;
  }

  function createNode(children) {
      return {
          children,
          height: 1,
          leaf: true,
          minX: Infinity,
          minY: Infinity,
          maxX: -Infinity,
          maxY: -Infinity
      };
  }

  // sort an array so that items come in groups of n unsorted items, with groups sorted between each other;
  // combines selection algorithm with binary divide & conquer approach

  function multiSelect(arr, left, right, n, compare) {
      const stack = [left, right];

      while (stack.length) {
          right = stack.pop();
          left = stack.pop();

          if (right - left <= n) continue;

          const mid = left + Math.ceil((right - left) / n / 2) * n;
          quickselect(arr, mid, left, right, compare);

          stack.push(left, mid, mid, right);
      }
  }

  var FROM = 0,
      TO = 1,
      WEIGHT = 2;
  var DATA_POINTS_LIMIT = 10000; // TODO: Arbitrary limit for datapoints for now, to avoid blowing up.

  var Y_BUFFER = 5; // for vertical adjustment to give enough padding at top/bottom for label (px assumed).
  // Key function for d3.data to uniquely identify data elements.

  var keyFn = function keyFn(elem) {
    return elem.key || "";
  };

  var getSankeyAlignmentFn = function getSankeyAlignmentFn(_alignment) {
    switch (_alignment) {
      case "left":
        return left;

      case "right":
        return right;

      case "center":
        return center;

      default:
        return justify;
    }
  };

  function buildLabelDomains(_nodes) {
    var colorDomains = []; // specific for color lookup.

    for (var i = 0; i < _nodes.length; ++i) {
      var dv = _nodes[i].$.caption;

      if (colorDomains.indexOf(dv) < 0) // don't want duplicated caption.
        {
          colorDomains.push(dv);
        }
    }

    colorDomains.sort();
    return colorDomains;
  }

  function mergeNodes(_from, _to) {
    var nodes = [].concat(_from);

    var _loop = function _loop(i) {
      var n = nodes.some(function (_e) {
        return _e.key === _to[i].key;
      });
      if (!n) nodes.push(_to[i]);
    };

    for (var i = 0; i < _to.length; ++i) {
      _loop(i);
    }

    return nodes;
  }

  function filterNodes(_nodes, _links) {
    var nodes = [].concat(_nodes);

    if (_links && _links.length > 0) {
      var filtered = nodes.filter(function (_n) {
        var anyLink = _links.some(function (_l) {
          return _l.source === _n.key || _l.target === _n.key;
        });

        return !!anyLink;
      });
      return filtered;
    } else return nodes;
  }

  function createLinkOpacityFn(_hasSelections) {
    if (_hasSelections) return function (d) {
      return d.$.highlighted || d.$.selected ? 0.9 : 0.3;
    };
    return function (d) {
      return d.$.highlighted ? 0.9 : 0.5;
    };
  }

  function createNodeOpacityFn(_hasSelections) {
    var nodeDecoration = function nodeDecoration(d) {
      // A node is decorated (highlighted/selected) if its datum (Tuple)
      // is decorated or one of its link is decorated
      var decoration = {
        highlighted: d.$.highlighted,
        selected: d.$.selected
      };
      [d.sourceLinks, d.targetLinks].forEach(function (links) {
        // Stop the loop if both highlighted and selected are set to true
        for (var i = 0; !(decoration.highlighted && decoration.selected) && i < links.length; ++i) {
          var source = links[i].$;
          decoration.highlighted = decoration.highlighted || source.highlighted;
          decoration.selected = decoration.selected || source.selected;
        }
      });
      return decoration;
    };

    if (_hasSelections) return function (d) {
      var decoration = nodeDecoration(d);
      return decoration.highlighted || decoration.selected ? 1 : 0.4;
    };
    return function (d) {
      var decoration = nodeDecoration(d);
      return decoration.highlighted ? 1 : 0.8;
    };
  }

  var _default = /*#__PURE__*/function (_RenderBase) {
    _inherits(_default, _RenderBase);

    var _super = _createSuper(_default);

    function _default() {
      var _this;

      _classCallCheck(this, _default);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _defineProperty(_assertThisInitialized(_this), "_renderId", void 0);

      _defineProperty(_assertThisInitialized(_this), "_domains", void 0);

      _defineProperty(_assertThisInitialized(_this), "_colorsFn", void 0);

      _defineProperty(_assertThisInitialized(_this), "_links", void 0);

      _defineProperty(_assertThisInitialized(_this), "_nodes", void 0);

      return _this;
    }

    _createClass(_default, [{
      key: "create",
      value: function create(_parent) {
        this.meta.dataLimit = DATA_POINTS_LIMIT; // Create an svg canvas with groups for nodes, links and labels.

        var svg = d3.select(_parent).append("svg").attr("width", "100%").attr("height", "100%");
        svg.append("g").attr("class", "chartContent links").attr("fill", "none");
        svg.append("g").attr("class", "chartContent nodes");
        svg.append("g").attr("class", "chartContent labels"); // A pesudo uuid - see https://stackoverflow.com/questions/105034/create-guid-uuid-in-javascript/2117523#2117523
        // At the moment, there seems to be no instanceid = dynamic from renderer, uniquely identifies the bundle instance with customvis.
        // Was considering of using such instanceid as unique id as part of the id of the gradient.

        this._renderId = ("" + 1e7 + -1e3 + -4e3 + -8e3 + -1e11).replace(/1|0/g, function () {
          return ( Math.random() * 16).toString(16);
        }); // Return void so that in update(), _info.node will be the container HTML Element as we
        // need to get clientWidth/clientHeight for all browser as for Firefox, a SVG node
        // clientWidth/clientHeight prop always returns zero!
        // (see https://stackoverflow.com/questions/13122790/how-to-get-svg-element-dimensions-in-firefox)
      }
    }, {
      key: "updateProperty",
      value: function updateProperty(_name, _value) {
        switch (_name) {
          case "label.show":
            this.properties.setActive("label.font", _value);
            this.properties.setActive("label.color", _value);
            this.properties.setActive("label.yAlign", _value);
            this.properties.setActive("label.wrapLongLabel", _value);
            this.properties.setActive("label.hideCollidedLabel", _value);
            this.properties.setActive("label.hideCollidedLabelIncludeNodes", _value && this.properties.get("label.hideCollidedLabel"));
            break;

          case "label.hideCollidedLabel":
            this.properties.setActive("label.hideCollidedLabelIncludeNodes", _value);
            break;

          case "linkFillType":
            this.properties.setActive("linkFillSolidColor", this.properties.get("linkFillType") === "solid");
            break;

          case "node.border.width":
            this.properties.setActive("node.border.color", _value > 0);
        }
      }
    }, {
      key: "hitTest",
      value: function hitTest(_elem) {
        var elem = d3.select(_elem);
        var data = elem.empty() ? null : elem.datum();
        return data && data.$; // the underlying vipr data is bound to "$" of datum.
      }
    }, {
      key: "update",
      value: function update(_info) {
        // Retrieve svg node (see `create`) and determine size.
        var svg = d3.select(_info.node).select("svg");
        var reason = _info.reason;

        if (reason.data || reason.properties || reason.size) {
          // width and height from container parent node - needed for firefox.
          var width = _info.node.clientWidth;
          var height = _info.node.clientHeight - 2 * Y_BUFFER; // plus adjustment to give gaps for labels in extreme case.

          var data = _info.data; // If there is no data, remove everything from the canvas and exit.

          if (!data) {
            svg.selectAll("g>*").remove();
            return;
          } // Generate data structure for sankey. Note the prefix that is used for the source
          // and target node.


          this._buildNodesAndLinks(_info); // this may rebuild this._links and this._nodes if required.


          var links = this._links;
          var nodes = this._nodes;

          if (links.length === 0 || nodes.length === 0) // equivalent to no data, due to options.
            {
              svg.selectAll("g>*").remove();
              return;
            }

          var nodeBorderWidth = _info.props.get("node.border.width"); // Generate sankey data from the data structures.


          var createSankey = Sankey().nodeId(function (n) {
            return n.key;
          }).nodeWidth(_info.props.get("node.width")).nodeAlign(getSankeyAlignmentFn(_info.props.get("node.alignment"))).nodePadding(_info.props.get("node.padding")).size([width - nodeBorderWidth * 2, height - nodeBorderWidth * 2]); // prevent node border from being cut off by chart container

          svg.selectAll(".chartContent").attr("transform", "translate(".concat(nodeBorderWidth, ", ").concat(nodeBorderWidth, ")"));
          createSankey({
            nodes: nodes,
            links: links
          }); // Create color function

          this._colorsFn = this._createColorFn(_info); // Update nodes.

          this._renderNodes(_info, svg, nodes); // // Update links that connect the nodes.


          this._renderLinks(_info, svg, links); // Update labels for each node.


          this._renderLabels(_info, svg, width, nodes, links);
        } // Decoration for highlight / selection on links


        this._decorate(svg, _info.data.hasSelections);
      }
    }, {
      key: "_buildNodesAndLinks",
      value: function _buildNodesAndLinks(_info) {
        // We only process and rebuild this._links and this._nodes if required. (i.e. skipping decoration/resize events)
        // TODO: fine tune to rebuild if we can work out the exact defails of _info.reason.properties.
        if (_info.reason.data || _info.reason.properties) {
          var data = _info.data; // We CANNOT use tuple's key to drive Sankey APIs, as the key is unique per column
          // and we cannot correctly "merge" two column data together show multiple levels.
          // Therefore we NEED to use captions.

          var links = this._dataLinks(data, _info.props.get("algorithm.considerNegatives"));

          var fromTuples = data.cols[FROM].tuples;
          var fromNodes = fromTuples.map(function (t) {
            return {
              key: "N:".concat(t.caption),
              $: t // bound vipr tuple - for hittest

            };
          });
          var toTuples = data.cols[TO].tuples;
          var toNodes = toTuples.map(function (t) {
            return {
              key: "N:".concat(t.caption),
              $: t // bound vipr tuple - for hittest

            };
          }); // we need to "merge" To and From nodes here via captions

          var nodes = mergeNodes(fromNodes, toNodes); // Now update this._domains due to change of this._nodes.
          // build domain before before filtering of nodes, to have consistent color per category, e.g. for small multiples.

          this._domains = buildLabelDomains(nodes); // color domains based on unique values from both from and to columns.
          // TODO: we may want to handle our own palette (as a property) and create our own colors function.
          // Not sure how to achieve that we need to have a single categorical palette for 2 slots - limited by current
          // customvis support. So we choose to use the predefined set of colours from Carbon palette.
          // We may filter the nodes rendering based on values available from links.

          if (_info.props.get("suppressUnused")) {
            nodes = filterNodes(nodes, links);
          } // update member _links and _nodes on renderer


          this._links = links;
          this._nodes = nodes;
        }
      }
    }, {
      key: "_createColorFn",
      value: function _createColorFn(_info) {
        var _this2 = this;

        var palette = _info.props.get("color");

        var colors = palette.source.value._resolver.colors.map(function (e) {
          return e.toString();
        });

        if (_info.props.get("node.level-color")) {
          var maxLevel = Math.max.apply(Math, _toConsumableArray(this._nodes.map(function (e) {
            return e.layer;
          })));
          var levels = [];

          for (var i = 0; i <= maxLevel; i++) {
            levels.push(i);
          }

          return function (_d) {
            return d3.scaleOrdinal(colors).domain(levels)(_d.layer.toString()).toString();
          };
        } else {
          return function (_d) {
            return d3.scaleOrdinal(colors).domain(_this2._domains)(_d.$.caption).toString();
          };
        }
      }
    }, {
      key: "_decorate",
      value: function _decorate(_svg, _hasSelections) {
        var linkOpacity = createLinkOpacityFn(_hasSelections);
        var nodeOpacity = createNodeOpacityFn(_hasSelections);

        _svg.select(".links").selectAll("g").attr("stroke-opacity", linkOpacity);

        _svg.select(".nodes").selectAll("rect").attr("fill-opacity", nodeOpacity);

        _svg.select(".links").selectAll("g").filter(function (_d) {
          return _d.$.selected || _d.$.highlighted;
        }).raise();
      }
    }, {
      key: "_renderNodes",
      value: function _renderNodes(_info, _svg, _nodes) {
        var _this3 = this;

        _svg.select(".nodes").selectAll("rect").data(_nodes, keyFn).join("rect").style("stroke-width", _info.props.get("node.border.width")).style("stroke", _info.props.get("node.border.color")).attr("x", function (d) {
          return d.x0;
        }).attr("y", function (d) {
          return d.y0;
        }).attr("height", function (d) {
          return Math.max(0, d.y1 - d.y0);
        }).attr("width", function (d) {
          return d.x1 - d.x0;
        }).attr("fill", function (d) {
          return _this3._colorsFn(d);
        });
      }
    }, {
      key: "_renderLinks",
      value: function _renderLinks(_info, _svg, _links) {
        var _this4 = this;

        var linkFillType = _info.props.get("linkFillType");

        var strokeFn = function strokeFn(d, i) {
          switch (linkFillType) {
            case "from":
              return _this4._colorsFn(d.source);

            case "to":
              return _this4._colorsFn(d.target);

            case "solid":
              return _info.props.get("linkFillSolidColor").toString();

            default:
              return "url(#".concat(_this4._gradient(d, i), ")");
          }
        };

        _svg.select(".links").selectAll("g").data(_links, keyFn).join(function (enter) {
          return enter.append("g").call(_this4._createLinks.bind(_this4));
        }).call(function (g) // 'g' represents a link with a path and linearGradient
        {
          if (linkFillType === "gradient") {
            g.select("linearGradient").attr("x1", function (d) {
              return d.source.x1;
            }).attr("x2", function (d) {
              return d.target.x0;
            });
            g.select("stop:nth-of-type(1)").attr("stop-color", function (d) {
              return _this4._colorsFn(d.source);
            });
            g.select("stop:nth-of-type(2)").attr("stop-color", function (d) {
              return _this4._colorsFn(d.target);
            });
          }

          g.select("path").attr("d", sankeyLinkHorizontal()).attr("stroke-width", function (d) {
            return Math.max(1, d.width);
          }).attr("stroke", strokeFn); // either a predefined gradient or use solid fill.
        });
      }
    }, {
      key: "_renderLabels",
      value: function _renderLabels(_info, _svg, _width, _nodes, _links) {
        var showLabel = _info.props.get("label.show");

        var wrapLongLabel = _info.props.get("label.wrapLongLabel");

        var hideCollidedLabel = _info.props.get("label.hideCollidedLabel");

        var hideCollidedLabelIncludeNodes = _info.props.get("label.hideCollidedLabelIncludeNodes");

        var labelYAlign = _info.props.get("label.yAlign");

        var labelYFn = function labelYFn(_d) {
          switch (labelYAlign) {
            case "top":
              return _d.y0 + Y_BUFFER;

            case "bottom":
              return _d.y1 - Y_BUFFER;

            default:
              return (_d.y1 + _d.y0) / 2 + Y_BUFFER;
          }
        };

        var labelFont = _info.props.get("label.font");

        _svg.select(".labels").style("font-size", labelFont.size ? labelFont.size.toString() : null).style("font-family", labelFont.family ? labelFont.family.toString() : null).style("font-style", labelFont.style ? labelFont.style.toString() : null).style("font-weight", labelFont.weight ? labelFont.weight.toString() : null).selectAll("text").data(_nodes, keyFn).join("text").style("fill", _info.props.get("label.color").toString()).attr("x", function (d) {
          return d.x0 < _width / 2 ? d.x1 + 6 : d.x0 - 6;
        }).attr("y", labelYFn).attr("dy", "0.35em").attr("text-anchor", function (d) {
          return d.x0 < _width / 2 ? "start" : "end";
        }).attr("font-weight", function (d) {
          return d.$.selected ? "bold" : "normal";
        }).attr("visibility", showLabel ? "visible" : "hidden").text(function (d) {
          return d.$.caption;
        }); // Extra label layout processing:


        if (showLabel) {
          if (wrapLongLabel) this._wrapLabels(_svg, _links);
          if (hideCollidedLabel) this._hideCollidedLabels(_svg, hideCollidedLabelIncludeNodes);else // reset visibiilty
            _svg.select(".labels").selectAll("text").attr("visibility", "visible");
        }
      }
    }, {
      key: "_dataLinks",
      value: function _dataLinks(_data, _considerNegatives) {
        // Generate data structure for sankey. Note the prefix that is used for the source
        // and target node. This is done to prevent circular links in case the FROM and TO
        // columns are mapped to the same data item.
        // We CANNOT use tuple's key to drive Sankey APIs, as the key is unique per column
        // and we cannot correctly "merge" two column data together show multiple levels.
        // Therefore we NEED to use captions.
        var links = _data.rows.map(function (_row) {
          return {
            source: "N:".concat(_row.tuple(FROM).caption),
            target: "N:".concat(_row.tuple(TO).caption),
            value: _row.value(WEIGHT),
            key: _row.key,
            $: _row // bound vipr datapoint - for hittest

          };
        }); // Option


        if (_considerNegatives) {
          links = links.map(function (_d) {
            if (_d.value < 0) {
              return {
                source: _d.target,
                target: _d.source,
                value: -1 * _d.value,
                key: _d.key,
                $: _d.$,
                // bound vipr datapoint - for hittest
                _negated: true // special flag to help extra data processing if needed

              };
            } else return _d;
          });
        } // Skip negative value - as the Sankey cannot show negative values - Sankey is not designed for that.
        // Skip duplicated links as we DO NOT/CANNOT "aggregate" the values - simply keep first
        // non-"made positive" link.


        links = links.filter(function (_d) {
          return _d.value >= 0;
        }); // skip negative values

        if (links.length > 1) links = links.reduce(function (_accum, _curr, _currentIndex) {
          var links = _accum;
          var i = -1;
          links.some(function (_e, _idx) {
            if (_e.source === _curr.source && _e.target === _curr.target) {
              i = _idx;
              return true;
            }

            return false;
          });
          if (i < 0) links.push(_curr); // add if unfound
          else if (links[i]._negated && !_curr._negated) // found "made" postitive and _curr is not "made" positive
              links[i] = _curr; // Prefer normal to "made positive" link

          return links;
        }, []); // TODO: To consider Circular linkings between nodes, and "break" the link.

        return links;
      }
    }, {
      key: "_gradient",
      value: function _gradient(d, _i) {
        var keys = [this._domains.indexOf(d.source.$.caption), this._domains.indexOf(d.target.$.caption)].sort();
        return "grad_".concat(this._renderId, "_").concat(keys[0], "_").concat(keys[1]);
      }
    }, {
      key: "_createLinks",
      value: function _createLinks(_selection) {
        var _this5 = this;

        // Create a linear gradient and a path.
        _selection.append("linearGradient").attr("gradientUnits", "userSpaceOnUse").attr("id", function (_, i) {
          return _this5._gradient(_, i);
        }).call(function (g) {
          return g.append("stop").attr("offset", "0%");
        }).call(function (g) {
          return g.append("stop").attr("offset", "100%");
        }); // TODO: optimise to create/remove gradient fills instead of predefining all, whether being used or not.


        _selection.append("path");
      } // Labels helpers:

    }, {
      key: "_hideCollidedLabels",
      value: function _hideCollidedLabels(_svg, _includeNodesCheck) {
        var tree = new RBush();

        if (_includeNodesCheck) {
          _svg.select(".nodes").selectAll("rect").each(function (_d, _i, _n) {
            var a = _n[_i];
            var bbox = a.getBoundingClientRect();
            tree.insert({
              minX: bbox.left,
              minY: bbox.top,
              maxX: bbox.right,
              maxY: bbox.bottom
            });
          });
        }

        _svg.select(".labels").selectAll("text").each(function (_d, _i, _n) {
          var a = _n[_i];
          var bbox = a.getBoundingClientRect();
          var treeItem = {
            minX: bbox.left,
            minY: bbox.top,
            maxX: bbox.right,
            maxY: bbox.bottom
          }; // check in the tree to see if we overlap

          var result = tree.search(treeItem);

          if (result === null || result.length === 0) {
            // not in the tree - this label doesn't overlap
            tree.insert(treeItem);
            a.setAttribute("visibility", "visible");
          } else a.setAttribute("visibility", "hidden");
        });
      }
    }, {
      key: "_wrapLabels",
      value: function _wrapLabels(_svg, _links) {
        var gapMinWidth = this._getMinimumGapWidth(_links);

        _svg.select(".labels").selectAll("text").call(this._wrap, gapMinWidth * 4 / 7); // a factor to keep it smaller than gap width - particularly useful when in small multiple mode.

      }
    }, {
      key: "_getMinimumGapWidth",
      value: function _getMinimumGapWidth(_links) {
        var w = Number.MAX_VALUE;

        for (var i = 0; i < _links.length; ++i) {
          var l = _links[i];
          w = Math.min(w, l.target.x0 - l.source.x1);
        }

        return w;
      }
    }, {
      key: "_wrap",
      value: function _wrap(text, width) {
        // logic idea from https://bl.ocks.org/mbostock/7555321 to wrap text.
        text.each(function () {
          var text = d3.select(this),
              words = text.text().split(/\s+/).reverse(),
              lineHeight = 1.1,
              // ems
          y = text.attr("y"),
              x = text.attr("x"),
              dy = parseFloat(text.attr("dy"));
          var word,
              line = [],
              lineNumber = 0,
              tspan = text.text("").append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em"); // eslint-disable-next-line no-cond-assign

          while (word = words.pop()) {
            line.push(word);
            tspan.text(line.join(" "));

            if (tspan.node().getComputedTextLength() > width) {
              line.pop();

              if (line.length > 0) {
                tspan.text(line.join(" "));
                line = [word];
                tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
              } else {
                line = [];
                if (words.length > 0) tspan = text.append("tspan").attr("x", x).attr("y", y).attr("dy", ++lineNumber * lineHeight + dy + "em").text("");
              }
            }
          }
        });
      }
    }]);

    return _default;
  }(st);

  return _default;

});
