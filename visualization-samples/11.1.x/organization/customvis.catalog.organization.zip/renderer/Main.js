define(['require', 'https://d3js.org/d3.v5.min.js'], function (requirejs, d3) { 'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }

    return obj;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;

    try {
      Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized(self);
  }

  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();

    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
          result;

      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;

        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }

      return _possibleConstructorReturn(this, result);
    };
  }

  var e=function(){function t(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}return t.prototype.getName=function(){return this.name},t.prototype.getSlot=function(){return this.slot},t.prototype.getAttributes=function(){return this.attributes},t.slotLimit=function(e,n){return new t("limit",e).attr("n",n)},t.dataLimit=function(e){return new t("limit").attr("n",e)},t.prototype.attr=function(t,e){return this.attributes.set(t,e),this},t}(),n=function(t,e){return (n=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e;}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n]);})(t,e)};
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0

  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.

  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */function r(t,e){function r(){this.constructor=t;}n(t,e),t.prototype=null===e?Object.create(e):(r.prototype=e.prototype,new r);}function o(t,e,n){return t.getDecoration(e,n)}function i(t){return t.hasDecoration("hasSelection")?o(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}var u,s=function(){function t(t,e){this.min=t,this.max=e;}return t.prototype.asArray=function(){return [this.min,this.max]},t.empty=new t(0,0),t}(),a=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e.fromRS=function(t){return new s(t.min,t.max)},e}(s),l=function(){function t(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";var n=t.getItems()||[];this.segments=n.map((function(t){return new p(t)}));}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),c=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(l),h=function(){function t(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),p=function(t){function e(e){return t.call(this,e)||this}return r(e,t),e}(h),f=new(function(){function t(){}return t.prototype.format=function(t){return t?t.toString():""},t}());!function(t){t.label="label",t.data="data";}(u||(u={}));var g=function(){function t(t,e,n,r,o){this.source=t,this.tuples=e,this.segments=n,this.domain=r,this.caption=o;var i=t.dataItems||[],u=i.length>0?i[0]:null,s=u&&u.asCont();s?(this._labelFormatter=s.getFormatter("label")||f,this._dataFormatter=s.getFormatter("data")||f):this._labelFormatter=this._dataFormatter=f;}return Object.defineProperty(t.prototype,"mapped",{get:function(){return this.source.mapped},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"dataType",{get:function(){var t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"},enumerable:!0,configurable:!0}),t.prototype.format=function(t,e){return function(t,e){return t.format(e)}(e===u.data?this._dataFormatter:this._labelFormatter,t)},t}(),d=function(t){function e(e,n,r,o,i){return t.call(this,e,n,r,o,i)||this}return r(e,t),e}(g),m=function(){function t(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t.prototype.tuple=function(t){var e=this._getSlot(t);if(!e||0===e.tuples.length)return null;var n=this.source.get(e.source);if(!n)return null;var r=n.asCat();return r?e.tuples[r.index]:null},t.prototype.value=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);if(!n)return null;var r=n.asCont();return r&&"numeric"===r.valueType?r.value:null},t.prototype.caption=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);return n&&n.getCaption("data")||""},t.prototype._getSlot=function(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null},t}(),y=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(m),v=function(){function t(t,e,n){var r=this;this.source=t,this.rows=t.dataPoints.map((function(t){return new y(t,r)})),this.cols=e,this.slotMap=n;}return t.filterRows=function(t,e,n){return t.filter((function(t){var r=t.tuple(e);return !!r&&r.key===n}))},Object.defineProperty(t.prototype,"hasSelections",{get:function(){return i(this.source)},enumerable:!0,configurable:!0}),t}(),_=function(t){function e(e,n,r){return t.call(this,e,n,r)||this}return r(e,t),e}(v);function b(t){var e=new Map,n=t.getSlots().map((function(t,n){var r=[],o=[],i=s.empty,u="";if(t.isMapped()){var l=t.getDataItem(0);if(u=l.getCaption("label"),"cat"===l.getRSType())r=l.getTuples().map((function(t,e){return new c(t,e)})),o=l.getItemClassSet(0).getItemClasses().map((function(t){return new p(t)}));else i=a.fromRS(l.getDomain()),o.push(new p(l.getItemClass()));}var h=new d(t,r,o,i,u);return e.set(t.name,h),h}));return new _(t,n,e)}function w(t){return t<0?0:t>255?255:Math.floor(t)}var C=function(){function t(t,e,n,r){var o;this.r=w(t),this.g=w(e),this.b=w(n),this.a=(o=r)<0?0:o>1?1:o;}return t.fromObject=function(e){return new t(e.r,e.g,e.b,void 0===e.a?1:e.a)},t.prototype.toString=function(){return 1===this.a?"rgb("+this.r+","+this.g+","+this.b+")":"rgba("+this.r+","+this.g+","+this.b+","+this.a+")"},t}();function S(t,e){var n=null;if(t instanceof m)n=t.source.getDataSet(e);else{var r=t.source.getDataItem(e);n=r&&r.getDataSet(e);}return !!n&&i(n)}var P=function(t){return "rgba("+t.r+","+t.g+","+t.b+",0.4)"},j=function(t){return "rgba("+Math.round(.7*t.r)+","+Math.round(.7*t.g)+","+Math.round(.7*t.b)+","+t.a+")"},x=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColor=function(t){return t?C.fromObject(this.source.getTupleColor(t.source,-1)):C.fromObject(this.source.getColor(null))},t.prototype._getTuple=function(t){if(t instanceof l)return t;var e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null},t.prototype.getFillColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),!t.selected&&S(t,this._dataContext)?P(e):e.toString()},t.prototype.getOutlineColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&S(t,this._dataContext)?j(e):null},t}(),O=function(t,e,n){this.color=t,this.at=e,this.value=n;};function I(t){return t.map((function(t){return new O(C.fromObject(t.color),t.at,t.value)}))}var D=function(){function t(t,e,n){this.source=t,this._slot=e,this._dataContext=n,this.stops=I(t.stops),this.aligned=I(t.aligned),this.interpolate=t.interpolate;}return t.prototype.getColor=function(t){return C.fromObject(this.source.getColor(t))},t.prototype.getFillColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return !t.selected&&S(t,this._dataContext)?P(n):n.toString()},t.prototype.getOutlineColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return t.highlighted||t.selected&&S(t,this._dataContext)?j(n):null},t}(),E=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColorStops=function(t){var e=t?t.source.getDataItem(0):null,n=e&&e.asCont(),r=n?n.getDomain(null):null,o=this.source.getColorStops(n,r),i=t?t.source.name:null;return new D(o,i,this._dataContext)},t.prototype._fetchColorStops=function(t){var e=t.source.getDataSet(this._dataContext),n=this.slot||this._slotResolver(t.dataSet,this.source.name),r=n?e.getSlot(n):null,o=r?r.getDataItem(0):null,i=o?o.asCont():null;if(this.source.dirty||!this._cachedStops||i!==this._lastDataItem){var u=i?i.getDomain(null):null,s=this.source.getColorStops(i,u);this._cachedStops=new D(s,r&&r.name,this._dataContext),this._lastDataItem=i;}return this._cachedStops},t.prototype.getFillColor=function(t){return this._fetchColorStops(t).getFillColor(t)},t.prototype.getOutlineColor=function(t){return this._fetchColorStops(t).getOutlineColor(t)},t}(),T=function(t){function e(e){var n=t.call(this,e.r,e.g,e.b,e.a)||this;return n._color=e,n}return r(e,t),e.prototype.getRed=function(){return this.r},e.prototype.getGreen=function(){return this.g},e.prototype.getBlue=function(){return this.b},e.prototype.getAlpha=function(){return this.a},e}(C),R=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:function(){return 0},getMax:function(){return 0},isEmpty:function(){return !0},isExplicit:function(){return !1}}),F=function(){function t(t,e,n,r,o,i){this.caption=t,this.color=e,this.shape=n,this.selected=r,this.highlighted=o,this.ref=i;}return t.prototype.getCaption=function(){return this.caption},t.prototype.getColor=function(){return this.color?new T(this.color):null},t.prototype.getShape=function(){return this.shape},t.prototype.isSelected=function(){return this.selected},t.prototype.isHighlighted=function(){return this.highlighted},t.prototype.getRef=function(){return this.ref},t}(),M=function(){function t(t,e,n,r,o,i){this.type=t,this.channel=e,this.slot=n,this.caption=r,this.subCaption=o,this.ref=i;}return t.prototype.getRSType=function(){return this.type},t.prototype.getChannel=function(){return this.channel},t.prototype.getSlot=function(){return this.slot},t.prototype.getCaption=function(){return this.caption},t.prototype.getSubCaption=function(){return this.subCaption},t.prototype.getRef=function(){return this.ref},t}(),L=function(t){function e(e,n,r,i,u){var s=this,a=n&&n.source,l=a&&a.name,c=a&&a.getDataItem(0),h=c&&c.asCat();s=t.call(this,"cat",e,l,r,"",h)||this;var p=h?h.tuples:[];return s.entries=p.map((function(t){var e=t.getCaption("label")||"",n=u&&u.source.getTupleColor(t,-1),r=o(t,"selected",!1),s=o(t,"highlighted",!1);return new F(e,n?C.fromObject(n):null,i,r,s,t)})),s}return r(e,t),e.prototype.getEntries=function(){return this.entries},e}(M),A=function(t){function e(e,n,r,o){var i=this,u=n&&n.source,s=u&&u.name,a=u&&u.getDataItem(0),l=a&&a.asCont();if((i=t.call(this,"cont",e,s,r,"",l)||this).domain=l?l.getDomain(null):R,o&&"color"===e){var c=o.source.getColorStops(l,null);i.stops=c.stops,i.interpolate=c.interpolate;}else i.stops=null,i.interpolate=!1;return i}return r(e,t),e.prototype.getDomain=function(){return this.domain},e.prototype.getInterpolate=function(){return this.interpolate},e.prototype.getStops=function(){return this.stops},e}(M);function z(t,e,n,r){if(!t)return [];var o=new Map,i=new Map;e.palettes.forEach((function(e){var n=e.slot||r&&r(t,e.source.name);n&&(e instanceof x?o.set(n,e):e instanceof E&&i.set(n,e));}));var u=[];return t.cols.forEach((function(t){var e=t.source;if(e.mapped){var r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;var s=o.get(e.name);s&&u.push(new L("color",t,t.caption,n.legendShape,s));break;case"cont":if(-1!==e.channels.indexOf("color")){var a=i.get(e.name);a&&u.push(new A("color",t,t.caption,a));}-1!==e.channels.indexOf("size")&&u.push(new A("size",t,t.caption,null));}}})),u}var N,k=function(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;};!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(N||(N={}));var H,U,V=function(){function t(t,e){this.value=t,this.unit=e;}return t.fromObject=function(e){return new t(e.value,function(t){switch(t){case"em":return N.Em;case"%":return N.Percentage;case"cm":return N.Centimeter;case"mm":return N.Millimeter;case"in":return N.Inch;case"pc":return N.Pica;case"pt":return N.Point;case"px":return N.Pixel;default:throw new Error("Invalid length unit '"+t+"' specified")}}(e.unit))},t.prototype.toString=function(){return ""+this.value+this.unit},t}();!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));var q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){var e=[];if(t)for(var n=0,r=t.length;n<r;++n){var o=t[n],i=q.test(o);e.push(i?'"'+o+'"':o);}return e.join(", ")}var J=function(){function t(t,e,n,r){this.family=t,this.size=e,this.style=n,this.weight=r;}return t.fromObject=function(e){return new t(e.family||null,e.size?V.fromObject(e.size):null,e.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error("Invalid font style '"+t+"' specified")}}(e.style):null,void 0!==e.weight&&null!==e.weight?e.weight:null)},t.prototype.toString=function(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){var t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){var e,n=[],r=G(t.family);return r.length>0&&n.push("font-family: "+r+";"),(r=t.size?t.size.toString():"").length>0&&n.push("font-size: "+r+";"),(r=(e=t.style)?e.toString():"").length>0&&n.push("font-style: "+r+";"),(r=K(t.weight)).length>0&&n.push("font-weight: "+r+";"),n.join(" ")}(this)},t}(),Q=function(){function t(t,e,n){var r=new Map;null!==t&&t.forEach((function(t,o){if("palette"===t.type){var i=t;switch(i.paletteType){case"cat":r.set(o,new x(i,e,n));break;case"cont":r.set(o,new E(i,e,n));}}})),this.source=t,this.palettes=r;}return t.prototype.get=function(t){return this._getValue(t,!1)},t.prototype.peek=function(t){return this._getValue(t,!0)},t.prototype._getValue=function(t,e){var n=this.source&&this.source.get(t);if(!n)return null;switch(n.type){case"string":case"number":case"boolean":case"enum":return e?n.peek:n.value;case"length":var r=e?n.peek:n.value;return r?V.fromObject(r):null;case"font":var o=e?n.peek:n.value;return o?J.fromObject(o):null;case"color":var i=e?n.peek:n.value;return i?C.fromObject(i):null;case"palette":return this.palettes.get(t)||null;default:return null}},t.prototype.isActive=function(t){var e=this.source&&this.source.get(t);return !!e&&e.active},t.prototype.setActive=function(t,e){var n=this.source&&this.source.get(t);n&&n.setActive(e);},t.prototype.isDirty=function(t){var e=this.source&&this.source.get(t);return !!e&&e.dirty},t}();var W=setTimeout;function X(t){return Boolean(t&&void 0!==t.length)}function Y(){}function Z(t){if(!(this instanceof Z))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],ot(t,this);}function $(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,Z._immediateFn((function(){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var r;try{r=n(t._value);}catch(t){return void et(e.promise,t)}tt(e.promise,r);}else(1===t._state?tt:et)(e.promise,t._value);}))):t._deferreds.push(e);}function tt(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var n=e.then;if(e instanceof Z)return t._state=3,t._value=e,void nt(t);if("function"==typeof n)return void ot((r=n,o=e,function(){r.apply(o,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){et(t,e);}var r,o;}function et(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&Z._immediateFn((function(){t._handled||Z._unhandledRejectionFn(t._value);}));for(var e=0,n=t._deferreds.length;e<n;e++)$(t,t._deferreds[e]);t._deferreds=null;}function rt(t,e,n){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=n;}function ot(t,e){var n=!1;try{t((function(t){n||(n=!0,tt(e,t));}),(function(t){n||(n=!0,et(e,t));}));}catch(t){if(n)return;n=!0,et(e,t);}}Z.prototype.catch=function(t){return this.then(null,t)},Z.prototype.then=function(t,e){var n=new this.constructor(Y);return $(this,new rt(t,e,n)),n},Z.prototype.finally=function(t){var e=this.constructor;return this.then((function(n){return e.resolve(t()).then((function(){return n}))}),(function(n){return e.resolve(t()).then((function(){return e.reject(n)}))}))},Z.all=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var o=r.length;function i(t,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var s=u.then;if("function"==typeof s)return void s.call(u,(function(e){i(t,e);}),n)}r[t]=u,0==--o&&e(r);}catch(t){n(t);}}for(var u=0;u<r.length;u++)i(u,r[u]);}))},Z.resolve=function(t){return t&&"object"==typeof t&&t.constructor===Z?t:new Z((function(e){e(t);}))},Z.reject=function(t){return new Z((function(e,n){n(t);}))},Z.race=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.race accepts an array"));for(var r=0,o=t.length;r<o;r++)Z.resolve(t[r]).then(e,n);}))},Z._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){W(t,0);},Z._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};var it=function(t,e,n,r){this.data=t,this.decorations=e,this.properties=n,this.size=r;},ut=function(t,e,n,r,o){this.reason=t,this.data=e,this.node=n,this.props=r,this.locale=o;};var st=function(){function n(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new k;}return n.prototype.init=function(t,e){var n=this,r=t.surface.appendChild(document.createElement("div"));r.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),r.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,Z.resolve(this.create(r)).then((function(o){n._elem=o||r,t.properties.forEach((function(t,e){return n.updateProperty(e,t.value)})),e.complete();})).catch((function(t){e.fail(t);}));},n.prototype.destroy=function(){},n.prototype.getPropertyApi=function(){return null},n.prototype.setData=function(t){t&&t.dataSets&&t.dataSets[0]?this._data=b(t.dataSets[0]):this._data=null;},n.prototype.setProperty=function(t,e){this.updateProperty(t,this.properties.peek(t));},n.prototype.getBlockingRequests=function(){return null},n.prototype.render=function(t,e,n){if(!this._elem)return n.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return n.complete(null,null,null),null;try{var r=this.update(new ut(function(t){return new it(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));Z.resolve(r).then((function(){return n.complete(null,null,null)})).catch(n.error);}catch(t){n.error(t);}return null},n.prototype.getEncodings=function(){return this._data?this.updateLegend(this._data):[]},n.prototype.getCapabilities=function(){var t=[];return this.meta.slotLimits.forEach((function(n,r){t.push(e.slotLimit(r,n));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t},n.prototype.getInteractivity=function(){return null},n.prototype.getVisCoordinate=function(t,e){return e},n.prototype.getRegionAtPoint=function(t,e){return null},n.prototype.getItemsAtPoint=function(t,e,n){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;var r=t,o=document.elementFromPoint(r.x,r.y),i=this.hitTest(o,r,e);return i&&i.source?[i.source]:[]},n.prototype.getItemsInPolygon=function(t,e){return []},n.prototype.getAxisItemsAtPoint=function(t,e,n){return []},n.prototype.getState=function(){return null},n.prototype.setState=function(t){},n.prototype.loadCss=function(t){var e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);},n.prototype.toUrl=function(e){return requirejs.toUrl(e)},n.prototype.update=function(t){},n.prototype.create=function(t){},n.prototype.updateProperty=function(t,e){},n.prototype.updateLegend=function(t){return z(t,this.properties,this.meta,this._slotResolver)},n.prototype.getSlotForPalette=function(t,e){return null},n.prototype.hitTest=function(t,e,n){var r=t&&t.__data__;return r&&r.source?r:null},n.prototype.nls=function(t){return this._nls&&this._nls.get(t)||""},n}();

  var NODES = 0,
      PARENT = 1,
      COLOR = 2; // Slot indices
  // Defaults

  var DEFAULT_WIDTH = 330;
  var DEFAULT_HEIGHT = 140;
  var DEFAULT_BORDER_WIDTH = 2;
  var DEFAULT_BORDER_RADIUS = 5;
  var DEFAULT_LINE_WIDTH = 5;
  var DEFAULT_PADDING = "3%";
  var DEFAULT_ANIMATION_TIME = 600;
  var MINIMUM_LIGHTNESS_DIFFERENCE = 50;
  var GENERATION_SIBLING_SEPARATION_FACTOR = 1.3;
  var GENERATION_COUSIN_SEPARATION_FACTOR = 1.6;
  var HORIZONTAL_ANCESTRAL_SEPARATION_FACTOR = 1.3;
  var VERTICAL_ANCESTRAL_SEPARATION_FACTOR = 2;
  var INITIAL_MINIMUM_THUMBNAIL_ZOOM = 0.03;
  var INITIAL_MINIMUM_ZOOM = 0.1;
  var INITIAL_MAXIMUM_ZOOM = 1; // Regex that matches hex color definitions.
  //     #9c9c9c     (#RRGGBB)
  //     #9c9c9cff   (#RRGGBBAA)

  var reHEX = /^\s*#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})[0-9a-fA-F]{0,2}\s*$/; // Regex that matches CSS rgb(a) statements.
  //     rgb ( 0, 255, 99 )
  //     rgba( 255, 99, 0, 0.1 )

  var reRGBA = /^\s*rgba?\s*\(\s*(\d+\%?)\s*,\s*(\d+\%?)\s*,\s*(\d+\%?)\s*(?:,\s*(\d+(?:\.\d+)?\%?)\s*)?\)\s*/;
  var COLOR_R = 1;
  var COLOR_G = 2;
  var COLOR_B = 3;
  var reButtonClass = /\bnode-button-circle\b/;

  function createFontString(_font) {
    var fontString = "";
    if (!_font) return fontString;
    if (_font.family && _font.family.length) fontString += "font-family:" + _font.family.join(", ") + ";";
    if (_font.size) fontString += "font-size:" + _font.size + ";";
    if (_font.style) fontString += "font-style:" + _font.style + ";";
    if (_font.weight) fontString += "font-weight:" + _font.weight + ";";
    return fontString;
  }

  var keyPrefix$1 = "$",
      ambiguous = Object.freeze({}),
      preroot = Object.freeze({
    depth: -1
  }),
      PARENT_SUBSTITUTE = "$$PARENT$$";

  function computeHeight(node) {
    var height = 0;

    do {
      node.height = height;
    } while ((node = node.parent) && node.height < ++height);
  }

  function calculateAnchorPoint(_point, _direction) {
    var reversed = _direction === "left" || _direction === "up";
    var x = 0;
    var y = 0;
    if (_direction === "left" || _direction === "right") x = (_point[0] || 0) / (reversed ? -2 : 2);else y = (_point[1] || 0) / (reversed ? -2 : 2);
    return [x, y];
  }

  function transposeCoordinates(_point, _direction) {
    var horizontal = _direction === "left" || _direction === "right";
    var x = _point[horizontal ? 1 : 0];
    var y = _point[horizontal ? 0 : 1];

    if (_direction === "left" || _direction === "up") {
      x *= -1;
      y *= -1;
    }

    return [x, y];
  }

  var OrganizationChart = /*#__PURE__*/function (_RenderBase) {
    _inherits(OrganizationChart, _RenderBase);

    var _super = _createSuper(OrganizationChart);

    function OrganizationChart() {
      var _this;

      _classCallCheck(this, OrganizationChart);

      _this = _super.call(this); // Exposed variables

      _defineProperty(_assertThisInitialized(_this), "getChartState", void 0);

      _defineProperty(_assertThisInitialized(_this), "_palette", void 0);

      _defineProperty(_assertThisInitialized(_this), "container", void 0);

      var attrs = {
        svgWidth: null,
        svgHeight: null,
        marginTop: 0,
        marginBottom: 0,
        marginRight: 0,
        marginLeft: 0,
        container: "body",
        defaultFont: null,
        data: null,
        duration: DEFAULT_ANIMATION_TIME,
        initialZoom: 1,
        onNodeClick: function onNodeClick(d) {
          return d;
        },
        direction: null
      };

      _this.getChartState = function () {
        return attrs;
      }; // Create attribute get/set functions


      Object.keys(attrs).forEach(function (key) {
        _this[key] = function (_) {
          if (!arguments.length) return attrs[key];
          attrs[key] = _;
          return this;
        };
      });
      return _this;
    }

    _createClass(OrganizationChart, [{
      key: "create",
      value: function create(_node) {
        this.container(_node).svgWidth("100%").svgHeight("100%");
        return _node;
      }
    }, {
      key: "update",
      value: function update(_info) {
        var _this2 = this;

        // Get data, properties and svg node.
        var data = _info.data;
        var props = _info.props; // Update data and render

        var attrs = this.getChartState(); // Drawing containers

        var container = d3.select(attrs.container);
        var containerRect = container.node().getBoundingClientRect();
        if (containerRect.width > 0) attrs.svgWidth = containerRect.width;
        if (containerRect.height > 0) attrs.svgHeight = containerRect.height;
        var chartWidth = attrs.svgWidth - attrs.marginRight - attrs.marginLeft;
        var chartHeight = attrs.svgHeight - attrs.marginBottom - attrs.marginTop;
        var centerX = chartWidth / 2;
        var centerY = chartHeight / 2; // If there is no data, remove all axes and elements.

        if (!data || !data.rows.length) {
          container.selectAll(".svg-chart-container").selectAll(".chart>*").remove();
          return;
        }

        this._updateProperties(_info); // Store direction (changes layout calculations)


        attrs.direction = props.get("direction");
        var horizontal = attrs.direction === "left" || attrs.direction === "right"; // Generate tree layout function (transpose if necessary)

        attrs.treemapLayout = d3.tree().size(horizontal ? [chartHeight, chartWidth] : [chartWidth, chartHeight]).nodeSize(horizontal ? [DEFAULT_HEIGHT, DEFAULT_WIDTH * HORIZONTAL_ANCESTRAL_SEPARATION_FACTOR] : [DEFAULT_WIDTH, DEFAULT_HEIGHT * VERTICAL_ANCESTRAL_SEPARATION_FACTOR]).separation(function (_a, _b) {
          return _a.parent === _b.parent ? GENERATION_SIBLING_SEPARATION_FACTOR : GENERATION_COUSIN_SEPARATION_FACTOR;
        }); // Create or update the tree

        attrs.root = this.stratify(data.rows, props, _info.reason); // Add svg

        var zoom = d3.zoom().on("zoom", function () {
          return _this2.onzoom();
        });
        var svg = container.selectAll(".svg-chart-container").data(["svg-chart-container"], function (_d, i) {
          return i;
        }).join("svg").attr("class", "svg-chart-container").attr("width", attrs.svgWidth).attr("height", attrs.svgHeight).attr("font-family", attrs.defaultFont).call(d3.zoom().on("zoom", function () {
          return _this2.onzoom();
        })).attr("cursor", "move");
        attrs.svg = svg; // Add container element

        var chart = svg.selectAll(".chart").data(["chart"], function (_d, i) {
          return i;
        }).join("g").attr("class", "chart").attr("transform", "translate(".concat(attrs.marginLeft, ",").concat(attrs.marginTop, ")")); // Calculate the initial zoom factor if data has changed

        if (_info.reason.data) {
          var minX = 0,
              minY = 0,
              maxX = 0,
              maxY = 0;
          attrs.root.each(function (node) {
            var x = horizontal ? node.y : node.x;
            var y = horizontal ? node.x : node.y;
            if (x < minX) minX = x;
            if (y < minY) minY = y;
            if (x > maxX) maxX = x;
            if (y > maxY) maxY = y;
          });
          var totalWidth = maxX - minX + DEFAULT_WIDTH;
          var totalHeight = maxY - minY + DEFAULT_HEIGHT; // Note: this only sets the initial zoom; if a tree is unbalanced, it will be partially offscreen

          var minimumZoom;
          if (chartWidth < 150 || chartHeight < 150) minimumZoom = INITIAL_MINIMUM_THUMBNAIL_ZOOM;else minimumZoom = INITIAL_MINIMUM_ZOOM;
          attrs.initialZoom = Math.max(minimumZoom, Math.min(chartWidth / totalWidth, chartHeight / totalHeight, INITIAL_MAXIMUM_ZOOM));
          attrs.lastTransform = d3.zoomIdentity.translate(centerX, centerY).scale(attrs.initialZoom);
          svg.transition().duration(attrs.duration).call(zoom.transform, attrs.lastTransform);
        } // Add one more container g element, for better positioning controls


        attrs.centerG = chart.selectAll(".center-group").data(["center-group"], function (_d, i) {
          return i;
        }).join("g").attr("class", "center-group");
        attrs.chart = chart; // Display tree contents

        this._update(attrs.root);
      }
    }, {
      key: "hitTest",
      value: function hitTest(_elem) {
        // Fetch element and its respective data
        var elem = d3.select(_elem);
        var datum = elem.empty() ? null : elem.datum(); // Don't highlight or select on expand button

        var className = _elem && _elem.getAttribute("class") || "";
        if (reButtonClass.test(className)) return null;
        return datum && datum.data && datum.data.dataPoint;
      }
    }, {
      key: "stratify",
      value: function stratify(_rows, _props, _reason) {
        var orgNode,
            i,
            rowLength = _rows.length,
            root,
            parent,
            node,
            nodeId,
            nodeKey;
        var nodes = new Array(rowLength),
            nodeByKey = {},
            attrs = this.getChartState(); // Check for references

        var byRef = false;

        for (i = 0; i < rowLength; ++i) {
          byRef = byRef || !!_rows[i].tuple(PARENT).source.reference;
          if (byRef) break;
        } // If data hasn't changed, keep the current tree in tact and only update the properties


        if (!_reason.data && attrs.allNodes) {
          for (i = 0; i < rowLength; ++i) {
            orgNode = this._createOrgNode(_rows[i], i, _props, byRef);

            if ((nodeId = orgNode.nodeId) !== null && (nodeId += "")) {
              nodeKey = keyPrefix$1 + nodeId;
              nodeByKey[nodeKey] = nodeKey in nodeByKey ? ambiguous : orgNode;
            }
          }

          for (i = 0, rowLength = attrs.allNodes.length; i < rowLength; ++i) {
            node = attrs.allNodes[i];
            orgNode = nodeByKey[keyPrefix$1 + node.data.nodeId];
            if (orgNode) Object.assign(node.data, orgNode);
          }

          return attrs.root;
        } // First pass: create all know nodes and store by (adapted) id.


        for (i = 0; i < rowLength; ++i) {
          node = nodes[i] = d3.hierarchy(this._createOrgNode(_rows[i], i, _props, byRef));

          if ((nodeId = node.data.nodeId) !== null && (nodeId += "")) {
            nodeKey = keyPrefix$1 + (node.id = nodeId);
            nodeByKey[nodeKey] = nodeKey in nodeByKey ? ambiguous : node;
          }
        } // Second pass: iterate nodes and find their corresponding parent. If not found, create a substitute.


        for (i = 0; i < rowLength; ++i) {
          node = nodes[i];
          nodeId = node.data.parentNodeId;
          parent = nodeByKey[keyPrefix$1 + nodeId];

          if (nodeByKey[keyPrefix$1 + node.data.nodeId] === ambiguous) {
            console.warn("Ignoring ambiguous node: ".concat(node.data.nodeId));
            continue;
          } else if (parent === ambiguous) {
            console.warn("Removing ambiguous parent: ".concat(nodeId));
            parent = null;
          }

          if (parent) {
            // Valid parent; assign parent-child relationship
            node.parent = parent;
            if (parent.children) parent.children.push(node);else parent.children = [node];
          } else {
            // Orphan
            if (!root) {
              // Set as root
              root = node;
            } else if (root.data.nodeId === PARENT_SUBSTITUTE) {
              // Add orphan to substitute root
              root.children.push(node);
              node.parent = root; // Note: this 'destroys' the original id

              node.data.parentNodeId = PARENT_SUBSTITUTE;
              console.warn("Add orphan ".concat(root.children.length, ": ").concat(node.data.nodeId, " to substitute root"));
            } else if (node.data.nodeId !== root.data.nodeId) {
              // Create substitute root and add previous root + current node
              console.warn("Creating substitute root for ".concat(node.data.nodeId, " and ").concat(root.data.nodeId));
              node.parent = root.parent = nodeByKey[keyPrefix$1 + PARENT_SUBSTITUTE] = d3.hierarchy({
                nodeId: PARENT_SUBSTITUTE
              });
              node.data.parentNodeId = root.data.parentNodeId = PARENT_SUBSTITUTE;
              root.parent.children = [root, node];
              root = root.parent;
            } else {
              console.warn("Ignoring ambiguous node: ".concat(node.data.nodeId));
            }
          }
        }

        if (!root) throw new Error("no root");
        root.parent = preroot;
        root.eachBefore(function (node) {
          node.depth = node.parent.depth + 1;
          --rowLength;
        }).eachBefore(computeHeight);
        root.parent = null;
        if (rowLength > 0) console.warn("Not all nodes linked: Either cyclic Parent-Nodes relationship or ambigous parents/children."); // Set child nodes enter appearance positions

        root.x0 = 0;
        root.y0 = 0; // Store flat list of nodes

        attrs.allNodes = attrs.treemapLayout(root).descendants();
        return root;
      } // This function basically redraws visible graph, based on nodes state

    }, {
      key: "_update",
      value: function _update(_ref) {
        var _this3 = this;

        var x0 = _ref.x0,
            y0 = _ref.y0,
            x = _ref.x,
            y = _ref.y;
        var attrs = this.getChartState();
        var chart = attrs.chart; // Reposition and rescale chart accordingly

        chart.attr("transform", attrs.lastTransform); // Get tree nodes and links and attach some properties

        var nodes = attrs.allNodes = attrs.treemapLayout(attrs.root).descendants(); // Get all links

        var links = nodes.slice(1); // Get links selection

        var linkSelection = attrs.centerG.selectAll("path.link").data(links, function (_ref2) {
          var id = _ref2.id;
          return id;
        }); // Enter any new links at the parent's previous position.

        var linkEnter = linkSelection.enter().insert("path", "g").attr("class", "link").attr("pointer-events", "all").attr("d", function () {
          var o = {
            x: x0,
            y: y0
          };
          return _this3.diagonal(o, o, attrs.direction);
        }); // Get links update selection

        var linkUpdate = linkEnter.merge(linkSelection); // Styling links

        linkUpdate.attr("fill", "none").attr("stroke-width", function (_ref3) {
          var data = _ref3.data;
          return data.connectorLineWidth || 2;
        }).attr("stroke", function (_ref4) {
          var data = _ref4.data;
          return data.connectorLineColor;
        }).attr("stroke-dasharray", function (_ref5) {
          var data = _ref5.data;
          return data.dashArray ? data.dashArray : "";
        }); // Transition back to the parent element position

        linkUpdate.transition().duration(attrs.duration).attr("d", function (d) {
          return _this3.diagonal(d, d.parent, attrs.direction);
        }); // Remove any  links which is exiting after animation

        linkSelection.exit().attr("pointer-events", "none").transition().duration(attrs.duration).attr("d", function () {
          var o = {
            x: x,
            y: y
          };
          return _this3.diagonal(o, o, attrs.direction);
        }).remove(); // Get nodes selection

        var nodesSelection = attrs.centerG.selectAll("g.node").data(nodes, function (_ref6) {
          var id = _ref6.id;
          return id;
        }); // Enter any new nodes at the parent's previous position.

        var nodeEnter = nodesSelection.enter().append("g").attr("pointer-events", "all").attr("class", "node").attr("transform", function () {
          return "translate(".concat(transposeCoordinates([x0, y0], attrs.direction), ")");
        }).attr("cursor", "pointer").on("click", function (_ref7) {
          var data = _ref7.data;
          var className = d3.event.srcElement && d3.event.srcElement.getAttribute("class") || "";
          if (reButtonClass.test(className)) return;
          attrs.onNodeClick(data.nodeId);
        }); // Add background rectangle for the nodes

        nodeEnter.append("rect").attr("class", "node-rect");
        var content = nodeEnter.append("g").attr("transform", function (_ref8) {
          var data = _ref8.data;
          return "translate(".concat(-(data.width || 0) / 2, ", ").concat(-(data.height || 0) / 2, ")");
        }).append("text");
        content.append("tspan").attr("class", "title").attr("x", function (_ref9) {
          var data = _ref9.data;
          return data.padding;
        }).attr("y", function (_ref10) {
          var data = _ref10.data;
          return data.padding;
        }).attr("dy", "1em");
        content.append("tspan").attr("class", "subtitle").attr("x", function (_ref11) {
          var data = _ref11.data;
          return data.padding;
        }).attr("dy", "1em"); // Node update styles

        var nodeUpdate = nodeEnter.merge(nodesSelection);
        nodeUpdate.selectAll("tspan.title").data(nodes, function (data) {
          return data.id;
        }).attr("style", function (_ref12) {
          var data = _ref12.data;
          return createFontString(data.titleFont);
        }).attr("fill", function (_ref13) {
          var data = _ref13.data;
          return data.titleColor;
        }).text(function (_ref14) {
          var data = _ref14.data;
          return data.title;
        });
        nodeUpdate.selectAll("tspan.subtitle").data(nodes, function (data) {
          return data.id;
        }).attr("style", function (_ref15) {
          var data = _ref15.data;
          return createFontString(data.nodeFont);
        }).attr("fill", function (_ref16) {
          var data = _ref16.data;
          return data.color;
        }).text(function (_ref17) {
          var data = _ref17.data;
          return data.subtitle;
        }); // Add Node button circle's group (expand-collapse button)

        var nodeButtonGroups = nodeEnter.append("g").attr("class", "node-button-g").data(nodes, function (data) {
          return data.id;
        }).on("click", function (d) {
          return _this3.onButtonClick(d);
        }).on("dblclick", function (d) {
          return _this3.onButtonClick(d);
        }); // Add expand collapse button circle

        nodeButtonGroups.append("circle").attr("class", "node-button-circle").data(nodes, function (data) {
          return data.id;
        }); // Add button text

        nodeButtonGroups.append("text").attr("class", "node-button-text").data(nodes, function (data) {
          return data.id;
        }).attr("pointer-events", "none"); // Transition to the proper position for the node

        nodeUpdate.transition().attr("opacity", 0).duration(attrs.duration).attr("transform", function (_ref18) {
          var x = _ref18.x,
              y = _ref18.y;
          return "translate(".concat(transposeCoordinates([x, y], attrs.direction), ")");
        }).attr("opacity", 1); // Style node rectangles

        nodeUpdate.select(".node-rect").attr("width", function (_ref19) {
          var data = _ref19.data;
          return data.width;
        }).attr("height", function (_ref20) {
          var data = _ref20.data;
          return data.height;
        }).attr("x", function (_ref21) {
          var data = _ref21.data;
          return -(data.width || 0) / 2;
        }).attr("y", function (_ref22) {
          var data = _ref22.data;
          return -(data.height || 0) / 2;
        }).attr("rx", function (_ref23) {
          var data = _ref23.data;
          return data.borderRadius || 0;
        }).attr("stroke-width", function (_ref24) {
          var data = _ref24.data;
          return data.borderWidth;
        }).attr("cursor", "pointer").attr("stroke", function (_ref25) {
          var data = _ref25.data;
          return data.borderColor;
        }).style("fill", function (_ref26) {
          var data = _ref26.data;
          return data.nodeColor;
        }); // Move node button group to the desired position

        nodeUpdate.select(".node-button-g").attr("transform", function (_ref27) {
          var data = _ref27.data;
          return "translate(".concat(calculateAnchorPoint([data.width, data.height], attrs.direction), ")");
        }).attr("opacity", function (_ref28) {
          var children = _ref28.children,
              collapsedChildren = _ref28.collapsedChildren,
              data = _ref28.data;
          return data.connectorLineWidth && (children || collapsedChildren) ? 1 : 0;
        }); // Restyle node button circle

        nodeUpdate.select(".node-button-circle").attr("r", 16).attr("stroke-width", function (_ref29) {
          var data = _ref29.data;
          return data.borderWidth;
        }).attr("fill", function (_ref30) {
          var data = _ref30.data;
          return data.nodeColor;
        }).attr("stroke", function (_ref31) {
          var data = _ref31.data;
          return data.borderColor;
        }); // Restyle button texts
        // NOTE: alignment-baseline breaks for Firefox and IE11/Edge (originally for tspan)
        //.      dominant-baseline breaks for IE11/Edge
        //       (See VIDA-4131)

        nodeUpdate.select(".node-button-text").attr("text-anchor", "middle").attr("dy", ".3em").attr("fill", function (_ref32) {
          var data = _ref32.data;
          return data.color;
        }).attr("font-size", function (_ref33) {
          var children = _ref33.children;
          return children ? 40 : 26;
        }).text(function (_ref34) {
          var children = _ref34.children;
          return children ? "-" : "+";
        }).attr("y", 0).attr("pointer-events", "none"); // Remove any exiting nodes after transition

        var nodeExitTransition = nodesSelection.exit().attr("opacity", 1).attr("pointer-events", "none").transition().duration(attrs.duration).attr("transform", function () {
          return "translate(".concat(transposeCoordinates([x, y], attrs.direction), ")");
        }).on("end", function () {
          d3.select(this).remove();
        }).attr("opacity", 0); // On exit reduce the node rects size to 0

        nodeExitTransition.selectAll(".node-rect").attr("width", 10).attr("height", 10).attr("x", 0).attr("y", 0); // Store the old positions for transition.

        nodes.forEach(function (d) {
          d.x0 = d.x;
          d.y0 = d.y;
        });
      }
      /**
       * Enable/disable properties based on data mapping
       * @param _info
       */

    }, {
      key: "_updateProperties",
      value: function _updateProperties(_info) {
        var isColorCont = _info.data.cols[COLOR].dataType === "cont";
        this.properties.setActive("contcolor", isColorCont);
        this.properties.setActive("catcolor", !isColorCont);
        this._palette = _info.props.get(isColorCont ? "contcolor" : "catcolor");
      }
    }, {
      key: "_createOrgNode",
      value: function _createOrgNode(_dataPoint, _index, _props, _byRef) {
        var caption = _dataPoint.caption(NODES);

        var titleFont = _props.get("title.font");

        var titleColor = _props.get("title.color");

        var nodeFont = _props.get("node.font");

        var nodeColor = _props.get("node.color"); // NOTE: since reference is not yet supported, fetch it from `source`


        var reference = _byRef ? _dataPoint.tuple(PARENT).source.reference : _dataPoint.tuple(PARENT).caption;
        var key = _byRef ? _dataPoint.tuple(NODES).key : caption;

        var colorCaption = _dataPoint.caption(COLOR);

        var backgroundColor = this._palette.getFillColor(_dataPoint);

        var nodeColorString = nodeColor.toString();
        var titleColorString = titleColor && titleColor.toString() || nodeColorString;

        if (_props.get("contrast.text.color")) {
          // Poor man's lightness calculations
          var nodeLightness = 0.3 * nodeColor.r + 0.59 * nodeColor.g + 0.11 * nodeColor.b;
          var lightness = 0; // Test against color notations

          var parts = reRGBA.exec(backgroundColor);

          if (parts) {
            lightness = 0.3 * +parts[COLOR_R] + 0.59 * +parts[COLOR_G] + 0.11 * +parts[COLOR_B];
          } else {
            parts = reHEX.exec(backgroundColor);
            if (parts) lightness = 0.3 * parseInt(parts[COLOR_R], 16) + 0.59 * parseInt(parts[COLOR_G], 16) + 0.11 * parseInt(parts[COLOR_B], 16);
          }

          if (Math.abs(lightness - nodeLightness) < MINIMUM_LIGHTNESS_DIFFERENCE) nodeColorString = lightness > 127 ? "black" : "white";

          if (titleColor) {
            var titleLightness = 0.3 * titleColor.r + 0.59 * titleColor.g + 0.11 * titleColor.b;
            if (Math.abs(lightness - titleLightness) < MINIMUM_LIGHTNESS_DIFFERENCE) titleColorString = lightness > 127 ? "black" : "white";
          } else {
            titleColorString = nodeColorString;
          }
        }

        var datum = {
          nodeId: key,
          parentNodeId: reference,
          width: DEFAULT_WIDTH,
          height: DEFAULT_HEIGHT,
          padding: DEFAULT_PADDING,
          borderWidth: DEFAULT_BORDER_WIDTH,
          borderRadius: DEFAULT_BORDER_RADIUS,
          color: nodeColorString,
          borderColor: this._palette.getOutlineColor(_dataPoint),
          nodeColor: backgroundColor,
          titleColor: titleColorString,
          nodeFont: nodeFont,
          titleFont: titleFont,
          title: caption,
          subtitle: colorCaption,
          connectorLineColor: _props.get("line.color"),
          connectorLineWidth: DEFAULT_LINE_WIDTH,
          dashArray: "",
          curvature: _props.get("line.curvature"),
          dataPoint: _dataPoint,
          direction: _props.get("direction")
        };
        return datum;
      } // Generate custom link connector line

    }, {
      key: "diagonal",
      value: function diagonal(_source, _target, _direction) {
        var width = _source.data && _source.data.width || 0;
        var height = _source.data && _source.data.height || 0;
        if (_source.data && !_source.data.connectorLineWidth || _target.data && !_target.data.connectorLineWidth) return ""; // Input values

        var horizontal = _direction === "left" || _direction === "right";
        var sourceCurveValue = _source.data && "curvature" in _source.data ? _source.data.curvature : 100;
        var targetCurveValue = _target.data && "curvature" in _target.data ? _target.data.curvature : 100; // Translated to ratios

        var sourceRatio1 = Math.min(1, sourceCurveValue / 50);
        var sourceRatio2 = Math.max(0, (sourceCurveValue - 50) / 50);
        var targetRatio1 = Math.min(1, targetCurveValue / 50);
        var targetRatio2 = Math.max(0, (targetCurveValue - 50) / 50); // Node point and offset

        var sourcePoint = transposeCoordinates([_source.x, _source.y], _direction);
        var sourceSize = transposeCoordinates([width / 2, height / 2], _direction);
        var targetPoint = transposeCoordinates([_target.x, _target.y], _direction);
        var targetSize = transposeCoordinates([width / 2, height / 2], _direction); // Fixed line points

        if (horizontal) {
          sourcePoint[0] -= sourceSize[1];
          targetPoint[0] += targetSize[1];
        } else {
          sourcePoint[1] -= sourceSize[1];
          targetPoint[1] += targetSize[1];
        }

        var centerPoint = [(sourcePoint[0] + targetPoint[0]) / 2, (sourcePoint[1] + targetPoint[1]) / 2]; // Dynamic line points

        var sourceCurve = [sourcePoint[0], sourcePoint[1]];
        var targetCurve = [targetPoint[0], targetPoint[1]];
        var sourceCenterOffset = [centerPoint[0], centerPoint[1]];
        var targetCenterOffset = [centerPoint[0], centerPoint[1]];

        if (horizontal) {
          sourceCurve[0] = sourceRatio1 * centerPoint[0] + (1 - sourceRatio1) * sourcePoint[0];
          targetCurve[0] = targetRatio1 * centerPoint[0] + (1 - targetRatio1) * targetPoint[0];
          sourceCenterOffset[1] = sourceRatio2 * sourcePoint[1] + (1 - sourceRatio2) * centerPoint[1];
          targetCenterOffset[1] = targetRatio2 * targetPoint[1] + (1 - targetRatio2) * centerPoint[1];
        } else {
          sourceCurve[1] = sourceRatio1 * centerPoint[1] + (1 - sourceRatio1) * sourcePoint[1];
          targetCurve[1] = targetRatio1 * centerPoint[1] + (1 - targetRatio1) * targetPoint[1];
          sourceCenterOffset[0] = sourceRatio2 * sourcePoint[0] + (1 - sourceRatio2) * centerPoint[0];
          targetCenterOffset[0] = targetRatio2 * targetPoint[0] + (1 - targetRatio2) * centerPoint[0];
        }

        return "M".concat(sourcePoint, " Q").concat(sourceCurve, " ").concat(sourceCenterOffset, " L").concat(targetCenterOffset, " Q").concat(targetCurve, " ").concat(targetPoint);
      }
    }, {
      key: "_centerNode",
      value: function _centerNode(source) {
        var attrs = this.getChartState();
        var t = attrs.lastTransform;
        var chartWidth = attrs.svgWidth - attrs.marginRight - attrs.marginLeft;
        var chartHeight = attrs.svgHeight - attrs.marginBottom - attrs.marginTop;
        var centerX = chartWidth / 2;
        var centerY = chartHeight / 2; // Center the node relative to the zoom factor

        var offset = transposeCoordinates([source.x * t.k, source.y * t.k], attrs.direction);
        t.x = centerX - offset[0];
        t.y = centerY - offset[1]; // Reposition and rescale chart accordingly

        attrs.chart.transition().duration(attrs.duration).attr("transform", t);
      } // Toggle children on click.

    }, {
      key: "onButtonClick",
      value: function onButtonClick(d) {
        // Expanded children?
        if (d.children) {
          // Store as collapsed
          d.collapsedChildren = d.children;
          d.children = null;
        } else if (d.collapsedChildren) {
          // Store as expanded
          d.children = d.collapsedChildren;
          d.collapsedChildren = null; // Set children as expanded

          d.children.forEach(function (_ref35) {
            var data = _ref35.data;
            return data.expanded = true;
          });
        } // Redraw Graph


        this._update(d);

        this._centerNode(d);
      } // Zoom handler

    }, {
      key: "onzoom",
      value: function onzoom() {
        var attrs = this.getChartState();
        var chart = attrs.chart; // Store d3 event transform object

        var transform = d3.event.transform;
        attrs.lastTransform = transform; // Reposition and rescale chart accordingly

        chart.attr("transform", transform);
      }
    }]);

    return OrganizationChart;
  }(st);

  return OrganizationChart;

});
