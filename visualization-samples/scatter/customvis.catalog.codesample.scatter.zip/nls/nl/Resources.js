define(
{
    "slot_categories":      "Categorieën",
    "slot_xpos":            "X-waarde",
    "slot_ypos":            "Y-waarde",
    "slot_color":           "Kleur",
    "prop_color_cat":       "Puntkleur",
    "prop_color_cont":      "Kleurbereik",
    "prop_shape":           "Vorm",
    "prop_shape_circle":    "Cirkel",
    "prop_shape_square":    "Vierkant",
    "prop_background":      "Achtergrond",
    "prop_show_background": "Toon achtergrond",
    "prop_xmax":            "X-as max",
    "prop_ymax":            "Y-as max",
    "prop_axis":            "As"
} );
