define(['require'], (function (requirejs) { 'use strict';

  function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
  }
  function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
  }
  function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties(e, r) {
    for (var t = 0; t < r.length; t++) {
      var o = r[t];
      o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
    }
  }
  function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
      writable: !1
    }), e;
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _getPrototypeOf(t) {
    return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
      return t.__proto__ || Object.getPrototypeOf(t);
    }, _getPrototypeOf(t);
  }
  function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(e && e.prototype, {
      constructor: {
        value: t,
        writable: !0,
        configurable: !0
      }
    }), Object.defineProperty(t, "prototype", {
      writable: !1
    }), e && _setPrototypeOf(t, e);
  }
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function () {
      return !!t;
    })();
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _possibleConstructorReturn(t, e) {
    if (e && ("object" == typeof e || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return _assertThisInitialized(t);
  }
  function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
      return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }

  class e{constructor(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}getName(){return this.name}getSlot(){return this.slot}getAttributes(){return this.attributes}static slotLimit(t,s){return new e("limit",t).attr("n",s)}static dataLimit(t){return new e("limit").attr("n",t)}attr(t,e){return this.attributes.set(t,e),this}}function s(t,e,s){return t.getDecoration(e,s)}function r(t){return t.hasDecoration("hasSelection")?s(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}class n{constructor(t,e){this.min=t,this.max=e;}asArray(){return [this.min,this.max]}}n.empty=new n(0,0);class o extends n{static fromRS(t){return new n(t.min,t.max)}constructor(t,e){super(t,e);}}class i{constructor(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";const s=t.getItems()||[];this.segments=s.map((t=>new c(t)));}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class l extends i{constructor(t,e){super(t,e);}}class a{constructor(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class c extends a{constructor(t){super(t);}}const u=new class{format(t){return t?t.toString():""}};var h;!function(t){t.label="label",t.data="data";}(h||(h={}));class p{constructor(t,e,s,r,n){this.source=t,this.tuples=e,this.segments=s,this.domain=r,this.caption=n;const o=t.dataItems||[],i=o.length>0?o[0]:null,l=i&&i.asCont();l?(this._labelFormatter=l.getFormatter("label")||u,this._dataFormatter=l.getFormatter("data")||u):this._labelFormatter=this._dataFormatter=u;}get mapped(){return this.source.mapped}get dataType(){const t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"}format(t,e){return function(t,e){return t.format(e)}(e===h.data?this._dataFormatter:this._labelFormatter,t)}}class g extends p{constructor(t,e,s,r,n){super(t,e,s,r,n);}}class f{constructor(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}tuple(t){const e=this._getSlot(t);if(!e||0===e.tuples.length)return null;const s=this.source.get(e.source);if(!s)return null;const r=s.asCat();return r?e.tuples[r.index]:null}value(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);if(!s)return null;const r=s.asCont();return r&&"numeric"===r.valueType?r.value:null}caption(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);return s&&s.getCaption("data")||""}_getSlot(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null}}class d extends f{constructor(t,e){super(t,e);}}class m{constructor(t,e,s){this.source=t,this.rows=t.dataPoints.map((t=>new d(t,this))),this.cols=e,this.slotMap=s;}static filterRows(t,e,s){return t.filter((t=>{const r=t.tuple(e);return !!r&&r.key===s}))}get hasSelections(){return r(this.source)}}class y extends m{constructor(t,e,s){super(t,e,s);}}function _(t){const e=new Map,s=t.getSlots().map(((t,s)=>{let r=[],i=[],a=n.empty,u="";if(t.isMapped()){const e=t.getDataItem(0);if(u=e.getCaption("label"),"cat"===e.getRSType()){r=e.getTuples().map(((t,e)=>new l(t,e)));i=e.getItemClassSet(0).getItemClasses().map((t=>new c(t)));}else a=o.fromRS(e.getDomain()),i.push(new c(e.getItemClass()));}const h=new g(t,r,i,a,u);return e.set(t.name,h),h}));return new y(t,s,e)}const w=/^\s*#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{0,2})\s*$/,C=/^\s*rgba?\s*\(\s*(\d+\%?)\s*,\s*(\d+\%?)\s*,\s*(\d+\%?)\s*(?:,\s*(\d+(?:\.\d+)?\%?)\s*)?\)\s*/;function b(t){return t<0?0:t>255?255:Math.floor(t)}class S{constructor(t,e,s,r){var n;this.r=b(t),this.g=b(e),this.b=b(s),this.a=(n=r)<0?0:n>1?1:n;}static darker(t,e){const s=e?Math.pow(.7,e):.7;return new S(t.r*s,t.g*s,t.b*s,t.a)}static fromObject(t){return new S(t.r,t.g,t.b,void 0===t.a?1:t.a)}static fromString(t){const e=C.exec(t);let s=e||w.exec(t);const r=e?void 0:16;if(!s)return null;const n=parseInt(s[1],r),o=parseInt(s[2],r),i=parseInt(s[3],r);let l;return s[4]&&(l=e?parseFloat(s[4]):Math.round(parseInt(s[4],r)/255*100)/100),this.fromObject({r:n,g:o,b:i,a:l})}toString(){return 1===this.a?`rgb(${this.r},${this.g},${this.b})`:`rgba(${this.r},${this.g},${this.b},${this.a})`}}function x(t,e){let s=null;if(t instanceof f)s=t.source.getDataSet(e);else {const r=t.source.getDataItem(e);s=r&&r.getDataSet(e);}return !!s&&r(s)}const I=t=>`rgba(${t.r},${t.g},${t.b},0.4)`,j=t=>`rgba(${Math.round(.7*t.r)},${Math.round(.7*t.g)},${Math.round(.7*t.b)},${t.a})`;class E{constructor(t,e,s){this.source=t,this._dataContext=e,this._slotResolver=s;}get slot(){return this.source.slot}getColor(t){return t?S.fromObject(this.source.getTupleColor(t.source,-1)):S.fromObject(this.source.getColor(null))}_getTuple(t){if(t instanceof i)return t;let e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null}getFillColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),!t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class P{constructor(t,e,s){this.color=t,this.at=e,this.value=s;}}function D(t){return t.map((t=>new P(S.fromObject(t.color),t.at,t.value)))}class F{constructor(t,e,s){this.source=t,this._slot=e,this._dataContext=s,this.stops=D(t.stops),this.aligned=D(t.aligned),this.interpolate=t.interpolate;}getColor(t){return S.fromObject(this.source.getColor(t))}getFillColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return !t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class T{constructor(t,e,s){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=s;}get slot(){return this.source.slot}getColorStops(t){const e=t?t.source.getDataItem(0):null,s=e&&e.asCont();let r=s?s.getDomain(null):null;const n=this.source.getColorStops(s,r),o=t?t.source.name:null;return new F(n,o,this._dataContext)}_fetchColorStops(t){const e=t.source.getDataSet(this._dataContext),s=this.slot||this._slotResolver(t.dataSet,this.source.name),r=s?e.getSlot(s):null,n=r?r.getDataItem(0):null,o=n?n.asCont():null;if(this.source.dirty||!this._cachedStops||o!==this._lastDataItem){const t=o?o.getDomain(null):null,e=this.source.getColorStops(o,t);this._cachedStops=new F(e,r&&r.name,this._dataContext),this._lastDataItem=o;}return this._cachedStops}getFillColor(t){return this._fetchColorStops(t).getFillColor(t)}getOutlineColor(t){return this._fetchColorStops(t).getOutlineColor(t)}}class A extends S{constructor(t){super(t.r,t.g,t.b,t.a),this._color=t;}getRed(){return this.r}getGreen(){return this.g}getBlue(){return this.b}getAlpha(){return this.a}}const O=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:()=>0,getMax:()=>0,isEmpty:()=>!0,isExplicit:()=>!1});class ${constructor(t,e,s,r,n,o){this.caption=t,this.color=e,this.shape=s,this.selected=r,this.highlighted=n,this.ref=o;}getCaption(){return this.caption}getColor(){return this.color?new A(this.color):null}getShape(){return this.shape}isSelected(){return this.selected}isHighlighted(){return this.highlighted}getRef(){return this.ref}}class R{constructor(t,e,s,r,n,o){this.type=t,this.channel=e,this.slot=s,this.caption=r,this.subCaption=n,this.ref=o;}getRSType(){return this.type}getChannel(){return this.channel}getSlot(){return this.slot}getCaption(){return this.caption}getSubCaption(){return this.subCaption}getRef(){return this.ref}}class M extends R{constructor(t,e,r,n,o){const i=e&&e.source,l=i&&i.name,a=i&&i.getDataItem(0),c=a&&a.asCat();super("cat",t,l,r,"",c);const u=c?c.tuples:[];this.entries=u.map((t=>{const e=t.getCaption("label")||"",r=o&&o.source.getTupleColor(t,-1),i=s(t,"selected",!1),l=s(t,"highlighted",!1);return new $(e,r?S.fromObject(r):null,n,i,l,t)}));}getEntries(){return this.entries}}class L extends R{constructor(t,e,s,r){const n=e&&e.source,o=n&&n.name,i=n&&n.getDataItem(0),l=i&&i.asCont();if(super("cont",t,o,s,"",l),this.domain=l?l.getDomain(null):O,r&&"color"===t){const t=r.source.getColorStops(l,null);this.stops=t.stops,this.interpolate=t.interpolate;}else this.stops=null,this.interpolate=!1;}getDomain(){return this.domain}getInterpolate(){return this.interpolate}getStops(){return this.stops}}function k(t,e,s,r){if(!t)return [];const n=new Map,o=new Map;e.palettes.forEach((e=>{const s=e.slot||r&&r(t,e.source.name);s&&(e instanceof E?n.set(s,e):e instanceof T&&o.set(s,e));}));const i=[];return t.cols.forEach((t=>{const e=t.source;if(!e.mapped)return;const r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;const r=n.get(e.name);r&&i.push(new M("color",t,t.caption,s.legendShape,r));break;case"cont":if(-1!==e.channels.indexOf("color")){const s=o.get(e.name);s&&i.push(new L("color",t,t.caption,s));}-1!==e.channels.indexOf("size")&&i.push(new L("size",t,t.caption,null));}})),i}class z{constructor(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;}}var B,H,U;!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(B||(B={}));class V{constructor(t,e){this.value=t,this.unit=e;}static fromObject(t){return new V(t.value,function(t){switch(t){case"em":return B.Em;case"%":return B.Percentage;case"cm":return B.Centimeter;case"mm":return B.Millimeter;case"in":return B.Inch;case"pc":return B.Pica;case"pt":return B.Point;case"px":return B.Pixel;default:throw new Error(`Invalid length unit '${t}' specified`)}}(t.unit))}toString(){return `${this.value}${this.unit}`}}!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));const q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){let e=[];if(t)for(let s=0,r=t.length;s<r;++s){const r=t[s],n=q.test(r);e.push(n?`"${r}"`:r);}return e.join(", ")}class J{constructor(t,e,s,r){this.family=t,this.size=e,this.style=s,this.weight=r;}static fromObject(t){const e=t.family||null,s=t.size?V.fromObject(t.size):null,r=t.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error(`Invalid font style '${t}' specified`)}}(t.style):null,n=void 0!==t.weight&&null!==t.weight?t.weight:null;return new J(e,s,r,n)}toString(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){const t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){const e=[];let s=G(t.family);var r;return s.length>0&&e.push(`font-family: ${s};`),s=t.size?t.size.toString():"",s.length>0&&e.push(`font-size: ${s};`),s=(r=t.style)?r.toString():"",s.length>0&&e.push(`font-style: ${s};`),s=K(t.weight),s.length>0&&e.push(`font-weight: ${s};`),e.join(" ")}(this)}}class Q{constructor(t,e,s){const r=new Map;null!==t&&t.forEach(((t,n)=>{if("palette"===t.type){const o=t;switch(o.paletteType){case"cat":r.set(n,new E(o,e,s));break;case"cont":r.set(n,new T(o,e,s));}}})),this.source=t,this.palettes=r;}get(t){return this._getValue(t,!1)}peek(t){return this._getValue(t,!0)}_getValue(t,e){const s=this.source&&this.source.get(t);if(!s)return null;switch(s.type){case"string":case"number":case"boolean":case"enum":return e?s.peek:s.value;case"length":const r=e?s.peek:s.value;return r?V.fromObject(r):null;case"font":const n=e?s.peek:s.value;return n?J.fromObject(n):null;case"color":const o=e?s.peek:s.value;return o?S.fromObject(o):null;case"palette":return this.palettes.get(t)||null;default:return null}}isActive(t){const e=this.source&&this.source.get(t);return !!e&&e.active}setActive(t,e){const s=this.source&&this.source.get(t);s&&s.setActive(e);}isDirty(t){const e=this.source&&this.source.get(t);return !!e&&e.dirty}}function W(t,e){this.name="AggregateError",this.errors=t,this.message=e||"";}W.prototype=Error.prototype;var X=setTimeout;function Y(t){return Boolean(t&&void 0!==t.length)}function Z(){}function tt(t){if(!(this instanceof tt))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],it(t,this);}function et(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,tt._immediateFn((function(){var s=1===t._state?e.onFulfilled:e.onRejected;if(null!==s){var r;try{r=s(t._value);}catch(t){return void rt(e.promise,t)}st(e.promise,r);}else (1===t._state?st:rt)(e.promise,t._value);}))):t._deferreds.push(e);}function st(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var s=e.then;if(e instanceof tt)return t._state=3,t._value=e,void nt(t);if("function"==typeof s)return void it((r=s,n=e,function(){r.apply(n,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){rt(t,e);}var r,n;}function rt(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&tt._immediateFn((function(){t._handled||tt._unhandledRejectionFn(t._value);}));for(var e=0,s=t._deferreds.length;e<s;e++)et(t,t._deferreds[e]);t._deferreds=null;}function ot(t,e,s){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=s;}function it(t,e){var s=!1;try{t((function(t){s||(s=!0,st(e,t));}),(function(t){s||(s=!0,rt(e,t));}));}catch(t){if(s)return;s=!0,rt(e,t);}}tt.prototype.catch=function(t){return this.then(null,t)},tt.prototype.then=function(t,e){var s=new this.constructor(Z);return et(this,new ot(t,e,s)),s},tt.prototype.finally=function(t){var e=this.constructor;return this.then((function(s){return e.resolve(t()).then((function(){return s}))}),(function(s){return e.resolve(t()).then((function(){return e.reject(s)}))}))},tt.all=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,i){try{if(i&&("object"==typeof i||"function"==typeof i)){var l=i.then;if("function"==typeof l)return void l.call(i,(function(e){o(t,e);}),s)}r[t]=i,0==--n&&e(r);}catch(t){s(t);}}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.any=function(t){var e=this;return new e((function(s,r){if(!t||void 0===t.length)return r(new TypeError("Promise.any accepts an array"));var n=Array.prototype.slice.call(t);if(0===n.length)return r();for(var o=[],i=0;i<n.length;i++)try{e.resolve(n[i]).then(s).catch((function(t){o.push(t),o.length===n.length&&r(new W(o,"All promises were rejected"));}));}catch(t){r(t);}}))},tt.allSettled=function(t){return new this((function(e,s){if(!t||void 0===t.length)return s(new TypeError(typeof t+" "+t+" is not iterable(cannot read property Symbol(Symbol.iterator))"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,s){if(s&&("object"==typeof s||"function"==typeof s)){var i=s.then;if("function"==typeof i)return void i.call(s,(function(e){o(t,e);}),(function(s){r[t]={status:"rejected",reason:s},0==--n&&e(r);}))}r[t]={status:"fulfilled",value:s},0==--n&&e(r);}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.resolve=function(t){return t&&"object"==typeof t&&t.constructor===tt?t:new tt((function(e){e(t);}))},tt.reject=function(t){return new tt((function(e,s){s(t);}))},tt.race=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.race accepts an array"));for(var r=0,n=t.length;r<n;r++)tt.resolve(t[r]).then(e,s);}))},tt._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){X(t,0);},tt._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};class lt{constructor(t,e,s,r){this.data=t,this.decorations=e,this.properties=s,this.size=r;}}class at{constructor(t,e,s,r,n){this.reason=t,this.data=e,this.node=s,this.props=r,this.locale=n;}}class ct{constructor(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new z;}init(t,e){const s=t.surface.appendChild(document.createElement("div"));s.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),s.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,tt.resolve(this.create(s)).then((r=>{this._elem=r||s;t.properties.forEach(((t,e)=>this.updateProperty(e,t.value))),e.complete();})).catch((t=>{e.fail(t);}));}destroy(){}getPropertyApi(){return null}setData(t){t&&t.dataSets&&t.dataSets[0]?this._data=_(t.dataSets[0]):this._data=null;}setProperty(t,e){this.updateProperty(t,this.properties.peek(t));}getBlockingRequests(){return null}render(t,e,s){if(!this._elem)return s.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return s.complete(null,null,null),null;try{const t=this.update(new at(function(t){return new lt(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));tt.resolve(t).then((()=>s.complete(null,null,null))).catch(s.error);}catch(t){s.error(t);}return null}getEncodings(){return this._data?this.updateLegend(this._data):[]}getCapabilities(){const t=[];return this.meta.slotLimits.forEach(((s,r)=>{t.push(e.slotLimit(r,s));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t}getInteractivity(){return null}getVisCoordinate(t,e){return e}getRegionAtPoint(t,e){return null}getItemsAtPoint(t,e,s){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;const r=t,n=document.elementFromPoint(r.x,r.y),o=this.hitTest(n,r,e);return Array.isArray(o)?o.length?[...o.map((t=>t.source))]:[]:o&&o.source?[o.source]:[]}getItemsInPolygon(t,e){return []}getAxisItemsAtPoint(t,e,s){return []}getState(){return null}setState(t){}loadCss(t){const e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);}toUrl(e){return requirejs.toUrl(e)}update(t){}create(t){}updateProperty(t,e){}updateLegend(t){return k(t,this.properties,this.meta,this._slotResolver)}getSlotForPalette(t,e){return null}hitTest(t,e,s){const r=t&&t.__data__;return r&&r.source?r:null}nls(t){return this._nls&&this._nls.get(t)||""}}

  // Licensed Materials - Property of IBM
  //
  // IBM Watson Analytics
  //
  // (C) Copyright IBM Corp. 2022
  //
  // US Government Users Restricted Rights - Use, duplication or
  // disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
  function loadGoogleCharts() {
      // Chart scripts may be loaded in separate vipr-amd iframe (code is executed inside iframe, but rendering is performed in higher scope, outside the iframe).
      // In such case google scripts must be loaded in higher scope, where visualisation is rendered.
      // It is necessary, because google scripts use window.location for generating svg clip-path links and location provided inside vipr-amd iframe may differ from location in higher scope.
      // Check if inside vipr-amd iframe. Only in such case load google scripts in lower scope.
      // This check is to prevent loading in lower scope if case, where vipr-amd iframe is not used, but everything (script + rendering) is performed inside another iframe.
      const isViprAmdScope = window.parent !== window
          && window.parent.document.body.querySelector("iframe[data-sandbox='vipr-amd']")?.contentWindow === window;
      const loadPromise = new Promise(resolve => {
          const targetWindow = isViprAmdScope ? window.parent : window;
          // Check if google charts are already loaded AND if they are loaded properly
          if (targetWindow.google?.charts && targetWindow.google === window.google)
              return resolve();
          const script = targetWindow.document.createElement("script");
          // Load charts from google corechart package
          script.onload = () => {
              if (isViprAmdScope)
                  Object.defineProperty(window, "google", { value: targetWindow.google });
              resolve();
          };
          script.src = "https://www.gstatic.com/charts/loader.js";
          targetWindow.document.head.appendChild(script);
      });
      return loadPromise;
  }

  var loadPromise = loadGoogleCharts();
  loadPromise.then(function () {
    return google.charts.load("current", {
      packages: ["corechart"]
    });
  });
  var CATEGORY = 0,
    SERIES = 1,
    VALUE = 2;
  var defaultOptions = {
    animation: {
      duration: 100
    }
  };
  var _default = /*#__PURE__*/function (_RenderBase) {
    function _default() {
      var _this;
      _classCallCheck(this, _default);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _callSuper(this, _default, [].concat(args));
      _defineProperty(_this, "_chart", void 0);
      return _this;
    }
    _inherits(_default, _RenderBase);
    return _createClass(_default, [{
      key: "create",
      value: function create(_node) {
        var _this2 = this;
        // Initialize the chart
        loadPromise.then(function () {
          return google.charts.setOnLoadCallback(function () {
            return _this2._chart = new google.visualization.BarChart(_node);
          });
        });
      }
    }, {
      key: "update",
      value: function update(_info) {
        var _this3 = this;
        var data = _info.data;
        var props = _info.props;

        // Clear chart if there's no data
        if (!data || data.rows.length === 0) {
          if (this._chart) this._chart.clearChart();
          return;
        }

        // Convert data source to google charts format
        var chartData = [];
        if (data.cols[SERIES].mapped) {
          // Get list of categories and series
          var categories = data.cols[CATEGORY].tuples.map(function (e) {
            return e.caption;
          });
          var series = data.cols[SERIES].tuples.map(function (e) {
            return e.caption;
          });
          // initialize chart data as 2d array
          // header row
          chartData.push([data.cols[CATEGORY].caption].concat(series));
          // empty array for each category
          categories.forEach(function (_category) {
            // for each category, create an array of series.length + 1, with an extra (first) item for category name
            // Fill with 0 since in some cases, null data is not handled well
            var catArray = new Array(series.length + 1).fill(0);
            catArray[0] = _category;
            chartData.push(catArray);
          });
          // fill chart data with data rows
          data.rows.forEach(function (_row) {
            chartData[categories.indexOf(_row.tuple(CATEGORY).caption) + 1][series.indexOf(_row.tuple(SERIES).caption) + 1] = _row.value(VALUE);
          });
        } else {
          // header row
          chartData.push([data.cols[CATEGORY].caption, data.cols[VALUE].caption]);
          // add data
          data.rows.forEach(function (_row) {
            chartData.push([_row.tuple(CATEGORY).caption, _row.value(VALUE)]);
          });
        }

        // Hide series options if series is not mapped
        props.setActive("series.type", data.cols[SERIES].mapped);

        // Set google chart options via properties and
        var palette = props.get("colors");
        var stack = props.get("series.type");
        var options = _objectSpread2(_objectSpread2({}, defaultOptions), {}, {
          backgroundColor: {
            fill: props.get("background.color").toString()
          },
          // If series is mapped, return an array of colors (from the palette) corresponding to tuples of series slot
          // Else, return an array containing the first color from the palette
          colors: data.cols[SERIES].mapped ? data.cols[SERIES].tuples.map(function (_t) {
            return palette.getColor(_t).toString();
          }) : [palette.getColor(null).toString()],
          hAxis: {
            title: props.get("hAxis.title"),
            titleTextStyle: {
              color: props.get("hAxis.title.color").toString()
            },
            textStyle: {
              color: props.get("hAxis.label.color").toString()
            },
            direction: props.get("hAxis.inverse") ? -1 : 1,
            gridlines: {
              color: props.get("hAxis.grid.color").toString()
            },
            baselineColor: props.get("hAxis.baseline.color").toString(),
            minValue: props.get("hAxis.minValue"),
            maxValue: props.get("hAxis.maxValue")
          },
          vAxis: {
            title: props.get("vAxis.title"),
            titleTextStyle: {
              color: props.get("vAxis.title.color").toString()
            },
            textStyle: {
              color: props.get("vAxis.label.color").toString()
            },
            direction: props.get("vAxis.inverse") ? -1 : 1
          },
          chartArea: {
            left: props.get("grid.left.padding"),
            right: props.get("grid.right.padding"),
            top: props.get("grid.top.padding"),
            bottom: props.get("grid.bottom.padding")
          },
          bar: {
            groupWidth: props.get("bar.width")
          },
          isStacked: stack === "grouped" ? false : stack === "stacked" ? true : "percent",
          legend: {
            position: props.get("googleLegend.position"),
            alignment: props.get("googleLegend.alignment"),
            textStyle: {
              color: props.get("googleLegend.color").toString()
            }
          }
        });
        loadPromise.then(function () {
          return google.charts.setOnLoadCallback(function () {
            return _this3._chart.draw(google.visualization.arrayToDataTable(chartData), options);
          });
        });
      }

      // Disable/enable properties based on property update
    }, {
      key: "updateProperty",
      value: function updateProperty(_name, _value) {
        switch (_name) {
          case "hAxis.title":
            this.properties.setActive("hAxis.title.color", _value);
            break;
          case "vAxis.title":
            this.properties.setActive("vAxis.title.color", _value);
            break;
          case "googleLegend.position":
            this.properties.setActive("googleLegend.alignment", _value !== "none");
            this.properties.setActive("googleLegend.color", _value !== "none");
        }
      }
    }]);
  }(ct);

  return _default;

}));
