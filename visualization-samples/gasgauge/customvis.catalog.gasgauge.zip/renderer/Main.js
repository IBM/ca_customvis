define(['require', 'https://d3js.org/d3.v5.min.js'], function (requirejs, d3) { 'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }

    return obj;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;

    try {
      Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized(self);
  }

  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();

    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
          result;

      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;

        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }

      return _possibleConstructorReturn(this, result);
    };
  }

  var e=function(){function t(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}return t.prototype.getName=function(){return this.name},t.prototype.getSlot=function(){return this.slot},t.prototype.getAttributes=function(){return this.attributes},t.slotLimit=function(e,n){return new t("limit",e).attr("n",n)},t.dataLimit=function(e){return new t("limit").attr("n",e)},t.prototype.attr=function(t,e){return this.attributes.set(t,e),this},t}(),n=function(t,e){return (n=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e;}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n]);})(t,e)};
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0

  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.

  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */function r(t,e){function r(){this.constructor=t;}n(t,e),t.prototype=null===e?Object.create(e):(r.prototype=e.prototype,new r);}function o(t,e,n){return t.getDecoration(e,n)}function i(t){return t.hasDecoration("hasSelection")?o(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}var u,s=function(){function t(t,e){this.min=t,this.max=e;}return t.prototype.asArray=function(){return [this.min,this.max]},t.empty=new t(0,0),t}(),a=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e.fromRS=function(t){return new s(t.min,t.max)},e}(s),l=function(){function t(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";var n=t.getItems()||[];this.segments=n.map((function(t){return new p(t)}));}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),c=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(l),h=function(){function t(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),p=function(t){function e(e){return t.call(this,e)||this}return r(e,t),e}(h),f=new(function(){function t(){}return t.prototype.format=function(t){return t?t.toString():""},t}());!function(t){t.label="label",t.data="data";}(u||(u={}));var g=function(){function t(t,e,n,r,o){this.source=t,this.tuples=e,this.segments=n,this.domain=r,this.caption=o;var i=t.dataItems||[],u=i.length>0?i[0]:null,s=u&&u.asCont();s?(this._labelFormatter=s.getFormatter("label")||f,this._dataFormatter=s.getFormatter("data")||f):this._labelFormatter=this._dataFormatter=f;}return Object.defineProperty(t.prototype,"mapped",{get:function(){return this.source.mapped},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"dataType",{get:function(){var t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"},enumerable:!0,configurable:!0}),t.prototype.format=function(t,e){return function(t,e){return t.format(e)}(e===u.data?this._dataFormatter:this._labelFormatter,t)},t}(),d=function(t){function e(e,n,r,o,i){return t.call(this,e,n,r,o,i)||this}return r(e,t),e}(g),m=function(){function t(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t.prototype.tuple=function(t){var e=this._getSlot(t);if(!e||0===e.tuples.length)return null;var n=this.source.get(e.source);if(!n)return null;var r=n.asCat();return r?e.tuples[r.index]:null},t.prototype.value=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);if(!n)return null;var r=n.asCont();return r&&"numeric"===r.valueType?r.value:null},t.prototype.caption=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);return n&&n.getCaption("data")||""},t.prototype._getSlot=function(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null},t}(),y=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(m),v=function(){function t(t,e,n){var r=this;this.source=t,this.rows=t.dataPoints.map((function(t){return new y(t,r)})),this.cols=e,this.slotMap=n;}return t.filterRows=function(t,e,n){return t.filter((function(t){var r=t.tuple(e);return !!r&&r.key===n}))},Object.defineProperty(t.prototype,"hasSelections",{get:function(){return i(this.source)},enumerable:!0,configurable:!0}),t}(),_=function(t){function e(e,n,r){return t.call(this,e,n,r)||this}return r(e,t),e}(v);function b(t){var e=new Map,n=t.getSlots().map((function(t,n){var r=[],o=[],i=s.empty,u="";if(t.isMapped()){var l=t.getDataItem(0);if(u=l.getCaption("label"),"cat"===l.getRSType())r=l.getTuples().map((function(t,e){return new c(t,e)})),o=l.getItemClassSet(0).getItemClasses().map((function(t){return new p(t)}));else i=a.fromRS(l.getDomain()),o.push(new p(l.getItemClass()));}var h=new d(t,r,o,i,u);return e.set(t.name,h),h}));return new _(t,n,e)}function w(t){return t<0?0:t>255?255:Math.floor(t)}var C=function(){function t(t,e,n,r){var o;this.r=w(t),this.g=w(e),this.b=w(n),this.a=(o=r)<0?0:o>1?1:o;}return t.fromObject=function(e){return new t(e.r,e.g,e.b,void 0===e.a?1:e.a)},t.prototype.toString=function(){return 1===this.a?"rgb("+this.r+","+this.g+","+this.b+")":"rgba("+this.r+","+this.g+","+this.b+","+this.a+")"},t}();function S(t,e){var n=null;if(t instanceof m)n=t.source.getDataSet(e);else{var r=t.source.getDataItem(e);n=r&&r.getDataSet(e);}return !!n&&i(n)}var P=function(t){return "rgba("+t.r+","+t.g+","+t.b+",0.4)"},j=function(t){return "rgba("+Math.round(.7*t.r)+","+Math.round(.7*t.g)+","+Math.round(.7*t.b)+","+t.a+")"},x=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColor=function(t){return t?C.fromObject(this.source.getTupleColor(t.source,-1)):C.fromObject(this.source.getColor(null))},t.prototype._getTuple=function(t){if(t instanceof l)return t;var e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null},t.prototype.getFillColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),!t.selected&&S(t,this._dataContext)?P(e):e.toString()},t.prototype.getOutlineColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&S(t,this._dataContext)?j(e):null},t}(),O=function(t,e,n){this.color=t,this.at=e,this.value=n;};function I(t){return t.map((function(t){return new O(C.fromObject(t.color),t.at,t.value)}))}var D=function(){function t(t,e,n){this.source=t,this._slot=e,this._dataContext=n,this.stops=I(t.stops),this.aligned=I(t.aligned),this.interpolate=t.interpolate;}return t.prototype.getColor=function(t){return C.fromObject(this.source.getColor(t))},t.prototype.getFillColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return !t.selected&&S(t,this._dataContext)?P(n):n.toString()},t.prototype.getOutlineColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return t.highlighted||t.selected&&S(t,this._dataContext)?j(n):null},t}(),E=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColorStops=function(t){var e=t?t.source.getDataItem(0):null,n=e&&e.asCont(),r=n?n.getDomain(null):null,o=this.source.getColorStops(n,r),i=t?t.source.name:null;return new D(o,i,this._dataContext)},t.prototype._fetchColorStops=function(t){var e=t.source.getDataSet(this._dataContext),n=this.slot||this._slotResolver(t.dataSet,this.source.name),r=n?e.getSlot(n):null,o=r?r.getDataItem(0):null,i=o?o.asCont():null;if(this.source.dirty||!this._cachedStops||i!==this._lastDataItem){var u=i?i.getDomain(null):null,s=this.source.getColorStops(i,u);this._cachedStops=new D(s,r&&r.name,this._dataContext),this._lastDataItem=i;}return this._cachedStops},t.prototype.getFillColor=function(t){return this._fetchColorStops(t).getFillColor(t)},t.prototype.getOutlineColor=function(t){return this._fetchColorStops(t).getOutlineColor(t)},t}(),T=function(t){function e(e){var n=t.call(this,e.r,e.g,e.b,e.a)||this;return n._color=e,n}return r(e,t),e.prototype.getRed=function(){return this.r},e.prototype.getGreen=function(){return this.g},e.prototype.getBlue=function(){return this.b},e.prototype.getAlpha=function(){return this.a},e}(C),R=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:function(){return 0},getMax:function(){return 0},isEmpty:function(){return !0},isExplicit:function(){return !1}}),F=function(){function t(t,e,n,r,o,i){this.caption=t,this.color=e,this.shape=n,this.selected=r,this.highlighted=o,this.ref=i;}return t.prototype.getCaption=function(){return this.caption},t.prototype.getColor=function(){return this.color?new T(this.color):null},t.prototype.getShape=function(){return this.shape},t.prototype.isSelected=function(){return this.selected},t.prototype.isHighlighted=function(){return this.highlighted},t.prototype.getRef=function(){return this.ref},t}(),M=function(){function t(t,e,n,r,o,i){this.type=t,this.channel=e,this.slot=n,this.caption=r,this.subCaption=o,this.ref=i;}return t.prototype.getRSType=function(){return this.type},t.prototype.getChannel=function(){return this.channel},t.prototype.getSlot=function(){return this.slot},t.prototype.getCaption=function(){return this.caption},t.prototype.getSubCaption=function(){return this.subCaption},t.prototype.getRef=function(){return this.ref},t}(),L=function(t){function e(e,n,r,i,u){var s=this,a=n&&n.source,l=a&&a.name,c=a&&a.getDataItem(0),h=c&&c.asCat();s=t.call(this,"cat",e,l,r,"",h)||this;var p=h?h.tuples:[];return s.entries=p.map((function(t){var e=t.getCaption("label")||"",n=u&&u.source.getTupleColor(t,-1),r=o(t,"selected",!1),s=o(t,"highlighted",!1);return new F(e,n?C.fromObject(n):null,i,r,s,t)})),s}return r(e,t),e.prototype.getEntries=function(){return this.entries},e}(M),A=function(t){function e(e,n,r,o){var i=this,u=n&&n.source,s=u&&u.name,a=u&&u.getDataItem(0),l=a&&a.asCont();if((i=t.call(this,"cont",e,s,r,"",l)||this).domain=l?l.getDomain(null):R,o&&"color"===e){var c=o.source.getColorStops(l,null);i.stops=c.stops,i.interpolate=c.interpolate;}else i.stops=null,i.interpolate=!1;return i}return r(e,t),e.prototype.getDomain=function(){return this.domain},e.prototype.getInterpolate=function(){return this.interpolate},e.prototype.getStops=function(){return this.stops},e}(M);function z(t,e,n,r){if(!t)return [];var o=new Map,i=new Map;e.palettes.forEach((function(e){var n=e.slot||r&&r(t,e.source.name);n&&(e instanceof x?o.set(n,e):e instanceof E&&i.set(n,e));}));var u=[];return t.cols.forEach((function(t){var e=t.source;if(e.mapped){var r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;var s=o.get(e.name);s&&u.push(new L("color",t,t.caption,n.legendShape,s));break;case"cont":if(-1!==e.channels.indexOf("color")){var a=i.get(e.name);a&&u.push(new A("color",t,t.caption,a));}-1!==e.channels.indexOf("size")&&u.push(new A("size",t,t.caption,null));}}})),u}var N,k=function(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;},B=function(){this.x=0,this.y=0;};!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(N||(N={}));var H,U,V=function(){function t(t,e){this.value=t,this.unit=e;}return t.fromObject=function(e){return new t(e.value,function(t){switch(t){case"em":return N.Em;case"%":return N.Percentage;case"cm":return N.Centimeter;case"mm":return N.Millimeter;case"in":return N.Inch;case"pc":return N.Pica;case"pt":return N.Point;case"px":return N.Pixel;default:throw new Error("Invalid length unit '"+t+"' specified")}}(e.unit))},t.prototype.toString=function(){return ""+this.value+this.unit},t}();!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));var q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){var e=[];if(t)for(var n=0,r=t.length;n<r;++n){var o=t[n],i=q.test(o);e.push(i?'"'+o+'"':o);}return e.join(", ")}var J=function(){function t(t,e,n,r){this.family=t,this.size=e,this.style=n,this.weight=r;}return t.fromObject=function(e){return new t(e.family||null,e.size?V.fromObject(e.size):null,e.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error("Invalid font style '"+t+"' specified")}}(e.style):null,void 0!==e.weight&&null!==e.weight?e.weight:null)},t.prototype.toString=function(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){var t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){var e,n=[],r=G(t.family);return r.length>0&&n.push("font-family: "+r+";"),(r=t.size?t.size.toString():"").length>0&&n.push("font-size: "+r+";"),(r=(e=t.style)?e.toString():"").length>0&&n.push("font-style: "+r+";"),(r=K(t.weight)).length>0&&n.push("font-weight: "+r+";"),n.join(" ")}(this)},t}(),Q=function(){function t(t,e,n){var r=new Map;null!==t&&t.forEach((function(t,o){if("palette"===t.type){var i=t;switch(i.paletteType){case"cat":r.set(o,new x(i,e,n));break;case"cont":r.set(o,new E(i,e,n));}}})),this.source=t,this.palettes=r;}return t.prototype.get=function(t){return this._getValue(t,!1)},t.prototype.peek=function(t){return this._getValue(t,!0)},t.prototype._getValue=function(t,e){var n=this.source&&this.source.get(t);if(!n)return null;switch(n.type){case"string":case"number":case"boolean":case"enum":return e?n.peek:n.value;case"length":var r=e?n.peek:n.value;return r?V.fromObject(r):null;case"font":var o=e?n.peek:n.value;return o?J.fromObject(o):null;case"color":var i=e?n.peek:n.value;return i?C.fromObject(i):null;case"palette":return this.palettes.get(t)||null;default:return null}},t.prototype.isActive=function(t){var e=this.source&&this.source.get(t);return !!e&&e.active},t.prototype.setActive=function(t,e){var n=this.source&&this.source.get(t);n&&n.setActive(e);},t.prototype.isDirty=function(t){var e=this.source&&this.source.get(t);return !!e&&e.dirty},t}();var W=setTimeout;function X(t){return Boolean(t&&void 0!==t.length)}function Y(){}function Z(t){if(!(this instanceof Z))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],ot(t,this);}function $(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,Z._immediateFn((function(){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var r;try{r=n(t._value);}catch(t){return void et(e.promise,t)}tt(e.promise,r);}else(1===t._state?tt:et)(e.promise,t._value);}))):t._deferreds.push(e);}function tt(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var n=e.then;if(e instanceof Z)return t._state=3,t._value=e,void nt(t);if("function"==typeof n)return void ot((r=n,o=e,function(){r.apply(o,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){et(t,e);}var r,o;}function et(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&Z._immediateFn((function(){t._handled||Z._unhandledRejectionFn(t._value);}));for(var e=0,n=t._deferreds.length;e<n;e++)$(t,t._deferreds[e]);t._deferreds=null;}function rt(t,e,n){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=n;}function ot(t,e){var n=!1;try{t((function(t){n||(n=!0,tt(e,t));}),(function(t){n||(n=!0,et(e,t));}));}catch(t){if(n)return;n=!0,et(e,t);}}Z.prototype.catch=function(t){return this.then(null,t)},Z.prototype.then=function(t,e){var n=new this.constructor(Y);return $(this,new rt(t,e,n)),n},Z.prototype.finally=function(t){var e=this.constructor;return this.then((function(n){return e.resolve(t()).then((function(){return n}))}),(function(n){return e.resolve(t()).then((function(){return e.reject(n)}))}))},Z.all=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var o=r.length;function i(t,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var s=u.then;if("function"==typeof s)return void s.call(u,(function(e){i(t,e);}),n)}r[t]=u,0==--o&&e(r);}catch(t){n(t);}}for(var u=0;u<r.length;u++)i(u,r[u]);}))},Z.resolve=function(t){return t&&"object"==typeof t&&t.constructor===Z?t:new Z((function(e){e(t);}))},Z.reject=function(t){return new Z((function(e,n){n(t);}))},Z.race=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.race accepts an array"));for(var r=0,o=t.length;r<o;r++)Z.resolve(t[r]).then(e,n);}))},Z._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){W(t,0);},Z._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};var it=function(t,e,n,r){this.data=t,this.decorations=e,this.properties=n,this.size=r;},ut=function(t,e,n,r,o){this.reason=t,this.data=e,this.node=n,this.props=r,this.locale=o;};var st=function(){function n(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new k;}return n.prototype.init=function(t,e){var n=this,r=t.surface.appendChild(document.createElement("div"));r.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),r.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,Z.resolve(this.create(r)).then((function(o){n._elem=o||r,t.properties.forEach((function(t,e){return n.updateProperty(e,t.value)})),e.complete();})).catch((function(t){e.fail(t);}));},n.prototype.destroy=function(){},n.prototype.getPropertyApi=function(){return null},n.prototype.setData=function(t){t&&t.dataSets&&t.dataSets[0]?this._data=b(t.dataSets[0]):this._data=null;},n.prototype.setProperty=function(t,e){this.updateProperty(t,this.properties.peek(t));},n.prototype.getBlockingRequests=function(){return null},n.prototype.render=function(t,e,n){if(!this._elem)return n.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return n.complete(null,null,null),null;try{var r=this.update(new ut(function(t){return new it(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));Z.resolve(r).then((function(){return n.complete(null,null,null)})).catch(n.error);}catch(t){n.error(t);}return null},n.prototype.getEncodings=function(){return this._data?this.updateLegend(this._data):[]},n.prototype.getCapabilities=function(){var t=[];return this.meta.slotLimits.forEach((function(n,r){t.push(e.slotLimit(r,n));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t},n.prototype.getInteractivity=function(){return null},n.prototype.getVisCoordinate=function(t,e){return e},n.prototype.getRegionAtPoint=function(t,e){return null},n.prototype.getItemsAtPoint=function(t,e,n){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;var r=t,o=document.elementFromPoint(r.x,r.y),i=this.hitTest(o,r,e);return i&&i.source?[i.source]:[]},n.prototype.getItemsInPolygon=function(t,e){return []},n.prototype.getAxisItemsAtPoint=function(t,e,n){return []},n.prototype.getState=function(){return null},n.prototype.setState=function(t){},n.prototype.loadCss=function(t){var e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);},n.prototype.toUrl=function(e){return requirejs.toUrl(e)},n.prototype.update=function(t){},n.prototype.create=function(t){},n.prototype.updateProperty=function(t,e){},n.prototype.updateLegend=function(t){return z(t,this.properties,this.meta,this._slotResolver)},n.prototype.getSlotForPalette=function(t,e){return null},n.prototype.hitTest=function(t,e,n){var r=t&&t.__data__;return r&&r.source?r:null},n.prototype.nls=function(t){return this._nls&&this._nls.get(t)||""},n}();

  var ACTUAL_VALUE_SLOT = 0;
  var MAX_AXIS_VALUE_SLOT = 1;
  var CENTER_X = 50;
  var CENTER_Y = 50;
  var BORDER_START_RADIUS = 38;
  var ARC_START_RADIUS = 29;
  var ARC_END_RADIUS = 35;
  var POINTER_INDICATOR_LENGTH = ARC_END_RADIUS - 1;
  var POINTER_INDICATOR_SIZE = 1.5;
  var POINTER_INDICATOR_ANIMATION_DURATION_IN_MS = 1000;
  var MAIN_AXIS_TICKS = 2; // results in default being min and max tick

  var AXIS_TICKS_DISTANCE_FROM_CENTER = 30;
  var STANDARD_TICK_SIZE = 5;
  var AXIS_TICK_TEXT_MAX_WIDTH = 15;
  var AXIS_TICK_TEXT_DISTANCE_FROM_TICKS = 2.5;
  var AXIS_FONT_WEIGHT = 1.25;
  var STANDARD_TRUNCATION_END_SECTION = "...";
  var STANDARD_FONT_SIZE = 3; // CSS global class names

  var VISUALIZATION_CLASS_NAME = "gas-gauge";
  var AXIS_CLASS_NAME = "axis";
  var POINTER_INDICATOR_CLASS_NAME = "pointer-indicator";
  var POINTER_CIRCLE_CLASS_NAME = "pointer-circle";
  var TARGET_INDICATOR_CLASS_NAME = "target-indicator";
  var OUTER_BORDER_CLASS_NAME = "outer-border";
  var INNER_BORDER_CLASS_NAME = "inner-border";

  function applyFont(_selection, _font) {
    _selection.style("font-size", _font.size ? _font.size.toString() : new V(STANDARD_FONT_SIZE, N.Pixel).toString()).style("font-family", _font.family ? _font.family.toString() : null).style("font-style", _font.style ? _font.style.toString() : null).style("font-weight", _font.weight ? _font.weight.toString() : null);
  }

  var _default = /*#__PURE__*/function (_RenderBase) {
    _inherits(_default, _RenderBase);

    var _super = _createSuper(_default);

    function _default() {
      var _this;

      _classCallCheck(this, _default);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _defineProperty(_assertThisInitialized(_this), "_dataSet", void 0);

      _defineProperty(_assertThisInitialized(_this), "_properties", void 0);

      _defineProperty(_assertThisInitialized(_this), "_svg", void 0);

      _defineProperty(_assertThisInitialized(_this), "_minAxisValue", void 0);

      _defineProperty(_assertThisInitialized(_this), "_maxAxisValue", void 0);

      _defineProperty(_assertThisInitialized(_this), "_angleScale", void 0);

      _defineProperty(_assertThisInitialized(_this), "_startAngleInDegrees", void 0);

      _defineProperty(_assertThisInitialized(_this), "_endAngleInDegrees", void 0);

      _defineProperty(_assertThisInitialized(_this), "_isAxisInverted", void 0);

      _defineProperty(_assertThisInitialized(_this), "_axisScaleLength", void 0);

      _defineProperty(_assertThisInitialized(_this), "_lastAngleValue", null);

      _defineProperty(_assertThisInitialized(_this), "_KPILabel", void 0);

      _defineProperty(_assertThisInitialized(_this), "_valueLabel", void 0);

      _defineProperty(_assertThisInitialized(_this), "_arcGenerator", d3.arc());

      return _this;
    }

    _createClass(_default, [{
      key: "create",
      value: function create(_node) {
        // Create an svg canvas that sizes to its parent.
        var svg = d3.select(_node).append("svg").attr("viewBox", "0 0 100 100").attr("width", "100%").attr("height", "100%"); // Create a group for the chart

        var chart = svg.append("g").attr("class", "".concat(VISUALIZATION_CLASS_NAME)); // Create a group for the center of the chart

        var center = chart.append("g").attr("class", "center").attr("transform", "translate(".concat(CENTER_X, " ").concat(CENTER_Y, ")")); // Create all group elements attached to the center

        var border = center.append("g").attr("class", "border");
        center.append("g").attr("class", "arc");
        center.append("g").attr("class", "".concat(AXIS_CLASS_NAME));
        var labels = center.append("g").attr("class", "labels");
        var target = center.append("g").attr("class", "target");
        var pointer = center.append("g").attr("class", "pointer");
        border.append("circle").attr("class", OUTER_BORDER_CLASS_NAME);
        border.append("circle").attr("class", INNER_BORDER_CLASS_NAME);
        pointer.append("circle").attr("class", POINTER_CIRCLE_CLASS_NAME).attr("cx", 0).attr("cy", 0).attr("r", "6").style("stroke-width", "0.5");
        this._KPILabel = labels.append("text").attr("class", "KPI-label").style("fill", "black").style("text-anchor", "middle");
        this._valueLabel = labels.append("text").attr("class", "value-label").style("fill", "black").style("text-anchor", "middle");
        target.append("line").attr("class", TARGET_INDICATOR_CLASS_NAME).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke-width", "1"); // Return the svg node as the visualization root node.

        return svg.node();
      }
    }, {
      key: "update",
      value: function update(_info) {
        // Update dataSet, svg and properties
        this.dataSet = _info.data;
        this.svg = d3.select(_info.node);
        this.properties = _info.props;
        this.minAxisValue = this.properties.get("min-axis-value");
        var maxAxisValueProperty = this.properties.get("max-axis-value");
        this.startAngleInDegrees = this._calculateStartAngle();

        if (this.dataSet && this.dataSet.rows.length) {
          if (this.dataSet.rows[0].value("max-axis-value")) {
            this.maxAxisValue = this.dataSet.rows[0].value("max-axis-value");
            this.properties.setActive("max-axis-value", false);
          } else {
            this.maxAxisValue = maxAxisValueProperty;
            this.properties.setActive("max-axis-value", true);
          }
        }

        if (!this.dataSet || !this.dataSet.rows.length || this.minAxisValue === this.maxAxisValue) {
          // Empty all labels
          this.svg.select("text.value-label").text("");
          this.svg.select("text.KPI-label").text(""); // Remove the pointer, axis and target indicator

          this.svg.select("." + POINTER_INDICATOR_CLASS_NAME).remove();
          this.svg.selectAll("." + AXIS_CLASS_NAME).selectAll("g").remove();
          this.svg.select(".arc").selectAll("path").remove();
          this.svg.select("." + TARGET_INDICATOR_CLASS_NAME).attr("visibility", "hidden"); // No data, reset lastAngleValue

          this._lastAngleValue = null;

          this._updateMainProperties();

          return;
        } // Update the inverted axis boolean


        this.isAxisInverted = this.maxAxisValue < this.minAxisValue;

        if (_info.reason.properties) {
          this._updateAllProperties();

          if (!_info.reason.data) {
            this._updateAngleScale();

            this._updatePointerIndicator();

            this._updateTargetIndicator();

            this._updateArc();

            this._updateAxis();
          }
        }

        if (_info.reason.data) {
          if (!_info.reason.properties) {
            this._updateLabels();
          }

          this._updateAngleScale();

          this._updatePointerIndicator();

          this._updateTargetIndicator();

          this._updateArc();

          this._updateAxis();
        }

        if (_info.reason.decorations) {
          // Choose between _enableFullDecorations or _enableCoreDecorations functions for tooltip support
          this._enableFullDecorations();
        }

        if (this._lastAngleValue === null) {
          this._lastAngleValue = this.startAngleInDegrees;
        }
      }
    }, {
      key: "_updateAllProperties",
      value: function _updateAllProperties() {
        this._updateMainProperties();

        this._updateLabels();
      }
    }, {
      key: "_updateLabels",
      value: function _updateLabels() {
        var valueColumn = this.dataSet.cols[ACTUAL_VALUE_SLOT];
        var KPILabelValue = valueColumn.caption;
        var ValueLabelValue = valueColumn.format(this.dataSet.rows[0].value("value"));
        this.svg.select("text.KPI-label").call(applyFont, this.properties.get("KPI-label-font")).style("fill", this.properties.get("KPI-label-font-color")).text(this.properties.get("KPI-label-show") ? KPILabelValue : "");
        this.svg.select("text.value-label").call(applyFont, this.properties.get("value-label-font")).style("fill", this.properties.get("value-label-font-color")).text(this.properties.get("value-label-show") ? ValueLabelValue : "");

        var calculateMaxTextWidth = this._createCalculateMaxTextWidthFn();

        var kpiLabelMaxWidth = calculateMaxTextWidth(this._properties.get("KPI-label-offset"));
        var valueLabelMaxWidth = calculateMaxTextWidth(this._properties.get("value-label-offset"));

        this._truncateTextLabel(this._KPILabel, kpiLabelMaxWidth, STANDARD_TRUNCATION_END_SECTION);

        this._truncateTextLabel(this._valueLabel, valueLabelMaxWidth, STANDARD_TRUNCATION_END_SECTION);
      }
      /**
       * Called for updating the main properties that should always render even if there is no data
       */

    }, {
      key: "_updateMainProperties",
      value: function _updateMainProperties() {
        this.svg.style("background-color", this.properties.get("background-color"));
        var borderSize = this.properties.get("border-size");
        this.svg.select("." + OUTER_BORDER_CLASS_NAME).style("stroke", this.properties.get("outer-border-stroke")).style("fill", this.properties.get("elements-background-color")).attr("r", BORDER_START_RADIUS + borderSize).style("stroke-width", 1 / 6 * borderSize);
        this.svg.select("." + INNER_BORDER_CLASS_NAME).style("stroke", this.properties.get("inner-border-stroke")).style("fill", this.properties.get("elements-background-color")).attr("r", BORDER_START_RADIUS + borderSize / 2).style("stroke-width", 5 / 6 * borderSize);
        this.svg.select("." + POINTER_CIRCLE_CLASS_NAME).style("stroke", this.properties.get("pointer-circle-stroke")).style("fill", this.properties.get("pointer-circle-fill"));
        var showBorder = this.properties.get("show-border");
        this.svg.select(".border").style("display", showBorder ? "inherit" : "none");
        this.properties.setActive("outer-border-stroke", showBorder);
        this.properties.setActive("inner-border-stroke", showBorder);
        this.properties.setActive("border-size", showBorder);
        this.svg.select("text.KPI-label").attr("y", this.properties.get("KPI-label-offset"));
        this.svg.select("text.value-label").attr("y", this.properties.get("value-label-offset"));
        var showPointerCircle = this.properties.get("show-pointer-circle");
        this.svg.select("circle.pointer-circle").style("display", showPointerCircle ? "inherit" : "none");
        this.properties.setActive("pointer-circle-fill", showPointerCircle);
        this.properties.setActive("pointer-circle-stroke", showPointerCircle);

        var extraHeight = this._calculateChartExtraHeight();

        this.svg.attr("viewBox", this._calculateViewBox(extraHeight));
        this.svg.select("g.center").attr("transform", this._calculateTranslation(extraHeight));
      }
    }, {
      key: "_updateAngleScale",
      value: function _updateAngleScale() {
        this.axisScaleLength = this._delta(this.minAxisValue, this.maxAxisValue);
        this.angleScale = (this.endAngleInDegrees - this.startAngleInDegrees) / this.axisScaleLength;
      }
    }, {
      key: "_updateTargetIndicator",
      value: function _updateTargetIndicator() {
        var targetSlotValue = this.dataSet.rows[0].value("target");
        var targetColor = this.properties.get("target-color"); // If the target slot has no value, set the target-value property to true, otherwise set it to false

        if (!targetSlotValue) {
          this.properties.setActive("target-value", true);
        } else {
          this.properties.setActive("target-value", false);
        } // If the target is set to hidden, change the visibility of the target and return


        if (!this.properties.get("target-show")) {
          this.svg.select("." + TARGET_INDICATOR_CLASS_NAME).attr("visibility", "hidden");
          return;
        } // Set target value to the target slot if it has a value (is mapped), otherwise use the target-value property


        var targetValue = targetSlotValue || this.properties.get("target-value"); // Calculate the target indicator angle and secure the angle limits

        var targetIndicatorAngle = this._clamp(this._calculateAngle(targetValue), this.startAngleInDegrees, this.endAngleInDegrees);

        this.svg.select("." + TARGET_INDICATOR_CLASS_NAME).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke", targetColor).attr("stroke-width", "1").attr("visibility", "visible").attr("transform", "rotate(".concat(targetIndicatorAngle, ")"));
      }
    }, {
      key: "_updateArc",
      value: function _updateArc() {
        this.svg.select(".arc").selectAll("path").remove();

        this._createArcPiece(this.properties.get("first-interval-start"), this.properties.get("first-interval-end"), this.properties.get("first-interval-color"));

        this._createArcPiece(this.properties.get("second-interval-start"), this.properties.get("second-interval-end"), this.properties.get("second-interval-color"));

        this._createArcPiece(this.properties.get("third-interval-start"), this.properties.get("third-interval-end"), this.properties.get("third-interval-color"));
      }
      /**
       * Used for creating a single arc piece that contributes to building the entire arc
       * @param _startValueInPercentage The starting value of the arc piece in percentage
       * @param _endValueInPercentage The ending value of the arc piece in percentage
       * @param _color The color of the arc piece
       */

    }, {
      key: "_createArcPiece",
      value: function _createArcPiece(_startValueInPercentage, _endValueInPercentage, _color) {
        var arcGeneratorStandardAngle = 180; // Standard arc start angle, use this to normalize the actual angle

        var startValueInDecimals = (_startValueInPercentage > 100 ? 100 : _startValueInPercentage) / 100;
        var endValueInDecimals = (_endValueInPercentage > 100 ? 100 : _endValueInPercentage) / 100;

        var startAngle = this._clamp(startValueInDecimals * (this.endAngleInDegrees - this.startAngleInDegrees) + this.startAngleInDegrees, this.startAngleInDegrees, this.endAngleInDegrees);

        var endAngle = this._clamp(endValueInDecimals * (this.endAngleInDegrees - this.startAngleInDegrees) + this.startAngleInDegrees, this.startAngleInDegrees, this.endAngleInDegrees);

        var intervalData = this._arcGenerator({
          startAngle: this._degreesToRadians(startAngle - arcGeneratorStandardAngle),
          endAngle: this._degreesToRadians(endAngle - arcGeneratorStandardAngle),
          innerRadius: ARC_START_RADIUS,
          outerRadius: ARC_END_RADIUS
        });

        this.svg.select(".arc").datum(this.dataSet.rows[0]).append("path").attr("d", intervalData).style("fill", _color);
      }
      /**
       * Used for updating the axis with new data
       */

    }, {
      key: "_updateAxis",
      value: function _updateAxis() {
        // Get properties needed to create the axis
        var minorTicksPerInterval = this.properties.get("minor-ticks-per-interval");
        var extraMajorTicksValue = this.properties.get("major-ticks-count");
        var axisTickColor = this.properties.get("axis-tick-color");
        var axisFontColor = this.properties.get("axis-font-color");
        var font = this.properties.get("axis-font"); // Create the axis

        this._createCustomAxis(extraMajorTicksValue, minorTicksPerInterval, axisTickColor, axisFontColor, font);
      }
      /**
       * Used for updating the pointer indicator when the actual value slot has been updated or the axis has changed
       */

    }, {
      key: "_updatePointerIndicator",
      value: function _updatePointerIndicator() {
        // Get value from value slot
        var valueSlotValue = this.dataSet.rows[0].value("value"); // Calculate the pointer indicator angle and secure the angle limits

        var pointerIndicatorAngle = this._clamp(this._calculateAngle(valueSlotValue), this.startAngleInDegrees, this.endAngleInDegrees);

        var pointerIndicator = this.svg.select(".pointer").selectAll("polygon").data(this.dataSet.rows, function (row) {
          return row.key;
        });
        var lastAngleValue = this._lastAngleValue;
        this._lastAngleValue = pointerIndicatorAngle;
        pointerIndicator.enter().insert("polygon", ":first-child").attr("points", "-".concat(POINTER_INDICATOR_SIZE, ",0 ").concat(POINTER_INDICATOR_SIZE, ",0 0,").concat(POINTER_INDICATOR_LENGTH)).attr("transform", "rotate(".concat(this.startAngleInDegrees, ")")).attr("class", POINTER_INDICATOR_CLASS_NAME).style("stroke-width", "0.5").merge(pointerIndicator).style("stroke", this.properties.get("pointer-indicator-stroke")).style("fill", this.properties.get("pointer-indicator-fill")).transition().duration(POINTER_INDICATOR_ANIMATION_DURATION_IN_MS).tween("pointerindicator.transform", function () {
          var elem = d3.select(this);
          var interpolator = d3.interpolateString("rotate( ".concat(lastAngleValue, " )"), "rotate( ".concat(pointerIndicatorAngle, " )"));
          return function (value) {
            return elem.attr("transform", interpolator(value));
          };
        });
      }
      /**
       * Used for creating the custom axis that is needed in this visualization
       * @param _extraMajorTicks The amount of extra major ticks that need to applied to the axis ticks. (Standard has the main axis ticks only)
       * @param _minorTicksPerInterval The amount of minor ticks per interval (in between major ticks)
       * @param _axisTickColor The color of the axis ticks
       * @param _axisFontColor The font color of the major axis tick labels
       * @param _font The font of the major axis tick labels
       */

    }, {
      key: "_createCustomAxis",
      value: function _createCustomAxis(_extraMajorTicks, _minorTicksPerInterval, _axisTickColor, _axisFontColor, _font) {
        var totalMajorTicks = Math.max(_extraMajorTicks + MAIN_AXIS_TICKS, MAIN_AXIS_TICKS);
        var previousTickAngle;
        var previousMajorTickLabel; // Clear all elements

        this.svg.select("." + AXIS_CLASS_NAME).selectAll("g").remove();

        for (var i = 0; i < totalMajorTicks; i++) {
          // Set up all the variables needed to create the axis
          var totalTicksIndexed = totalMajorTicks - 1; // Start at 0 instead of 1

          var currentTickAsMultiplier = i / totalTicksIndexed;

          var value = this._clamp(currentTickAsMultiplier * this.axisScaleLength + (this.isAxisInverted ? this.minAxisValue : this.maxAxisValue) - this.axisScaleLength, this.isAxisInverted ? this.maxAxisValue : this.minAxisValue, this.isAxisInverted ? this.minAxisValue : this.maxAxisValue);

          var fontSize = _font && _font.size ? _font.size.value : STANDARD_FONT_SIZE;

          var currentTickAngleLineLocation = this._clamp(this._calculateLineAngle(value), this.startAngleInDegrees, this.endAngleInDegrees);

          var currentTickAngleTextLocation = this._clamp(this._calculateAngle(value), this.startAngleInDegrees, this.endAngleInDegrees);

          var majorTickSelection = this.svg.select("." + AXIS_CLASS_NAME).append("g").attr("class", "major-tick"); // Create main ticks

          majorTickSelection.append("line").datum(this.dataSet.rows[0]).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke", _axisTickColor).attr("stroke-width", "1").attr("shape-rendering", "geometricPrecision").attr("transform", "rotate(".concat(currentTickAngleLineLocation, ")"));
          var showMajorTicksText = this.properties.get("show-major-tick-text");
          var maxAxisValueColumn = this.dataSet.cols[MAX_AXIS_VALUE_SLOT];
          var formattedMajorTickText = maxAxisValueColumn.mapped ? maxAxisValueColumn.format(value) : this.dataSet.cols[ACTUAL_VALUE_SLOT].format(value); // Create text labels

          if (showMajorTicksText || !showMajorTicksText && (i === 0 || i === totalTicksIndexed)) {
            var majorTickLabel = majorTickSelection.append("text").datum(this.dataSet.rows[0]).call(applyFont, _font).style("fill", _axisFontColor).style("text-anchor", "middle").text(formattedMajorTickText);

            this._truncateTextLabel(majorTickLabel, AXIS_TICK_TEXT_MAX_WIDTH, STANDARD_TRUNCATION_END_SECTION);

            var y = AXIS_TICKS_DISTANCE_FROM_CENTER - AXIS_TICK_TEXT_DISTANCE_FROM_TICKS - majorTickLabel.node().getBBox().width / 4 - this._calculateFontImpactOnAxisTickLabel(fontSize, currentTickAngleLineLocation);

            var point = this._calculateCoordinatesAfterRotation(0, y, currentTickAngleTextLocation);

            majorTickLabel.attr("x", point.x).attr("y", point.y + majorTickLabel.node().getBBox().height / 4); // Check if labels overlap

            if (previousMajorTickLabel && this._checkLabelOverlap(majorTickLabel, previousMajorTickLabel)) {
              // Main tick always has priority over Major tick, therefore the previous label will be removed
              if (i === totalTicksIndexed) {
                previousMajorTickLabel.remove();
              } else majorTickLabel.remove();
            } else previousMajorTickLabel = majorTickLabel;
          } // Create minor ticks


          if (_minorTicksPerInterval > 0 && previousTickAngle) {
            var currentIntervalTotalAngle = this._delta(currentTickAngleLineLocation, previousTickAngle);

            var minorTickMultiplier = currentIntervalTotalAngle / (_minorTicksPerInterval + 1);
            var axisIntervalSelection = this.svg.select("." + AXIS_CLASS_NAME).append("g").attr("class", "interval");

            for (var _i = 1; _i <= _minorTicksPerInterval; _i++) {
              var currentMinorTickAngle = previousTickAngle + minorTickMultiplier * _i;
              axisIntervalSelection.append("line").datum(this.dataSet.rows[0]).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER + 2).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke", _axisTickColor).attr("stroke-width", "0.5").attr("shape-rendering", "geometricPrecision").attr("transform", "rotate(".concat(currentMinorTickAngle, ")"));
            }
          } // End of loop, currentTickAngleLineLocation becomes the previousTickAngle


          previousTickAngle = currentTickAngleLineLocation;
        }
      }
      /**
       * Used for calculating the font impact on an axis tick label, the bigger the font, the more distance the tick label will have from a tick
       * @param _fontSize The current font size
       * @param _tickAngle The current angle of the tick, depending on the angle more or less distance should be given to the tick label
       * @returns {number} The calculated impact multiplier the font has on the axis tick label
       */

    }, {
      key: "_calculateFontImpactOnAxisTickLabel",
      value: function _calculateFontImpactOnAxisTickLabel(_fontSize, _tickAngle) {
        var side = 180;
        var fontWeight = _fontSize / AXIS_FONT_WEIGHT;

        if (_tickAngle <= side && _tickAngle > side * 0.75 || _tickAngle >= side && _tickAngle < side + side * 0.25) {
          return 0.25 * fontWeight;
        }

        if (_tickAngle <= side) {
          return _tickAngle / side * fontWeight;
        }

        return (side * 2 - _tickAngle) / side * fontWeight;
      }
    }, {
      key: "_calculateAngle",
      value: function _calculateAngle(_value) {
        if (!this.isAxisInverted) {
          return this.startAngleInDegrees + (_value - this.minAxisValue) * this.angleScale;
        }

        return this.endAngleInDegrees - (_value - this.maxAxisValue) * this.angleScale;
      }
    }, {
      key: "_calculateLineAngle",
      value: function _calculateLineAngle(_value) {
        return this.startAngleInDegrees + (_value - (!this.isAxisInverted ? this.minAxisValue : this.maxAxisValue)) * this.angleScale;
      }
      /**
       * Used for securing a value to never go out of a given range
       * @param _value the value to be secured
       * @param _min the minimum of the range for the value to be in
       * @param _max the maximum of the range for the value to be in
       */

    }, {
      key: "_clamp",
      value: function _clamp(_value, _min, _max) {
        return Math.min(Math.max(_value, _min), _max);
      }
      /**
       * Used to apply truncation to a given text element, will only apply truncation if it meets the requirements
       * @param _textElement The text element that needs to be possibly be truncated
       * @param _maxWidth The max width that the text element is suposed to be. (If it goes over max width, truncation will apply till it no longer does)
       * @param _endingSection The optional ending section that will be applied to the end of the truncated label
       */

    }, {
      key: "_truncateTextLabel",
      value: function _truncateTextLabel(_textElement, _maxWidth) {
        var _endingSection = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";

        var currentText = _textElement.text(); // Check if the width of the text is too long


        if (_textElement.node().getBBox().width > _maxWidth) {
          // Keep reducing the width of the text as long as the width is longer than the maxWidth
          var iterator = currentText.length;

          while (_textElement.node().getBBox().width > _maxWidth && iterator > 0) {
            currentText = currentText.substring(0, iterator).trim();

            _textElement.text(currentText + _endingSection);

            iterator--;
          }

          if (_endingSection) currentText += _endingSection;
        }
      }
      /**
       * Use a formula to determine the coordinates of an element after it rotated
       * @param _x The X coordinate before rotation
       * @param _y The Y coordinate before rotation
       * @param _angleInDegrees The angle that shows the amount of rotation that has taken place
       * @returns {Point} The point with the new X and Y coordinates inside of it
       */

    }, {
      key: "_calculateCoordinatesAfterRotation",
      value: function _calculateCoordinatesAfterRotation(_x, _y, _angleInDegrees) {
        var point = new B();

        var angleInRadians = this._degreesToRadians(_angleInDegrees);

        point.y = _y * Math.cos(angleInRadians) + _x * Math.sin(angleInRadians);
        point.x = _x * Math.cos(angleInRadians) - _y * Math.sin(angleInRadians);
        return point;
      }
      /**
       * Check if overlapping occurs between labels
       * @param _firstLabel The first label that needs to be checked for overlapping
       * @param _secondLabel The second label that needs to be checked for overlapping
       * @param _deviation The optional deviation to be used for eliminating borderline cases, e.g. elements that look like they are overlapping but in reality are not
       */

    }, {
      key: "_checkLabelOverlap",
      value: function _checkLabelOverlap(_firstLabel, _secondLabel) {
        var _deviation = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 2;

        var firstLabelBBox = _firstLabel.node().getBBox();

        var secondLabelBBox = _secondLabel.node().getBBox(); // Get deltas from x and y coordinates, then investigate if these are smaller than the Box height and width, if both apply then overlapping occurs


        var checkHeight = this._delta(secondLabelBBox.y, firstLabelBBox.y) < firstLabelBBox.height + _deviation;

        var checkWidth = this._delta(secondLabelBBox.x, firstLabelBBox.x) < firstLabelBBox.width + _deviation;

        return checkHeight && checkWidth;
      }
      /**
       * Core decorations for the visualization, this will enable tooltip support for the core only
       */

    }, {
      key: "_enableCoreDecorations",
      value: function _enableCoreDecorations() {
        this.svg.select(".pointer").select("circle").datum(this.dataSet.rows[0]);
        this.svg.select(".pointer").select("polygon").datum(this.dataSet.rows[0]);
        this.svg.select(".labels").select("text.KPI-label").datum(this.dataSet.rows[0]);
        this.svg.select(".labels").select("text.value-label").datum(this.dataSet.rows[0]);
        this.svg.select(".target").select("line").datum(this.dataSet.rows[0]);
      }
      /**
       * Additional decorations for the visualization, this will enable tooltip support for the entire visualization
       */

    }, {
      key: "_enableFullDecorations",
      value: function _enableFullDecorations() {
        this._enableCoreDecorations();

        this.svg.select(".border").select("circle.inner-border").datum(this.dataSet.rows[0]);
        this.svg.select(".border").select("circle.outer-border").datum(this.dataSet.rows[0]);
      }
      /**
       * Formula for converting degrees to radians
       * @param _degrees Amount of degrees that need to be converted
       */

    }, {
      key: "_degreesToRadians",
      value: function _degreesToRadians(_degrees) {
        return _degrees * Math.PI / 180;
      }
    }, {
      key: "_delta",
      value: function _delta(_value1, _value2) {
        return Math.abs(_value1 - _value2);
      }
    }, {
      key: "_calculateStartAngle",
      value: function _calculateStartAngle() {
        return (360 - this._properties.get("sweep-angle")) / 2;
      } // Calculate the circle extra height (vertical distance from the bottom of the circle to center)
      // Chart has minimum extra height at sweep angle <= 180
      // maximum height at maximum angle ( 350 degree )

    }, {
      key: "_calculateCircleExtraHeight",
      value: function _calculateCircleExtraHeight() {
        var startAngle = this._calculateStartAngle();

        return ARC_END_RADIUS * Math.cos(this._degreesToRadians(startAngle));
      } // Calculate extra height of the chart (distance from chart bottom to center)
      // Comparing extra height of the circle and label offset

    }, {
      key: "_calculateChartExtraHeight",
      value: function _calculateChartExtraHeight() {
        if (this._properties.get("show-border")) return ARC_END_RADIUS; // always return full height when gauge border is shown

        var circleExtraHeight = this._calculateCircleExtraHeight();

        var labelOffset = this._properties.get("KPI-label-show") ? this._properties.get("KPI-label-offset") : 0;
        var valueOffset = this._properties.get("value-label-show") ? this._properties.get("value-label-offset") : 0;
        return this._clamp(Math.max(circleExtraHeight, labelOffset, valueOffset), 0, ARC_END_RADIUS);
      }
    }, {
      key: "_calculateViewBox",
      value: function _calculateViewBox(_extraGaugeHeight) {
        var maxGaugeExtraHeight = ARC_END_RADIUS;

        var showBorder = this._properties.get("show-border");

        var borderOffset = showBorder ? 0 : -10;
        var maxExtraHeight = 50 + borderOffset / 2; // Height including padding

        var minHeight = 50 + borderOffset / 2;
        var width = 100;
        var height = minHeight + Math.round(_extraGaugeHeight / maxGaugeExtraHeight * maxExtraHeight);

        var showPointerCircle = this._properties.get("show-pointer-circle");

        if (showPointerCircle) height = Math.max(height, minHeight + 3);
        return "0 0 ".concat(width + borderOffset * 2, " ").concat(height + borderOffset / 2);
      }
    }, {
      key: "_calculateTranslation",
      value: function _calculateTranslation(_extraGaugeHeight) {
        var maxExtraHeight = ARC_END_RADIUS;
        var maxYOffset = 10;
        var yOffset = maxYOffset - Math.round(_extraGaugeHeight / maxExtraHeight * maxYOffset);

        var showBorder = this._properties.get("show-border");

        var borderOffset = showBorder ? 0 : -10;
        return "translate(".concat(CENTER_X + borderOffset, " ").concat(CENTER_Y - yOffset + borderOffset / 2, ")");
      } // Create function that calculate maximum text width of KPI and value label
      // Based on their offset (y position) and current sweep angle, border visibility

    }, {
      key: "_createCalculateMaxTextWidthFn",
      value: function _createCalculateMaxTextWidthFn() {
        var _this2 = this;

        return function (_textOffset) {
          var padding = 3;

          var circleExtraHeight = _this2._calculateCircleExtraHeight();

          var innerRadius = ARC_START_RADIUS - padding * 2; // Vertical distance from first tick to circle center

          var firstTickHeight = ARC_START_RADIUS * Math.cos(_this2._degreesToRadians(_this2._calculateStartAngle())); // Text is under the whole gauge

          if (_textOffset > circleExtraHeight + padding) {
            if (_this2._properties.get("show-border")) return Math.sqrt(Math.pow(BORDER_START_RADIUS, 2) - Math.pow(_textOffset, 2)) * 2;else return 100;
          } // Text is between first tick and bottom of gauge
          else if (_textOffset > firstTickHeight) return Math.sqrt(Math.pow(ARC_END_RADIUS - padding, 2) - Math.pow(_textOffset, 2)) * 2; // Text is inside the inner circle
            else return Math.sqrt(Math.pow(innerRadius, 2) - Math.pow(_textOffset, 2)) * 2;
        };
      } //#region GETTERS AND SETTERS

    }, {
      key: "dataSet",
      get: function get() {
        return this._dataSet;
      },
      set: function set(_dataSet) {
        this._dataSet = _dataSet;
      }
    }, {
      key: "properties",
      get: function get() {
        return this._properties;
      },
      set: function set(_properties) {
        this._properties = _properties;
      }
    }, {
      key: "svg",
      get: function get() {
        return this._svg;
      },
      set: function set(_svg) {
        this._svg = _svg;
      }
    }, {
      key: "minAxisValue",
      get: function get() {
        return this._minAxisValue;
      },
      set: function set(_minAxisValue) {
        this._minAxisValue = _minAxisValue;
      }
    }, {
      key: "maxAxisValue",
      get: function get() {
        return this._maxAxisValue;
      },
      set: function set(_maxAxisValue) {
        this._maxAxisValue = _maxAxisValue;
      }
    }, {
      key: "angleScale",
      get: function get() {
        return this._angleScale;
      },
      set: function set(_angleScale) {
        this._angleScale = _angleScale;
      }
    }, {
      key: "startAngleInDegrees",
      get: function get() {
        return this._startAngleInDegrees;
      },
      set: function set(_startAngleInDegrees) {
        this._startAngleInDegrees = _startAngleInDegrees;
        this._endAngleInDegrees = 360 - _startAngleInDegrees;
      }
    }, {
      key: "endAngleInDegrees",
      get: function get() {
        return this._endAngleInDegrees;
      }
    }, {
      key: "isAxisInverted",
      get: function get() {
        return this._isAxisInverted;
      },
      set: function set(_isAxisInverted) {
        this._isAxisInverted = _isAxisInverted;
      }
    }, {
      key: "axisScaleLength",
      get: function get() {
        return this._axisScaleLength;
      },
      set: function set(_axisScaleLength) {
        this._axisScaleLength = _axisScaleLength;
      } //#endregion

    }]);

    return _default;
  }(st);

  return _default;

});
