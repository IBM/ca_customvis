define(['require', 'https://d3js.org/d3.v5.min.js'], (function (requirejs, d3) { 'use strict';

  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = Object.create(null);
    if (e) {
      Object.keys(e).forEach(function (k) {
        if (k !== 'default') {
          var d = Object.getOwnPropertyDescriptor(e, k);
          Object.defineProperty(n, k, d.get ? d : {
            enumerable: true,
            get: function () { return e[k]; }
          });
        }
      });
    }
    n["default"] = e;
    return Object.freeze(n);
  }

  var d3__namespace = /*#__PURE__*/_interopNamespace(d3);

  function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
  }
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function () {
      return !!t;
    })();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }
    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    Object.defineProperty(subClass, "prototype", {
      writable: false
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    } else if (call !== void 0) {
      throw new TypeError("Derived constructors may only return object or undefined");
    }
    return _assertThisInitialized(self);
  }

  class e{constructor(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}getName(){return this.name}getSlot(){return this.slot}getAttributes(){return this.attributes}static slotLimit(t,s){return new e("limit",t).attr("n",s)}static dataLimit(t){return new e("limit").attr("n",t)}attr(t,e){return this.attributes.set(t,e),this}}function s(t,e,s){return t.getDecoration(e,s)}function r(t){return t.hasDecoration("hasSelection")?s(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}class n{constructor(t,e){this.min=t,this.max=e;}asArray(){return [this.min,this.max]}}n.empty=new n(0,0);class o extends n{static fromRS(t){return new n(t.min,t.max)}constructor(t,e){super(t,e);}}class i{constructor(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";const s=t.getItems()||[];this.segments=s.map((t=>new c(t)));}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class l extends i{constructor(t,e){super(t,e);}}class a{constructor(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}}class c extends a{constructor(t){super(t);}}const u=new class{format(t){return t?t.toString():""}};var h;!function(t){t.label="label",t.data="data";}(h||(h={}));class p{constructor(t,e,s,r,n){this.source=t,this.tuples=e,this.segments=s,this.domain=r,this.caption=n;const o=t.dataItems||[],i=o.length>0?o[0]:null,l=i&&i.asCont();l?(this._labelFormatter=l.getFormatter("label")||u,this._dataFormatter=l.getFormatter("data")||u):this._labelFormatter=this._dataFormatter=u;}get mapped(){return this.source.mapped}get dataType(){const t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"}format(t,e){return function(t,e){return t.format(e)}(e===h.data?this._dataFormatter:this._labelFormatter,t)}}class g extends p{constructor(t,e,s,r,n){super(t,e,s,r,n);}}class f{constructor(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}get selected(){return s(this.source,"selected",!1)}get highlighted(){return s(this.source,"highlighted",!1)}tuple(t){const e=this._getSlot(t);if(!e||0===e.tuples.length)return null;const s=this.source.get(e.source);if(!s)return null;const r=s.asCat();return r?e.tuples[r.index]:null}value(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);if(!s)return null;const r=s.asCont();return r&&"numeric"===r.valueType?r.value:null}caption(t){const e=this._getSlot(t),s=e&&this.source.get(e.source);return s&&s.getCaption("data")||""}_getSlot(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null}}class d extends f{constructor(t,e){super(t,e);}}class m{constructor(t,e,s){this.source=t,this.rows=t.dataPoints.map((t=>new d(t,this))),this.cols=e,this.slotMap=s;}static filterRows(t,e,s){return t.filter((t=>{const r=t.tuple(e);return !!r&&r.key===s}))}get hasSelections(){return r(this.source)}}class y extends m{constructor(t,e,s){super(t,e,s);}}function _(t){const e=new Map,s=t.getSlots().map(((t,s)=>{let r=[],i=[],a=n.empty,u="";if(t.isMapped()){const e=t.getDataItem(0);if(u=e.getCaption("label"),"cat"===e.getRSType()){r=e.getTuples().map(((t,e)=>new l(t,e)));i=e.getItemClassSet(0).getItemClasses().map((t=>new c(t)));}else a=o.fromRS(e.getDomain()),i.push(new c(e.getItemClass()));}const h=new g(t,r,i,a,u);return e.set(t.name,h),h}));return new y(t,s,e)}const w=/^\s*#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{0,2})\s*$/,C=/^\s*rgba?\s*\(\s*(\d+\%?)\s*,\s*(\d+\%?)\s*,\s*(\d+\%?)\s*(?:,\s*(\d+(?:\.\d+)?\%?)\s*)?\)\s*/;function b(t){return t<0?0:t>255?255:Math.floor(t)}class S{constructor(t,e,s,r){var n;this.r=b(t),this.g=b(e),this.b=b(s),this.a=(n=r)<0?0:n>1?1:n;}static darker(t,e){const s=e?Math.pow(.7,e):.7;return new S(t.r*s,t.g*s,t.b*s,t.a)}static fromObject(t){return new S(t.r,t.g,t.b,void 0===t.a?1:t.a)}static fromString(t){const e=C.exec(t);let s=e||w.exec(t);const r=e?void 0:16;if(!s)return null;const n=parseInt(s[1],r),o=parseInt(s[2],r),i=parseInt(s[3],r);let l;return s[4]&&(l=e?parseFloat(s[4]):Math.round(parseInt(s[4],r)/255*100)/100),this.fromObject({r:n,g:o,b:i,a:l})}toString(){return 1===this.a?`rgb(${this.r},${this.g},${this.b})`:`rgba(${this.r},${this.g},${this.b},${this.a})`}}function x(t,e){let s=null;if(t instanceof f)s=t.source.getDataSet(e);else {const r=t.source.getDataItem(e);s=r&&r.getDataSet(e);}return !!s&&r(s)}const I=t=>`rgba(${t.r},${t.g},${t.b},0.4)`,j=t=>`rgba(${Math.round(.7*t.r)},${Math.round(.7*t.g)},${Math.round(.7*t.b)},${t.a})`;class E{constructor(t,e,s){this.source=t,this._dataContext=e,this._slotResolver=s;}get slot(){return this.source.slot}getColor(t){return t?S.fromObject(this.source.getTupleColor(t.source,-1)):S.fromObject(this.source.getColor(null))}_getTuple(t){if(t instanceof i)return t;let e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null}getFillColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),!t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){if(null===t)return this.source.getColor(null).toString();const e=this._getTuple(t);let s;return s=e?this.source.getTupleColor(e.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class P{constructor(t,e,s){this.color=t,this.at=e,this.value=s;}}function D(t){return t.map((t=>new P(S.fromObject(t.color),t.at,t.value)))}class F{constructor(t,e,s){this.source=t,this._slot=e,this._dataContext=s,this.stops=D(t.stops),this.aligned=D(t.aligned),this.interpolate=t.interpolate;}getColor(t){return S.fromObject(this.source.getColor(t))}getFillColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return !t.selected&&x(t,this._dataContext)?I(s):s.toString()}getOutlineColor(t){const e=this._slot?Number(t.value(this._slot)):0,s=this.source.getColor(e);return t.highlighted||t.selected&&x(t,this._dataContext)?j(s):null}}class T{constructor(t,e,s){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=s;}get slot(){return this.source.slot}getColorStops(t){const e=t?t.source.getDataItem(0):null,s=e&&e.asCont();let r=s?s.getDomain(null):null;const n=this.source.getColorStops(s,r),o=t?t.source.name:null;return new F(n,o,this._dataContext)}_fetchColorStops(t){const e=t.source.getDataSet(this._dataContext),s=this.slot||this._slotResolver(t.dataSet,this.source.name),r=s?e.getSlot(s):null,n=r?r.getDataItem(0):null,o=n?n.asCont():null;if(this.source.dirty||!this._cachedStops||o!==this._lastDataItem){const t=o?o.getDomain(null):null,e=this.source.getColorStops(o,t);this._cachedStops=new F(e,r&&r.name,this._dataContext),this._lastDataItem=o;}return this._cachedStops}getFillColor(t){return this._fetchColorStops(t).getFillColor(t)}getOutlineColor(t){return this._fetchColorStops(t).getOutlineColor(t)}}class A extends S{constructor(t){super(t.r,t.g,t.b,t.a),this._color=t;}getRed(){return this.r}getGreen(){return this.g}getBlue(){return this.b}getAlpha(){return this.a}}const O=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:()=>0,getMax:()=>0,isEmpty:()=>!0,isExplicit:()=>!1});class ${constructor(t,e,s,r,n,o){this.caption=t,this.color=e,this.shape=s,this.selected=r,this.highlighted=n,this.ref=o;}getCaption(){return this.caption}getColor(){return this.color?new A(this.color):null}getShape(){return this.shape}isSelected(){return this.selected}isHighlighted(){return this.highlighted}getRef(){return this.ref}}class R{constructor(t,e,s,r,n,o){this.type=t,this.channel=e,this.slot=s,this.caption=r,this.subCaption=n,this.ref=o;}getRSType(){return this.type}getChannel(){return this.channel}getSlot(){return this.slot}getCaption(){return this.caption}getSubCaption(){return this.subCaption}getRef(){return this.ref}}class M extends R{constructor(t,e,r,n,o){const i=e&&e.source,l=i&&i.name,a=i&&i.getDataItem(0),c=a&&a.asCat();super("cat",t,l,r,"",c);const u=c?c.tuples:[];this.entries=u.map((t=>{const e=t.getCaption("label")||"",r=o&&o.source.getTupleColor(t,-1),i=s(t,"selected",!1),l=s(t,"highlighted",!1);return new $(e,r?S.fromObject(r):null,n,i,l,t)}));}getEntries(){return this.entries}}class L extends R{constructor(t,e,s,r){const n=e&&e.source,o=n&&n.name,i=n&&n.getDataItem(0),l=i&&i.asCont();if(super("cont",t,o,s,"",l),this.domain=l?l.getDomain(null):O,r&&"color"===t){const t=r.source.getColorStops(l,null);this.stops=t.stops,this.interpolate=t.interpolate;}else this.stops=null,this.interpolate=!1;}getDomain(){return this.domain}getInterpolate(){return this.interpolate}getStops(){return this.stops}}function k(t,e,s,r){if(!t)return [];const n=new Map,o=new Map;e.palettes.forEach((e=>{const s=e.slot||r&&r(t,e.source.name);s&&(e instanceof E?n.set(s,e):e instanceof T&&o.set(s,e));}));const i=[];return t.cols.forEach((t=>{const e=t.source;if(!e.mapped)return;const r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;const r=n.get(e.name);r&&i.push(new M("color",t,t.caption,s.legendShape,r));break;case"cont":if(-1!==e.channels.indexOf("color")){const s=o.get(e.name);s&&i.push(new L("color",t,t.caption,s));}-1!==e.channels.indexOf("size")&&i.push(new L("size",t,t.caption,null));}})),i}class z{constructor(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;}}class N{constructor(){this.x=0,this.y=0;}}var B,H,U;!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(B||(B={}));class V{constructor(t,e){this.value=t,this.unit=e;}static fromObject(t){return new V(t.value,function(t){switch(t){case"em":return B.Em;case"%":return B.Percentage;case"cm":return B.Centimeter;case"mm":return B.Millimeter;case"in":return B.Inch;case"pc":return B.Pica;case"pt":return B.Point;case"px":return B.Pixel;default:throw new Error(`Invalid length unit '${t}' specified`)}}(t.unit))}toString(){return `${this.value}${this.unit}`}}!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));const q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){let e=[];if(t)for(let s=0,r=t.length;s<r;++s){const r=t[s],n=q.test(r);e.push(n?`"${r}"`:r);}return e.join(", ")}class J{constructor(t,e,s,r){this.family=t,this.size=e,this.style=s,this.weight=r;}static fromObject(t){const e=t.family||null,s=t.size?V.fromObject(t.size):null,r=t.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error(`Invalid font style '${t}' specified`)}}(t.style):null,n=void 0!==t.weight&&null!==t.weight?t.weight:null;return new J(e,s,r,n)}toString(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){const t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){const e=[];let s=G(t.family);var r;return s.length>0&&e.push(`font-family: ${s};`),s=t.size?t.size.toString():"",s.length>0&&e.push(`font-size: ${s};`),s=(r=t.style)?r.toString():"",s.length>0&&e.push(`font-style: ${s};`),s=K(t.weight),s.length>0&&e.push(`font-weight: ${s};`),e.join(" ")}(this)}}class Q{constructor(t,e,s){const r=new Map;null!==t&&t.forEach(((t,n)=>{if("palette"===t.type){const o=t;switch(o.paletteType){case"cat":r.set(n,new E(o,e,s));break;case"cont":r.set(n,new T(o,e,s));}}})),this.source=t,this.palettes=r;}get(t){return this._getValue(t,!1)}peek(t){return this._getValue(t,!0)}_getValue(t,e){const s=this.source&&this.source.get(t);if(!s)return null;switch(s.type){case"string":case"number":case"boolean":case"enum":return e?s.peek:s.value;case"length":const r=e?s.peek:s.value;return r?V.fromObject(r):null;case"font":const n=e?s.peek:s.value;return n?J.fromObject(n):null;case"color":const o=e?s.peek:s.value;return o?S.fromObject(o):null;case"palette":return this.palettes.get(t)||null;default:return null}}isActive(t){const e=this.source&&this.source.get(t);return !!e&&e.active}setActive(t,e){const s=this.source&&this.source.get(t);s&&s.setActive(e);}isDirty(t){const e=this.source&&this.source.get(t);return !!e&&e.dirty}}function W(t,e){this.name="AggregateError",this.errors=t,this.message=e||"";}W.prototype=Error.prototype;var X=setTimeout;function Y(t){return Boolean(t&&void 0!==t.length)}function Z(){}function tt(t){if(!(this instanceof tt))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],it(t,this);}function et(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,tt._immediateFn((function(){var s=1===t._state?e.onFulfilled:e.onRejected;if(null!==s){var r;try{r=s(t._value);}catch(t){return void rt(e.promise,t)}st(e.promise,r);}else (1===t._state?st:rt)(e.promise,t._value);}))):t._deferreds.push(e);}function st(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var s=e.then;if(e instanceof tt)return t._state=3,t._value=e,void nt(t);if("function"==typeof s)return void it((r=s,n=e,function(){r.apply(n,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){rt(t,e);}var r,n;}function rt(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&tt._immediateFn((function(){t._handled||tt._unhandledRejectionFn(t._value);}));for(var e=0,s=t._deferreds.length;e<s;e++)et(t,t._deferreds[e]);t._deferreds=null;}function ot(t,e,s){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=s;}function it(t,e){var s=!1;try{t((function(t){s||(s=!0,st(e,t));}),(function(t){s||(s=!0,rt(e,t));}));}catch(t){if(s)return;s=!0,rt(e,t);}}tt.prototype.catch=function(t){return this.then(null,t)},tt.prototype.then=function(t,e){var s=new this.constructor(Z);return et(this,new ot(t,e,s)),s},tt.prototype.finally=function(t){var e=this.constructor;return this.then((function(s){return e.resolve(t()).then((function(){return s}))}),(function(s){return e.resolve(t()).then((function(){return e.reject(s)}))}))},tt.all=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,i){try{if(i&&("object"==typeof i||"function"==typeof i)){var l=i.then;if("function"==typeof l)return void l.call(i,(function(e){o(t,e);}),s)}r[t]=i,0==--n&&e(r);}catch(t){s(t);}}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.any=function(t){var e=this;return new e((function(s,r){if(!t||void 0===t.length)return r(new TypeError("Promise.any accepts an array"));var n=Array.prototype.slice.call(t);if(0===n.length)return r();for(var o=[],i=0;i<n.length;i++)try{e.resolve(n[i]).then(s).catch((function(t){o.push(t),o.length===n.length&&r(new W(o,"All promises were rejected"));}));}catch(t){r(t);}}))},tt.allSettled=function(t){return new this((function(e,s){if(!t||void 0===t.length)return s(new TypeError(typeof t+" "+t+" is not iterable(cannot read property Symbol(Symbol.iterator))"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var n=r.length;function o(t,s){if(s&&("object"==typeof s||"function"==typeof s)){var i=s.then;if("function"==typeof i)return void i.call(s,(function(e){o(t,e);}),(function(s){r[t]={status:"rejected",reason:s},0==--n&&e(r);}))}r[t]={status:"fulfilled",value:s},0==--n&&e(r);}for(var i=0;i<r.length;i++)o(i,r[i]);}))},tt.resolve=function(t){return t&&"object"==typeof t&&t.constructor===tt?t:new tt((function(e){e(t);}))},tt.reject=function(t){return new tt((function(e,s){s(t);}))},tt.race=function(t){return new tt((function(e,s){if(!Y(t))return s(new TypeError("Promise.race accepts an array"));for(var r=0,n=t.length;r<n;r++)tt.resolve(t[r]).then(e,s);}))},tt._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){X(t,0);},tt._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};class lt{constructor(t,e,s,r){this.data=t,this.decorations=e,this.properties=s,this.size=r;}}class at{constructor(t,e,s,r,n){this.reason=t,this.data=e,this.node=s,this.props=r,this.locale=n;}}class ct{constructor(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new z;}init(t,e){const s=t.surface.appendChild(document.createElement("div"));s.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),s.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,tt.resolve(this.create(s)).then((r=>{this._elem=r||s;t.properties.forEach(((t,e)=>this.updateProperty(e,t.value))),e.complete();})).catch((t=>{e.fail(t);}));}destroy(){}getPropertyApi(){return null}setData(t){t&&t.dataSets&&t.dataSets[0]?this._data=_(t.dataSets[0]):this._data=null;}setProperty(t,e){this.updateProperty(t,this.properties.peek(t));}getBlockingRequests(){return null}render(t,e,s){if(!this._elem)return s.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return s.complete(null,null,null),null;try{const t=this.update(new at(function(t){return new lt(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));tt.resolve(t).then((()=>s.complete(null,null,null))).catch(s.error);}catch(t){s.error(t);}return null}getEncodings(){return this._data?this.updateLegend(this._data):[]}getCapabilities(){const t=[];return this.meta.slotLimits.forEach(((s,r)=>{t.push(e.slotLimit(r,s));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t}getInteractivity(){return null}getVisCoordinate(t,e){return e}getRegionAtPoint(t,e){return null}getItemsAtPoint(t,e,s){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;const r=t,n=document.elementFromPoint(r.x,r.y),o=this.hitTest(n,r,e);return Array.isArray(o)?o.length?[...o.map((t=>t.source))]:[]:o&&o.source?[o.source]:[]}getItemsInPolygon(t,e){return []}getAxisItemsAtPoint(t,e,s){return []}getState(){return null}setState(t){}loadCss(t){const e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);}toUrl(e){return requirejs.toUrl(e)}update(t){}create(t){}updateProperty(t,e){}updateLegend(t){return k(t,this.properties,this.meta,this._slotResolver)}getSlotForPalette(t,e){return null}hitTest(t,e,s){const r=t&&t.__data__;return r&&r.source?r:null}nls(t){return this._nls&&this._nls.get(t)||""}}

  // General global settings
  var ACTUAL_VALUE_SLOT = 0;
  var MAX_AXIS_VALUE_SLOT = 1;
  var CENTER_X = 200;
  var CENTER_Y = 200;
  var BORDER_START_RADIUS = 152;
  var ARC_START_RADIUS = 116;
  var ARC_END_RADIUS = 140;
  var POINTER_INDICATOR_LENGTH = ARC_END_RADIUS - 4;
  var POINTER_INDICATOR_SIZE = 6;
  var POINTER_INDICATOR_ANIMATION_DURATION_IN_MS = 1000;
  var MAIN_AXIS_TICKS = 2; // results in default being min and max tick
  var AXIS_TICKS_DISTANCE_FROM_CENTER = 120;
  var STANDARD_TICK_SIZE = 20;
  var AXIS_TICK_TEXT_MAX_WIDTH = 60;
  var AXIS_TICK_TEXT_DISTANCE_FROM_TICKS = 10;
  var AXIS_FONT_WEIGHT = 1.25;
  var STANDARD_TRUNCATION_END_SECTION = "...";
  var STANDARD_FONT_SIZE = 12;

  // CSS global class names
  var VISUALIZATION_CLASS_NAME = "gas-gauge";
  var AXIS_CLASS_NAME = "axis";
  var POINTER_INDICATOR_CLASS_NAME = "pointer-indicator";
  var POINTER_CIRCLE_CLASS_NAME = "pointer-circle";
  var TARGET_INDICATOR_CLASS_NAME = "target-indicator";
  var OUTER_BORDER_CLASS_NAME = "outer-border";
  var INNER_BORDER_CLASS_NAME = "inner-border";
  function applyFont(_selection, _font) {
    _selection.style("font-size", _font.size ? _font.size.toString() : new V(STANDARD_FONT_SIZE, B.Pixel).toString()).style("font-family", _font.family ? _font.family.toString() : null).style("font-style", _font.style ? _font.style.toString() : null).style("font-weight", _font.weight ? _font.weight.toString() : null);
  }
  var _default = /*#__PURE__*/function (_RenderBase) {
    function _default() {
      var _this;
      _classCallCheck(this, _default);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _callSuper(this, _default, [].concat(args));
      // Private fields
      _defineProperty(_this, "_dataSet", void 0);
      _defineProperty(_this, "_svg", void 0);
      _defineProperty(_this, "_minAxisValue", void 0);
      _defineProperty(_this, "_maxAxisValue", void 0);
      _defineProperty(_this, "_angleScale", void 0);
      _defineProperty(_this, "_startAngleInDegrees", void 0);
      _defineProperty(_this, "_endAngleInDegrees", void 0);
      _defineProperty(_this, "_isAxisInverted", void 0);
      _defineProperty(_this, "_axisScaleLength", void 0);
      _defineProperty(_this, "_lastAngleValue", null);
      // last angle  value that was rendered
      _defineProperty(_this, "_KPILabel", void 0);
      _defineProperty(_this, "_valueLabel", void 0);
      _defineProperty(_this, "_arcGenerator", d3__namespace.arc());
      return _this;
    }
    _inherits(_default, _RenderBase);
    return _createClass(_default, [{
      key: "create",
      value: function create(_node) {
        // Create an svg canvas that sizes to its parent.
        // Note that Safari has issues determining the SVG's size upon rerender: we need position: absolute
        var svg = d3__namespace.select(_node).append("svg").style("position", "absolute").attr("viewBox", "0 0 400 400").attr("width", "100%").attr("height", "100%");

        // Create a group for the chart
        var chart = svg.append("g").attr("class", "".concat(VISUALIZATION_CLASS_NAME));

        // Create a group for the center of the chart
        var center = chart.append("g").attr("class", "center").attr("transform", "translate(".concat(CENTER_X, " ").concat(CENTER_Y, ")"));

        // Create all group elements attached to the center
        var border = center.append("g").attr("class", "border");
        center.append("g").attr("class", "arc");
        center.append("g").attr("class", "".concat(AXIS_CLASS_NAME));
        var labels = center.append("g").attr("class", "labels");
        var target = center.append("g").attr("class", "target");
        var pointer = center.append("g").attr("class", "pointer");
        border.append("circle").attr("class", OUTER_BORDER_CLASS_NAME);
        border.append("circle").attr("class", INNER_BORDER_CLASS_NAME);
        pointer.append("circle").attr("class", POINTER_CIRCLE_CLASS_NAME).attr("cx", 0).attr("cy", 0).attr("r", "24").style("stroke-width", "2");
        this._KPILabel = labels.append("text").attr("class", "KPI-label").style("fill", "black").style("text-anchor", "middle");
        this._valueLabel = labels.append("text").attr("class", "value-label").style("fill", "black").style("text-anchor", "middle");
        target.append("line").attr("class", TARGET_INDICATOR_CLASS_NAME).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke-width", "4");

        // Return the svg node as the visualization root node.
        return svg.node();
      }
    }, {
      key: "update",
      value: function update(_info) {
        // Update dataSet, svg and properties
        this.dataSet = _info.data;
        this.svg = d3__namespace.select(_info.node);
        this.minAxisValue = this.properties.get("min-axis-value");
        var maxAxisValueProperty = this.properties.get("max-axis-value");
        this.startAngleInDegrees = this._calculateStartAngle();
        if (this.dataSet && this.dataSet.rows.length) {
          if (this.dataSet.rows[0].value("max-axis-value")) {
            this.maxAxisValue = this.dataSet.rows[0].value("max-axis-value");
            this.properties.setActive("max-axis-value", false);
          } else {
            this.maxAxisValue = maxAxisValueProperty;
            this.properties.setActive("max-axis-value", true);
          }
        }
        if (!this.dataSet || !this.dataSet.rows.length || this.minAxisValue === this.maxAxisValue) {
          // Empty all labels
          this.svg.select("text.value-label").text("");
          this.svg.select("text.KPI-label").text("");

          // Remove the pointer, axis and target indicator
          this.svg.select("." + POINTER_INDICATOR_CLASS_NAME).remove();
          this.svg.selectAll("." + AXIS_CLASS_NAME).selectAll("g").remove();
          this.svg.select(".arc").selectAll("path").remove();
          this.svg.select("." + TARGET_INDICATOR_CLASS_NAME).attr("visibility", "hidden");

          // No data, reset lastAngleValue
          this._lastAngleValue = null;
          this._updateMainProperties();
          return;
        }

        // Update the inverted axis boolean
        this.isAxisInverted = this.maxAxisValue < this.minAxisValue;
        if (_info.reason.properties) {
          this._updateAllProperties();
          if (!_info.reason.data) {
            this._updateAngleScale();
            this._updatePointerIndicator();
            this._updateTargetIndicator();
            this._updateArc();
            this._updateAxis();
          }
        }
        if (_info.reason.data) {
          if (!_info.reason.properties) {
            this._updateLabels();
          }
          this._updateAngleScale();
          this._updatePointerIndicator();
          this._updateTargetIndicator();
          this._updateArc();
          this._updateAxis();
        }
        if (_info.reason.decorations) {
          // Choose between _enableFullDecorations or _enableCoreDecorations functions for tooltip support
          this._enableFullDecorations();
        }
        if (this._lastAngleValue === null) {
          this._lastAngleValue = this.startAngleInDegrees;
        }
      }
    }, {
      key: "_updateAllProperties",
      value: function _updateAllProperties() {
        this._updateMainProperties();
        this._updateLabels();
      }
    }, {
      key: "_updateLabels",
      value: function _updateLabels() {
        var valueColumn = this.dataSet.cols[ACTUAL_VALUE_SLOT];
        var KPILabelValue = valueColumn.caption;
        var ValueLabelValue = valueColumn.format(this.dataSet.rows[0].value("value"));
        this.svg.select("text.KPI-label").call(applyFont, this.properties.get("KPI-label-font")).style("fill", this.properties.get("KPI-label-font-color")).text(this.properties.get("KPI-label-show") ? KPILabelValue : "");
        this.svg.select("text.value-label").call(applyFont, this.properties.get("value-label-font")).style("fill", this.properties.get("value-label-font-color")).text(this.properties.get("value-label-show") ? ValueLabelValue : "");
        var calculateMaxTextWidth = this._createCalculateMaxTextWidthFn();
        var kpiLabelMaxWidth = calculateMaxTextWidth(this.properties.get("KPI-label-offset"));
        var valueLabelMaxWidth = calculateMaxTextWidth(this.properties.get("value-label-offset"));
        this._truncateTextLabel(this._KPILabel, kpiLabelMaxWidth, STANDARD_TRUNCATION_END_SECTION);
        this._truncateTextLabel(this._valueLabel, valueLabelMaxWidth, STANDARD_TRUNCATION_END_SECTION);
      }

      /**
       * Called for updating the main properties that should always render even if there is no data
       */
    }, {
      key: "_updateMainProperties",
      value: function _updateMainProperties() {
        this.svg.style("background-color", this.properties.get("background-color"));
        var borderSize = this.properties.get("border-size");
        this.svg.select("." + OUTER_BORDER_CLASS_NAME).style("stroke", this.properties.get("outer-border-stroke")).style("fill", this.properties.get("elements-background-color")).attr("r", BORDER_START_RADIUS + borderSize).style("stroke-width", 1 / 6 * borderSize);
        this.svg.select("." + INNER_BORDER_CLASS_NAME).style("stroke", this.properties.get("inner-border-stroke")).style("fill", this.properties.get("elements-background-color")).attr("r", BORDER_START_RADIUS + borderSize / 2).style("stroke-width", 5 / 6 * borderSize);
        this.svg.select("." + POINTER_CIRCLE_CLASS_NAME).style("stroke", this.properties.get("pointer-circle-stroke")).style("fill", this.properties.get("pointer-circle-fill"));
        var showBorder = this.properties.get("show-border");
        this.svg.select(".border").style("display", showBorder ? "inherit" : "none");
        this.properties.setActive("outer-border-stroke", showBorder);
        this.properties.setActive("inner-border-stroke", showBorder);
        this.properties.setActive("border-size", showBorder);
        this.svg.select("text.KPI-label").attr("y", this.properties.get("KPI-label-offset"));
        this.svg.select("text.value-label").attr("y", this.properties.get("value-label-offset"));
        var showPointerCircle = this.properties.get("show-pointer-circle");
        this.svg.select("circle.pointer-circle").style("display", showPointerCircle ? "inherit" : "none");
        this.properties.setActive("pointer-circle-fill", showPointerCircle);
        this.properties.setActive("pointer-circle-stroke", showPointerCircle);
        var extraHeight = this._calculateChartExtraHeight();
        this.svg.attr("viewBox", this._calculateViewBox(extraHeight));
        this.svg.select("g.center").attr("transform", this._calculateTranslation(extraHeight));
      }
    }, {
      key: "_updateAngleScale",
      value: function _updateAngleScale() {
        this.axisScaleLength = this._delta(this.minAxisValue, this.maxAxisValue);
        this.angleScale = (this.endAngleInDegrees - this.startAngleInDegrees) / this.axisScaleLength;
      }
    }, {
      key: "_updateTargetIndicator",
      value: function _updateTargetIndicator() {
        var targetSlotValue = this.dataSet.rows[0].value("target");
        var targetColor = this.properties.get("target-color");

        // If the target slot has no value, set the target-value property to true, otherwise set it to false
        if (!targetSlotValue) {
          this.properties.setActive("target-value", true);
        } else {
          this.properties.setActive("target-value", false);
        }

        // If the target is set to hidden, change the visibility of the target and return
        if (!this.properties.get("target-show")) {
          this.svg.select("." + TARGET_INDICATOR_CLASS_NAME).attr("visibility", "hidden");
          return;
        }

        // Set target value to the target slot if it has a value (is mapped), otherwise use the target-value property
        var targetValue = targetSlotValue || this.properties.get("target-value");

        // Calculate the target indicator angle and secure the angle limits
        var targetIndicatorAngle = this._clamp(this._calculateAngle(targetValue), this.startAngleInDegrees, this.endAngleInDegrees);
        this.svg.select("." + TARGET_INDICATOR_CLASS_NAME).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke", targetColor).attr("stroke-width", "4").attr("visibility", "visible").attr("transform", "rotate(".concat(targetIndicatorAngle, ")"));
      }
    }, {
      key: "_updateArc",
      value: function _updateArc() {
        this.svg.select(".arc").selectAll("path").remove();
        this._createArcPiece(this.properties.get("first-interval-start"), this.properties.get("first-interval-end"), this.properties.get("first-interval-color"));
        this._createArcPiece(this.properties.get("second-interval-start"), this.properties.get("second-interval-end"), this.properties.get("second-interval-color"));
        this._createArcPiece(this.properties.get("third-interval-start"), this.properties.get("third-interval-end"), this.properties.get("third-interval-color"));
      }

      /**
       * Used for creating a single arc piece that contributes to building the entire arc
       * @param _startValueInPercentage The starting value of the arc piece in percentage
       * @param _endValueInPercentage The ending value of the arc piece in percentage
       * @param _color The color of the arc piece
       */
    }, {
      key: "_createArcPiece",
      value: function _createArcPiece(_startValueInPercentage, _endValueInPercentage, _color) {
        var arcGeneratorStandardAngle = 180; // Standard arc start angle, use this to normalize the actual angle
        var startValueInDecimals = (_startValueInPercentage > 100 ? 100 : _startValueInPercentage) / 100;
        var endValueInDecimals = (_endValueInPercentage > 100 ? 100 : _endValueInPercentage) / 100;
        var startAngle = this._clamp(startValueInDecimals * (this.endAngleInDegrees - this.startAngleInDegrees) + this.startAngleInDegrees, this.startAngleInDegrees, this.endAngleInDegrees);
        var endAngle = this._clamp(endValueInDecimals * (this.endAngleInDegrees - this.startAngleInDegrees) + this.startAngleInDegrees, this.startAngleInDegrees, this.endAngleInDegrees);
        var intervalData = this._arcGenerator({
          startAngle: this._degreesToRadians(startAngle - arcGeneratorStandardAngle),
          endAngle: this._degreesToRadians(endAngle - arcGeneratorStandardAngle),
          innerRadius: ARC_START_RADIUS,
          outerRadius: ARC_END_RADIUS
        });
        this.svg.select(".arc").datum(this.dataSet.rows[0]).append("path").attr("d", intervalData).style("fill", _color);
      }

      /**
       * Used for updating the axis with new data
       */
    }, {
      key: "_updateAxis",
      value: function _updateAxis() {
        // Get properties needed to create the axis
        var minorTicksPerInterval = this.properties.get("minor-ticks-per-interval");
        var extraMajorTicksValue = this.properties.get("major-ticks-count");
        var axisTickColor = this.properties.get("axis-tick-color");
        var axisFontColor = this.properties.get("axis-font-color");
        var font = this.properties.get("axis-font");

        // Create the axis
        this._createCustomAxis(extraMajorTicksValue, minorTicksPerInterval, axisTickColor, axisFontColor, font);
      }

      /**
       * Used for updating the pointer indicator when the actual value slot has been updated or the axis has changed
       */
    }, {
      key: "_updatePointerIndicator",
      value: function _updatePointerIndicator() {
        // Get value from value slot
        var valueSlotValue = this.dataSet.rows[0].value("value");

        // Calculate the pointer indicator angle and secure the angle limits
        var pointerIndicatorAngle = this._clamp(this._calculateAngle(valueSlotValue), this.startAngleInDegrees, this.endAngleInDegrees);
        var pointerIndicator = this.svg.select(".pointer").selectAll("polygon").data(this.dataSet.rows, function (row) {
          return row.key;
        });
        var lastAngleValue = this._lastAngleValue;
        this._lastAngleValue = pointerIndicatorAngle;
        pointerIndicator.enter().insert("polygon", ":first-child").attr("points", "-".concat(POINTER_INDICATOR_SIZE, ",0 ").concat(POINTER_INDICATOR_SIZE, ",0 0,").concat(POINTER_INDICATOR_LENGTH)).attr("transform", "rotate(".concat(this.startAngleInDegrees, ")")).attr("class", POINTER_INDICATOR_CLASS_NAME).style("stroke-width", "2").merge(pointerIndicator).style("stroke", this.properties.get("pointer-indicator-stroke")).style("fill", this.properties.get("pointer-indicator-fill")).transition().duration(POINTER_INDICATOR_ANIMATION_DURATION_IN_MS).tween("pointerindicator.transform", function () {
          var elem = d3__namespace.select(this);
          var interpolator = d3__namespace.interpolateString("rotate( ".concat(lastAngleValue, " )"), "rotate( ".concat(pointerIndicatorAngle, " )"));
          return function (value) {
            return elem.attr("transform", interpolator(value));
          };
        });
      }

      /**
       * Used for creating the custom axis that is needed in this visualization
       * @param _extraMajorTicks The amount of extra major ticks that need to applied to the axis ticks. (Standard has the main axis ticks only)
       * @param _minorTicksPerInterval The amount of minor ticks per interval (in between major ticks)
       * @param _axisTickColor The color of the axis ticks
       * @param _axisFontColor The font color of the major axis tick labels
       * @param _font The font of the major axis tick labels
       */
    }, {
      key: "_createCustomAxis",
      value: function _createCustomAxis(_extraMajorTicks, _minorTicksPerInterval, _axisTickColor, _axisFontColor, _font) {
        var totalMajorTicks = Math.max(_extraMajorTicks + MAIN_AXIS_TICKS, MAIN_AXIS_TICKS);
        var previousTickAngle;
        var previousMajorTickLabel;

        // Clear all elements
        this.svg.select("." + AXIS_CLASS_NAME).selectAll("g").remove();
        for (var i = 0; i < totalMajorTicks; i++) {
          // Set up all the variables needed to create the axis
          var totalTicksIndexed = totalMajorTicks - 1; // Start at 0 instead of 1
          var currentTickAsMultiplier = i / totalTicksIndexed;
          var value = this._clamp(currentTickAsMultiplier * this.axisScaleLength + (this.isAxisInverted ? this.minAxisValue : this.maxAxisValue) - this.axisScaleLength, this.isAxisInverted ? this.maxAxisValue : this.minAxisValue, this.isAxisInverted ? this.minAxisValue : this.maxAxisValue);
          var fontSize = _font && _font.size ? _font.size.value : STANDARD_FONT_SIZE;
          var currentTickAngleLineLocation = this._clamp(this._calculateLineAngle(value), this.startAngleInDegrees, this.endAngleInDegrees);
          var currentTickAngleTextLocation = this._clamp(this._calculateAngle(value), this.startAngleInDegrees, this.endAngleInDegrees);
          var majorTickSelection = this.svg.select("." + AXIS_CLASS_NAME).append("g").attr("class", "major-tick");

          // Create main ticks
          majorTickSelection.append("line").datum(this.dataSet.rows[0]).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke", _axisTickColor).attr("stroke-width", "4").attr("shape-rendering", "geometricPrecision").attr("transform", "rotate(".concat(currentTickAngleLineLocation, ")"));
          var showMajorTicksText = this.properties.get("show-major-tick-text");
          var maxAxisValueColumn = this.dataSet.cols[MAX_AXIS_VALUE_SLOT];
          var formattedMajorTickText = maxAxisValueColumn.mapped ? maxAxisValueColumn.format(value) : this.dataSet.cols[ACTUAL_VALUE_SLOT].format(value);

          // Create text labels
          if (showMajorTicksText || !showMajorTicksText && (i === 0 || i === totalTicksIndexed)) {
            var majorTickLabel = majorTickSelection.append("text").datum(this.dataSet.rows[0]).call(applyFont, _font).style("fill", _axisFontColor).style("text-anchor", "middle").text(formattedMajorTickText);
            this._truncateTextLabel(majorTickLabel, AXIS_TICK_TEXT_MAX_WIDTH, STANDARD_TRUNCATION_END_SECTION);
            var y = AXIS_TICKS_DISTANCE_FROM_CENTER - AXIS_TICK_TEXT_DISTANCE_FROM_TICKS - majorTickLabel.node().getBBox().width / 4 - this._calculateFontImpactOnAxisTickLabel(fontSize, currentTickAngleLineLocation);
            var point = this._calculateCoordinatesAfterRotation(0, y, currentTickAngleTextLocation);
            majorTickLabel.attr("x", point.x).attr("y", point.y + majorTickLabel.node().getBBox().height / 4);

            // Check if labels overlap
            if (previousMajorTickLabel && this._checkLabelOverlap(majorTickLabel, previousMajorTickLabel)) {
              // Main tick always has priority over Major tick, therefore the previous label will be removed
              if (i === totalTicksIndexed) {
                previousMajorTickLabel.remove();
              } else majorTickLabel.remove();
            } else previousMajorTickLabel = majorTickLabel;
          }

          // Create minor ticks
          if (_minorTicksPerInterval > 0 && previousTickAngle) {
            var currentIntervalTotalAngle = this._delta(currentTickAngleLineLocation, previousTickAngle);
            var minorTickMultiplier = currentIntervalTotalAngle / (_minorTicksPerInterval + 1);
            var axisIntervalSelection = this.svg.select("." + AXIS_CLASS_NAME).append("g").attr("class", "interval");
            for (var j = 1; j <= _minorTicksPerInterval; ++j) {
              var currentMinorTickAngle = previousTickAngle + minorTickMultiplier * j;
              axisIntervalSelection.append("line").datum(this.dataSet.rows[0]).attr("y1", AXIS_TICKS_DISTANCE_FROM_CENTER + 8).attr("y2", AXIS_TICKS_DISTANCE_FROM_CENTER + STANDARD_TICK_SIZE).attr("stroke", _axisTickColor).attr("stroke-width", "2").attr("shape-rendering", "geometricPrecision").attr("transform", "rotate(".concat(currentMinorTickAngle, ")"));
            }
          }

          // End of loop, currentTickAngleLineLocation becomes the previousTickAngle
          previousTickAngle = currentTickAngleLineLocation;
        }
      }

      /**
       * Used for calculating the font impact on an axis tick label, the bigger the font, the more distance the tick label will have from a tick
       * @param _fontSize The current font size
       * @param _tickAngle The current angle of the tick, depending on the angle more or less distance should be given to the tick label
       * @returns {number} The calculated impact multiplier the font has on the axis tick label
       */
    }, {
      key: "_calculateFontImpactOnAxisTickLabel",
      value: function _calculateFontImpactOnAxisTickLabel(_fontSize, _tickAngle) {
        var side = 180;
        var fontWeight = _fontSize / AXIS_FONT_WEIGHT;
        if (_tickAngle <= side && _tickAngle > side * 0.75 || _tickAngle >= side && _tickAngle < side + side * 0.25) {
          return 0.25 * fontWeight;
        }
        if (_tickAngle <= side) {
          return _tickAngle / side * fontWeight;
        }
        return (side * 2 - _tickAngle) / side * fontWeight;
      }
    }, {
      key: "_calculateAngle",
      value: function _calculateAngle(_value) {
        if (!this.isAxisInverted) {
          return this.startAngleInDegrees + (_value - this.minAxisValue) * this.angleScale;
        }
        return this.endAngleInDegrees - (_value - this.maxAxisValue) * this.angleScale;
      }
    }, {
      key: "_calculateLineAngle",
      value: function _calculateLineAngle(_value) {
        return this.startAngleInDegrees + (_value - (!this.isAxisInverted ? this.minAxisValue : this.maxAxisValue)) * this.angleScale;
      }

      /**
       * Used for securing a value to never go out of a given range
       * @param _value the value to be secured
       * @param _min the minimum of the range for the value to be in
       * @param _max the maximum of the range for the value to be in
       */
    }, {
      key: "_clamp",
      value: function _clamp(_value, _min, _max) {
        return Math.min(Math.max(_value, _min), _max);
      }

      /**
       * Used to apply truncation to a given text element, will only apply truncation if it meets the requirements
       * @param _textElement The text element that needs to be possibly be truncated
       * @param _maxWidth The max width that the text element is suposed to be. (If it goes over max width, truncation will apply till it no longer does)
       * @param _endingSection The optional ending section that will be applied to the end of the truncated label
       */
    }, {
      key: "_truncateTextLabel",
      value: function _truncateTextLabel(_textElement, _maxWidth) {
        var _endingSection = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "";
        var currentText = _textElement.text();

        // Check if the width of the text is too long
        if (_textElement.node().getBBox().width > _maxWidth) {
          // Keep reducing the width of the text as long as the width is longer than the maxWidth
          var iterator = currentText.length;
          while (_textElement.node().getBBox().width > _maxWidth && iterator > 0) {
            currentText = currentText.substring(0, iterator).trim();
            _textElement.text(currentText + _endingSection);
            iterator--;
          }
        }
      }

      /**
       * Use a formula to determine the coordinates of an element after it rotated
       * @param _x The X coordinate before rotation
       * @param _y The Y coordinate before rotation
       * @param _angleInDegrees The angle that shows the amount of rotation that has taken place
       * @returns {Point} The point with the new X and Y coordinates inside of it
       */
    }, {
      key: "_calculateCoordinatesAfterRotation",
      value: function _calculateCoordinatesAfterRotation(_x, _y, _angleInDegrees) {
        var point = new N();
        var angleInRadians = this._degreesToRadians(_angleInDegrees);
        point.y = _y * Math.cos(angleInRadians) + _x * Math.sin(angleInRadians);
        point.x = _x * Math.cos(angleInRadians) - _y * Math.sin(angleInRadians);
        return point;
      }

      /**
       * Check if overlapping occurs between labels
       * @param _firstLabel The first label that needs to be checked for overlapping
       * @param _secondLabel The second label that needs to be checked for overlapping
       * @param _deviation The optional deviation to be used for eliminating borderline cases, e.g. elements that look like they are overlapping but in reality are not
       */
    }, {
      key: "_checkLabelOverlap",
      value: function _checkLabelOverlap(_firstLabel, _secondLabel) {
        var _deviation = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 8;
        var firstLabelBBox = _firstLabel.node().getBBox();
        var secondLabelBBox = _secondLabel.node().getBBox();

        // Get deltas from x and y coordinates, then investigate if these are smaller than the Box height and width, if both apply then overlapping occurs
        var checkHeight = this._delta(secondLabelBBox.y, firstLabelBBox.y) < firstLabelBBox.height + _deviation;
        var checkWidth = this._delta(secondLabelBBox.x, firstLabelBBox.x) < firstLabelBBox.width + _deviation;
        return checkHeight && checkWidth;
      }

      /**
       * Core decorations for the visualization, this will enable tooltip support for the core only
       */
    }, {
      key: "_enableCoreDecorations",
      value: function _enableCoreDecorations() {
        this.svg.select(".pointer").select("circle").datum(this.dataSet.rows[0]);
        this.svg.select(".pointer").select("polygon").datum(this.dataSet.rows[0]);
        this.svg.select(".labels").select("text.KPI-label").datum(this.dataSet.rows[0]);
        this.svg.select(".labels").select("text.value-label").datum(this.dataSet.rows[0]);
        this.svg.select(".target").select("line").datum(this.dataSet.rows[0]);
      }

      /**
       * Additional decorations for the visualization, this will enable tooltip support for the entire visualization
       */
    }, {
      key: "_enableFullDecorations",
      value: function _enableFullDecorations() {
        this._enableCoreDecorations();
        this.svg.select(".border").select("circle.inner-border").datum(this.dataSet.rows[0]);
        this.svg.select(".border").select("circle.outer-border").datum(this.dataSet.rows[0]);
      }

      /**
       * Formula for converting degrees to radians
       * @param _degrees Amount of degrees that need to be converted
       */
    }, {
      key: "_degreesToRadians",
      value: function _degreesToRadians(_degrees) {
        return _degrees * Math.PI / 180;
      }
    }, {
      key: "_delta",
      value: function _delta(_value1, _value2) {
        return Math.abs(_value1 - _value2);
      }
    }, {
      key: "_calculateStartAngle",
      value: function _calculateStartAngle() {
        return (360 - this.properties.get("sweep-angle")) / 2;
      }

      // Calculate the circle extra height (vertical distance from the bottom of the circle to center)
      // Chart has minimum extra height at sweep angle <= 180
      // maximum height at maximum angle ( 350 degree )
    }, {
      key: "_calculateCircleExtraHeight",
      value: function _calculateCircleExtraHeight() {
        var startAngle = this._calculateStartAngle();
        return ARC_END_RADIUS * Math.cos(this._degreesToRadians(startAngle));
      }

      // Calculate extra height of the chart (distance from chart bottom to center)
      // Comparing extra height of the circle and label offset
    }, {
      key: "_calculateChartExtraHeight",
      value: function _calculateChartExtraHeight() {
        if (this.properties.get("show-border")) return ARC_END_RADIUS; // always return full height when gauge border is shown
        var circleExtraHeight = this._calculateCircleExtraHeight();
        var labelOffset = this.properties.get("KPI-label-show") ? this.properties.get("KPI-label-offset") : 0;
        var valueOffset = this.properties.get("value-label-show") ? this.properties.get("value-label-offset") : 0;
        return this._clamp(Math.max(circleExtraHeight, labelOffset, valueOffset), 0, ARC_END_RADIUS);
      }
    }, {
      key: "_calculateViewBox",
      value: function _calculateViewBox(_extraGaugeHeight) {
        var maxGaugeExtraHeight = ARC_END_RADIUS;
        var showBorder = this.properties.get("show-border");
        var borderOffset = showBorder ? 0 : -40;
        var maxExtraHeight = 200 + borderOffset / 2; // Height including padding
        var minHeight = 200 + borderOffset / 2;
        var width = 400;
        var height = minHeight + Math.round(_extraGaugeHeight / maxGaugeExtraHeight * maxExtraHeight);
        var showPointerCircle = this.properties.get("show-pointer-circle");
        if (showPointerCircle) height = Math.max(height, minHeight + 12);
        return "0 0 ".concat(width + borderOffset * 2, " ").concat(height + borderOffset / 2);
      }
    }, {
      key: "_calculateTranslation",
      value: function _calculateTranslation(_extraGaugeHeight) {
        var maxExtraHeight = ARC_END_RADIUS;
        var maxYOffset = 40;
        var yOffset = maxYOffset - Math.round(_extraGaugeHeight / maxExtraHeight * maxYOffset);
        var showBorder = this.properties.get("show-border");
        var borderOffset = showBorder ? 0 : -40;
        return "translate(".concat(CENTER_X + borderOffset, " ").concat(CENTER_Y - yOffset + borderOffset / 2, ")");
      }

      // Create function that calculate maximum text width of KPI and value label
      // Based on their offset (y position) and current sweep angle, border visibility
    }, {
      key: "_createCalculateMaxTextWidthFn",
      value: function _createCalculateMaxTextWidthFn() {
        var _this2 = this;
        return function (_textOffset) {
          var padding = 12;
          var circleExtraHeight = _this2._calculateCircleExtraHeight();
          var innerRadius = ARC_START_RADIUS - padding * 2;
          // Vertical distance from first tick to circle center
          var firstTickHeight = ARC_START_RADIUS * Math.cos(_this2._degreesToRadians(_this2._calculateStartAngle()));

          // Text is under the whole gauge
          if (_textOffset > circleExtraHeight + padding) {
            if (_this2.properties.get("show-border")) return Math.sqrt(Math.pow(BORDER_START_RADIUS, 2) - Math.pow(_textOffset, 2)) * 2;else return 400;
          }
          // Text is between first tick and bottom of gauge
          else if (_textOffset > firstTickHeight) return Math.sqrt(Math.pow(ARC_END_RADIUS - padding, 2) - Math.pow(_textOffset, 2)) * 2;
          // Text is inside the inner circle
          else return Math.sqrt(Math.pow(innerRadius, 2) - Math.pow(_textOffset, 2)) * 2;
        };
      }

      //#region GETTERS AND SETTERS
    }, {
      key: "dataSet",
      get: function get() {
        return this._dataSet;
      },
      set: function set(_dataSet) {
        this._dataSet = _dataSet;
      }
    }, {
      key: "svg",
      get: function get() {
        return this._svg;
      },
      set: function set(_svg) {
        this._svg = _svg;
      }
    }, {
      key: "minAxisValue",
      get: function get() {
        return this._minAxisValue;
      },
      set: function set(_minAxisValue) {
        this._minAxisValue = _minAxisValue;
      }
    }, {
      key: "maxAxisValue",
      get: function get() {
        return this._maxAxisValue;
      },
      set: function set(_maxAxisValue) {
        this._maxAxisValue = _maxAxisValue;
      }
    }, {
      key: "angleScale",
      get: function get() {
        return this._angleScale;
      },
      set: function set(_angleScale) {
        this._angleScale = _angleScale;
      }
    }, {
      key: "startAngleInDegrees",
      get: function get() {
        return this._startAngleInDegrees;
      },
      set: function set(_startAngleInDegrees) {
        this._startAngleInDegrees = _startAngleInDegrees;
        this._endAngleInDegrees = 360 - _startAngleInDegrees;
      }
    }, {
      key: "endAngleInDegrees",
      get: function get() {
        return this._endAngleInDegrees;
      }
    }, {
      key: "isAxisInverted",
      get: function get() {
        return this._isAxisInverted;
      },
      set: function set(_isAxisInverted) {
        this._isAxisInverted = _isAxisInverted;
      }
    }, {
      key: "axisScaleLength",
      get: function get() {
        return this._axisScaleLength;
      },
      set: function set(_axisScaleLength) {
        this._axisScaleLength = _axisScaleLength;
      }
      //#endregion
    }]);
  }(ct);

  return _default;

}));
