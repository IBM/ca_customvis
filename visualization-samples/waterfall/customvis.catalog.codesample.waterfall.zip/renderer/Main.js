define(['require', 'https://d3js.org/d3.v5.min.js'], function (requirejs, d3) { 'use strict';

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }

    return obj;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;

    try {
      Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized(self);
  }

  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();

    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
          result;

      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;

        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }

      return _possibleConstructorReturn(this, result);
    };
  }

  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
  }

  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
  }

  function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
  }

  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }

  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;

    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

    return arr2;
  }

  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var e=function(){function t(t,e){this.name=t,this.slot=e||null,this.attributes=new Map;}return t.prototype.getName=function(){return this.name},t.prototype.getSlot=function(){return this.slot},t.prototype.getAttributes=function(){return this.attributes},t.slotLimit=function(e,n){return new t("limit",e).attr("n",n)},t.dataLimit=function(e){return new t("limit").attr("n",e)},t.prototype.attr=function(t,e){return this.attributes.set(t,e),this},t}(),n=function(t,e){return (n=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e;}||function(t,e){for(var n in e)e.hasOwnProperty(n)&&(t[n]=e[n]);})(t,e)};
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0

  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.

  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */function r(t,e){function r(){this.constructor=t;}n(t,e),t.prototype=null===e?Object.create(e):(r.prototype=e.prototype,new r);}function o(t,e,n){return t.getDecoration(e,n)}function i(t){return t.hasDecoration("hasSelection")?o(t,"hasSelection",!1):!!function(t){return "getSlot"in t&&"hasDecorationOnDataPoints"in t}(t)&&t.hasDecorationOnDataPoints("selected")}var u,s=function(){function t(t,e){this.min=t,this.max=e;}return t.prototype.asArray=function(){return [this.min,this.max]},t.empty=new t(0,0),t}(),a=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e.fromRS=function(t){return new s(t.min,t.max)},e}(s),l=function(){function t(t,e){this.source=t,this.index=e,this.key=t.getKey(!1),this.caption=t.getCaption("label")||"";var n=t.getItems()||[];this.segments=n.map((function(t){return new p(t)}));}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),c=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(l),h=function(){function t(t){this.source=t,this.key=this.source.getUniqueName()||"",this.caption=this.source.getCaption("label")||"";}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t}(),p=function(t){function e(e){return t.call(this,e)||this}return r(e,t),e}(h),f=new(function(){function t(){}return t.prototype.format=function(t){return t?t.toString():""},t}());!function(t){t.label="label",t.data="data";}(u||(u={}));var g=function(){function t(t,e,n,r,o){this.source=t,this.tuples=e,this.segments=n,this.domain=r,this.caption=o;var i=t.dataItems||[],u=i.length>0?i[0]:null,s=u&&u.asCont();s?(this._labelFormatter=s.getFormatter("label")||f,this._dataFormatter=s.getFormatter("data")||f):this._labelFormatter=this._dataFormatter=f;}return Object.defineProperty(t.prototype,"mapped",{get:function(){return this.source.mapped},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"dataType",{get:function(){var t=this.source.getDataItem(0);return this.mapped&&t?t.type:"none"},enumerable:!0,configurable:!0}),t.prototype.format=function(t,e){return function(t,e){return t.format(e)}(e===u.data?this._dataFormatter:this._labelFormatter,t)},t}(),d=function(t){function e(e,n,r,o,i){return t.call(this,e,n,r,o,i)||this}return r(e,t),e}(g),m=function(){function t(t,e){this.source=t,this.key=t.getKey(!1),this.dataSet=e;}return Object.defineProperty(t.prototype,"selected",{get:function(){return o(this.source,"selected",!1)},enumerable:!0,configurable:!0}),Object.defineProperty(t.prototype,"highlighted",{get:function(){return o(this.source,"highlighted",!1)},enumerable:!0,configurable:!0}),t.prototype.tuple=function(t){var e=this._getSlot(t);if(!e||0===e.tuples.length)return null;var n=this.source.get(e.source);if(!n)return null;var r=n.asCat();return r?e.tuples[r.index]:null},t.prototype.value=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);if(!n)return null;var r=n.asCont();return r&&"numeric"===r.valueType?r.value:null},t.prototype.caption=function(t){var e=this._getSlot(t),n=e&&this.source.get(e.source);return n&&n.getCaption("data")||""},t.prototype._getSlot=function(t){return "string"==typeof t?this.dataSet.slotMap.get(t)||null:this.dataSet.cols[t]||null},t}(),y=function(t){function e(e,n){return t.call(this,e,n)||this}return r(e,t),e}(m),v=function(){function t(t,e,n){var r=this;this.source=t,this.rows=t.dataPoints.map((function(t){return new y(t,r)})),this.cols=e,this.slotMap=n;}return t.filterRows=function(t,e,n){return t.filter((function(t){var r=t.tuple(e);return !!r&&r.key===n}))},Object.defineProperty(t.prototype,"hasSelections",{get:function(){return i(this.source)},enumerable:!0,configurable:!0}),t}(),_=function(t){function e(e,n,r){return t.call(this,e,n,r)||this}return r(e,t),e}(v);function b(t){var e=new Map,n=t.getSlots().map((function(t,n){var r=[],o=[],i=s.empty,u="";if(t.isMapped()){var l=t.getDataItem(0);if(u=l.getCaption("label"),"cat"===l.getRSType())r=l.getTuples().map((function(t,e){return new c(t,e)})),o=l.getItemClassSet(0).getItemClasses().map((function(t){return new p(t)}));else i=a.fromRS(l.getDomain()),o.push(new p(l.getItemClass()));}var h=new d(t,r,o,i,u);return e.set(t.name,h),h}));return new _(t,n,e)}function w(t){return t<0?0:t>255?255:Math.floor(t)}var C=function(){function t(t,e,n,r){var o;this.r=w(t),this.g=w(e),this.b=w(n),this.a=(o=r)<0?0:o>1?1:o;}return t.fromObject=function(e){return new t(e.r,e.g,e.b,void 0===e.a?1:e.a)},t.prototype.toString=function(){return 1===this.a?"rgb("+this.r+","+this.g+","+this.b+")":"rgba("+this.r+","+this.g+","+this.b+","+this.a+")"},t}();function S(t,e){var n=null;if(t instanceof m)n=t.source.getDataSet(e);else{var r=t.source.getDataItem(e);n=r&&r.getDataSet(e);}return !!n&&i(n)}var P=function(t){return "rgba("+t.r+","+t.g+","+t.b+",0.4)"},j=function(t){return "rgba("+Math.round(.7*t.r)+","+Math.round(.7*t.g)+","+Math.round(.7*t.b)+","+t.a+")"},x=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColor=function(t){return t?C.fromObject(this.source.getTupleColor(t.source,-1)):C.fromObject(this.source.getColor(null))},t.prototype._getTuple=function(t){if(t instanceof l)return t;var e=this.slot||this._slotResolver(t.dataSet,this.source.name);return e?t.tuple(e):null},t.prototype.getFillColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),!t.selected&&S(t,this._dataContext)?P(e):e.toString()},t.prototype.getOutlineColor=function(t){if(null===t)return this.source.getColor(null).toString();var e,n=this._getTuple(t);return e=n?this.source.getTupleColor(n.source,-1):this.source.getColor(t.source),t.highlighted||t.selected&&S(t,this._dataContext)?j(e):null},t}(),O=function(t,e,n){this.color=t,this.at=e,this.value=n;};function I(t){return t.map((function(t){return new O(C.fromObject(t.color),t.at,t.value)}))}var D=function(){function t(t,e,n){this.source=t,this._slot=e,this._dataContext=n,this.stops=I(t.stops),this.aligned=I(t.aligned),this.interpolate=t.interpolate;}return t.prototype.getColor=function(t){return C.fromObject(this.source.getColor(t))},t.prototype.getFillColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return !t.selected&&S(t,this._dataContext)?P(n):n.toString()},t.prototype.getOutlineColor=function(t){var e=this._slot?Number(t.value(this._slot)):0,n=this.source.getColor(e);return t.highlighted||t.selected&&S(t,this._dataContext)?j(n):null},t}(),E=function(){function t(t,e,n){this.source=t,this._dataContext=e,this._lastDataItem=null,this._cachedStops=null,this._slotResolver=n;}return Object.defineProperty(t.prototype,"slot",{get:function(){return this.source.slot},enumerable:!0,configurable:!0}),t.prototype.getColorStops=function(t){var e=t?t.source.getDataItem(0):null,n=e&&e.asCont(),r=n?n.getDomain(null):null,o=this.source.getColorStops(n,r),i=t?t.source.name:null;return new D(o,i,this._dataContext)},t.prototype._fetchColorStops=function(t){var e=t.source.getDataSet(this._dataContext),n=this.slot||this._slotResolver(t.dataSet,this.source.name),r=n?e.getSlot(n):null,o=r?r.getDataItem(0):null,i=o?o.asCont():null;if(this.source.dirty||!this._cachedStops||i!==this._lastDataItem){var u=i?i.getDomain(null):null,s=this.source.getColorStops(i,u);this._cachedStops=new D(s,r&&r.name,this._dataContext),this._lastDataItem=i;}return this._cachedStops},t.prototype.getFillColor=function(t){return this._fetchColorStops(t).getFillColor(t)},t.prototype.getOutlineColor=function(t){return this._fetchColorStops(t).getOutlineColor(t)},t}(),T=function(t){function e(e){var n=t.call(this,e.r,e.g,e.b,e.a)||this;return n._color=e,n}return r(e,t),e.prototype.getRed=function(){return this.r},e.prototype.getGreen=function(){return this.g},e.prototype.getBlue=function(){return this.b},e.prototype.getAlpha=function(){return this.a},e}(C),R=Object.freeze({min:0,max:0,empty:!0,explicit:!1,getMin:function(){return 0},getMax:function(){return 0},isEmpty:function(){return !0},isExplicit:function(){return !1}}),F=function(){function t(t,e,n,r,o,i){this.caption=t,this.color=e,this.shape=n,this.selected=r,this.highlighted=o,this.ref=i;}return t.prototype.getCaption=function(){return this.caption},t.prototype.getColor=function(){return this.color?new T(this.color):null},t.prototype.getShape=function(){return this.shape},t.prototype.isSelected=function(){return this.selected},t.prototype.isHighlighted=function(){return this.highlighted},t.prototype.getRef=function(){return this.ref},t}(),M=function(){function t(t,e,n,r,o,i){this.type=t,this.channel=e,this.slot=n,this.caption=r,this.subCaption=o,this.ref=i;}return t.prototype.getRSType=function(){return this.type},t.prototype.getChannel=function(){return this.channel},t.prototype.getSlot=function(){return this.slot},t.prototype.getCaption=function(){return this.caption},t.prototype.getSubCaption=function(){return this.subCaption},t.prototype.getRef=function(){return this.ref},t}(),L=function(t){function e(e,n,r,i,u){var s=this,a=n&&n.source,l=a&&a.name,c=a&&a.getDataItem(0),h=c&&c.asCat();s=t.call(this,"cat",e,l,r,"",h)||this;var p=h?h.tuples:[];return s.entries=p.map((function(t){var e=t.getCaption("label")||"",n=u&&u.source.getTupleColor(t,-1),r=o(t,"selected",!1),s=o(t,"highlighted",!1);return new F(e,n?C.fromObject(n):null,i,r,s,t)})),s}return r(e,t),e.prototype.getEntries=function(){return this.entries},e}(M),A=function(t){function e(e,n,r,o){var i=this,u=n&&n.source,s=u&&u.name,a=u&&u.getDataItem(0),l=a&&a.asCont();if((i=t.call(this,"cont",e,s,r,"",l)||this).domain=l?l.getDomain(null):R,o&&"color"===e){var c=o.source.getColorStops(l,null);i.stops=c.stops,i.interpolate=c.interpolate;}else i.stops=null,i.interpolate=!1;return i}return r(e,t),e.prototype.getDomain=function(){return this.domain},e.prototype.getInterpolate=function(){return this.interpolate},e.prototype.getStops=function(){return this.stops},e}(M);function z(t,e,n,r){if(!t)return [];var o=new Map,i=new Map;e.palettes.forEach((function(e){var n=e.slot||r&&r(t,e.source.name);n&&(e instanceof x?o.set(n,e):e instanceof E&&i.set(n,e));}));var u=[];return t.cols.forEach((function(t){var e=t.source;if(e.mapped){var r=e.getDataItem(0);if(r)switch(r.type){case"cat":if(-1===e.channels.indexOf("color"))return;var s=o.get(e.name);s&&u.push(new L("color",t,t.caption,n.legendShape,s));break;case"cont":if(-1!==e.channels.indexOf("color")){var a=i.get(e.name);a&&u.push(new A("color",t,t.caption,a));}-1!==e.channels.indexOf("size")&&u.push(new A("size",t,t.caption,null));}}})),u}var N,k=function(){this.legendShape=null,this.slotLimits=new Map,this.dataLimit=-1;};!function(t){t.Em="em",t.Percentage="%",t.Centimeter="cm",t.Millimeter="mm",t.Inch="in",t.Pica="pc",t.Point="pt",t.Pixel="px";}(N||(N={}));var H,U,V=function(){function t(t,e){this.value=t,this.unit=e;}return t.fromObject=function(e){return new t(e.value,function(t){switch(t){case"em":return N.Em;case"%":return N.Percentage;case"cm":return N.Centimeter;case"mm":return N.Millimeter;case"in":return N.Inch;case"pc":return N.Pica;case"pt":return N.Point;case"px":return N.Pixel;default:throw new Error("Invalid length unit '"+t+"' specified")}}(e.unit))},t.prototype.toString=function(){return ""+this.value+this.unit},t}();!function(t){t.Normal="normal",t.Italic="italic";}(H||(H={})),function(t){t[t.Thin=100]="Thin",t[t.ExtraLight=200]="ExtraLight",t[t.Light=300]="Light",t[t.Normal=400]="Normal",t[t.Medium=500]="Medium",t[t.SemiBold=600]="SemiBold",t[t.Bold=700]="Bold",t[t.ExtraBold=800]="ExtraBold",t[t.Heavy=900]="Heavy";}(U||(U={}));var q=/\s+/g;function K(t){switch(t){case U.Normal:return "normal";case U.Bold:return "bold";case U.Thin:case U.ExtraLight:case U.Light:case U.Medium:case U.SemiBold:case U.ExtraBold:case U.Heavy:return t.toString();default:return ""}}function G(t){var e=[];if(t)for(var n=0,r=t.length;n<r;++n){var o=t[n],i=q.test(o);e.push(i?'"'+o+'"':o);}return e.join(", ")}var J=function(){function t(t,e,n,r){this.family=t,this.size=e,this.style=n,this.weight=r;}return t.fromObject=function(e){return new t(e.family||null,e.size?V.fromObject(e.size):null,e.style?function(t){switch(t){case"normal":return H.Normal;case"italic":return H.Italic;default:throw new Error("Invalid font style '"+t+"' specified")}}(e.style):null,void 0!==e.weight&&null!==e.weight?e.weight:null)},t.prototype.toString=function(){if(this.style!==H.Normal&&this.weight!==U.Normal||this.style===H.Normal&&this.weight===U.Normal){var t=[];return this.style===H.Normal?t.push("normal"):(this.style&&t.push(this.style),this.weight&&t.push(K(this.weight))),this.size&&t.push(this.size.toString()),this.family&&t.push(G(this.family)),t.join(" ")}return function(t){var e,n=[],r=G(t.family);return r.length>0&&n.push("font-family: "+r+";"),(r=t.size?t.size.toString():"").length>0&&n.push("font-size: "+r+";"),(r=(e=t.style)?e.toString():"").length>0&&n.push("font-style: "+r+";"),(r=K(t.weight)).length>0&&n.push("font-weight: "+r+";"),n.join(" ")}(this)},t}(),Q=function(){function t(t,e,n){var r=new Map;null!==t&&t.forEach((function(t,o){if("palette"===t.type){var i=t;switch(i.paletteType){case"cat":r.set(o,new x(i,e,n));break;case"cont":r.set(o,new E(i,e,n));}}})),this.source=t,this.palettes=r;}return t.prototype.get=function(t){return this._getValue(t,!1)},t.prototype.peek=function(t){return this._getValue(t,!0)},t.prototype._getValue=function(t,e){var n=this.source&&this.source.get(t);if(!n)return null;switch(n.type){case"string":case"number":case"boolean":case"enum":return e?n.peek:n.value;case"length":var r=e?n.peek:n.value;return r?V.fromObject(r):null;case"font":var o=e?n.peek:n.value;return o?J.fromObject(o):null;case"color":var i=e?n.peek:n.value;return i?C.fromObject(i):null;case"palette":return this.palettes.get(t)||null;default:return null}},t.prototype.isActive=function(t){var e=this.source&&this.source.get(t);return !!e&&e.active},t.prototype.setActive=function(t,e){var n=this.source&&this.source.get(t);n&&n.setActive(e);},t.prototype.isDirty=function(t){var e=this.source&&this.source.get(t);return !!e&&e.dirty},t}();var W=setTimeout;function X(t){return Boolean(t&&void 0!==t.length)}function Y(){}function Z(t){if(!(this instanceof Z))throw new TypeError("Promises must be constructed via new");if("function"!=typeof t)throw new TypeError("not a function");this._state=0,this._handled=!1,this._value=void 0,this._deferreds=[],ot(t,this);}function $(t,e){for(;3===t._state;)t=t._value;0!==t._state?(t._handled=!0,Z._immediateFn((function(){var n=1===t._state?e.onFulfilled:e.onRejected;if(null!==n){var r;try{r=n(t._value);}catch(t){return void et(e.promise,t)}tt(e.promise,r);}else(1===t._state?tt:et)(e.promise,t._value);}))):t._deferreds.push(e);}function tt(t,e){try{if(e===t)throw new TypeError("A promise cannot be resolved with itself.");if(e&&("object"==typeof e||"function"==typeof e)){var n=e.then;if(e instanceof Z)return t._state=3,t._value=e,void nt(t);if("function"==typeof n)return void ot((r=n,o=e,function(){r.apply(o,arguments);}),t)}t._state=1,t._value=e,nt(t);}catch(e){et(t,e);}var r,o;}function et(t,e){t._state=2,t._value=e,nt(t);}function nt(t){2===t._state&&0===t._deferreds.length&&Z._immediateFn((function(){t._handled||Z._unhandledRejectionFn(t._value);}));for(var e=0,n=t._deferreds.length;e<n;e++)$(t,t._deferreds[e]);t._deferreds=null;}function rt(t,e,n){this.onFulfilled="function"==typeof t?t:null,this.onRejected="function"==typeof e?e:null,this.promise=n;}function ot(t,e){var n=!1;try{t((function(t){n||(n=!0,tt(e,t));}),(function(t){n||(n=!0,et(e,t));}));}catch(t){if(n)return;n=!0,et(e,t);}}Z.prototype.catch=function(t){return this.then(null,t)},Z.prototype.then=function(t,e){var n=new this.constructor(Y);return $(this,new rt(t,e,n)),n},Z.prototype.finally=function(t){var e=this.constructor;return this.then((function(n){return e.resolve(t()).then((function(){return n}))}),(function(n){return e.resolve(t()).then((function(){return e.reject(n)}))}))},Z.all=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.all accepts an array"));var r=Array.prototype.slice.call(t);if(0===r.length)return e([]);var o=r.length;function i(t,u){try{if(u&&("object"==typeof u||"function"==typeof u)){var s=u.then;if("function"==typeof s)return void s.call(u,(function(e){i(t,e);}),n)}r[t]=u,0==--o&&e(r);}catch(t){n(t);}}for(var u=0;u<r.length;u++)i(u,r[u]);}))},Z.resolve=function(t){return t&&"object"==typeof t&&t.constructor===Z?t:new Z((function(e){e(t);}))},Z.reject=function(t){return new Z((function(e,n){n(t);}))},Z.race=function(t){return new Z((function(e,n){if(!X(t))return n(new TypeError("Promise.race accepts an array"));for(var r=0,o=t.length;r<o;r++)Z.resolve(t[r]).then(e,n);}))},Z._immediateFn="function"==typeof setImmediate&&function(t){setImmediate(t);}||function(t){W(t,0);},Z._unhandledRejectionFn=function(t){"undefined"!=typeof console&&console&&console.warn("Possible Unhandled Promise Rejection:",t);};var it=function(t,e,n,r){this.data=t,this.decorations=e,this.properties=n,this.size=r;},ut=function(t,e,n,r,o){this.reason=t,this.data=e,this.node=n,this.props=r,this.locale=o;};var st=function(){function n(){this._data=null,this._elem=null,this._nls=null,this._locale="en-us",this._slotResolver=this.getSlotForPalette.bind(this),this.properties=new Q(null,null,this._slotResolver),this.meta=new k;}return n.prototype.init=function(t,e){var n=this,r=t.surface.appendChild(document.createElement("div"));r.setAttribute("style","left: 0; top: 0; width: 100%; height: 100%; position: absolute"),r.setAttribute("data-charttype","custom-viz"),this.properties=new Q(t.properties,t.dataContext,this._slotResolver),this._nls=t.nls,this._locale=t.locale,Z.resolve(this.create(r)).then((function(o){n._elem=o||r,t.properties.forEach((function(t,e){return n.updateProperty(e,t.value)})),e.complete();})).catch((function(t){e.fail(t);}));},n.prototype.destroy=function(){},n.prototype.getPropertyApi=function(){return null},n.prototype.setData=function(t){t&&t.dataSets&&t.dataSets[0]?this._data=b(t.dataSets[0]):this._data=null;},n.prototype.setProperty=function(t,e){this.updateProperty(t,this.properties.peek(t));},n.prototype.getBlockingRequests=function(){return null},n.prototype.render=function(t,e,n){if(!this._elem)return n.complete(null,null,null),null;if(!(e.data||e.decorations||e.properties||e.size))return n.complete(null,null,null),null;try{var r=this.update(new ut(function(t){return new it(t.data,t.decorations,t.properties,t.size)}(e),this._data,this._elem,this.properties,this._locale));Z.resolve(r).then((function(){return n.complete(null,null,null)})).catch(n.error);}catch(t){n.error(t);}return null},n.prototype.getEncodings=function(){return this._data?this.updateLegend(this._data):[]},n.prototype.getCapabilities=function(){var t=[];return this.meta.slotLimits.forEach((function(n,r){t.push(e.slotLimit(r,n));})),this.meta.dataLimit>=0&&t.push(e.dataLimit(this.meta.dataLimit)),t},n.prototype.getInteractivity=function(){return null},n.prototype.getVisCoordinate=function(t,e){return e},n.prototype.getRegionAtPoint=function(t,e){return null},n.prototype.getItemsAtPoint=function(t,e,n){if(!t||!t.hasOwnProperty("x")||!t.hasOwnProperty("y"))return null;var r=t,o=document.elementFromPoint(r.x,r.y),i=this.hitTest(o,r,e);return i&&i.source?[i.source]:[]},n.prototype.getItemsInPolygon=function(t,e){return []},n.prototype.getAxisItemsAtPoint=function(t,e,n){return []},n.prototype.getState=function(){return null},n.prototype.setState=function(t){},n.prototype.loadCss=function(t){var e=document.createElement("link");e.type="text/css",e.rel="stylesheet",e.href=this.toUrl(t),document.getElementsByTagName("head")[0].appendChild(e);},n.prototype.toUrl=function(e){return requirejs.toUrl(e)},n.prototype.update=function(t){},n.prototype.create=function(t){},n.prototype.updateProperty=function(t,e){},n.prototype.updateLegend=function(t){return z(t,this.properties,this.meta,this._slotResolver)},n.prototype.getSlotForPalette=function(t,e){return null},n.prototype.hitTest=function(t,e,n){var r=t&&t.__data__;return r&&r.source?r:null},n.prototype.nls=function(t){return this._nls&&this._nls.get(t)||""},n}();

  // Licensed Materials - Property of IBM

  function _typeof(obj) {
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof = function (obj) {
        return typeof obj;
      };
    } else {
      _typeof = function (obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };
    }

    return _typeof(obj);
  }

  function _classCallCheck$1(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties$1(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass$1(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties$1(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties$1(Constructor, staticProps);
    return Constructor;
  }

  var LabelLayoutMode = Object.freeze({
    Automode: "automatic",
    Horizontal: "horizontal",
    Rotate90: "rotate90",
    Rotate45: "rotate45",
    Stagger: "stagger"
  });

  var Orientation = Object.freeze({
    Bottom: "bottom",
    Top: "top",
    Left: "left",
    Right: "right"
  });

  function verifyBounds(_bounds) {
    if (_typeof(_bounds) !== 'object') throw Error("bounds must be an object with width and height property");
    if (_bounds.height === null || _bounds.height === undefined || _bounds.width === null || _bounds.width === undefined) throw Error("bounds must specify height and width");
  }
  function verifyLabelMode(_mode) {
    switch (_mode) {
      case LabelLayoutMode.Automode:
      case LabelLayoutMode.Horizontal:
      case LabelLayoutMode.Rotate45:
      case LabelLayoutMode.Rotate90:
      case LabelLayoutMode.Stagger:
        break;

      default:
        throw Error("Unsupported label layout mode");
    }
  }
  function verifyAxis(_axis) {
    if (!_axis || !_axis.scale || typeof _axis.scale !== "function") throw Error("Unsupported axis");
  }
  function verifyOrientation(_orientation) {
    switch (_orientation) {
      case Orientation.Left:
      case Orientation.Top:
      case Orientation.Right:
      case Orientation.Bottom:
        break;

      default:
        throw Error("Unsupported orientation");
    }
  }

  function calculate45DegreeSpace(_node, _bbox, _orientation, _maxWidth) {
    // - Axis.java: from Axis.axis(g) method ... "Each 'tick' is a group node ... which contains a line (the tick mark)
    //   and a text node (the tick label)."
    // - The incoming node passed here is the text node, to get the x location our text node is displayed at, we lookup
    //   the transform on the parent group node and parse the "translate(x," from it. If anything fails, we return the
    //   incoming maxWidth (length of a 45 degree label that isn't restricted by edge conditions)
    var width = _maxWidth; // consolidate the SVGTransformList containing all transformations
    // to a single SVGTransform of type SVG_TRANSFORM_MATRIX and get
    // its SVGMatrix.

    var matrix = _node.parentNode.transform.baseVal.consolidate().matrix;

    if (matrix) {
      var xLabelPos = matrix.e; // 0.7071 = Math.cos(45)

      var xLabelWidth = _bbox.width * 0.7071;
      var isBottom = _orientation === Orientation.Bottom;

      if (isBottom) {
        // given xLabelPos is baseline, shift slightly to left (want top of text box)
        xLabelPos -= _bbox.height / 4;

        if (xLabelPos - xLabelWidth < 0) {
          xLabelWidth = xLabelPos;
          width = xLabelWidth / 0.7071;
        }
      } // no shift of xLabelPos (as was done for bottom axis), baseline works well for top axis.

      /*if ( xLabelPos + xLabelWidth > bounds.width )
      {
          xLabelWidth = bounds.width - xLabelPos;
          width = xLabelWidth / 0.7071;
      }*/
      // don't make text longer than space available.


      if (width > _maxWidth) width = _maxWidth;
    }

    return Math.abs(width);
  }

  var HORIZONTAL_WEIGHT = 1.1;
  var LabelLayoutCalculator = function LabelLayoutCalculator() {
    // Input needed to do layout.
    var labelBounds, layoutMode, isContinuous, cachedBBoxMap, orientation; // computed output layout values.

    var labelHeight = 0,
        usedSizeForLabels = 0,
        layoutSpillOver = 0;
    var isHorizontal;

    function layout(_textSelection) {
      var cellWidth = labelBounds.width;
      var cellWidth90 = labelBounds.height;
      var horizontalScore = 0;
      var staggerScore = 0;
      var rotate45Score = 0;
      var rotate90Score = 0;
      isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom; // For numeric axis:
      // (1) layout is HORIZONTAL for vertical oriented axis and
      // (2) either HORIZONTAL or ROTATE90 for horizontal oriented axis based on configured _layoutMode.

      if (isContinuous) {
        // _layoutMode can be a bunch of invalid values (categorical axis
        // has more modes), so unless _layoutMode is explicitly
        // ROTATE90, we use HORIZONTAL.
        var _mode2 = LabelLayoutMode.Horizontal;
        if (isHorizontal) _mode2 = layoutMode === LabelLayoutMode.Rotate90 ? LabelLayoutMode.Rotate90 : LabelLayoutMode.Horizontal;
        measureNumericLabel();
        layoutMode = _mode2;
        return _mode2;
      }

      var labelCount = _textSelection.size(); // determine which scores to calculate


      var calcStagger = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Stagger;
      var calcRotate45 = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Rotate45;
      var calcRotate90 = layoutMode === LabelLayoutMode.Automode || layoutMode === LabelLayoutMode.Rotate90;
      var spaceFor45Label = 0;
      var widestLabel = 0;

      _textSelection.each(function (_data, _index) {
        var labelBounds = cachedBBoxMap.get(_index); // In case of empty label, do not calculate space for each mode, it is zero always.

        if (labelBounds.height > 0 && labelBounds.width > 0) {
          var labelWidth = labelBounds.width;
          if (labelWidth > widestLabel) widestLabel = labelWidth;
          labelHeight = labelBounds.height;
          horizontalScore += labelWidth <= cellWidth ? 1 : cellWidth / labelWidth;

          if (isHorizontal) {
            if (calcStagger) {
              // we don't consider stagger/rotated for left/right axis orientation
              var spaceForLabel = cellWidth * 2; // if only a single label, half normal stagger space

              if (_index === 0 && _index === labelCount - 1) spaceForLabel *= 0.5; // first and last label only get 3/4 normal stagger space
              else if (_index === 0 || _index === labelCount - 1) spaceForLabel *= 0.75;
              staggerScore += labelWidth <= spaceForLabel ? 1 : spaceForLabel / labelWidth;
            }

            if (calcRotate45) {
              // vertical space for 90 degree rotated label is 'cellWidth90'
              // height of tick label is 'labelHeight'
              // longest label at 45 degree rotation is cellWidth90 / Math.cos(45) - labelHeight
              // 0.7071 = Math.cos(45)
              if (spaceFor45Label === 0) spaceFor45Label = cellWidth90 / 0.7071 - labelHeight;
              var space = calculate45DegreeSpace(this, labelBounds, orientation, spaceFor45Label);
              rotate45Score += labelWidth <= space ? 1 : space / labelWidth;
            }

            if (calcRotate90) {
              rotate90Score += labelWidth <= cellWidth90 ? 1 : cellWidth90 / labelWidth;
            }
          }
        }
      });

      var mode = LabelLayoutMode.Horizontal;

      if (layoutMode === LabelLayoutMode.Automode) {
        // Product Management has decided that it is better to truncate a little with horizontal label orientation
        // than to show text rotated with no truncation, so bump up scores if stagger is allowed
        if (isHorizontal) {
          horizontalScore *= HORIZONTAL_WEIGHT;
          staggerScore *= HORIZONTAL_WEIGHT;
        } // determine the winner (highest score), mode is initialized to HORIZONTAL


        if (staggerScore > horizontalScore && staggerScore >= rotate45Score && staggerScore >= rotate90Score) mode = LabelLayoutMode.Stagger;else if (rotate45Score > horizontalScore && rotate45Score >= rotate90Score) mode = LabelLayoutMode.Rotate45;else if (rotate90Score > horizontalScore) mode = LabelLayoutMode.Rotate90;
      } else {
        if (!isHorizontal) mode = LabelLayoutMode.Horizontal;else mode = layoutMode; // forced to one of HORIZONTAL, STAGGER, ROTATE45 or ROTATE90
      }

      if (isHorizontal) {
        switch (mode) {
          case LabelLayoutMode.Stagger:
            usedSizeForLabels = labelHeight * 2;
            break;

          case LabelLayoutMode.Rotate45:
            // 0.7071 = Math.cos(45)
            usedSizeForLabels = (widestLabel + labelHeight) * 0.7071;
            break;

          case LabelLayoutMode.Rotate90:
            usedSizeForLabels = widestLabel;
            break;

          case LabelLayoutMode.Horizontal:
          default:
            usedSizeForLabels = labelHeight;
            break;
        }
      } else {
        usedSizeForLabels = widestLabel;
        layoutSpillOver = labelHeight / 2;
      }

      layoutMode = mode;
      return mode;
    }

    layout.labelBounds = function (_bounds) {
      labelBounds = _bounds;
      return layout;
    };

    layout.cachedBBoxMap = function (_map) {
      cachedBBoxMap = _map;
      return layout;
    };

    layout.layoutMode = function (_mode) {
      if (_mode !== null && _mode !== undefined) {
        layoutMode = _mode;
        return layout;
      } else {
        return layoutMode;
      }
    };

    layout.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return layout;
    };

    layout.isContinuousAxis = function (_isContinuos) {
      isContinuous = _isContinuos;
      return layout;
    };

    layout.labelHeight = function () {
      return labelHeight;
    };

    layout.usedSizeForLabels = function () {
      return usedSizeForLabels;
    };

    layout.layoutSpillOver = function () {
      return layoutSpillOver;
    };

    function measureNumericLabel() {
      layoutSpillOver = 0;
      labelHeight = 0;
      var widestLabel = 0;

      for (var index = 0; index < cachedBBoxMap.size; index++) {
        if (cachedBBoxMap.get(index).width > widestLabel) widestLabel = cachedBBoxMap.get(index).width;
        if (cachedBBoxMap.get(index).height > labelHeight) labelHeight = cachedBBoxMap.get(index).height;
      }

      if (isHorizontal) {
        layoutSpillOver = layoutMode === LabelLayoutMode.Rotate90 ? labelHeight / 2 : widestLabel / 2 + 2;
        usedSizeForLabels = layoutMode === LabelLayoutMode.Rotate90 ? widestLabel : labelHeight;
      } else {
        layoutSpillOver = labelHeight / 2;
        usedSizeForLabels = widestLabel;
      }
    }

    return layout;
  };

  var LabelAnchor = function LabelAnchor() {
    var mode, orientation;

    function anchor(_textSelection) {
      var isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom;
      var anchorVal;

      if (mode === LabelLayoutMode.Rotate45 || mode === LabelLayoutMode.Rotate90) {
        if (isHorizontal) {
          if (orientation === Orientation.Bottom) anchorVal = "end";else if (orientation === Orientation.Top) anchorVal = "start";else anchorVal = "middle";
        }
      } else {
        if (isHorizontal) anchorVal = "middle";else if (orientation === Orientation.Right) anchorVal = "start";else anchorVal = "end";
      }

      _textSelection.style("text-anchor", anchorVal);
    }

    anchor.labelMode = function (_mode) {
      mode = _mode;
      return anchor;
    };

    anchor.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return anchor;
    };

    return anchor;
  };

  var LabelTransform = function LabelTransform() {
    var mode, orientation, cachedBBoxMap;

    function transform(_textSelection) {
      var isBottom = orientation === Orientation.Bottom;

      _textSelection.attr("transform", function (_data, _index, _grouIndex) {
        var bbox = cachedBBoxMap.get(_index);
        var x = 0;
        var y = 0;
        var rotation_cy = 0; // if stagger, every other label is on the second line
        // adjust x for first / last if not doing 'middle' alignment

        if (mode === LabelLayoutMode.Stagger) {
          if (_index % 2 === 1) {
            var staggerDirection = isBottom ? 1 : -1;
            y += bbox.height * staggerDirection;
          }
        } // if rotate 45 degrees, shift x position


        if (mode === LabelLayoutMode.Rotate45) {
          if (isBottom) x -= bbox.height;else x += bbox.height / 2;
        } // if rotate 90 degrees, shift x position.
        else if (mode === LabelLayoutMode.Rotate90) {
            if (isBottom) {
              // assumption is height * 1/4 is descent
              x -= cachedBBoxMap.get(_index).height * 1 / 4; // space to move away from axis

              rotation_cy = 10;
            } else {
              x += cachedBBoxMap.get(_index).height / 2; // space to move away from axis

              rotation_cy = -10;
            }
          }

        var rotationDegrees = mode === LabelLayoutMode.Rotate90 ? -90 : mode === LabelLayoutMode.Rotate45 ? -45 : 0;
        return "translate(" + x + "," + y + ") rotate(" + rotationDegrees + ",0," + rotation_cy + ")";
      });
    }

    transform.labelMode = function (_mode) {
      mode = _mode;
      return transform;
    };

    transform.axisOrientation = function (_orientation) {
      orientation = _orientation;
      return transform;
    };

    transform.cachedBBoxMap = function (_map) {
      cachedBBoxMap = _map;
      return transform;
    };

    return transform;
  };

  /**
   * Set font to a struct of the following 6 properties: font-style
   * font-variant font-weight font-size/line-height font-family. see
   * https://developer.mozilla.org/en-US/docs/Web/CSS/font
   */

  var FontStyleStruct =
  /*#__PURE__*/
  function () {
    function FontStyleStruct(_textNode) {
      _classCallCheck$1(this, FontStyleStruct);

      var styles = getComputedStyle(_textNode);
      this.fontStyle = styles["font-style"];
      this.fontVariant = styles["font-variant"];
      this.fontWeight = styles["font-weight"];
      this.fontSize = styles["font-size"];
      this.lineHeight = styles["line-height"];
      this.fontFamily = styles["font-family"];
    }

    _createClass$1(FontStyleStruct, [{
      key: "toString",
      value: function toString() {
        return this.fontStyle.toString() + " " + this.fontVariant.toString() + " " + this.fontWeight.toString() + " " + this.fontSize.toString() + "/" + this.lineHeight.toString() + " " + this.fontFamily.toString();
      }
    }]);

    return FontStyleStruct;
  }();

  var TextData =
  /*#__PURE__*/
  function () {
    function TextData() {
      _classCallCheck$1(this, TextData);

      /**
      * Lines array
      */
      this.lines = [];
    }
    /**
     * @param line line text string
     */


    _createClass$1(TextData, [{
      key: "add",
      value: function add(_line) {
        if (_line) this.lines.push(_line);
      }
      /**
       * @return number of lines
       */

    }, {
      key: "length",
      value: function length() {
        return this.lines.length;
      }
    }]);

    return TextData;
  }();

  var Canvas =
  /*#__PURE__*/
  function () {
    function Canvas() {
      _classCallCheck$1(this, Canvas);
    }

    _createClass$1(Canvas, null, [{
      key: "create",
      value: function create() {
        if (typeof document !== "undefined") {
          var canvas = document.createElement("canvas");
          return canvas;
        }

        return null;
      }
    }]);

    return Canvas;
  }();

  var LabelWrap = function LabelWrap() {
    var bounds;
    var canvas = Canvas.create();
    var textOverFlow = "...";
    var multiLine = false;

    function wrap(_selection) {
      var height = bounds.height;
      var width = bounds.width; // Read the font style once.
      // Assumption: All axis labels have the same font.

      var fontStyleStruct = new FontStyleStruct(_selection.node());
      var lineHeight = fontStyleStruct.lineHeight || fontStyleStruct.fontSize.value;
      var fontStyle = fontStyleStruct.toString();

      _selection.each(function (_data) {
        var textData = new TextData();
        var n;
        var line = "";
        var space = "";
        var total_height = 0;
        var clipped = false;
        var words = multiLine ? this.textContent.split(' ') : [this.textContent];

        for (n = 0; !clipped && n < words.length && total_height < height; ++n) {
          var testLine = line.concat(space).concat(words[n]);
          space = " ";

          if (_measureText(testLine, fontStyle) > width) {
            // even 1 word could not be wrapped, clip|truncate and exit
            if (_measureText(words[n], fontStyle) > width) {
              // Adds a truncated line to the textData
              textData.add(_truncate(testLine, width, fontStyle)); // If we can't even fit a single ellipse, return immediately

              if (textData.length() <= 0) return; // Otherwise, stop adding lines now

              clipped = true;
              line = "";
            } else {
              textData.add(line); // line could be wider than max width, but if so, it will be truncated.

              line = words[n];
            }

            total_height += lineHeight;
          } else {
            line = testLine;
          }
        } // once we are out we either run out of vertical space or words
        // if we run out of words we have one last line to add
        // we run out of words, add last line if there is anything in it, truncate|clip if needed


        if (n === words.length) {
          if (total_height + lineHeight <= height) {
            // height allows, add last line
            // Don't allow a blank line to be added--it will not change appearance, but
            // it can mess up the flags.
            if (line) textData.add(_truncate(line, width, fontStyle));
          }
        } // now we are back within height bounds
        // step back - remove trailing line to add ellipses and add it back truncated


        var lastAddedLine = "";
        if (textData.length() > 0) lastAddedLine = textData.lines.pop();
        line = lastAddedLine.concat(" ").concat(line);
        textData.add(_truncate(line, width, fontStyle));

        if (textData.length() <= 1) {
          d3.select(this).text(line);
        }
      });
    }

    wrap.bounds = function (_bounds) {
      bounds = _bounds;
      return wrap;
    };

    wrap.multiLine = function (_multiLine) {
      multiLine = _multiLine;
      return wrap;
    };

    function _measureText(_text, _fontStruct) {
      var ctx = canvas.getContext("2d");
      ctx.font = _fontStruct;
      return ctx.measureText(_text).width;
    }

    function _truncate(_text, _width, _fontStruct) {
      // Should optimize by using an educated guess.
      var marker = _text.length;
      var testLine = _text.substring(0, marker) + " ";
      marker = marker + 1;
      var exit = false;

      while (_measureText(testLine.concat(textOverFlow), _fontStruct) > _width && !exit) {
        marker--;

        if (marker <= 0) {
          marker = 0;
          exit = true;
        }

        testLine = testLine.substring(0, marker);
      }

      return testLine.concat(textOverFlow);
    }

    return wrap;
  };

  var DropOverlap = function DropOverlap() {
    var widthRadius = 0;
    var heightRadius = 0;
    var rect;
    var hasCollided = false;

    function drop(_selection) {
      var quadtree$1 = d3.quadtree().x(function (d) {
        return d.x;
      }).y(function (d) {
        return d.y;
      });

      _selection.each(function () {
        rect = this.getBoundingClientRect();
        widthRadius = Math.max(widthRadius, rect.width);
        heightRadius = Math.max(heightRadius, rect.height);
        hasCollided = false;
        quadtree$1.visit(visit);

        if (!hasCollided) {
          quadtree$1.add(rect);
          this.collide = false;
        } else this.collide = true;
      });

      _selection.style("visibility", function () {
        return this.collide ? "hidden" : null;
      });
    }

    function visit(_node, _x1, _y1, _x2, _y2) {
      if (hasCollided) return true;
      if (_node.data === rect) return false; // child node

      if (!_node.length) hasCollided = !(rect.x + rect.width < _node.data.x || _node.data.x + _node.data.width < rect.x || rect.y + rect.height < _node.data.y || _node.data.y + _node.data.height < rect.y);
      return !(rect.x < _x2 + widthRadius && rect.x + rect.width > _x1 - widthRadius && rect.y < _y2 + heightRadius && rect.y + rect.height > _y1 - heightRadius);
    }

    return drop;
  };

  var AxisLabelLayout = function AxisLabelLayout() {
    var bounds, axis;
    var isContinuous, orientation, isHorizontal;
    var labelModeCalculator = LabelLayoutCalculator();
    var labelAnchor = LabelAnchor();
    var labelTransform = LabelTransform();
    var labelWrap = LabelWrap();
    var labelDropOverlap = DropOverlap();
    var cachedBBoxMap = new Map();

    function layout(_selection) {
      cachedBBoxMap.clear();
      var scale = axis.scale();
      isContinuous = !scale.rangeBand && !scale.step;
      isHorizontal = orientation === Orientation.Top || orientation === Orientation.Bottom;

      var textSelection = _selection.selectAll(".tick text");

      textSelection.each(function (_data, _index) {
        cachedBBoxMap.set(_index, this.getBBox());
      });
      var labelSpace = labelExtent(textSelection);
      labelModeCalculator.labelBounds(labelSpace).isContinuousAxis(isContinuous).cachedBBoxMap(cachedBBoxMap).axisOrientation(orientation);
      textSelection.call(labelModeCalculator);
      labelAnchor.labelMode(labelModeCalculator.layoutMode()).axisOrientation(orientation);
      labelTransform.labelMode(labelModeCalculator.layoutMode()).axisOrientation(orientation).cachedBBoxMap(cachedBBoxMap);
      if (!isContinuous) doLabelWrapping(textSelection, labelSpace);else textSelection.call(labelDropOverlap);
      textSelection.call(labelTransform);
      textSelection.call(labelAnchor);
    }

    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };

    layout.mode = function (_mode) {
      if (_mode) {
        verifyLabelMode(_mode);
        labelModeCalculator.layoutMode(_mode);
        return layout;
      } else {
        return labelModeCalculator.layoutMode();
      }
    };

    layout.axis = function (_axis) {
      verifyAxis(_axis);
      axis = _axis;
      return layout;
    };

    layout.axisOrientation = function (_orientation) {
      verifyOrientation(_orientation);
      orientation = _orientation;
      return layout;
    };

    layout.layoutSpillOver = function () {
      return labelModeCalculator.layoutSpillOver();
    };

    layout.usedSizeForLabels = function () {
      return labelModeCalculator.usedSizeForLabels();
    };

    function labelExtent(_textSelection) {
      var w = bounds.width;
      var h = bounds.height;

      var tickCount = _textSelection.size();

      var range = axis.scale().range();
      var tickSpace = Math.abs(range[range.length - 1] - range[0]) / tickCount; // set w (for top/bottom) or h (for left/right) based on cell size

      if (isHorizontal) w = tickSpace;else h = tickSpace; // reduce space used by ticks, padding and title

      if (isHorizontal) {
        h -= axis.tickSize(); // ticks space always given regardless if they are visible

        h -= axis.tickPadding(); // half the padding goes to labels
      } else {
        w -= axis.tickSize();
        w -= axis.tickPadding();
      }

      return {
        width: w,
        height: h
      };
    }

    function doLabelWrapping(_textSelection, _labelExtent) {
      if (!_labelExtent || _labelExtent.width < 0 || _labelExtent.height < 0) return;
      var mode = labelModeCalculator.layoutMode();
      var w = _labelExtent.width;
      var h = _labelExtent.height;

      if (mode === LabelLayoutMode.Rotate45) {
        w = _labelExtent.height / 0.7071 - labelModeCalculator.labelHeight();
        h = labelModeCalculator.labelHeight() / 0.7071;
      } else if (mode === LabelLayoutMode.Rotate90) {
        var tmp = w;
        w = h;
        h = tmp;
      }

      var cellWidth = w;

      _textSelection.each(function (_data, _index, _groupIndex) {
        var width = cellWidth; // 1.2 magic constant to prevent textFlow removing labels due to height issues.

        if (mode === LabelLayoutMode.Rotate45) {
          width = calculate45DegreeSpace(this, cachedBBoxMap.get(_index), orientation, cellWidth);
        }

        if (mode === LabelLayoutMode.Stagger) {
          width = cellWidth * 2;
        }

        if (cachedBBoxMap.get(_index).width > width) {
          labelWrap.bounds({
            width: width,
            height: h / 2
          });
          d3.select(this).call(labelWrap);
        }
      });
    }

    return layout;
  };

  var AxisProperty =
  /*#__PURE__*/
  function () {
    function AxisProperty() {
      _classCallCheck$1(this, AxisProperty);

      this._axisTitle = "";
      this._showTitle = true;
      this._showTicks = true;
      this._showTickLabels = true;
      this._showAxisLine = true;
      this._titleFont = {};
      this._tickLabelFont = {};
      this._tickLabelColor = "currentColor";
      this._titleColor = "currentColor";
      this._lineColor = "currentColor";
      this._tickColor = "currentColor";
      this._labelLayoutMode = "automatic";
    }

    _createClass$1(AxisProperty, [{
      key: "title",
      value: function title(_axisTitle) {
        if (_axisTitle !== null && _axisTitle !== undefined) {
          this._axisTitle = _axisTitle;
          return this;
        }

        return this._axisTitle;
      }
    }, {
      key: "showTitle",
      value: function showTitle(_showTitle) {
        if (_showTitle !== null && _showTitle !== undefined) {
          this._showTitle = _showTitle;
          return this;
        }

        return this._showTitle;
      }
    }, {
      key: "showTicks",
      value: function showTicks(_showTicks) {
        if (_showTicks !== null && _showTicks !== undefined) {
          this._showTicks = _showTicks;
          return this;
        }

        return this._showTicks;
      }
    }, {
      key: "ticksColor",
      value: function ticksColor(_tickColor) {
        if (_tickColor !== null && _tickColor !== undefined) {
          this._tickColor = _tickColor;
          return this;
        }

        return this._tickColor;
      }
    }, {
      key: "showTickLabels",
      value: function showTickLabels(_showTickLabels) {
        if (_showTickLabels !== null && _showTickLabels !== undefined) {
          this._showTickLabels = _showTickLabels;
          return this;
        }

        return this._showTickLabels;
      }
    }, {
      key: "tickLabelMode",
      value: function tickLabelMode(_labelLayoutMode) {
        if (_labelLayoutMode !== null && _labelLayoutMode !== undefined) {
          this._labelLayoutMode = _labelLayoutMode;
          return this;
        }

        return this._labelLayoutMode;
      }
    }, {
      key: "showAxisLine",
      value: function showAxisLine(_showAxisLine) {
        if (_showAxisLine !== null && _showAxisLine !== undefined) {
          this._showAxisLine = _showAxisLine;
          return this;
        }

        return this._showAxisLine;
      }
    }, {
      key: "axisLineColor",
      value: function axisLineColor(_lineColor) {
        if (_lineColor !== null && _lineColor !== undefined) {
          this._lineColor = _lineColor;
          return this;
        }

        return this._lineColor;
      }
    }, {
      key: "tickLabelFont",
      value: function tickLabelFont(_tickLabelFont) {
        if (_tickLabelFont !== null && _tickLabelFont !== undefined) {
          this._tickLabelFont = _tickLabelFont;
          return this;
        }

        return this._tickLabelFont;
      }
    }, {
      key: "tickLabelColor",
      value: function tickLabelColor(_tickLabelColor) {
        if (_tickLabelColor !== null && _tickLabelColor !== undefined) {
          this._tickLabelColor = _tickLabelColor;
          return this;
        }

        return this._tickLabelColor;
      }
    }, {
      key: "titleFont",
      value: function titleFont(_titleFont) {
        if (_titleFont !== null && _titleFont !== undefined) {
          this._titleFont = _titleFont;
          return this;
        }

        return this._titleFont;
      }
    }, {
      key: "titleColor",
      value: function titleColor(_titleColor) {
        if (_titleColor !== null && _titleColor !== undefined) {
          this._titleColor = _titleColor;
          return this;
        }

        return this._titleColor;
      }
    }]);

    return AxisProperty;
  }();

  function applyAxisProperties(_selector, _axisProperty) {
    _selector.selectAll(".tick text").style("visibility", _axisProperty.showTickLabels() ? null : "hidden").attr("fill", _axisProperty.tickLabelColor());

    var styles = _axisProperty.tickLabelFont();

    for (var property in styles) {
      if (styles.hasOwnProperty(property)) {
        _selector.style(property, styles[property]);

        _selector.attr(property, styles[property]);
      }
    }

    _selector.selectAll(".tick line").style("visibility", _axisProperty.showTicks() ? null : "hidden").attr("stroke", _axisProperty.ticksColor());

    _selector.selectAll("path.domain").style("visibility", _axisProperty.showAxisLine() ? null : "hidden").attr("stroke", _axisProperty.axisLineColor());
  }

  var AxisLayout = function AxisLayout() {
    var bounds;
    var axis;
    var axisTitle;
    var orientation;
    var axisTitleHeight = 0;
    var DEFAULT_TICKS_COUNT = 10;
    var axisLabelLayout = AxisLabelLayout();
    var axisProperty = new AxisProperty();

    function layout(_selector) {
      if (bounds.height <= 0 || bounds.width <= 0) return;
      var scale = axis.scale();
      var range = scale.range();
      var axisExtent = Math.abs(range[range.length - 1] - range[0]);
      var labelHeight = 20; // space the ticks at least to have labelHeight between them to avoid collision.

      var isOrdinal = scale.bandwidth || scale.step;

      if (isOrdinal && axisExtent > 0) {
        var maxTickCount = Math.round(axisExtent / (labelHeight + axis.tickPadding()));

        if (scale.domain().length > maxTickCount) {
          var tickSkipCount = Math.round(scale.domain().length / maxTickCount);
          var tickValues = [];
          var domain = scale.domain();

          for (var i = 0; i < domain.length; i = i + tickSkipCount) {
            tickValues.push(domain[i]);
          }

          axis.tickValues(tickValues);
        }
      } else if (axisExtent > 0) {
        if (axisLabelLayout.mode() === LabelLayoutMode.Horizontal) labelHeight = axisLabelLayout.usedSizeForLabels();
        var tickCount = axisExtent / (labelHeight + axis.tickPadding());
        axis.tickArguments([Math.ceil(Math.min(tickCount, DEFAULT_TICKS_COUNT))]);
      }

      _selector.call(axis);

      applyAxisProperties(_selector, axisProperty); // axis path should contains H command for d.

      var isHorizontal = _selector.select(".domain").attr("d").split("H").length === 2;
      var labelPos;

      if (isHorizontal) {
        labelPos = _selector.select(".tick text").attr("y");
        orientation = labelPos > 0 ? Orientation.Bottom : Orientation.Top;
      } else {
        labelPos = _selector.select(".tick text").attr("x");
        orientation = labelPos > 0 ? Orientation.Right : Orientation.Left;
      }

      if (axisProperty.showTickLabels()) {
        axisLabelLayout.bounds(bounds).mode(axisProperty.tickLabelMode()).axis(axis).axisOrientation(orientation);

        _selector.call(axisLabelLayout);
      }

      drawTitle(_selector);
      drawTitle(_selector, true);
    }

    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };

    layout.axis = function (_axis) {
      verifyAxis(_axis);
      axis = _axis;
      return layout;
    };

    layout.axisProperty = function (_axisProperty) {
      axisProperty = _axisProperty;
      return layout;
    };

    layout.getSpillOver = function () {
      return axisLabelLayout.layoutSpillOver();
    };

    layout.getPreferredSize = function () {
      var layoutPaddingSize = 0;
      var usedSizeForLabels = 0; // axis will by null if the chart has no data

      if (axis) {
        layoutPaddingSize = axis.tickSize();
        usedSizeForLabels = axisLabelLayout.usedSizeForLabels();

        if (usedSizeForLabels !== 0) {
          // Add additional breathing space for the title and the labels.
          // Both the labels and the title will get half of the padding size as additional breathing
          // space at the bottom to leave some space there.
          // Since this is two times half of the padding, we will add padding as breathing space.
          layoutPaddingSize += layoutPaddingSize; // Besides the breathing space we need to add an additional 2px for truncation of doubles to
          // ints in textflow calculations.
          // Please note that this is only applicable if there are labels available.

          layoutPaddingSize += 2;
        } else if (axisTitleHeight !== 0) {
          // In this case no ticks / tick labels are shown. Only the title is visible.
          // Add padding as breathing space.
          layoutPaddingSize += layoutPaddingSize;
        }
      }

      return usedSizeForLabels + axisTitleHeight + layoutPaddingSize;
    };

    function drawTitle(_axisSelector, _usePreferredSize) {
      axisTitle = axisProperty.title();

      if (!axisTitle || !axisProperty.showTitle()) {
        _axisSelector.selectAll("text." + orientation).remove();

        axisTitleHeight = 0;
        return;
      } // Origins for each axis location (T for Top, L for Left, R for Right, B for Bottom)
      //
      // -------L-----------R-------        Unrotated axis orientation @ T,B,L,R
      // |      |    Top    |      |
      // T------+-----------+------|         *----x
      // |      |           |      |         |
      // | Left |  Element  | Right|         y
      // |      |           |      |
      //  B------+-----------+-----|
      // |      |   Bottom  |      |
      // ---------------------------


      var x = 0;
      var y = 0;
      var dy = "";
      var transform = null;
      var axisWidth = 0.0;
      var padding = 16;
      if (orientation === Orientation.Top || orientation === Orientation.Bottom) axisWidth = bounds.height;else axisWidth = bounds.width;
      if (_usePreferredSize) axisWidth = Math.min(layout.getPreferredSize(), axisWidth);
      var axisRange = axis.scale().range();
      var extent = Math.abs(axisRange[0] + axisRange[axisRange.length - 1]);

      if (orientation === Orientation.Top) {
        x = extent / 2;
        y = -axisWidth + padding / 4;
        dy = "0.75em"; // assumption is that text is 0.75em above baseline and 0.25em below baseline
      } else if (orientation === Orientation.Bottom) {
        x = extent / 2;
        y = axisWidth - padding / 4;
        dy = "-0.25em";
      } else if (orientation === Orientation.Left) {
        x = -extent / 2; // Rotated axis orientation

        y = -axisWidth + padding / 4;
        dy = "0.75em";
        transform = "rotate(-90)";
      } else {
        x = extent / 2; // Rotated axis orientation

        y = -axisWidth + padding / 4;
        dy = "0.75em";
        transform = "rotate(90)";
      }

      var titleSelector = _axisSelector.selectAll("text." + orientation);

      if (titleSelector.empty()) {
        // There was no title text, so add it using the final attribute values (to avoid transitions from off-screen)
        titleSelector = _axisSelector.append("text").attr("class", orientation).style("text-anchor", "middle");
      }

      titleSelector.attr("x", x).attr("y", y).attr("transform", transform).attr("dy", dy).style("fill", axisProperty.titleColor()).text(axisTitle).each(function (_d) {
        var styles = axisProperty.titleFont();

        for (var property in styles) {
          if (styles.hasOwnProperty(property)) this.style[property] = styles[property];
        }
      });
      if (!_usePreferredSize) axisTitleHeight = titleSelector.node().getBBox().height;
    }

    return layout;
  };

  function copyRect(_rect) {
    return {
      x: _rect.x || 0,
      y: _rect.y || 0,
      width: _rect.width,
      height: _rect.height
    };
  }

  var ChartLayoutComponent =
  /*#__PURE__*/
  function () {
    function ChartLayoutComponent() {
      _classCallCheck$1(this, ChartLayoutComponent);

      this._axisSizable = new Map();
      this._orientationMap = new Map();
    }

    _createClass$1(ChartLayoutComponent, [{
      key: "chartRect",
      value: function chartRect(_chartBounds) {
        this._chartRect = copyRect(_chartBounds);
        this._elementRect = copyRect(_chartBounds);
      }
    }, {
      key: "add",
      value: function add(_orientation, _axisLabelComp) {
        this._axisSizable.set(_orientation, _axisLabelComp);
      }
    }, {
      key: "getRect",
      value: function getRect(_orientation) {
        return this._orientationMap.get(_orientation);
      }
    }, {
      key: "elementRect",
      value: function elementRect() {
        return this._elementRect;
      }
    }, {
      key: "layout",
      value: function layout() {
        var _this = this;

        if (this._chartRect.width <= 0 || this._chartRect.height <= 0) {
          this._elementRect = copyRect(this._chartRect);

          this._orientationMap.set(Orientation.Left, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });

          this._orientationMap.set(Orientation.Right, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });

          this._orientationMap.set(Orientation.Top, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });

          this._orientationMap.set(Orientation.Bottom, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: 0,
            height: 0
          });
        } else {
          var bottomH = 0;
          var topH = 0;
          var leftW = 0;
          var rightW = 0;
          var tbSO = 0; // top-bottom spill over: amount y1,y2 axes need above and below of the element rectangle

          var lrSO = 0; // left-right spill over: amount x1,x2 axes need left and right of the element rectangle
          // Determine space for top,left,bottom,right rectangles based on the preferred size of each axis

          this._axisSizable.forEach(function (_axisLabelComp, _orientation) {
            var sizable = _axisLabelComp;
            var orientation = _orientation;
            var tbAxis = Orientation.Top === orientation || Orientation.Bottom === orientation;
            var axisDynamicSize = sizable.getPreferredSize();
            var spillOver = sizable.getSpillOver();

            if (tbAxis) {
              if (axisDynamicSize > _this._chartRect.height * 0.5) axisDynamicSize = _this._chartRect.height * 0.5;
              if (Orientation.Top === orientation) topH = axisDynamicSize;else bottomH = axisDynamicSize;
              if (spillOver > lrSO) lrSO = spillOver;
            } else {
              if (axisDynamicSize > _this._chartRect.width * 0.5) axisDynamicSize = _this._chartRect.width * 0.5;
              if (Orientation.Left === orientation) leftW = axisDynamicSize;else rightW = axisDynamicSize;
              if (spillOver > tbSO) tbSO = spillOver;
            }
          });

          if (lrSO > leftW) leftW = lrSO;
          if (lrSO > rightW) rightW = lrSO;
          if (tbSO > topH) topH = tbSO;
          if (tbSO > bottomH) bottomH = tbSO;
          var elementRectW = Math.max(0, this._chartRect.width - (leftW + rightW));
          var elementRectH = Math.max(0, this._chartRect.height - (topH + bottomH));
          var elementRectT = this._chartRect.y + topH;

          this._orientationMap.set(Orientation.Left, {
            x: this._chartRect.x,
            y: elementRectT,
            width: leftW,
            height: elementRectH
          });

          this._orientationMap.set(Orientation.Right, {
            x: this._chartRect.x + this._chartRect.width - rightW,
            y: elementRectT,
            width: rightW,
            height: elementRectH
          });

          this._orientationMap.set(Orientation.Top, {
            x: this._chartRect.x,
            y: this._chartRect.y,
            width: this._chartRect.width,
            height: topH
          });

          this._orientationMap.set(Orientation.Bottom, {
            x: this._chartRect.x,
            y: this._chartRect.y + this._chartRect.height - bottomH,
            width: this._chartRect.width,
            height: bottomH
          });

          this._elementRect = {
            x: this._chartRect.x + leftW,
            y: elementRectT,
            width: elementRectW,
            height: elementRectH
          };
        }
      }
    }]);

    return ChartLayoutComponent;
  }();

  // 1: vertical numeric; 2: vertical categorical; 3: horizontal numeric; 4: horizontal categorical; 5: axis with no scale

  var AxisScaleScore = Object.freeze({
    VerticalNumeric: 1,
    VerticalCategorical: 2,
    HorizontalNumeric: 3,
    HorizontalCategorical: 4,
    NoScale: 5
  });
  var AxisLayoutOrder = [Orientation.Bottom, Orientation.Top, Orientation.Left, Orientation.Right];

  var AxisLayoutScore = function AxisLayoutScore(_orientation, _score) {
    _classCallCheck$1(this, AxisLayoutScore);

    this.orientation = _orientation;
    this.score = _score;
  };

  function getOrientation(_axisSelector) {
    var labelPos = 0,
        orientation = null;
    var isHorizontal = _axisSelector.select(".domain").attr("d").split("H").length === 2;

    if (_axisSelector.selectAll(".tick text").size() > 0) {
      if (isHorizontal) {
        labelPos = _axisSelector.select(".tick text").attr("y");
        orientation = labelPos > 0 ? Orientation.Bottom : Orientation.Top;
      } else {
        labelPos = _axisSelector.select(".tick text").attr("x");
        orientation = labelPos > 0 ? Orientation.Right : Orientation.Left;
      }
    }

    return orientation;
  }

  var AxesComponent = function AxesComponent() {
    var selector, axes, bounds;
    var layoutProgress;
    var axesScore;
    var elementRect;
    var axisLayoutComponents = new Map();
    var chartLayoutComponent = new ChartLayoutComponent();
    var axisRects = new Map();
    var axisOrientationMap = new Map();
    var layoutAxisOrder = new Array(4);
    var axesPropertyMap = new Map();

    function draw() {
      for (var index = 0; index < 4; index++) {
        var orientation = layoutAxisOrder[index];
        var axisGroup = selector.select(".axisTransform." + orientation);
        if (!orientation) continue;
        var axis = axisOrientationMap.get(orientation);

        if (!axis) {
          axisGroup.remove();
          continue;
        }

        if (axisGroup.empty()) axisGroup = selector.append("g").attr("class", "axisTransform " + orientation);
        var axisLayoutComp = axisLayoutComponents.get(orientation);
        var axisProperty = axesPropertyMap.get(orientation);
        if (!axisProperty) axisProperty = new AxisProperty();

        if (!axisLayoutComp) {
          axisLayoutComp = AxisLayout().axisProperty(axisProperty);
          axisLayoutComponents.set(orientation, axisLayoutComp);
        }

        setScaleRangePadded(orientation);
        var axisRect = axisRects.get(orientation);
        axisLayoutComp.bounds(axisRect).axis(axis);
        axisGroup.call(axisLayoutComp);
        var transform = getTransform(orientation);
        var axisTransform = "translate(" + transform[0] + "," + transform[1] + ")";
        axisGroup.attr("transform", axisTransform);
        if (layoutProgress) postDraw(orientation);
      }
    }

    function postDraw(_orientation) {
      // chip away at the _elementRect based on how much space the just rendered axis wants
      var axisLayoutComponent = axisLayoutComponents.get(_orientation);
      var size = axisLayoutComponent.getPreferredSize();

      if (_orientation === Orientation.Top || _orientation === Orientation.Bottom) {
        if (size > bounds.height * 0.5) size = bounds.height * 0.5;

        if (_orientation === Orientation.Top) {
          elementRect.y += size;
          elementRect.height -= size;
        } else {
          elementRect.height -= size;
        }
      } else {
        if (size > bounds.width * 0.5) size = bounds.width;

        if (_orientation === Orientation.Left) {
          elementRect.x += size;
          elementRect.width -= size;
        } else {
          elementRect.width -= size;
        }
      }

      chartLayoutComponent.add(_orientation, axisLayoutComponent);
    }

    function layout(_selector) {
      selector = _selector.append("g");
      preLayout();
      selector = _selector; // Update rect bounds to use from chartlayout.

      elementRect = chartLayoutComponent.elementRect();
      axisRects.forEach(function (_rect, _orientation) {
        return axisRects.set(_orientation, chartLayoutComponent.getRect(_orientation));
      });
      draw();
    }

    function preLayout() {
      // extra layer to do prelayout.
      layoutProgress = true;
      axisLayoutComponents.clear();
      chartLayoutComponent.chartRect(bounds);

      if (axes) {
        axes.forEach(function (_axis) {
          var dummyNode = selector.append("g");
          dummyNode.call(_axis);
          axisOrientationMap.set(getOrientation(dummyNode), _axis);
          dummyNode.remove();
        });
      }

      for (var index = 0; index < 4; index++) {
        var orientation = AxisLayoutOrder[index];
        if (axisOrientationMap.get(orientation)) // initialize all axis 'rects' to the chart area.
          axisRects.set(orientation, {
            x: bounds.x || 0,
            y: bounds.y || 0,
            width: bounds.width,
            height: bounds.height
          });
      }

      elementRect = {
        x: bounds.x || 0,
        y: bounds.y || 0,
        width: bounds.width,
        height: bounds.height
      };
      axesScore = [];
      var score = 0;

      for (var _index = 0; _index < 4; _index++) {
        var _orientation2 = AxisLayoutOrder[_index];
        var isHorz = _orientation2 === Orientation.Top || _orientation2 === Orientation.Bottom;
        var axis = axisOrientationMap.get(_orientation2);

        if (axis) {
          var scale = axis.scale();
          var isContinuousAxis = scale.rangeBand || scale.step ? false : true;

          if (!isContinuousAxis) {
            score = isHorz ? AxisScaleScore.HorizontalCategorical : AxisScaleScore.VerticalCategorical;
            axesScore.push(new AxisLayoutScore(_orientation2, score));
          } else {
            score = isHorz ? AxisScaleScore.HorizontalNumeric : AxisScaleScore.VerticalNumeric;
            axesScore.push(new AxisLayoutScore(_orientation2, score));
          }
        } else {
          axesScore.push(new AxisLayoutScore(_orientation2, AxisScaleScore.NoScale));
        }
      }

      axesScore.sort(function (a1, a2) {
        return a1.score < a2.score ? -1 : a1.score > a2.score ? 1 : 0;
      });

      for (var i = 0; i < 4; i++) {
        layoutAxisOrder[i] = axesScore[i] ? axesScore[i].orientation : null;
      }

      draw();
      chartLayoutComponent.layout();
      selector.remove();
      layoutProgress = false;
    }

    layout.axes = function (_axes) {
      axes = [];
      _axes && _axes.forEach(function (_axis) {
        verifyAxis(_axis);
        axes.push(_axis);
      });
      return layout;
    };

    layout.axisProperty = function (_orientation, _axisProperty) {
      axesPropertyMap.set(_orientation, _axisProperty);
      return this;
    };

    layout.bounds = function (_bounds) {
      verifyBounds(_bounds);
      bounds = _bounds;
      return layout;
    };

    layout.getRect = function (_orientation) {
      verifyOrientation(_orientation);
      return chartLayoutComponent.getRect(_orientation);
    };

    layout.getScale = function (_orientation) {
      var axis = axisOrientationMap.get(_orientation);
      return axis ? axis.scale() : null;
    };

    function getTransform(_orientation) {
      if (_orientation === Orientation.Left) return [elementRect.x, 0.0];
      if (_orientation === Orientation.Right) return [elementRect.x + elementRect.width, 0.0];
      if (_orientation === Orientation.Top) return [0.0, elementRect.y];
      return [0.0, elementRect.y + elementRect.height];
    }

    function setScaleRangePadded(_orientation) {
      var axis = axisOrientationMap.get(_orientation);

      if (axis) {
        var scale = axis.scale();
        var min, max;
        var isHorizontal = _orientation === Orientation.Bottom || _orientation === Orientation.Top;

        if (isHorizontal) {
          // This axis is on the horizontal
          min = elementRect.x;
          max = elementRect.x + elementRect.width;
        } else {
          min = elementRect.y + elementRect.height;
          max = elementRect.y;
        }

        scale.range([min, max]);
      }
    }

    return layout;
  };

  var CATEGORIES = 0,
      TYPE = 1,
      VALUE = 2; // data column indices

  var margin = {
    left: 50,
    top: 10,
    right: 50,
    bottom: 10
  }; // chart margins
  // data type which is used to determine the positions

  // darker the color by a factor
  var darker = function darker(_color) {
    var _factor = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0.7;

    return "rgba(".concat(_factor * _color.r, ",").concat(_factor * _color.g, ",").concat(_factor * _color.b, ",").concat(_color.a, ")");
  };

  var _default = /*#__PURE__*/function (_RenderBase) {
    _inherits(_default, _RenderBase);

    var _super = _createSuper(_default);

    function _default() {
      var _this;

      _classCallCheck(this, _default);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _defineProperty(_assertThisInitialized(_this), "_uuid", "id".concat(Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)));

      _defineProperty(_assertThisInitialized(_this), "_axisComp", new AxesComponent());

      return _this;
    }

    _createClass(_default, [{
      key: "create",
      // Create is called during initialization
      value: function create(_node) {
        // Create a svg node
        var svg = d3.select(_node).append("svg").attr("width", "100%").attr("height", "100%");
        svg.append("defs").append("clipPath").attr("id", this._uuid).append("rect");
        var container = svg.append("g").attr("class", "container").attr("transform", "translate( ".concat(margin.left, " ").concat(margin.top, " )"));
        container.append("g").attr("class", "chartContent").append("g").attr("class", "elements");
        container.append("g").attr("class", "axes"); // return the container

        return _node;
      } // Update is called during new data, property change, resizing, etc.

    }, {
      key: "update",
      value: function update(_info) {
        var defs = d3.select(_info.node).select("defs");
        var container = d3.select(_info.node).select(".container"); // if no data is mapped, clean up and exit

        if (!_info.data) {
          container.select(".elements").selectAll("*").remove();
          container.select(".axes").selectAll("*").remove();
          return;
        } // get all the props


        var baseRatio = _info.props.get("baseRatio");

        var totalBarColor = _info.props.get("totalBarColor");

        var adjustmentBarColor = _info.props.get("adjustmentBarColor");

        var posDeltaColor = _info.props.get("posDeltaColor");

        var negDeltaColor = _info.props.get("negDeltaColor");

        var labelFont = _info.props.get("labelFont");

        var axisFont = _info.props.get("axisFont");

        var totalType = _info.props.get("totalType").toString();

        var adjustmentType = _info.props.get("adjustmentType").toString();

        var deltaType = _info.props.get("deltaType").toString();

        var showDeltaLines = _info.props.get("deltaLines");

        function isDelta(_d) {
          return _d.caption(TYPE) === deltaType;
        }

        function isAdjustment(_d) {
          return _d.caption(TYPE) === adjustmentType;
        }

        function isTotal(_d) {
          return _d.caption(TYPE) === totalType;
        } // calculate containerBounds


        var containerBounds = {
          width: _info.node.clientWidth - margin.left - margin.right,
          height: _info.node.clientHeight - margin.top - margin.bottom
        }; // generate key categories

        var cats = _info.data.cols[CATEGORIES].tuples.map(function (_t) {
          return _t.key;
        }); // cache the xScale for performance


        var xScale = d3.scaleBand().paddingOuter(0.05).paddingInner(0.3).domain(cats); // create tick format

        var bottomAxis = d3.axisBottom(xScale).tickFormat(function (_val, _idx) {
          return _info.data.cols[CATEGORIES].tuples[_idx].caption;
        }); // create/update axis

        var axisProp = new AxisProperty().tickLabelFont({
          "font-size": axisFont.size ? axisFont.size : null,
          "font-family": axisFont.family ? axisFont.family : null,
          "font-style": axisFont.style ? axisFont.style : null,
          "font-weight": axisFont.weight ? axisFont.weight : null
        });
        container.select(".axes").call(this._axisComp.bounds(containerBounds).axisProperty("bottom", axisProp).axes([bottomAxis]));

        var bottomRect = this._axisComp.getRect("bottom"); // calculate the chart rects ( without axis )


        var chartTopPadding = 60;
        var chartBounds = {
          height: containerBounds.height - bottomRect.height - chartTopPadding,
          width: containerBounds.width
        }; // update the clip rect

        defs.select("#".concat(this._uuid, " rect")).attr("width", chartBounds.width).attr("height", containerBounds.height - bottomRect.height);
        var baseHeight = chartBounds.height * baseRatio;

        var totalValues = _info.data.rows.filter(isTotal); // generate a model from data which is used to calculate the bar positions


        var bars = new Array(_info.data.rows.length);

        for (var i = 0; i < _info.data.rows.length; ++i) {
          var dp = _info.data.rows[i];

          if ((isAdjustment(dp) || isDelta(dp)) && i > 0) {
            bars[i] = {
              ref: dp,
              close: bars[i - 1].close + dp.value(VALUE),
              open: bars[i - 1].close
            };
          } else {
            bars[i] = {
              ref: dp,
              close: dp.value(VALUE),
              open: dp.value(VALUE)
            };
          }
        } // determine the min and max of the domain


        var min = Math.min.apply(Math, _toConsumableArray(bars.map(function (v) {
          return v.close;
        })));
        var max = Math.max.apply(Math, _toConsumableArray(bars.map(function (v) {
          return v.close;
        })));
        var domain = [min, max];
        var yScale = d3.scaleLinear().domain(domain).range([0, chartBounds.height - baseHeight]);
        var elementsSelection = container.select(".chartContent").attr("clip-path", "url(#".concat(this._uuid, ")")).select(".elements").attr("transform", "translate( 0 ".concat(chartTopPadding, " )"));
        var barWidth = xScale.bandwidth();

        function getBarHeight(_row, _idx) {
          if (isTotal(_row)) return Math.max(1, yScale(bars[_idx].open) - yScale(domain[0]));
          return Math.max(1, Math.abs(yScale(bars[_idx].open) - yScale(bars[_idx].close)));
        }

        function getBarY(_row, _idx) {
          if (isTotal(_row)) return chartBounds.height - baseHeight - yScale(bars[_idx].open);
          return chartBounds.height - baseHeight - yScale(Math.max(bars[_idx].open, bars[_idx].close));
        }

        function barFill(_row, _idx) {
          if (isDelta(_row)) return _row.value(VALUE) > 0 ? posDeltaColor : _row.value(VALUE) < 0 ? negDeltaColor : totalBarColor;
          if (isAdjustment(_row)) return adjustmentBarColor;
          return totalBarColor;
        }

        function applyBarStyling(_selection) {
          _selection.attr("stroke-width", function (_d) {
            return _d.selected || _d.highlighted ? 2.5 : 0;
          }).attr("stroke", function (_row, _idx) {
            return darker(barFill(_row));
          }).attr("fill-opacity", function (_d) {
            return !_info.data.hasSelections ? 1 : _d.selected ? 1 : 0.75;
          }).attr("fill", function (_row, _idx) {
            return barFill(_row).toString();
          });
        }

        elementsSelection.selectAll(".dataBar").data(_info.data.rows, function (d) {
          return d.key;
        }).join("rect").attr("class", "dataBar").attr("x", function (row) {
          return xScale(row.tuple(CATEGORIES).key);
        }).attr("y", getBarY).attr("width", barWidth).attr("height", getBarHeight).call(applyBarStyling);
        elementsSelection.selectAll(".baseBar").data(totalValues, function (d) {
          return d.key;
        }).join("rect").attr("class", "baseBar").attr("x", function (row) {
          return xScale(row.tuple(CATEGORIES).key);
        }).attr("y", chartBounds.height - baseHeight + 10).attr("width", barWidth).attr("height", Math.max(1, baseHeight - 10)).call(applyBarStyling); // connections between bars
        // there are next possibilities:
        // connection between 2 delta/adjustment bars
        // connection between total bar and adjustment/delta bar
        // which means no ancestor total bars have connection

        var connections = [];

        for (var _i = 0; _i < _info.data.rows.length - 1; ++_i) {
          var b1 = _info.data.rows[_i];
          var b2 = _info.data.rows[_i + 1];
          if (!(isTotal(b1) && isTotal(b2))) connections.push({
            s: b1,
            e: b2,
            y1: bars[_i].close,
            y2: bars[_i + 1].open
          });
        }

        elementsSelection.selectAll(".connection").data(connections, function (d) {
          return d.s.key;
        }).join("line").attr("class", "connection").attr("x1", function (_row, _idx) {
          return xScale(_row.s.tuple(CATEGORIES).key) + barWidth;
        }).attr("x2", function (_row, _idx) {
          return xScale(_row.e.tuple(CATEGORIES).key);
        }).attr("y1", function (_row, _idx) {
          return chartBounds.height - baseHeight - yScale(_row.y1);
        }).attr("y2", function (_row, _idx) {
          return chartBounds.height - baseHeight - yScale(_row.y2);
        }).style("stroke-width", 1).style("stroke-dasharray", 4).style("stroke", "black");
        var labelContainers = elementsSelection.selectAll(".barLabel").data(_info.data.rows, function (d) {
          return d.key;
        }).join(function (enter) {
          var textContainer = enter.append("g");
          textContainer.append("rect");
          textContainer.append("text");
          return textContainer;
        }).attr("class", "barLabel").style("font", labelFont.toString()).attr("transform", function (_row, _idx) {
          var y; // center of the bar

          if (isDelta(_row) || isAdjustment(_row)) y = chartBounds.height - baseHeight - yScale(_row.value(VALUE) * 0.5 + bars[_idx].open);else y = chartBounds.height - baseHeight - yScale(_row.value(VALUE)) - 10;
          return "translate( ".concat(xScale(_row.tuple(CATEGORIES).key) + barWidth * 0.5, " ").concat(y, " )");
        });
        labelContainers.select("rect").attr("width", function (row) {
          return "".concat(row.value(VALUE).toString().length * 0.75, "em");
        }).attr("height", "1.01em").attr("x", function (row) {
          return "-".concat(row.value(VALUE).toString().length * 0.75 * 0.5, "em");
        }).attr("y", "-0.55em").attr("fill", "white").attr("fill-opacity", 0.6);
        labelContainers.select("text").attr("dy", "0.3em").attr("text-anchor", "middle").text(function (row) {
          return row.value(VALUE);
        }); // render delta lines

        var deltaLines = []; // only calculate delta lines if property is enabled

        if (showDeltaLines) for (var _i2 = 0; _i2 < totalValues.length - 1; ++_i2) {
          deltaLines.push({
            start: totalValues[_i2],
            end: totalValues[_i2 + 1]
          });
        }
        elementsSelection.selectAll(".deltaLine").data(deltaLines, function (_d) {
          return _d.start.key;
        }).join("path").attr("class", "deltaLine").attr("d", function (_d) {
          var yLeft = chartBounds.height - baseHeight - yScale(_d.start.value(VALUE));
          var yRight = chartBounds.height - baseHeight - yScale(_d.end.value(VALUE));
          var maxY = Math.min(yLeft, yRight);
          var x1 = xScale(_d.start.tuple(CATEGORIES).key) + barWidth * 0.5;
          var y1 = yLeft - 30;
          var x2 = xScale(_d.start.tuple(CATEGORIES).key) + barWidth * 0.5;
          var y2 = maxY - 40;
          var x3 = xScale(_d.end.tuple(CATEGORIES).key) + barWidth * 0.5;
          var y3 = maxY - 40;
          var x4 = xScale(_d.end.tuple(CATEGORIES).key) + barWidth * 0.5;
          var y4 = yRight - 30;
          return "M".concat(x1, ",").concat(y1, " ").concat(x2, ",").concat(y2, " ").concat(x3, ",").concat(y3, " ").concat(x4, ",").concat(y4);
        }).attr("stroke-width", 1.5).attr("fill", "none").attr("stroke", "black");
        var lineLabels = elementsSelection.selectAll(".deltaLineLabel").data(deltaLines, function (_d) {
          return _d.start.key;
        }).join(function (enter) {
          var textContainer = enter.append("g");
          textContainer.append("rect");
          textContainer.append("text");
          return textContainer;
        }).attr("class", "deltaLineLabel").style("font", labelFont.toString()).attr("transform", function (_d, _idx) {
          var yLeft = chartBounds.height - baseHeight - yScale(_d.start.value(VALUE));
          var yRight = chartBounds.height - baseHeight - yScale(_d.end.value(VALUE));
          var maxY = Math.min(yLeft, yRight);
          var x2 = xScale(_d.start.tuple(CATEGORIES).key) + barWidth * 0.5;
          var y2 = maxY - 40;
          var x3 = xScale(_d.end.tuple(CATEGORIES).key) + barWidth * 0.5;
          return "translate( ".concat((x3 - x2) * 0.5 + x2, " ").concat(y2, ")");
        });

        function getPercentage(_d) {
          return "".concat(Math.round((_d.end.value(VALUE) - _d.start.value(VALUE)) / _d.start.value(VALUE) * 100), "%");
        }

        lineLabels.select("rect").attr("width", function (_d) {
          return "".concat(getPercentage(_d).toString().length, "em");
        }).attr("height", "1.1em").attr("x", function (_d) {
          return "-".concat(getPercentage(_d).toString().length * 0.5, "em");
        }).attr("y", "-0.55em").attr("rx", 5).attr("ry", 5).attr("stroke", "black").attr("fill", "white");
        lineLabels.select("text").attr("dy", "0.3em").attr("text-anchor", "middle").text(getPercentage);
      }
    }]);

    return _default;
  }(st);

  return _default;

});
