define( [], function()
{
    return {
        root: true,
        nl: true,
        de: true
    };
} );
