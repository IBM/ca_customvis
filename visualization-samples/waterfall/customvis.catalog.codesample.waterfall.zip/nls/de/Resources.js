define(
{
    "no_data": "Keine Daten"
} );
