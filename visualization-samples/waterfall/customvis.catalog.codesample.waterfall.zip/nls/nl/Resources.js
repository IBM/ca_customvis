define(
{
    "no_data": "Geen Data"
} );
