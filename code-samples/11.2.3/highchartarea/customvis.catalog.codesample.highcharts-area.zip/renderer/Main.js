define(['require'], (function (requirejs) { 'use strict';

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
  }
  function _callSuper(t, o, e) {
    return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
  }
  function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  function _defineProperties(e, r) {
    for (var t = 0; t < r.length; t++) {
      var o = r[t];
      o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
    }
  }
  function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
      writable: !1
    }), e;
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _getPrototypeOf(t) {
    return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
      return t.__proto__ || Object.getPrototypeOf(t);
    }, _getPrototypeOf(t);
  }
  function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(e && e.prototype, {
      constructor: {
        value: t,
        writable: !0,
        configurable: !0
      }
    }), Object.defineProperty(t, "prototype", {
      writable: !1
    }), e && _setPrototypeOf(t, e);
  }
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (_isNativeReflectConstruct = function () {
      return !!t;
    })();
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _possibleConstructorReturn(t, e) {
    if (e && ("object" == typeof e || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return _assertThisInitialized(t);
  }
  function _setPrototypeOf(t, e) {
    return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
      return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r);
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (String )(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _typeof(o) {
    "@babel/helpers - typeof";

    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
      return typeof o;
    } : function (o) {
      return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var e = /*#__PURE__*/function () {
    function e(t, _e) {
      _classCallCheck(this, e);
      this.name = t, this.slot = _e || null, this.attributes = new Map();
    }
    return _createClass(e, [{
      key: "getName",
      value: function getName() {
        return this.name;
      }
    }, {
      key: "getSlot",
      value: function getSlot() {
        return this.slot;
      }
    }, {
      key: "getAttributes",
      value: function getAttributes() {
        return this.attributes;
      }
    }, {
      key: "attr",
      value: function attr(t, _e2) {
        return this.attributes.set(t, _e2), this;
      }
    }], [{
      key: "slotLimit",
      value: function slotLimit(t, s) {
        return new e("limit", t).attr("n", s);
      }
    }, {
      key: "dataLimit",
      value: function dataLimit(t) {
        return new e("limit").attr("n", t);
      }
    }]);
  }();
  function s(t, e, s) {
    return t.getDecoration(e, s);
  }
  function r(t) {
    return t.hasDecoration("hasSelection") ? s(t, "hasSelection", !1) : !!function (t) {
      return "getSlot" in t && "hasDecorationOnDataPoints" in t;
    }(t) && t.hasDecorationOnDataPoints("selected");
  }
  var n = /*#__PURE__*/function () {
    function n(t, e) {
      _classCallCheck(this, n);
      this.min = t, this.max = e;
    }
    return _createClass(n, [{
      key: "asArray",
      value: function asArray() {
        return [this.min, this.max];
      }
    }]);
  }();
  n.empty = new n(0, 0);
  var o = /*#__PURE__*/function (_n) {
    function o(t, e) {
      _classCallCheck(this, o);
      return _callSuper(this, o, [t, e]);
    }
    _inherits(o, _n);
    return _createClass(o, null, [{
      key: "fromRS",
      value: function fromRS(t) {
        return new n(t.min, t.max);
      }
    }]);
  }(n);
  var i = /*#__PURE__*/function () {
    function i(t, e) {
      _classCallCheck(this, i);
      this.source = t, this.index = e, this.key = t.getKey(!1), this.caption = t.getCaption("label") || "";
      var s = t.getItems() || [];
      this.segments = s.map(function (t) {
        return new c(t);
      });
    }
    return _createClass(i, [{
      key: "selected",
      get: function get() {
        return s(this.source, "selected", !1);
      }
    }, {
      key: "highlighted",
      get: function get() {
        return s(this.source, "highlighted", !1);
      }
    }]);
  }();
  var l = /*#__PURE__*/function (_i) {
    function l(t, e) {
      _classCallCheck(this, l);
      return _callSuper(this, l, [t, e]);
    }
    _inherits(l, _i);
    return _createClass(l);
  }(i);
  var a = /*#__PURE__*/function () {
    function a(t) {
      _classCallCheck(this, a);
      this.source = t, this.key = this.source.getUniqueName() || "", this.caption = this.source.getCaption("label") || "";
    }
    return _createClass(a, [{
      key: "selected",
      get: function get() {
        return s(this.source, "selected", !1);
      }
    }, {
      key: "highlighted",
      get: function get() {
        return s(this.source, "highlighted", !1);
      }
    }]);
  }();
  var c = /*#__PURE__*/function (_a) {
    function c(t) {
      _classCallCheck(this, c);
      return _callSuper(this, c, [t]);
    }
    _inherits(c, _a);
    return _createClass(c);
  }(a);
  var u = new (/*#__PURE__*/function () {
    function _class() {
      _classCallCheck(this, _class);
    }
    return _createClass(_class, [{
      key: "format",
      value: function format(t) {
        return t ? t.toString() : "";
      }
    }]);
  }())();
  var h;
  !function (t) {
    t.label = "label", t.data = "data";
  }(h || (h = {}));
  var p = /*#__PURE__*/function () {
    function p(t, e, s, r, n) {
      _classCallCheck(this, p);
      this.source = t, this.tuples = e, this.segments = s, this.domain = r, this.caption = n;
      var o = t.dataItems || [],
        i = o.length > 0 ? o[0] : null,
        l = i && i.asCont();
      l ? (this._labelFormatter = l.getFormatter("label") || u, this._dataFormatter = l.getFormatter("data") || u) : this._labelFormatter = this._dataFormatter = u;
    }
    return _createClass(p, [{
      key: "mapped",
      get: function get() {
        return this.source.mapped;
      }
    }, {
      key: "dataType",
      get: function get() {
        var t = this.source.getDataItem(0);
        return this.mapped && t ? t.type : "none";
      }
    }, {
      key: "format",
      value: function format(t, e) {
        return function (t, e) {
          return t.format(e);
        }(e === h.data ? this._dataFormatter : this._labelFormatter, t);
      }
    }]);
  }();
  var g = /*#__PURE__*/function (_p) {
    function g(t, e, s, r, n) {
      _classCallCheck(this, g);
      return _callSuper(this, g, [t, e, s, r, n]);
    }
    _inherits(g, _p);
    return _createClass(g);
  }(p);
  var f = /*#__PURE__*/function () {
    function f(t, e) {
      _classCallCheck(this, f);
      this.source = t, this.key = t.getKey(!1), this.dataSet = e;
    }
    return _createClass(f, [{
      key: "selected",
      get: function get() {
        return s(this.source, "selected", !1);
      }
    }, {
      key: "highlighted",
      get: function get() {
        return s(this.source, "highlighted", !1);
      }
    }, {
      key: "tuple",
      value: function tuple(t) {
        var e = this._getSlot(t);
        if (!e || 0 === e.tuples.length) return null;
        var s = this.source.get(e.source);
        if (!s) return null;
        var r = s.asCat();
        return r ? e.tuples[r.index] : null;
      }
    }, {
      key: "value",
      value: function value(t) {
        var e = this._getSlot(t),
          s = e && this.source.get(e.source);
        if (!s) return null;
        var r = s.asCont();
        return r && "numeric" === r.valueType ? r.value : null;
      }
    }, {
      key: "caption",
      value: function caption(t) {
        var e = this._getSlot(t),
          s = e && this.source.get(e.source);
        return s && s.getCaption("data") || "";
      }
    }, {
      key: "_getSlot",
      value: function _getSlot(t) {
        return "string" == typeof t ? this.dataSet.slotMap.get(t) || null : this.dataSet.cols[t] || null;
      }
    }]);
  }();
  var d = /*#__PURE__*/function (_f) {
    function d(t, e) {
      _classCallCheck(this, d);
      return _callSuper(this, d, [t, e]);
    }
    _inherits(d, _f);
    return _createClass(d);
  }(f);
  var m = /*#__PURE__*/function () {
    function m(t, e, s) {
      var _this = this;
      _classCallCheck(this, m);
      this.source = t, this.rows = t.dataPoints.map(function (t) {
        return new d(t, _this);
      }), this.cols = e, this.slotMap = s;
    }
    return _createClass(m, [{
      key: "hasSelections",
      get: function get() {
        return r(this.source);
      }
    }], [{
      key: "filterRows",
      value: function filterRows(t, e, s) {
        return t.filter(function (t) {
          var r = t.tuple(e);
          return !!r && r.key === s;
        });
      }
    }]);
  }();
  var y = /*#__PURE__*/function (_m) {
    function y(t, e, s) {
      _classCallCheck(this, y);
      return _callSuper(this, y, [t, e, s]);
    }
    _inherits(y, _m);
    return _createClass(y);
  }(m);
  function _(t) {
    var e = new Map(),
      s = t.getSlots().map(function (t, s) {
        var r = [],
          i = [],
          a = n.empty,
          u = "";
        if (t.isMapped()) {
          var _e3 = t.getDataItem(0);
          if (u = _e3.getCaption("label"), "cat" === _e3.getRSType()) {
            r = _e3.getTuples().map(function (t, e) {
              return new l(t, e);
            });
            i = _e3.getItemClassSet(0).getItemClasses().map(function (t) {
              return new c(t);
            });
          } else a = o.fromRS(_e3.getDomain()), i.push(new c(_e3.getItemClass()));
        }
        var h = new g(t, r, i, a, u);
        return e.set(t.name, h), h;
      });
    return new y(t, s, e);
  }
  var w = /^\s*#([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{0,2})\s*$/,
    C = /^\s*rgba?\s*\(\s*(\d+\%?)\s*,\s*(\d+\%?)\s*,\s*(\d+\%?)\s*(?:,\s*(\d+(?:\.\d+)?\%?)\s*)?\)\s*/;
  function b(t) {
    return t < 0 ? 0 : t > 255 ? 255 : Math.floor(t);
  }
  var S = /*#__PURE__*/function () {
    function S(t, e, s, r) {
      _classCallCheck(this, S);
      var n;
      this.r = b(t), this.g = b(e), this.b = b(s), this.a = (n = r) < 0 ? 0 : n > 1 ? 1 : n;
    }
    return _createClass(S, [{
      key: "toString",
      value: function toString() {
        return 1 === this.a ? "rgb(".concat(this.r, ",").concat(this.g, ",").concat(this.b, ")") : "rgba(".concat(this.r, ",").concat(this.g, ",").concat(this.b, ",").concat(this.a, ")");
      }
    }], [{
      key: "darker",
      value: function darker(t, e) {
        var s = e ? Math.pow(.7, e) : .7;
        return new S(t.r * s, t.g * s, t.b * s, t.a);
      }
    }, {
      key: "fromObject",
      value: function fromObject(t) {
        return new S(t.r, t.g, t.b, void 0 === t.a ? 1 : t.a);
      }
    }, {
      key: "fromString",
      value: function fromString(t) {
        var e = C.exec(t);
        var s = e || w.exec(t);
        var r = e ? void 0 : 16;
        if (!s) return null;
        var n = parseInt(s[1], r),
          o = parseInt(s[2], r),
          i = parseInt(s[3], r);
        var l;
        return s[4] && (l = e ? parseFloat(s[4]) : Math.round(parseInt(s[4], r) / 255 * 100) / 100), this.fromObject({
          r: n,
          g: o,
          b: i,
          a: l
        });
      }
    }]);
  }();
  function x(t, e) {
    var s = null;
    if (t instanceof f) s = t.source.getDataSet(e);else {
      var _r = t.source.getDataItem(e);
      s = _r && _r.getDataSet(e);
    }
    return !!s && r(s);
  }
  var I = function I(t) {
      return "rgba(".concat(t.r, ",").concat(t.g, ",").concat(t.b, ",0.4)");
    },
    j = function j(t) {
      return "rgba(".concat(Math.round(.7 * t.r), ",").concat(Math.round(.7 * t.g), ",").concat(Math.round(.7 * t.b), ",").concat(t.a, ")");
    };
  var E = /*#__PURE__*/function () {
    function E(t, e, s) {
      _classCallCheck(this, E);
      this.source = t, this._dataContext = e, this._slotResolver = s;
    }
    return _createClass(E, [{
      key: "slot",
      get: function get() {
        return this.source.slot;
      }
    }, {
      key: "getColor",
      value: function getColor(t) {
        return t ? S.fromObject(this.source.getTupleColor(t.source, -1)) : S.fromObject(this.source.getColor(null));
      }
    }, {
      key: "_getTuple",
      value: function _getTuple(t) {
        if (t instanceof i) return t;
        var e = this.slot || this._slotResolver(t.dataSet, this.source.name);
        return e ? t.tuple(e) : null;
      }
    }, {
      key: "getFillColor",
      value: function getFillColor(t) {
        if (null === t) return this.source.getColor(null).toString();
        var e = this._getTuple(t);
        var s;
        return s = e ? this.source.getTupleColor(e.source, -1) : this.source.getColor(t.source), !t.selected && x(t, this._dataContext) ? I(s) : s.toString();
      }
    }, {
      key: "getOutlineColor",
      value: function getOutlineColor(t) {
        if (null === t) return this.source.getColor(null).toString();
        var e = this._getTuple(t);
        var s;
        return s = e ? this.source.getTupleColor(e.source, -1) : this.source.getColor(t.source), t.highlighted || t.selected && x(t, this._dataContext) ? j(s) : null;
      }
    }]);
  }();
  var P = /*#__PURE__*/_createClass(function P(t, e, s) {
    _classCallCheck(this, P);
    this.color = t, this.at = e, this.value = s;
  });
  function D(t) {
    return t.map(function (t) {
      return new P(S.fromObject(t.color), t.at, t.value);
    });
  }
  var F = /*#__PURE__*/function () {
    function F(t, e, s) {
      _classCallCheck(this, F);
      this.source = t, this._slot = e, this._dataContext = s, this.stops = D(t.stops), this.aligned = D(t.aligned), this.interpolate = t.interpolate;
    }
    return _createClass(F, [{
      key: "getColor",
      value: function getColor(t) {
        return S.fromObject(this.source.getColor(t));
      }
    }, {
      key: "getFillColor",
      value: function getFillColor(t) {
        var e = this._slot ? Number(t.value(this._slot)) : 0,
          s = this.source.getColor(e);
        return !t.selected && x(t, this._dataContext) ? I(s) : s.toString();
      }
    }, {
      key: "getOutlineColor",
      value: function getOutlineColor(t) {
        var e = this._slot ? Number(t.value(this._slot)) : 0,
          s = this.source.getColor(e);
        return t.highlighted || t.selected && x(t, this._dataContext) ? j(s) : null;
      }
    }]);
  }();
  var T = /*#__PURE__*/function () {
    function T(t, e, s) {
      _classCallCheck(this, T);
      this.source = t, this._dataContext = e, this._lastDataItem = null, this._cachedStops = null, this._slotResolver = s;
    }
    return _createClass(T, [{
      key: "slot",
      get: function get() {
        return this.source.slot;
      }
    }, {
      key: "getColorStops",
      value: function getColorStops(t) {
        var e = t ? t.source.getDataItem(0) : null,
          s = e && e.asCont();
        var r = s ? s.getDomain(null) : null;
        var n = this.source.getColorStops(s, r),
          o = t ? t.source.name : null;
        return new F(n, o, this._dataContext);
      }
    }, {
      key: "_fetchColorStops",
      value: function _fetchColorStops(t) {
        var e = t.source.getDataSet(this._dataContext),
          s = this.slot || this._slotResolver(t.dataSet, this.source.name),
          r = s ? e.getSlot(s) : null,
          n = r ? r.getDataItem(0) : null,
          o = n ? n.asCont() : null;
        if (this.source.dirty || !this._cachedStops || o !== this._lastDataItem) {
          var _t = o ? o.getDomain(null) : null,
            _e4 = this.source.getColorStops(o, _t);
          this._cachedStops = new F(_e4, r && r.name, this._dataContext), this._lastDataItem = o;
        }
        return this._cachedStops;
      }
    }, {
      key: "getFillColor",
      value: function getFillColor(t) {
        return this._fetchColorStops(t).getFillColor(t);
      }
    }, {
      key: "getOutlineColor",
      value: function getOutlineColor(t) {
        return this._fetchColorStops(t).getOutlineColor(t);
      }
    }]);
  }();
  var A = /*#__PURE__*/function (_S) {
    function A(t) {
      var _this2;
      _classCallCheck(this, A);
      _this2 = _callSuper(this, A, [t.r, t.g, t.b, t.a]), _this2._color = t;
      return _this2;
    }
    _inherits(A, _S);
    return _createClass(A, [{
      key: "getRed",
      value: function getRed() {
        return this.r;
      }
    }, {
      key: "getGreen",
      value: function getGreen() {
        return this.g;
      }
    }, {
      key: "getBlue",
      value: function getBlue() {
        return this.b;
      }
    }, {
      key: "getAlpha",
      value: function getAlpha() {
        return this.a;
      }
    }]);
  }(S);
  var O = Object.freeze({
    min: 0,
    max: 0,
    empty: !0,
    explicit: !1,
    getMin: function getMin() {
      return 0;
    },
    getMax: function getMax() {
      return 0;
    },
    isEmpty: function isEmpty() {
      return !0;
    },
    isExplicit: function isExplicit() {
      return !1;
    }
  });
  var $ = /*#__PURE__*/function () {
    function $(t, e, s, r, n, o) {
      _classCallCheck(this, $);
      this.caption = t, this.color = e, this.shape = s, this.selected = r, this.highlighted = n, this.ref = o;
    }
    return _createClass($, [{
      key: "getCaption",
      value: function getCaption() {
        return this.caption;
      }
    }, {
      key: "getColor",
      value: function getColor() {
        return this.color ? new A(this.color) : null;
      }
    }, {
      key: "getShape",
      value: function getShape() {
        return this.shape;
      }
    }, {
      key: "isSelected",
      value: function isSelected() {
        return this.selected;
      }
    }, {
      key: "isHighlighted",
      value: function isHighlighted() {
        return this.highlighted;
      }
    }, {
      key: "getRef",
      value: function getRef() {
        return this.ref;
      }
    }]);
  }();
  var R = /*#__PURE__*/function () {
    function R(t, e, s, r, n, o) {
      _classCallCheck(this, R);
      this.type = t, this.channel = e, this.slot = s, this.caption = r, this.subCaption = n, this.ref = o;
    }
    return _createClass(R, [{
      key: "getRSType",
      value: function getRSType() {
        return this.type;
      }
    }, {
      key: "getChannel",
      value: function getChannel() {
        return this.channel;
      }
    }, {
      key: "getSlot",
      value: function getSlot() {
        return this.slot;
      }
    }, {
      key: "getCaption",
      value: function getCaption() {
        return this.caption;
      }
    }, {
      key: "getSubCaption",
      value: function getSubCaption() {
        return this.subCaption;
      }
    }, {
      key: "getRef",
      value: function getRef() {
        return this.ref;
      }
    }]);
  }();
  var M = /*#__PURE__*/function (_R) {
    function M(t, e, r, n, o) {
      var _this3;
      _classCallCheck(this, M);
      var i = e && e.source,
        l = i && i.name,
        a = i && i.getDataItem(0),
        c = a && a.asCat();
      _this3 = _callSuper(this, M, ["cat", t, l, r, "", c]);
      var u = c ? c.tuples : [];
      _this3.entries = u.map(function (t) {
        var e = t.getCaption("label") || "",
          r = o && o.source.getTupleColor(t, -1),
          i = s(t, "selected", !1),
          l = s(t, "highlighted", !1);
        return new $(e, r ? S.fromObject(r) : null, n, i, l, t);
      });
      return _this3;
    }
    _inherits(M, _R);
    return _createClass(M, [{
      key: "getEntries",
      value: function getEntries() {
        return this.entries;
      }
    }]);
  }(R);
  var L = /*#__PURE__*/function (_R2) {
    function L(t, e, s, r) {
      var _this4;
      _classCallCheck(this, L);
      var n = e && e.source,
        o = n && n.name,
        i = n && n.getDataItem(0),
        l = i && i.asCont();
      if (_this4 = _callSuper(this, L, ["cont", t, o, s, "", l]), _this4.domain = l ? l.getDomain(null) : O, r && "color" === t) {
        var _t2 = r.source.getColorStops(l, null);
        _this4.stops = _t2.stops, _this4.interpolate = _t2.interpolate;
      } else _this4.stops = null, _this4.interpolate = !1;
      return _this4;
    }
    _inherits(L, _R2);
    return _createClass(L, [{
      key: "getDomain",
      value: function getDomain() {
        return this.domain;
      }
    }, {
      key: "getInterpolate",
      value: function getInterpolate() {
        return this.interpolate;
      }
    }, {
      key: "getStops",
      value: function getStops() {
        return this.stops;
      }
    }]);
  }(R);
  function k(t, e, s, r) {
    if (!t) return [];
    var n = new Map(),
      o = new Map();
    e.palettes.forEach(function (e) {
      var s = e.slot || r && r(t, e.source.name);
      s && (e instanceof E ? n.set(s, e) : e instanceof T && o.set(s, e));
    });
    var i = [];
    return t.cols.forEach(function (t) {
      var e = t.source;
      if (!e.mapped) return;
      var r = e.getDataItem(0);
      if (r) switch (r.type) {
        case "cat":
          if (-1 === e.channels.indexOf("color")) return;
          var _r2 = n.get(e.name);
          _r2 && i.push(new M("color", t, t.caption, s.legendShape, _r2));
          break;
        case "cont":
          if (-1 !== e.channels.indexOf("color")) {
            var _s = o.get(e.name);
            _s && i.push(new L("color", t, t.caption, _s));
          }
          -1 !== e.channels.indexOf("size") && i.push(new L("size", t, t.caption, null));
      }
    }), i;
  }
  var z = /*#__PURE__*/_createClass(function z() {
    _classCallCheck(this, z);
    this.legendShape = null, this.slotLimits = new Map(), this.dataLimit = -1;
  });
  var B, H, U;
  !function (t) {
    t.Em = "em", t.Percentage = "%", t.Centimeter = "cm", t.Millimeter = "mm", t.Inch = "in", t.Pica = "pc", t.Point = "pt", t.Pixel = "px";
  }(B || (B = {}));
  var V = /*#__PURE__*/function () {
    function V(t, e) {
      _classCallCheck(this, V);
      this.value = t, this.unit = e;
    }
    return _createClass(V, [{
      key: "toString",
      value: function toString() {
        return "".concat(this.value).concat(this.unit);
      }
    }], [{
      key: "fromObject",
      value: function fromObject(t) {
        return new V(t.value, function (t) {
          switch (t) {
            case "em":
              return B.Em;
            case "%":
              return B.Percentage;
            case "cm":
              return B.Centimeter;
            case "mm":
              return B.Millimeter;
            case "in":
              return B.Inch;
            case "pc":
              return B.Pica;
            case "pt":
              return B.Point;
            case "px":
              return B.Pixel;
            default:
              throw new Error("Invalid length unit '".concat(t, "' specified"));
          }
        }(t.unit));
      }
    }]);
  }();
  !function (t) {
    t.Normal = "normal", t.Italic = "italic";
  }(H || (H = {})), function (t) {
    t[t.Thin = 100] = "Thin", t[t.ExtraLight = 200] = "ExtraLight", t[t.Light = 300] = "Light", t[t.Normal = 400] = "Normal", t[t.Medium = 500] = "Medium", t[t.SemiBold = 600] = "SemiBold", t[t.Bold = 700] = "Bold", t[t.ExtraBold = 800] = "ExtraBold", t[t.Heavy = 900] = "Heavy";
  }(U || (U = {}));
  var q = /\s+/g;
  function K(t) {
    switch (t) {
      case U.Normal:
        return "normal";
      case U.Bold:
        return "bold";
      case U.Thin:
      case U.ExtraLight:
      case U.Light:
      case U.Medium:
      case U.SemiBold:
      case U.ExtraBold:
      case U.Heavy:
        return t.toString();
      default:
        return "";
    }
  }
  function G(t) {
    var e = [];
    if (t) for (var _s2 = 0, _r3 = t.length; _s2 < _r3; ++_s2) {
      var _r4 = t[_s2],
        _n2 = q.test(_r4);
      e.push(_n2 ? "\"".concat(_r4, "\"") : _r4);
    }
    return e.join(", ");
  }
  var J = /*#__PURE__*/function () {
    function J(t, e, s, r) {
      _classCallCheck(this, J);
      this.family = t, this.size = e, this.style = s, this.weight = r;
    }
    return _createClass(J, [{
      key: "toString",
      value: function toString() {
        if (this.style !== H.Normal && this.weight !== U.Normal || this.style === H.Normal && this.weight === U.Normal) {
          var _t3 = [];
          return this.style === H.Normal ? _t3.push("normal") : (this.style && _t3.push(this.style), this.weight && _t3.push(K(this.weight))), this.size && _t3.push(this.size.toString()), this.family && _t3.push(G(this.family)), _t3.join(" ");
        }
        return function (t) {
          var e = [];
          var s = G(t.family);
          var r;
          return s.length > 0 && e.push("font-family: ".concat(s, ";")), s = t.size ? t.size.toString() : "", s.length > 0 && e.push("font-size: ".concat(s, ";")), s = (r = t.style) ? r.toString() : "", s.length > 0 && e.push("font-style: ".concat(s, ";")), s = K(t.weight), s.length > 0 && e.push("font-weight: ".concat(s, ";")), e.join(" ");
        }(this);
      }
    }], [{
      key: "fromObject",
      value: function fromObject(t) {
        var e = t.family || null,
          s = t.size ? V.fromObject(t.size) : null,
          r = t.style ? function (t) {
            switch (t) {
              case "normal":
                return H.Normal;
              case "italic":
                return H.Italic;
              default:
                throw new Error("Invalid font style '".concat(t, "' specified"));
            }
          }(t.style) : null,
          n = void 0 !== t.weight && null !== t.weight ? t.weight : null;
        return new J(e, s, r, n);
      }
    }]);
  }();
  var Q = /*#__PURE__*/function () {
    function Q(t, e, s) {
      _classCallCheck(this, Q);
      var r = new Map();
      null !== t && t.forEach(function (t, n) {
        if ("palette" === t.type) {
          var _o = t;
          switch (_o.paletteType) {
            case "cat":
              r.set(n, new E(_o, e, s));
              break;
            case "cont":
              r.set(n, new T(_o, e, s));
          }
        }
      }), this.source = t, this.palettes = r;
    }
    return _createClass(Q, [{
      key: "get",
      value: function get(t) {
        return this._getValue(t, !1);
      }
    }, {
      key: "peek",
      value: function peek(t) {
        return this._getValue(t, !0);
      }
    }, {
      key: "_getValue",
      value: function _getValue(t, e) {
        var s = this.source && this.source.get(t);
        if (!s) return null;
        switch (s.type) {
          case "string":
          case "number":
          case "boolean":
          case "enum":
            return e ? s.peek : s.value;
          case "length":
            var _r5 = e ? s.peek : s.value;
            return _r5 ? V.fromObject(_r5) : null;
          case "font":
            var _n3 = e ? s.peek : s.value;
            return _n3 ? J.fromObject(_n3) : null;
          case "color":
            var _o2 = e ? s.peek : s.value;
            return _o2 ? S.fromObject(_o2) : null;
          case "palette":
            return this.palettes.get(t) || null;
          default:
            return null;
        }
      }
    }, {
      key: "isActive",
      value: function isActive(t) {
        var e = this.source && this.source.get(t);
        return !!e && e.active;
      }
    }, {
      key: "setActive",
      value: function setActive(t, e) {
        var s = this.source && this.source.get(t);
        s && s.setActive(e);
      }
    }, {
      key: "isDirty",
      value: function isDirty(t) {
        var e = this.source && this.source.get(t);
        return !!e && e.dirty;
      }
    }]);
  }();
  function W(t, e) {
    this.name = "AggregateError", this.errors = t, this.message = e || "";
  }
  W.prototype = Error.prototype;
  var X = setTimeout;
  function Y(t) {
    return Boolean(t && void 0 !== t.length);
  }
  function Z() {}
  function tt(t) {
    if (!(this instanceof tt)) throw new TypeError("Promises must be constructed via new");
    if ("function" != typeof t) throw new TypeError("not a function");
    this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], it(t, this);
  }
  function et(t, e) {
    for (; 3 === t._state;) t = t._value;
    0 !== t._state ? (t._handled = !0, tt._immediateFn(function () {
      var s = 1 === t._state ? e.onFulfilled : e.onRejected;
      if (null !== s) {
        var r;
        try {
          r = s(t._value);
        } catch (t) {
          return void rt(e.promise, t);
        }
        st(e.promise, r);
      } else (1 === t._state ? st : rt)(e.promise, t._value);
    })) : t._deferreds.push(e);
  }
  function st(t, e) {
    try {
      if (e === t) throw new TypeError("A promise cannot be resolved with itself.");
      if (e && ("object" == _typeof(e) || "function" == typeof e)) {
        var s = e.then;
        if (e instanceof tt) return t._state = 3, t._value = e, void nt(t);
        if ("function" == typeof s) return void it((r = s, n = e, function () {
          r.apply(n, arguments);
        }), t);
      }
      t._state = 1, t._value = e, nt(t);
    } catch (e) {
      rt(t, e);
    }
    var r, n;
  }
  function rt(t, e) {
    t._state = 2, t._value = e, nt(t);
  }
  function nt(t) {
    2 === t._state && 0 === t._deferreds.length && tt._immediateFn(function () {
      t._handled || tt._unhandledRejectionFn(t._value);
    });
    for (var e = 0, s = t._deferreds.length; e < s; e++) et(t, t._deferreds[e]);
    t._deferreds = null;
  }
  function ot(t, e, s) {
    this.onFulfilled = "function" == typeof t ? t : null, this.onRejected = "function" == typeof e ? e : null, this.promise = s;
  }
  function it(t, e) {
    var s = !1;
    try {
      t(function (t) {
        s || (s = !0, st(e, t));
      }, function (t) {
        s || (s = !0, rt(e, t));
      });
    } catch (t) {
      if (s) return;
      s = !0, rt(e, t);
    }
  }
  tt.prototype["catch"] = function (t) {
    return this.then(null, t);
  }, tt.prototype.then = function (t, e) {
    var s = new this.constructor(Z);
    return et(this, new ot(t, e, s)), s;
  }, tt.prototype["finally"] = function (t) {
    var e = this.constructor;
    return this.then(function (s) {
      return e.resolve(t()).then(function () {
        return s;
      });
    }, function (s) {
      return e.resolve(t()).then(function () {
        return e.reject(s);
      });
    });
  }, tt.all = function (t) {
    return new tt(function (e, s) {
      if (!Y(t)) return s(new TypeError("Promise.all accepts an array"));
      var r = Array.prototype.slice.call(t);
      if (0 === r.length) return e([]);
      var n = r.length;
      function o(t, i) {
        try {
          if (i && ("object" == _typeof(i) || "function" == typeof i)) {
            var l = i.then;
            if ("function" == typeof l) return void l.call(i, function (e) {
              o(t, e);
            }, s);
          }
          r[t] = i, 0 == --n && e(r);
        } catch (t) {
          s(t);
        }
      }
      for (var i = 0; i < r.length; i++) o(i, r[i]);
    });
  }, tt.any = function (t) {
    var e = this;
    return new e(function (s, r) {
      if (!t || void 0 === t.length) return r(new TypeError("Promise.any accepts an array"));
      var n = Array.prototype.slice.call(t);
      if (0 === n.length) return r();
      for (var o = [], i = 0; i < n.length; i++) try {
        e.resolve(n[i]).then(s)["catch"](function (t) {
          o.push(t), o.length === n.length && r(new W(o, "All promises were rejected"));
        });
      } catch (t) {
        r(t);
      }
    });
  }, tt.allSettled = function (t) {
    return new this(function (e, s) {
      if (!t || void 0 === t.length) return s(new TypeError(_typeof(t) + " " + t + " is not iterable(cannot read property Symbol(Symbol.iterator))"));
      var r = Array.prototype.slice.call(t);
      if (0 === r.length) return e([]);
      var n = r.length;
      function o(t, s) {
        if (s && ("object" == _typeof(s) || "function" == typeof s)) {
          var i = s.then;
          if ("function" == typeof i) return void i.call(s, function (e) {
            o(t, e);
          }, function (s) {
            r[t] = {
              status: "rejected",
              reason: s
            }, 0 == --n && e(r);
          });
        }
        r[t] = {
          status: "fulfilled",
          value: s
        }, 0 == --n && e(r);
      }
      for (var i = 0; i < r.length; i++) o(i, r[i]);
    });
  }, tt.resolve = function (t) {
    return t && "object" == _typeof(t) && t.constructor === tt ? t : new tt(function (e) {
      e(t);
    });
  }, tt.reject = function (t) {
    return new tt(function (e, s) {
      s(t);
    });
  }, tt.race = function (t) {
    return new tt(function (e, s) {
      if (!Y(t)) return s(new TypeError("Promise.race accepts an array"));
      for (var r = 0, n = t.length; r < n; r++) tt.resolve(t[r]).then(e, s);
    });
  }, tt._immediateFn = "function" == typeof setImmediate && function (t) {
    setImmediate(t);
  } || function (t) {
    X(t, 0);
  }, tt._unhandledRejectionFn = function (t) {
    "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", t);
  };
  var lt = /*#__PURE__*/_createClass(function lt(t, e, s, r) {
    _classCallCheck(this, lt);
    this.data = t, this.decorations = e, this.properties = s, this.size = r;
  });
  var at = /*#__PURE__*/_createClass(function at(t, e, s, r, n) {
    _classCallCheck(this, at);
    this.reason = t, this.data = e, this.node = s, this.props = r, this.locale = n;
  });
  var ct = /*#__PURE__*/function () {
    function ct() {
      _classCallCheck(this, ct);
      this._data = null, this._elem = null, this._nls = null, this._locale = "en-us", this._slotResolver = this.getSlotForPalette.bind(this), this.properties = new Q(null, null, this._slotResolver), this.meta = new z();
    }
    return _createClass(ct, [{
      key: "init",
      value: function init(t, e) {
        var _this5 = this;
        var s = t.surface.appendChild(document.createElement("div"));
        s.setAttribute("style", "left: 0; top: 0; width: 100%; height: 100%; position: absolute"), s.setAttribute("data-charttype", "custom-viz"), this.properties = new Q(t.properties, t.dataContext, this._slotResolver), this._nls = t.nls, this._locale = t.locale, tt.resolve(this.create(s)).then(function (r) {
          _this5._elem = r || s;
          t.properties.forEach(function (t, e) {
            return _this5.updateProperty(e, t.value);
          }), e.complete();
        })["catch"](function (t) {
          e.fail(t);
        });
      }
    }, {
      key: "destroy",
      value: function destroy() {}
    }, {
      key: "getPropertyApi",
      value: function getPropertyApi() {
        return null;
      }
    }, {
      key: "setData",
      value: function setData(t) {
        t && t.dataSets && t.dataSets[0] ? this._data = _(t.dataSets[0]) : this._data = null;
      }
    }, {
      key: "setProperty",
      value: function setProperty(t, e) {
        this.updateProperty(t, this.properties.peek(t));
      }
    }, {
      key: "getBlockingRequests",
      value: function getBlockingRequests() {
        return null;
      }
    }, {
      key: "render",
      value: function render(t, e, s) {
        if (!this._elem) return s.complete(null, null, null), null;
        if (!(e.data || e.decorations || e.properties || e.size)) return s.complete(null, null, null), null;
        try {
          var _t4 = this.update(new at(function (t) {
            return new lt(t.data, t.decorations, t.properties, t.size);
          }(e), this._data, this._elem, this.properties, this._locale));
          tt.resolve(_t4).then(function () {
            return s.complete(null, null, null);
          })["catch"](s.error);
        } catch (t) {
          s.error(t);
        }
        return null;
      }
    }, {
      key: "getEncodings",
      value: function getEncodings() {
        return this._data ? this.updateLegend(this._data) : [];
      }
    }, {
      key: "getCapabilities",
      value: function getCapabilities() {
        var t = [];
        return this.meta.slotLimits.forEach(function (s, r) {
          t.push(e.slotLimit(r, s));
        }), this.meta.dataLimit >= 0 && t.push(e.dataLimit(this.meta.dataLimit)), t;
      }
    }, {
      key: "getInteractivity",
      value: function getInteractivity() {
        return null;
      }
    }, {
      key: "getVisCoordinate",
      value: function getVisCoordinate(t, e) {
        return e;
      }
    }, {
      key: "getRegionAtPoint",
      value: function getRegionAtPoint(t, e) {
        return null;
      }
    }, {
      key: "getItemsAtPoint",
      value: function getItemsAtPoint(t, e, s) {
        if (!t || !t.hasOwnProperty("x") || !t.hasOwnProperty("y")) return null;
        var r = t,
          n = document.elementFromPoint(r.x, r.y),
          o = this.hitTest(n, r, e);
        return Array.isArray(o) ? o.length ? _toConsumableArray(o.map(function (t) {
          return t.source;
        })) : [] : o && o.source ? [o.source] : [];
      }
    }, {
      key: "getItemsInPolygon",
      value: function getItemsInPolygon(t, e) {
        return [];
      }
    }, {
      key: "getAxisItemsAtPoint",
      value: function getAxisItemsAtPoint(t, e, s) {
        return [];
      }
    }, {
      key: "getState",
      value: function getState() {
        return null;
      }
    }, {
      key: "setState",
      value: function setState(t) {}
    }, {
      key: "loadCss",
      value: function loadCss(t) {
        var e = document.createElement("link");
        e.type = "text/css", e.rel = "stylesheet", e.href = this.toUrl(t), document.getElementsByTagName("head")[0].appendChild(e);
      }
    }, {
      key: "toUrl",
      value: function toUrl(e) {
        return requirejs.toUrl(e);
      }
    }, {
      key: "update",
      value: function update(t) {}
    }, {
      key: "create",
      value: function create(t) {}
    }, {
      key: "updateProperty",
      value: function updateProperty(t, e) {}
    }, {
      key: "updateLegend",
      value: function updateLegend(t) {
        return k(t, this.properties, this.meta, this._slotResolver);
      }
    }, {
      key: "getSlotForPalette",
      value: function getSlotForPalette(t, e) {
        return null;
      }
    }, {
      key: "hitTest",
      value: function hitTest(t, e, s) {
        var r = t && t.__data__;
        return r && r.source ? r : null;
      }
    }, {
      key: "nls",
      value: function nls(t) {
        return this._nls && this._nls.get(t) || "";
      }
    }]);
  }();

  // Licensed Materials - Property of IBM
  //
  // IBM VIDA
  //
  // (C) Copyright IBM Corp. 2026
  //
  // US Government Users Restricted Rights - Use, duplication or
  // disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

  // In production, simply add dependency for highcharts to package.json
  function loadHighCharts() {
    var _window$parent$docume;
    // Chart scripts may be loaded in separate vipr-amd iframe (code is executed inside iframe, but rendering is performed in higher scope, outside the iframe).
    // In such case google scripts must be loaded in higher scope, where visualisation is rendered.
    // It is necessary, because google scripts use window.location for generating svg clip-path links and location provided inside vipr-amd iframe may differ from location in higher scope.

    // Check if inside vipr-amd iframe. Only in such case load google scripts in lower scope.
    // This check is to prevent loading in lower scope if case, where vipr-amd iframe is not used, but everything (script + rendering) is performed inside another iframe.
    var isViprAmdScope = window.parent !== window && ((_window$parent$docume = window.parent.document.body.querySelector("iframe[data-sandbox='vipr-amd']")) === null || _window$parent$docume === void 0 ? void 0 : _window$parent$docume.contentWindow) === window;
    var loadPromise = new Promise(function (resolve) {
      var _targetWindow$require;
      var targetWindow = isViprAmdScope ? window.parent : window;
      if (targetWindow.Highcharts && targetWindow.Highcharts === window.Highcharts) return resolve();

      // If another customvis already loaded highcharts in parent context
      if ("Highcharts" in targetWindow) {
        Object.defineProperty(window, "Highcharts", {
          value: targetWindow.Highcharts
        });
        return resolve();
      } else if ("require" in targetWindow && (_targetWindow$require = targetWindow.require.s) !== null && _targetWindow$require !== void 0 && (_targetWindow$require = _targetWindow$require.contexts) !== null && _targetWindow$require !== void 0 && (_targetWindow$require = _targetWindow$require._) !== null && _targetWindow$require !== void 0 && (_targetWindow$require = _targetWindow$require.defined) !== null && _targetWindow$require !== void 0 && _targetWindow$require["highcharts/highcharts"]) {
        return targetWindow["require"](["highcharts/highcharts"], function (highcharts) {
          if (highcharts) {
            Object.defineProperty(window, "Highcharts", {
              value: highcharts
            });
            resolve();
          }
        });
      }
      var script = targetWindow.document.createElement("script");
      // Load charts from google corechart package
      script.onload = function () {
        if (isViprAmdScope) {
          if ("Highcharts" in targetWindow) {
            Object.defineProperty(window, "Highcharts", {
              value: targetWindow.Highcharts
            });
            return resolve();
          } else if ("require" in targetWindow && typeof targetWindow["require"] === "function") {
            return targetWindow["require"](["highcharts/highcharts"], function (highcharts) {
              if (highcharts) {
                Object.defineProperty(window, "Highcharts", {
                  value: highcharts
                });
                resolve();
              }
            });
          }
        } else {
          return resolve();
        }
      };
      script.src = "https://code.highcharts.com/highcharts.js";
      targetWindow.document.head.appendChild(script);
    });
    return loadPromise;
  }

  var CATEGORY = 0,
    SERIES = 1,
    VALUE = 2;
  var loadPromise = loadHighCharts();
  var _default = /*#__PURE__*/function (_RenderBase) {
    function _default() {
      var _this;
      _classCallCheck(this, _default);
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _callSuper(this, _default, [].concat(args));
      _defineProperty(_this, "_chart", void 0);
      _defineProperty(_this, "_rows", void 0);
      _defineProperty(_this, "_itemAtPoint", null);
      _defineProperty(_this, "_showHighchartsTooltip", true);
      return _this;
    }
    _inherits(_default, _RenderBase);
    return _createClass(_default, [{
      key: "create",
      value: function create(_node) {
        var _this2 = this;
        loadPromise.then(function () {
          _this2._chart = window.Highcharts.chart(_node, {
            title: {
              text: undefined
            }
          });
        });
      }
    }, {
      key: "update",
      value: function update(_info) {
        var _this3 = this;
        if (!this._chart) {
          loadPromise.then(function () {
            return _this3.update(_info);
          });
          return;
        }
        var data = _info.data;
        // Clear the chart if there's no data
        if (!data) {
          while (this._chart.series.length > 0) this._chart.series[0].remove(true);
          return;
        }
        this._rows = data.rows;
        var props = _info.props;
        var seriesMapped = data.cols[SERIES].mapped;
        var palette = props.get("colors");
        var chartData = [];
        // Get the list of categories and series
        var categories = data.cols[CATEGORY].tuples.map(function (_tuple) {
          return _tuple.caption;
        });
        var series = seriesMapped ? data.cols[SERIES].tuples : [null];
        // For each series, create an series object, storing an array of data for that series
        // The data array contains data value for every categories in that series
        series.forEach(function (_tuple) {
          chartData.push({
            name: seriesMapped ? _tuple.caption : data.cols[VALUE].caption,
            color: palette.getColor(_tuple).toString(),
            data: new Array(categories.length).fill(null)
          });
        });
        this._rows.forEach(function (_row) {
          // Fill data in the 2-d array based on index of category (column) and series (row)
          // If series is not mapped, series index is always 0 since there's only one series
          var seriesIndex = seriesMapped ? _row.tuple(SERIES).index : 0;
          var catIndex = _row.tuple(CATEGORY).index;
          chartData[seriesIndex].data[catIndex] = {
            id: _row.key,
            y: _row.value(VALUE)
          };
        });

        // Set options based on properties
        var stacking = props.get("area.stack");
        if (stacking === "none") stacking = undefined;
        this._showHighchartsTooltip = props.get("tooltip.show");
        var options = {
          chart: {
            type: "area",
            backgroundColor: props.get("background.color").toString(),
            zoomType: props.get("area.zoom")
          },
          xAxis: {
            categories: categories,
            title: {
              text: props.get("xAxis.title"),
              style: {
                color: props.get("xAxis.title.color").toString()
              }
            },
            labels: {
              style: {
                color: props.get("xAxis.label.color").toString()
              }
            },
            lineColor: props.get("xAxis.line.color").toString()
          },
          yAxis: {
            reversedStacks: props.get("area.reverse"),
            title: {
              text: props.get("yAxis.title"),
              style: {
                color: props.get("yAxis.title.color").toString()
              }
            },
            labels: {
              style: {
                color: props.get("yAxis.label.color").toString()
              }
            },
            gridLineColor: props.get("yAxis.grid.color").toString()
          },
          plotOptions: {
            area: {
              fillOpacity: props.get("area.fillOpacity"),
              stacking: stacking,
              marker: {
                enabled: props.get("area.symbol") !== "none",
                symbol: props.get("area.symbol")
              }
            },
            series: {
              connectNulls: true,
              point: {
                events: {
                  // Set itemAtPoint as the current highlighted item for hitTest
                  mouseOver: function mouseOver(e) {
                    _this3._itemAtPoint = _this3._rows.find(function (_row) {
                      return _row.key === e.target.id;
                    }) || null;
                  },
                  mouseOut: function mouseOut() {
                    _this3._itemAtPoint = null;
                  }
                }
              }
            }
          },
          tooltip: {
            enabled: this._showHighchartsTooltip,
            split: props.get("tooltip.focus") === "category"
          },
          legend: {
            enabled: props.get("highchartsLegend.show"),
            align: props.get("highchartsLegend.place.horizontal"),
            verticalAlign: props.get("highchartsLegend.place.vertical"),
            layout: props.get("highchartsLegend.layout"),
            itemStyle: {
              color: props.get("highchartsLegend.text.color").toString()
            }
          },
          series: chartData
        };

        // If container size changes, resize the chart for better responsiveness
        if (_info.reason.size) this._chart.setSize(_info.node.clientWidth, _info.node.clientHeight);
        this._chart.update(options, true, true);
      }
    }, {
      key: "updateProperty",
      value: function updateProperty(_name, _value) {
        switch (_name) {
          case "area.stack":
            this.properties.setActive("area.reverse", _value !== "none");
            break;
          case "xAxis.title":
            this.properties.setActive("xAxis.title.color", _value);
            break;
          case "yAxis.title":
            this.properties.setActive("yAxis.title.color", _value);
            break;
          case "highchartsLegend.show":
            this.properties.setActive("highchartsLegend.place.horizontal", _value);
            this.properties.setActive("highchartsLegend.place.vertical", _value);
            this.properties.setActive("highchartsLegend.layout", _value);
            this.properties.setActive("highchartsLegend.text.color", _value);
            break;
          case "tooltip.show":
            this.properties.setActive("tooltip.focus", _value);
        }
      }

      // Return itemAtPoint for VIDA tooltip only if Highcharts tooltip is not shown
    }, {
      key: "hitTest",
      value: function hitTest() {
        return this._showHighchartsTooltip ? null : this._itemAtPoint;
      }
    }]);
  }(ct);

  return _default;

}));
