/**
 * CDN method from highcharts documentation.
 * Doesn't work with iframe solution from VIPR. Currently a workaround from `loadHighCharts.ts` is applied instead.
 * Once the iframe solution is replaced with ESM or by CA requireJS, this workaround can be removed.
 */
define( [], function()
{
    "use strict";
    return {
        packages: [
        {
            name: 'highcharts',
            main: 'highcharts'
        } ],
        paths:
        {
            "highcharts": "https://code.highcharts.com/12.6.0/highcharts.js"
        }
    };
} );
