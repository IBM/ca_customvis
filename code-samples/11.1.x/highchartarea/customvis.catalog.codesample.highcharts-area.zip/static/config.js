define( [], function()
{
    "use strict";
    return {
        packages:[
        {
            name: 'highcharts',
            main: 'highcharts'
        } ],
        paths:
        {
            "highcharts": "https://code.highcharts.com"
        }
    };
} );
