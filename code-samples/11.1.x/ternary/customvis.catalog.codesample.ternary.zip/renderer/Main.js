define(['require', 'https://d3js.org/d3.v5.min.js'], function (requirejs, d3) { 'use strict';

  function _typeof(obj) {
    "@babel/helpers - typeof";

    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
      _typeof = function (obj) {
        return typeof obj;
      };
    } else {
      _typeof = function (obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };
    }

    return _typeof(obj);
  }

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    return Constructor;
  }

  function _defineProperty(obj, key, value) {
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }

    return obj;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function");
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        writable: true,
        configurable: true
      }
    });
    if (superClass) _setPrototypeOf(subClass, superClass);
  }

  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }

  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };

    return _setPrototypeOf(o, p);
  }

  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;

    try {
      Date.prototype.toString.call(Reflect.construct(Date, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }

  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return self;
  }

  function _possibleConstructorReturn(self, call) {
    if (call && (typeof call === "object" || typeof call === "function")) {
      return call;
    }

    return _assertThisInitialized(self);
  }

  function _createSuper(Derived) {
    var hasNativeReflectConstruct = _isNativeReflectConstruct();

    return function _createSuperInternal() {
      var Super = _getPrototypeOf(Derived),
          result;

      if (hasNativeReflectConstruct) {
        var NewTarget = _getPrototypeOf(this).constructor;

        result = Reflect.construct(Super, arguments, NewTarget);
      } else {
        result = Super.apply(this, arguments);
      }

      return _possibleConstructorReturn(this, result);
    };
  }

  function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
  }

  function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
  }

  function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
  }

  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }

  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;

    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];

    return arr2;
  }

  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var e = function () {
    function t(t, e) {
      this.name = t, this.slot = e || null, this.attributes = new Map();
    }

    return t.prototype.getName = function () {
      return this.name;
    }, t.prototype.getSlot = function () {
      return this.slot;
    }, t.prototype.getAttributes = function () {
      return this.attributes;
    }, t.slotLimit = function (e, n) {
      return new t("limit", e).attr("n", n);
    }, t.dataLimit = function (e) {
      return new t("limit").attr("n", e);
    }, t.prototype.attr = function (t, e) {
      return this.attributes.set(t, e), this;
    }, t;
  }(),
      _n = function n(t, e) {
    return (_n = Object.setPrototypeOf || {
      __proto__: []
    } instanceof Array && function (t, e) {
      t.__proto__ = e;
    } || function (t, e) {
      for (var n in e) {
        Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
      }
    })(t, e);
  };
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */


  function r(t, e) {
    function r() {
      this.constructor = t;
    }

    _n(t, e), t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r());
  }

  function o(t, e, n) {
    return t.getDecoration(e, n);
  }

  function i(t) {
    return t.hasDecoration("hasSelection") ? o(t, "hasSelection", !1) : !!function (t) {
      return "getSlot" in t && "hasDecorationOnDataPoints" in t;
    }(t) && t.hasDecorationOnDataPoints("selected");
  }

  var u,
      s = function () {
    function t(t, e) {
      this.min = t, this.max = e;
    }

    return t.prototype.asArray = function () {
      return [this.min, this.max];
    }, t.empty = new t(0, 0), t;
  }(),
      a = function (t) {
    function e(e, n) {
      return t.call(this, e, n) || this;
    }

    return r(e, t), e.fromRS = function (t) {
      return new s(t.min, t.max);
    }, e;
  }(s),
      l = function () {
    function t(t, e) {
      this.source = t, this.index = e, this.key = t.getKey(!1), this.caption = t.getCaption("label") || "";
      var n = t.getItems() || [];
      this.segments = n.map(function (t) {
        return new p(t);
      });
    }

    return Object.defineProperty(t.prototype, "selected", {
      get: function get() {
        return o(this.source, "selected", !1);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(t.prototype, "highlighted", {
      get: function get() {
        return o(this.source, "highlighted", !1);
      },
      enumerable: !1,
      configurable: !0
    }), t;
  }(),
      c = function (t) {
    function e(e, n) {
      return t.call(this, e, n) || this;
    }

    return r(e, t), e;
  }(l),
      h = function () {
    function t(t) {
      this.source = t, this.key = this.source.getUniqueName() || "", this.caption = this.source.getCaption("label") || "";
    }

    return Object.defineProperty(t.prototype, "selected", {
      get: function get() {
        return o(this.source, "selected", !1);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(t.prototype, "highlighted", {
      get: function get() {
        return o(this.source, "highlighted", !1);
      },
      enumerable: !1,
      configurable: !0
    }), t;
  }(),
      p = function (t) {
    function e(e) {
      return t.call(this, e) || this;
    }

    return r(e, t), e;
  }(h),
      f = new (function () {
    function t() {}

    return t.prototype.format = function (t) {
      return t ? t.toString() : "";
    }, t;
  }())();

  !function (t) {
    t.label = "label", t.data = "data";
  }(u || (u = {}));

  var g = function () {
    function t(t, e, n, r, o) {
      this.source = t, this.tuples = e, this.segments = n, this.domain = r, this.caption = o;
      var i = t.dataItems || [],
          u = i.length > 0 ? i[0] : null,
          s = u && u.asCont();
      s ? (this._labelFormatter = s.getFormatter("label") || f, this._dataFormatter = s.getFormatter("data") || f) : this._labelFormatter = this._dataFormatter = f;
    }

    return Object.defineProperty(t.prototype, "mapped", {
      get: function get() {
        return this.source.mapped;
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(t.prototype, "dataType", {
      get: function get() {
        var t = this.source.getDataItem(0);
        return this.mapped && t ? t.type : "none";
      },
      enumerable: !1,
      configurable: !0
    }), t.prototype.format = function (t, e) {
      return function (t, e) {
        return t.format(e);
      }(e === u.data ? this._dataFormatter : this._labelFormatter, t);
    }, t;
  }(),
      d = function (t) {
    function e(e, n, r, o, i) {
      return t.call(this, e, n, r, o, i) || this;
    }

    return r(e, t), e;
  }(g),
      m = function () {
    function t(t, e) {
      this.source = t, this.key = t.getKey(!1), this.dataSet = e;
    }

    return Object.defineProperty(t.prototype, "selected", {
      get: function get() {
        return o(this.source, "selected", !1);
      },
      enumerable: !1,
      configurable: !0
    }), Object.defineProperty(t.prototype, "highlighted", {
      get: function get() {
        return o(this.source, "highlighted", !1);
      },
      enumerable: !1,
      configurable: !0
    }), t.prototype.tuple = function (t) {
      var e = this._getSlot(t);

      if (!e || 0 === e.tuples.length) return null;
      var n = this.source.get(e.source);
      if (!n) return null;
      var r = n.asCat();
      return r ? e.tuples[r.index] : null;
    }, t.prototype.value = function (t) {
      var e = this._getSlot(t),
          n = e && this.source.get(e.source);

      if (!n) return null;
      var r = n.asCont();
      return r && "numeric" === r.valueType ? r.value : null;
    }, t.prototype.caption = function (t) {
      var e = this._getSlot(t),
          n = e && this.source.get(e.source);

      return n && n.getCaption("data") || "";
    }, t.prototype._getSlot = function (t) {
      return "string" == typeof t ? this.dataSet.slotMap.get(t) || null : this.dataSet.cols[t] || null;
    }, t;
  }(),
      y = function (t) {
    function e(e, n) {
      return t.call(this, e, n) || this;
    }

    return r(e, t), e;
  }(m),
      v = function () {
    function t(t, e, n) {
      var r = this;
      this.source = t, this.rows = t.dataPoints.map(function (t) {
        return new y(t, r);
      }), this.cols = e, this.slotMap = n;
    }

    return t.filterRows = function (t, e, n) {
      return t.filter(function (t) {
        var r = t.tuple(e);
        return !!r && r.key === n;
      });
    }, Object.defineProperty(t.prototype, "hasSelections", {
      get: function get() {
        return i(this.source);
      },
      enumerable: !1,
      configurable: !0
    }), t;
  }(),
      _ = function (t) {
    function e(e, n, r) {
      return t.call(this, e, n, r) || this;
    }

    return r(e, t), e;
  }(v);

  function b(t) {
    var e = new Map(),
        n = t.getSlots().map(function (t, n) {
      var r = [],
          o = [],
          i = s.empty,
          u = "";

      if (t.isMapped()) {
        var l = t.getDataItem(0);
        if (u = l.getCaption("label"), "cat" === l.getRSType()) r = l.getTuples().map(function (t, e) {
          return new c(t, e);
        }), o = l.getItemClassSet(0).getItemClasses().map(function (t) {
          return new p(t);
        });else i = a.fromRS(l.getDomain()), o.push(new p(l.getItemClass()));
      }

      var h = new d(t, r, o, i, u);
      return e.set(t.name, h), h;
    });
    return new _(t, n, e);
  }

  function w(t) {
    return t < 0 ? 0 : t > 255 ? 255 : Math.floor(t);
  }

  var C = function () {
    function t(t, e, n, r) {
      var o;
      this.r = w(t), this.g = w(e), this.b = w(n), this.a = (o = r) < 0 ? 0 : o > 1 ? 1 : o;
    }

    return t.fromObject = function (e) {
      return new t(e.r, e.g, e.b, void 0 === e.a ? 1 : e.a);
    }, t.prototype.toString = function () {
      return 1 === this.a ? "rgb(" + this.r + "," + this.g + "," + this.b + ")" : "rgba(" + this.r + "," + this.g + "," + this.b + "," + this.a + ")";
    }, t;
  }();

  function S(t, e) {
    var n = null;
    if (t instanceof m) n = t.source.getDataSet(e);else {
      var r = t.source.getDataItem(e);
      n = r && r.getDataSet(e);
    }
    return !!n && i(n);
  }

  var P = function P(t) {
    return "rgba(" + t.r + "," + t.g + "," + t.b + ",0.4)";
  },
      j = function j(t) {
    return "rgba(" + Math.round(.7 * t.r) + "," + Math.round(.7 * t.g) + "," + Math.round(.7 * t.b) + "," + t.a + ")";
  },
      O = function () {
    function t(t, e, n) {
      this.source = t, this._dataContext = e, this._slotResolver = n;
    }

    return Object.defineProperty(t.prototype, "slot", {
      get: function get() {
        return this.source.slot;
      },
      enumerable: !1,
      configurable: !0
    }), t.prototype.getColor = function (t) {
      return t ? C.fromObject(this.source.getTupleColor(t.source, -1)) : C.fromObject(this.source.getColor(null));
    }, t.prototype._getTuple = function (t) {
      if (t instanceof l) return t;

      var e = this.slot || this._slotResolver(t.dataSet, this.source.name);

      return e ? t.tuple(e) : null;
    }, t.prototype.getFillColor = function (t) {
      if (null === t) return this.source.getColor(null).toString();

      var e,
          n = this._getTuple(t);

      return e = n ? this.source.getTupleColor(n.source, -1) : this.source.getColor(t.source), !t.selected && S(t, this._dataContext) ? P(e) : e.toString();
    }, t.prototype.getOutlineColor = function (t) {
      if (null === t) return this.source.getColor(null).toString();

      var e,
          n = this._getTuple(t);

      return e = n ? this.source.getTupleColor(n.source, -1) : this.source.getColor(t.source), t.highlighted || t.selected && S(t, this._dataContext) ? j(e) : null;
    }, t;
  }(),
      x = function x(t, e, n) {
    this.color = t, this.at = e, this.value = n;
  };

  function I(t) {
    return t.map(function (t) {
      return new x(C.fromObject(t.color), t.at, t.value);
    });
  }

  var D = function () {
    function t(t, e, n) {
      this.source = t, this._slot = e, this._dataContext = n, this.stops = I(t.stops), this.aligned = I(t.aligned), this.interpolate = t.interpolate;
    }

    return t.prototype.getColor = function (t) {
      return C.fromObject(this.source.getColor(t));
    }, t.prototype.getFillColor = function (t) {
      var e = this._slot ? Number(t.value(this._slot)) : 0,
          n = this.source.getColor(e);
      return !t.selected && S(t, this._dataContext) ? P(n) : n.toString();
    }, t.prototype.getOutlineColor = function (t) {
      var e = this._slot ? Number(t.value(this._slot)) : 0,
          n = this.source.getColor(e);
      return t.highlighted || t.selected && S(t, this._dataContext) ? j(n) : null;
    }, t;
  }(),
      E = function () {
    function t(t, e, n) {
      this.source = t, this._dataContext = e, this._lastDataItem = null, this._cachedStops = null, this._slotResolver = n;
    }

    return Object.defineProperty(t.prototype, "slot", {
      get: function get() {
        return this.source.slot;
      },
      enumerable: !1,
      configurable: !0
    }), t.prototype.getColorStops = function (t) {
      var e = t ? t.source.getDataItem(0) : null,
          n = e && e.asCont(),
          r = n ? n.getDomain(null) : null,
          o = this.source.getColorStops(n, r),
          i = t ? t.source.name : null;
      return new D(o, i, this._dataContext);
    }, t.prototype._fetchColorStops = function (t) {
      var e = t.source.getDataSet(this._dataContext),
          n = this.slot || this._slotResolver(t.dataSet, this.source.name),
          r = n ? e.getSlot(n) : null,
          o = r ? r.getDataItem(0) : null,
          i = o ? o.asCont() : null;

      if (this.source.dirty || !this._cachedStops || i !== this._lastDataItem) {
        var u = i ? i.getDomain(null) : null,
            s = this.source.getColorStops(i, u);
        this._cachedStops = new D(s, r && r.name, this._dataContext), this._lastDataItem = i;
      }

      return this._cachedStops;
    }, t.prototype.getFillColor = function (t) {
      return this._fetchColorStops(t).getFillColor(t);
    }, t.prototype.getOutlineColor = function (t) {
      return this._fetchColorStops(t).getOutlineColor(t);
    }, t;
  }(),
      T = function (t) {
    function e(e) {
      var n = t.call(this, e.r, e.g, e.b, e.a) || this;
      return n._color = e, n;
    }

    return r(e, t), e.prototype.getRed = function () {
      return this.r;
    }, e.prototype.getGreen = function () {
      return this.g;
    }, e.prototype.getBlue = function () {
      return this.b;
    }, e.prototype.getAlpha = function () {
      return this.a;
    }, e;
  }(C),
      R = Object.freeze({
    min: 0,
    max: 0,
    empty: !0,
    explicit: !1,
    getMin: function getMin() {
      return 0;
    },
    getMax: function getMax() {
      return 0;
    },
    isEmpty: function isEmpty() {
      return !0;
    },
    isExplicit: function isExplicit() {
      return !1;
    }
  }),
      F = function () {
    function t(t, e, n, r, o, i) {
      this.caption = t, this.color = e, this.shape = n, this.selected = r, this.highlighted = o, this.ref = i;
    }

    return t.prototype.getCaption = function () {
      return this.caption;
    }, t.prototype.getColor = function () {
      return this.color ? new T(this.color) : null;
    }, t.prototype.getShape = function () {
      return this.shape;
    }, t.prototype.isSelected = function () {
      return this.selected;
    }, t.prototype.isHighlighted = function () {
      return this.highlighted;
    }, t.prototype.getRef = function () {
      return this.ref;
    }, t;
  }(),
      M = function () {
    function t(t, e, n, r, o, i) {
      this.type = t, this.channel = e, this.slot = n, this.caption = r, this.subCaption = o, this.ref = i;
    }

    return t.prototype.getRSType = function () {
      return this.type;
    }, t.prototype.getChannel = function () {
      return this.channel;
    }, t.prototype.getSlot = function () {
      return this.slot;
    }, t.prototype.getCaption = function () {
      return this.caption;
    }, t.prototype.getSubCaption = function () {
      return this.subCaption;
    }, t.prototype.getRef = function () {
      return this.ref;
    }, t;
  }(),
      L = function (t) {
    function e(e, n, r, i, u) {
      var s = this,
          a = n && n.source,
          l = a && a.name,
          c = a && a.getDataItem(0),
          h = c && c.asCat();
      s = t.call(this, "cat", e, l, r, "", h) || this;
      var p = h ? h.tuples : [];
      return s.entries = p.map(function (t) {
        var e = t.getCaption("label") || "",
            n = u && u.source.getTupleColor(t, -1),
            r = o(t, "selected", !1),
            s = o(t, "highlighted", !1);
        return new F(e, n ? C.fromObject(n) : null, i, r, s, t);
      }), s;
    }

    return r(e, t), e.prototype.getEntries = function () {
      return this.entries;
    }, e;
  }(M),
      A = function (t) {
    function e(e, n, r, o) {
      var i = this,
          u = n && n.source,
          s = u && u.name,
          a = u && u.getDataItem(0),
          l = a && a.asCont();

      if ((i = t.call(this, "cont", e, s, r, "", l) || this).domain = l ? l.getDomain(null) : R, o && "color" === e) {
        var c = o.source.getColorStops(l, null);
        i.stops = c.stops, i.interpolate = c.interpolate;
      } else i.stops = null, i.interpolate = !1;

      return i;
    }

    return r(e, t), e.prototype.getDomain = function () {
      return this.domain;
    }, e.prototype.getInterpolate = function () {
      return this.interpolate;
    }, e.prototype.getStops = function () {
      return this.stops;
    }, e;
  }(M);

  function z(t, e, n, r) {
    if (!t) return [];
    var o = new Map(),
        i = new Map();
    e.palettes.forEach(function (e) {
      var n = e.slot || r && r(t, e.source.name);
      n && (e instanceof O ? o.set(n, e) : e instanceof E && i.set(n, e));
    });
    var u = [];
    return t.cols.forEach(function (t) {
      var e = t.source;

      if (e.mapped) {
        var r = e.getDataItem(0);
        if (r) switch (r.type) {
          case "cat":
            if (-1 === e.channels.indexOf("color")) return;
            var s = o.get(e.name);
            s && u.push(new L("color", t, t.caption, n.legendShape, s));
            break;

          case "cont":
            if (-1 !== e.channels.indexOf("color")) {
              var a = i.get(e.name);
              a && u.push(new A("color", t, t.caption, a));
            }

            -1 !== e.channels.indexOf("size") && u.push(new A("size", t, t.caption, null));
        }
      }
    }), u;
  }

  var N,
      k = function k() {
    this.legendShape = null, this.slotLimits = new Map(), this.dataLimit = -1;
  };

  !function (t) {
    t.Em = "em", t.Percentage = "%", t.Centimeter = "cm", t.Millimeter = "mm", t.Inch = "in", t.Pica = "pc", t.Point = "pt", t.Pixel = "px";
  }(N || (N = {}));

  var H,
      U,
      V = function () {
    function t(t, e) {
      this.value = t, this.unit = e;
    }

    return t.fromObject = function (e) {
      return new t(e.value, function (t) {
        switch (t) {
          case "em":
            return N.Em;

          case "%":
            return N.Percentage;

          case "cm":
            return N.Centimeter;

          case "mm":
            return N.Millimeter;

          case "in":
            return N.Inch;

          case "pc":
            return N.Pica;

          case "pt":
            return N.Point;

          case "px":
            return N.Pixel;

          default:
            throw new Error("Invalid length unit '" + t + "' specified");
        }
      }(e.unit));
    }, t.prototype.toString = function () {
      return "" + this.value + this.unit;
    }, t;
  }();

  !function (t) {
    t.Normal = "normal", t.Italic = "italic";
  }(H || (H = {})), function (t) {
    t[t.Thin = 100] = "Thin", t[t.ExtraLight = 200] = "ExtraLight", t[t.Light = 300] = "Light", t[t.Normal = 400] = "Normal", t[t.Medium = 500] = "Medium", t[t.SemiBold = 600] = "SemiBold", t[t.Bold = 700] = "Bold", t[t.ExtraBold = 800] = "ExtraBold", t[t.Heavy = 900] = "Heavy";
  }(U || (U = {}));
  var q = /\s+/g;

  function K(t) {
    switch (t) {
      case U.Normal:
        return "normal";

      case U.Bold:
        return "bold";

      case U.Thin:
      case U.ExtraLight:
      case U.Light:
      case U.Medium:
      case U.SemiBold:
      case U.ExtraBold:
      case U.Heavy:
        return t.toString();

      default:
        return "";
    }
  }

  function G(t) {
    var e = [];
    if (t) for (var n = 0, r = t.length; n < r; ++n) {
      var o = t[n],
          i = q.test(o);
      e.push(i ? '"' + o + '"' : o);
    }
    return e.join(", ");
  }

  var J = function () {
    function t(t, e, n, r) {
      this.family = t, this.size = e, this.style = n, this.weight = r;
    }

    return t.fromObject = function (e) {
      return new t(e.family || null, e.size ? V.fromObject(e.size) : null, e.style ? function (t) {
        switch (t) {
          case "normal":
            return H.Normal;

          case "italic":
            return H.Italic;

          default:
            throw new Error("Invalid font style '" + t + "' specified");
        }
      }(e.style) : null, void 0 !== e.weight && null !== e.weight ? e.weight : null);
    }, t.prototype.toString = function () {
      if (this.style !== H.Normal && this.weight !== U.Normal || this.style === H.Normal && this.weight === U.Normal) {
        var t = [];
        return this.style === H.Normal ? t.push("normal") : (this.style && t.push(this.style), this.weight && t.push(K(this.weight))), this.size && t.push(this.size.toString()), this.family && t.push(G(this.family)), t.join(" ");
      }

      return function (t) {
        var e,
            n = [],
            r = G(t.family);
        return r.length > 0 && n.push("font-family: " + r + ";"), (r = t.size ? t.size.toString() : "").length > 0 && n.push("font-size: " + r + ";"), (r = (e = t.style) ? e.toString() : "").length > 0 && n.push("font-style: " + r + ";"), (r = K(t.weight)).length > 0 && n.push("font-weight: " + r + ";"), n.join(" ");
      }(this);
    }, t;
  }(),
      Q = function () {
    function t(t, e, n) {
      var r = new Map();
      null !== t && t.forEach(function (t, o) {
        if ("palette" === t.type) {
          var i = t;

          switch (i.paletteType) {
            case "cat":
              r.set(o, new O(i, e, n));
              break;

            case "cont":
              r.set(o, new E(i, e, n));
          }
        }
      }), this.source = t, this.palettes = r;
    }

    return t.prototype.get = function (t) {
      return this._getValue(t, !1);
    }, t.prototype.peek = function (t) {
      return this._getValue(t, !0);
    }, t.prototype._getValue = function (t, e) {
      var n = this.source && this.source.get(t);
      if (!n) return null;

      switch (n.type) {
        case "string":
        case "number":
        case "boolean":
        case "enum":
          return e ? n.peek : n.value;

        case "length":
          var r = e ? n.peek : n.value;
          return r ? V.fromObject(r) : null;

        case "font":
          var o = e ? n.peek : n.value;
          return o ? J.fromObject(o) : null;

        case "color":
          var i = e ? n.peek : n.value;
          return i ? C.fromObject(i) : null;

        case "palette":
          return this.palettes.get(t) || null;

        default:
          return null;
      }
    }, t.prototype.isActive = function (t) {
      var e = this.source && this.source.get(t);
      return !!e && e.active;
    }, t.prototype.setActive = function (t, e) {
      var n = this.source && this.source.get(t);
      n && n.setActive(e);
    }, t.prototype.isDirty = function (t) {
      var e = this.source && this.source.get(t);
      return !!e && e.dirty;
    }, t;
  }();

  var W = setTimeout;

  function X(t) {
    return Boolean(t && void 0 !== t.length);
  }

  function Y() {}

  function Z(t) {
    if (!(this instanceof Z)) throw new TypeError("Promises must be constructed via new");
    if ("function" != typeof t) throw new TypeError("not a function");
    this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], ot(t, this);
  }

  function $(t, e) {
    for (; 3 === t._state;) {
      t = t._value;
    }

    0 !== t._state ? (t._handled = !0, Z._immediateFn(function () {
      var n = 1 === t._state ? e.onFulfilled : e.onRejected;

      if (null !== n) {
        var r;

        try {
          r = n(t._value);
        } catch (t) {
          return void et(e.promise, t);
        }

        tt(e.promise, r);
      } else (1 === t._state ? tt : et)(e.promise, t._value);
    })) : t._deferreds.push(e);
  }

  function tt(t, e) {
    try {
      if (e === t) throw new TypeError("A promise cannot be resolved with itself.");

      if (e && ("object" == _typeof(e) || "function" == typeof e)) {
        var n = e.then;
        if (e instanceof Z) return t._state = 3, t._value = e, void nt(t);
        if ("function" == typeof n) return void ot((r = n, o = e, function () {
          r.apply(o, arguments);
        }), t);
      }

      t._state = 1, t._value = e, nt(t);
    } catch (e) {
      et(t, e);
    }

    var r, o;
  }

  function et(t, e) {
    t._state = 2, t._value = e, nt(t);
  }

  function nt(t) {
    2 === t._state && 0 === t._deferreds.length && Z._immediateFn(function () {
      t._handled || Z._unhandledRejectionFn(t._value);
    });

    for (var e = 0, n = t._deferreds.length; e < n; e++) {
      $(t, t._deferreds[e]);
    }

    t._deferreds = null;
  }

  function rt(t, e, n) {
    this.onFulfilled = "function" == typeof t ? t : null, this.onRejected = "function" == typeof e ? e : null, this.promise = n;
  }

  function ot(t, e) {
    var n = !1;

    try {
      t(function (t) {
        n || (n = !0, tt(e, t));
      }, function (t) {
        n || (n = !0, et(e, t));
      });
    } catch (t) {
      if (n) return;
      n = !0, et(e, t);
    }
  }

  Z.prototype["catch"] = function (t) {
    return this.then(null, t);
  }, Z.prototype.then = function (t, e) {
    var n = new this.constructor(Y);
    return $(this, new rt(t, e, n)), n;
  }, Z.prototype["finally"] = function (t) {
    var e = this.constructor;
    return this.then(function (n) {
      return e.resolve(t()).then(function () {
        return n;
      });
    }, function (n) {
      return e.resolve(t()).then(function () {
        return e.reject(n);
      });
    });
  }, Z.all = function (t) {
    return new Z(function (e, n) {
      if (!X(t)) return n(new TypeError("Promise.all accepts an array"));
      var r = Array.prototype.slice.call(t);
      if (0 === r.length) return e([]);
      var o = r.length;

      function i(t, u) {
        try {
          if (u && ("object" == _typeof(u) || "function" == typeof u)) {
            var s = u.then;
            if ("function" == typeof s) return void s.call(u, function (e) {
              i(t, e);
            }, n);
          }

          r[t] = u, 0 == --o && e(r);
        } catch (t) {
          n(t);
        }
      }

      for (var u = 0; u < r.length; u++) {
        i(u, r[u]);
      }
    });
  }, Z.resolve = function (t) {
    return t && "object" == _typeof(t) && t.constructor === Z ? t : new Z(function (e) {
      e(t);
    });
  }, Z.reject = function (t) {
    return new Z(function (e, n) {
      n(t);
    });
  }, Z.race = function (t) {
    return new Z(function (e, n) {
      if (!X(t)) return n(new TypeError("Promise.race accepts an array"));

      for (var r = 0, o = t.length; r < o; r++) {
        Z.resolve(t[r]).then(e, n);
      }
    });
  }, Z._immediateFn = "function" == typeof setImmediate && function (t) {
    setImmediate(t);
  } || function (t) {
    W(t, 0);
  }, Z._unhandledRejectionFn = function (t) {
    "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", t);
  };

  var it = function it(t, e, n, r) {
    this.data = t, this.decorations = e, this.properties = n, this.size = r;
  },
      ut = function ut(t, e, n, r, o) {
    this.reason = t, this.data = e, this.node = n, this.props = r, this.locale = o;
  };

  var st = function () {
    function n() {
      this._data = null, this._elem = null, this._nls = null, this._locale = "en-us", this._slotResolver = this.getSlotForPalette.bind(this), this.properties = new Q(null, null, this._slotResolver), this.meta = new k();
    }

    return n.prototype.init = function (t, e) {
      var n = this,
          r = t.surface.appendChild(document.createElement("div"));
      r.setAttribute("style", "left: 0; top: 0; width: 100%; height: 100%; position: absolute"), r.setAttribute("data-charttype", "custom-viz"), this.properties = new Q(t.properties, t.dataContext, this._slotResolver), this._nls = t.nls, this._locale = t.locale, Z.resolve(this.create(r)).then(function (o) {
        n._elem = o || r, t.properties.forEach(function (t, e) {
          return n.updateProperty(e, t.value);
        }), e.complete();
      })["catch"](function (t) {
        e.fail(t);
      });
    }, n.prototype.destroy = function () {}, n.prototype.getPropertyApi = function () {
      return null;
    }, n.prototype.setData = function (t) {
      t && t.dataSets && t.dataSets[0] ? this._data = b(t.dataSets[0]) : this._data = null;
    }, n.prototype.setProperty = function (t, e) {
      this.updateProperty(t, this.properties.peek(t));
    }, n.prototype.getBlockingRequests = function () {
      return null;
    }, n.prototype.render = function (t, e, n) {
      if (!this._elem) return n.complete(null, null, null), null;
      if (!(e.data || e.decorations || e.properties || e.size)) return n.complete(null, null, null), null;

      try {
        var r = this.update(new ut(function (t) {
          return new it(t.data, t.decorations, t.properties, t.size);
        }(e), this._data, this._elem, this.properties, this._locale));
        Z.resolve(r).then(function () {
          return n.complete(null, null, null);
        })["catch"](n.error);
      } catch (t) {
        n.error(t);
      }

      return null;
    }, n.prototype.getEncodings = function () {
      return this._data ? this.updateLegend(this._data) : [];
    }, n.prototype.getCapabilities = function () {
      var t = [];
      return this.meta.slotLimits.forEach(function (n, r) {
        t.push(e.slotLimit(r, n));
      }), this.meta.dataLimit >= 0 && t.push(e.dataLimit(this.meta.dataLimit)), t;
    }, n.prototype.getInteractivity = function () {
      return null;
    }, n.prototype.getVisCoordinate = function (t, e) {
      return e;
    }, n.prototype.getRegionAtPoint = function (t, e) {
      return null;
    }, n.prototype.getItemsAtPoint = function (t, e, n) {
      if (!t || !t.hasOwnProperty("x") || !t.hasOwnProperty("y")) return null;
      var r = t,
          o = document.elementFromPoint(r.x, r.y),
          i = this.hitTest(o, r, e);
      return i && i.source ? [i.source] : [];
    }, n.prototype.getItemsInPolygon = function (t, e) {
      return [];
    }, n.prototype.getAxisItemsAtPoint = function (t, e, n) {
      return [];
    }, n.prototype.getState = function () {
      return null;
    }, n.prototype.setState = function (t) {}, n.prototype.loadCss = function (t) {
      var e = document.createElement("link");
      e.type = "text/css", e.rel = "stylesheet", e.href = this.toUrl(t), document.getElementsByTagName("head")[0].appendChild(e);
    }, n.prototype.toUrl = function (e) {
      return requirejs.toUrl(e);
    }, n.prototype.update = function (t) {}, n.prototype.create = function (t) {}, n.prototype.updateProperty = function (t, e) {}, n.prototype.updateLegend = function (t) {
      return z(t, this.properties, this.meta, this._slotResolver);
    }, n.prototype.getSlotForPalette = function (t, e) {
      return null;
    }, n.prototype.hitTest = function (t, e, n) {
      var r = t && t.__data__;
      return r && r.source ? r : null;
    }, n.prototype.nls = function (t) {
      return this._nls && this._nls.get(t) || "";
    }, n;
  }();

  // Represents a 2d point.

  /**
   * Licensed Materials - Property of IBM
   *
   * Copyright IBM Corp. 2019 All Rights Reserved.
   *
   * US Government Users Restricted Rights - Use, duplication or
   * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
   */
  var Pt2d = /*#__PURE__*/function () {
    function Pt2d(x, y) {
      _classCallCheck(this, Pt2d);

      this.x = x;
      this.y = y;
    }

    _createClass(Pt2d, [{
      key: "toString",
      value: function toString() {
        return "".concat(this.x, ",").concat(this.y);
      }
    }]);

    return Pt2d;
  }(); // Represents a rectangle with an x, y, width and height.

  var Rect2d = function Rect2d(x, y, w, h) {
    _classCallCheck(this, Rect2d);

    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }; // Represents an edge with a start and end point.

  var Edge = /*#__PURE__*/function () {
    function Edge(pt1, pt2) {
      _classCallCheck(this, Edge);

      this.pt1 = pt1;
      this.pt2 = pt2;

      _defineProperty(this, "center", void 0);

      this.center = new Pt2d((pt1.x + pt2.x) / 2, (pt1.y + pt2.y) / 2);
    } // Evaluates a ratio from 0 - 1 and returns its position the edge.


    _createClass(Edge, [{
      key: "eval",
      value: function _eval(_t) {
        return new Pt2d(this.pt1.x + _t * (this.pt2.x - this.pt1.x), this.pt1.y + _t * (this.pt2.y - this.pt1.y));
      }
    }]);

    return Edge;
  }(); // Represents a triangle consisting of three edges and three vertices.

  var Triangle = /*#__PURE__*/function () {
    function Triangle(vertices) {
      _classCallCheck(this, Triangle);

      this.vertices = vertices;

      _defineProperty(this, "edges", void 0);

      this.edges = [new Edge(vertices[1], vertices[2]), new Edge(vertices[2], vertices[0]), new Edge(vertices[0], vertices[1])];
    } // Returns a path representation of the triangle.


    _createClass(Triangle, [{
      key: "toPath",
      value: function toPath() {
        return "M".concat(this.vertices[0], "L").concat(this.vertices[1], "L").concat(this.vertices[2], "Z");
      }
    }]);

    return Triangle;
  }();

  // of this class by calling Ternary.createLayout().

  var TernaryLayout = // eslint-disable-next-line @typescript-eslint/explicit-member-accessibility
  function TernaryLayout(center, triangle, circleXFn, circleYFn, circleRFn, labelXFn, labelYFn) // label y-position
  {
    _classCallCheck(this, TernaryLayout);

    this.center = center;
    this.triangle = triangle;
    this.circleXFn = circleXFn;
    this.circleYFn = circleYFn;
    this.circleRFn = circleRFn;
    this.labelXFn = labelXFn;
    this.labelYFn = labelYFn;
  }; // Calculate the size of the largest triangle that fits into the width / height.

  function calcLimits(_width, _height, _margin) {
    var width = _width - 2 * _margin; // apply margin to left and right

    var height = _height - 2 * _margin; // apply margin to top and bottom

    var calcH = width * Math.sqrt(3) / 2;
    if (calcH <= height) // portrait orientation
      return new Rect2d(_margin, _margin + (height - calcH) / 2, width, calcH);
    var calcW = height * 2 / Math.sqrt(3); // landscape orientation

    return new Rect2d(_margin + (width - calcW) / 2, _margin, calcW, height);
  } // Factory class for creating TernaryLayout instances.


  var Ternary = /*#__PURE__*/function () {
    function Ternary() {
      _classCallCheck(this, Ternary);

      _defineProperty(this, "labelPlacement", "TopLeft");

      _defineProperty(this, "pointSize", 10);

      _defineProperty(this, "width", 0);

      _defineProperty(this, "height", 0);

      _defineProperty(this, "titleMargin", 50);

      _defineProperty(this, "topValue", function () {
        return 0;
      });

      _defineProperty(this, "leftValue", function () {
        return 0;
      });

      _defineProperty(this, "rightValue", function () {
        return 0;
      });

      _defineProperty(this, "sizeValue", function () {
        return 0;
      });
    }

    _createClass(Ternary, [{
      key: "createLayout",
      // resolver for the point size
      // Create a TernaryLayout instance that can be used for rendering the chart.
      value: function createLayout() {
        var _this = this;

        var rect = calcLimits(this.width, this.height, this.titleMargin);
        var centerX = rect.x + rect.w / 2;
        var centerY = rect.y + rect.h - rect.w / (2 * Math.sqrt(3));
        var radius = centerY - rect.y;
        var triangle = new Triangle([-90, 150, 30].map(function (_d) {
          return new Pt2d(Math.cos(_d * Math.PI / 180) * radius, Math.sin(_d * Math.PI / 180) * radius);
        })); // Create accessor function for calculating position and radius.

        var v = triangle.vertices;

        var circleXFn = function circleXFn(_d) {
          var v0 = _this.topValue(_d),
              v1 = _this.leftValue(_d),
              v2 = _this.rightValue(_d);

          return (v[0].x * v0 + v[1].x * v1 + v[2].x * v2) / (v0 + v1 + v2);
        };

        var circleYFn = function circleYFn(_d) {
          var v0 = _this.topValue(_d),
              v1 = _this.leftValue(_d),
              v2 = _this.rightValue(_d);

          return (v[0].y * v0 + v[1].y * v1 + v[2].y * v2) / (v0 + v1 + v2);
        };

        var circleRFn = function circleRFn(_d) {
          if (typeof _this.pointSize === "function") return _this.pointSize(_this.sizeValue(_d)) / 2;
          return _this.pointSize / 2;
        };

        var dX = this.labelPlacement.indexOf("Left") !== -1 ? 1 : -1;
        var dY = this.labelPlacement.indexOf("Top") !== -1 ? -1 : 1;

        var labelXFn = function labelXFn(_d) {
          return circleXFn(_d) + dX * circleRFn(_d) * Math.SQRT2 / 4;
        };

        var labelYFn = function labelYFn(_d) {
          return circleYFn(_d) + dY * circleRFn(_d) * Math.SQRT2 / 4;
        };

        return new TernaryLayout(new Pt2d(centerX, centerY), triangle, circleXFn, circleYFn, circleRFn, labelXFn, labelYFn);
      }
    }]);

    return Ternary;
  }();

  function quickselect(arr, k, left, right, compare) {
    quickselectStep(arr, k, left || 0, right || arr.length - 1, compare || defaultCompare);
  }

  function quickselectStep(arr, k, left, right, compare) {
    while (right > left) {
      if (right - left > 600) {
        var n = right - left + 1;
        var m = k - left + 1;
        var z = Math.log(n);
        var s = 0.5 * Math.exp(2 * z / 3);
        var sd = 0.5 * Math.sqrt(z * s * (n - s) / n) * (m - n / 2 < 0 ? -1 : 1);
        var newLeft = Math.max(left, Math.floor(k - m * s / n + sd));
        var newRight = Math.min(right, Math.floor(k + (n - m) * s / n + sd));
        quickselectStep(arr, k, newLeft, newRight, compare);
      }

      var t = arr[k];
      var i = left;
      var j = right;
      swap(arr, left, k);
      if (compare(arr[right], t) > 0) swap(arr, left, right);

      while (i < j) {
        swap(arr, i, j);
        i++;
        j--;

        while (compare(arr[i], t) < 0) {
          i++;
        }

        while (compare(arr[j], t) > 0) {
          j--;
        }
      }

      if (compare(arr[left], t) === 0) swap(arr, left, j);else {
        j++;
        swap(arr, j, right);
      }
      if (j <= k) left = j + 1;
      if (k <= j) right = j - 1;
    }
  }

  function swap(arr, i, j) {
    var tmp = arr[i];
    arr[i] = arr[j];
    arr[j] = tmp;
  }

  function defaultCompare(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }

  var RBush = /*#__PURE__*/function () {
    function RBush() {
      var maxEntries = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 9;

      _classCallCheck(this, RBush);

      // max entries in a node is 9 by default; min node fill is 40% for best performance
      this._maxEntries = Math.max(4, maxEntries);
      this._minEntries = Math.max(2, Math.ceil(this._maxEntries * 0.4));
      this.clear();
    }

    _createClass(RBush, [{
      key: "all",
      value: function all() {
        return this._all(this.data, []);
      }
    }, {
      key: "search",
      value: function search(bbox) {
        var node = this.data;
        var result = [];
        if (!intersects(bbox, node)) return result;
        var toBBox = this.toBBox;
        var nodesToSearch = [];

        while (node) {
          for (var i = 0; i < node.children.length; i++) {
            var child = node.children[i];
            var childBBox = node.leaf ? toBBox(child) : child;

            if (intersects(bbox, childBBox)) {
              if (node.leaf) result.push(child);else if (contains(bbox, childBBox)) this._all(child, result);else nodesToSearch.push(child);
            }
          }

          node = nodesToSearch.pop();
        }

        return result;
      }
    }, {
      key: "collides",
      value: function collides(bbox) {
        var node = this.data;
        if (!intersects(bbox, node)) return false;
        var nodesToSearch = [];

        while (node) {
          for (var i = 0; i < node.children.length; i++) {
            var child = node.children[i];
            var childBBox = node.leaf ? this.toBBox(child) : child;

            if (intersects(bbox, childBBox)) {
              if (node.leaf || contains(bbox, childBBox)) return true;
              nodesToSearch.push(child);
            }
          }

          node = nodesToSearch.pop();
        }

        return false;
      }
    }, {
      key: "load",
      value: function load(data) {
        if (!(data && data.length)) return this;

        if (data.length < this._minEntries) {
          for (var i = 0; i < data.length; i++) {
            this.insert(data[i]);
          }

          return this;
        } // recursively build the tree with the given data from scratch using OMT algorithm


        var node = this._build(data.slice(), 0, data.length - 1, 0);

        if (!this.data.children.length) {
          // save as is if tree is empty
          this.data = node;
        } else if (this.data.height === node.height) {
          // split root if trees have the same height
          this._splitRoot(this.data, node);
        } else {
          if (this.data.height < node.height) {
            // swap trees if inserted one is bigger
            var tmpNode = this.data;
            this.data = node;
            node = tmpNode;
          } // insert the small tree into the large tree at appropriate level


          this._insert(node, this.data.height - node.height - 1, true);
        }

        return this;
      }
    }, {
      key: "insert",
      value: function insert(item) {
        if (item) this._insert(item, this.data.height - 1);
        return this;
      }
    }, {
      key: "clear",
      value: function clear() {
        this.data = createNode([]);
        return this;
      }
    }, {
      key: "remove",
      value: function remove(item, equalsFn) {
        if (!item) return this;
        var node = this.data;
        var bbox = this.toBBox(item);
        var path = [];
        var indexes = [];
        var i, parent, goingUp; // depth-first iterative tree traversal

        while (node || path.length) {
          if (!node) {
            // go up
            node = path.pop();
            parent = path[path.length - 1];
            i = indexes.pop();
            goingUp = true;
          }

          if (node.leaf) {
            // check current node
            var index = findItem(item, node.children, equalsFn);

            if (index !== -1) {
              // item found, remove the item and condense tree upwards
              node.children.splice(index, 1);
              path.push(node);

              this._condense(path);

              return this;
            }
          }

          if (!goingUp && !node.leaf && contains(node, bbox)) {
            // go down
            path.push(node);
            indexes.push(i);
            i = 0;
            parent = node;
            node = node.children[0];
          } else if (parent) {
            // go right
            i++;
            node = parent.children[i];
            goingUp = false;
          } else node = null; // nothing found

        }

        return this;
      }
    }, {
      key: "toBBox",
      value: function toBBox(item) {
        return item;
      }
    }, {
      key: "compareMinX",
      value: function compareMinX(a, b) {
        return a.minX - b.minX;
      }
    }, {
      key: "compareMinY",
      value: function compareMinY(a, b) {
        return a.minY - b.minY;
      }
    }, {
      key: "toJSON",
      value: function toJSON() {
        return this.data;
      }
    }, {
      key: "fromJSON",
      value: function fromJSON(data) {
        this.data = data;
        return this;
      }
    }, {
      key: "_all",
      value: function _all(node, result) {
        var nodesToSearch = [];

        while (node) {
          if (node.leaf) result.push.apply(result, _toConsumableArray(node.children));else nodesToSearch.push.apply(nodesToSearch, _toConsumableArray(node.children));
          node = nodesToSearch.pop();
        }

        return result;
      }
    }, {
      key: "_build",
      value: function _build(items, left, right, height) {
        var N = right - left + 1;
        var M = this._maxEntries;
        var node;

        if (N <= M) {
          // reached leaf level; return leaf
          node = createNode(items.slice(left, right + 1));
          calcBBox(node, this.toBBox);
          return node;
        }

        if (!height) {
          // target height of the bulk-loaded tree
          height = Math.ceil(Math.log(N) / Math.log(M)); // target number of root entries to maximize storage utilization

          M = Math.ceil(N / Math.pow(M, height - 1));
        }

        node = createNode([]);
        node.leaf = false;
        node.height = height; // split the items into M mostly square tiles

        var N2 = Math.ceil(N / M);
        var N1 = N2 * Math.ceil(Math.sqrt(M));
        multiSelect(items, left, right, N1, this.compareMinX);

        for (var i = left; i <= right; i += N1) {
          var right2 = Math.min(i + N1 - 1, right);
          multiSelect(items, i, right2, N2, this.compareMinY);

          for (var j = i; j <= right2; j += N2) {
            var right3 = Math.min(j + N2 - 1, right2); // pack each entry recursively

            node.children.push(this._build(items, j, right3, height - 1));
          }
        }

        calcBBox(node, this.toBBox);
        return node;
      }
    }, {
      key: "_chooseSubtree",
      value: function _chooseSubtree(bbox, node, level, path) {
        while (true) {
          path.push(node);
          if (node.leaf || path.length - 1 === level) break;
          var minArea = Infinity;
          var minEnlargement = Infinity;
          var targetNode = void 0;

          for (var i = 0; i < node.children.length; i++) {
            var child = node.children[i];
            var area = bboxArea(child);
            var enlargement = enlargedArea(bbox, child) - area; // choose entry with the least area enlargement

            if (enlargement < minEnlargement) {
              minEnlargement = enlargement;
              minArea = area < minArea ? area : minArea;
              targetNode = child;
            } else if (enlargement === minEnlargement) {
              // otherwise choose one with the smallest area
              if (area < minArea) {
                minArea = area;
                targetNode = child;
              }
            }
          }

          node = targetNode || node.children[0];
        }

        return node;
      }
    }, {
      key: "_insert",
      value: function _insert(item, level, isNode) {
        var bbox = isNode ? item : this.toBBox(item);
        var insertPath = []; // find the best node for accommodating the item, saving all nodes along the path too

        var node = this._chooseSubtree(bbox, this.data, level, insertPath); // put the item into the node


        node.children.push(item);
        extend(node, bbox); // split on node overflow; propagate upwards if necessary

        while (level >= 0) {
          if (insertPath[level].children.length > this._maxEntries) {
            this._split(insertPath, level);

            level--;
          } else break;
        } // adjust bboxes along the insertion path


        this._adjustParentBBoxes(bbox, insertPath, level);
      } // split overflowed node into two

    }, {
      key: "_split",
      value: function _split(insertPath, level) {
        var node = insertPath[level];
        var M = node.children.length;
        var m = this._minEntries;

        this._chooseSplitAxis(node, m, M);

        var splitIndex = this._chooseSplitIndex(node, m, M);

        var newNode = createNode(node.children.splice(splitIndex, node.children.length - splitIndex));
        newNode.height = node.height;
        newNode.leaf = node.leaf;
        calcBBox(node, this.toBBox);
        calcBBox(newNode, this.toBBox);
        if (level) insertPath[level - 1].children.push(newNode);else this._splitRoot(node, newNode);
      }
    }, {
      key: "_splitRoot",
      value: function _splitRoot(node, newNode) {
        // split root node
        this.data = createNode([node, newNode]);
        this.data.height = node.height + 1;
        this.data.leaf = false;
        calcBBox(this.data, this.toBBox);
      }
    }, {
      key: "_chooseSplitIndex",
      value: function _chooseSplitIndex(node, m, M) {
        var index;
        var minOverlap = Infinity;
        var minArea = Infinity;

        for (var i = m; i <= M - m; i++) {
          var bbox1 = distBBox(node, 0, i, this.toBBox);
          var bbox2 = distBBox(node, i, M, this.toBBox);
          var overlap = intersectionArea(bbox1, bbox2);
          var area = bboxArea(bbox1) + bboxArea(bbox2); // choose distribution with minimum overlap

          if (overlap < minOverlap) {
            minOverlap = overlap;
            index = i;
            minArea = area < minArea ? area : minArea;
          } else if (overlap === minOverlap) {
            // otherwise choose distribution with minimum area
            if (area < minArea) {
              minArea = area;
              index = i;
            }
          }
        }

        return index || M - m;
      } // sorts node children by the best axis for split

    }, {
      key: "_chooseSplitAxis",
      value: function _chooseSplitAxis(node, m, M) {
        var compareMinX = node.leaf ? this.compareMinX : compareNodeMinX;
        var compareMinY = node.leaf ? this.compareMinY : compareNodeMinY;

        var xMargin = this._allDistMargin(node, m, M, compareMinX);

        var yMargin = this._allDistMargin(node, m, M, compareMinY); // if total distributions margin value is minimal for x, sort by minX,
        // otherwise it's already sorted by minY


        if (xMargin < yMargin) node.children.sort(compareMinX);
      } // total margin of all possible split distributions where each node is at least m full

    }, {
      key: "_allDistMargin",
      value: function _allDistMargin(node, m, M, compare) {
        node.children.sort(compare);
        var toBBox = this.toBBox;
        var leftBBox = distBBox(node, 0, m, toBBox);
        var rightBBox = distBBox(node, M - m, M, toBBox);
        var margin = bboxMargin(leftBBox) + bboxMargin(rightBBox);

        for (var i = m; i < M - m; i++) {
          var child = node.children[i];
          extend(leftBBox, node.leaf ? toBBox(child) : child);
          margin += bboxMargin(leftBBox);
        }

        for (var _i = M - m - 1; _i >= m; _i--) {
          var _child = node.children[_i];
          extend(rightBBox, node.leaf ? toBBox(_child) : _child);
          margin += bboxMargin(rightBBox);
        }

        return margin;
      }
    }, {
      key: "_adjustParentBBoxes",
      value: function _adjustParentBBoxes(bbox, path, level) {
        // adjust bboxes along the given tree path
        for (var i = level; i >= 0; i--) {
          extend(path[i], bbox);
        }
      }
    }, {
      key: "_condense",
      value: function _condense(path) {
        // go through the path, removing empty nodes and updating bboxes
        for (var i = path.length - 1, siblings; i >= 0; i--) {
          if (path[i].children.length === 0) {
            if (i > 0) {
              siblings = path[i - 1].children;
              siblings.splice(siblings.indexOf(path[i]), 1);
            } else this.clear();
          } else calcBBox(path[i], this.toBBox);
        }
      }
    }]);

    return RBush;
  }();

  function findItem(item, items, equalsFn) {
    if (!equalsFn) return items.indexOf(item);

    for (var i = 0; i < items.length; i++) {
      if (equalsFn(item, items[i])) return i;
    }

    return -1;
  } // calculate node's bbox from bboxes of its children


  function calcBBox(node, toBBox) {
    distBBox(node, 0, node.children.length, toBBox, node);
  } // min bounding rectangle of node children from k to p-1


  function distBBox(node, k, p, toBBox, destNode) {
    if (!destNode) destNode = createNode(null);
    destNode.minX = Infinity;
    destNode.minY = Infinity;
    destNode.maxX = -Infinity;
    destNode.maxY = -Infinity;

    for (var i = k; i < p; i++) {
      var child = node.children[i];
      extend(destNode, node.leaf ? toBBox(child) : child);
    }

    return destNode;
  }

  function extend(a, b) {
    a.minX = Math.min(a.minX, b.minX);
    a.minY = Math.min(a.minY, b.minY);
    a.maxX = Math.max(a.maxX, b.maxX);
    a.maxY = Math.max(a.maxY, b.maxY);
    return a;
  }

  function compareNodeMinX(a, b) {
    return a.minX - b.minX;
  }

  function compareNodeMinY(a, b) {
    return a.minY - b.minY;
  }

  function bboxArea(a) {
    return (a.maxX - a.minX) * (a.maxY - a.minY);
  }

  function bboxMargin(a) {
    return a.maxX - a.minX + (a.maxY - a.minY);
  }

  function enlargedArea(a, b) {
    return (Math.max(b.maxX, a.maxX) - Math.min(b.minX, a.minX)) * (Math.max(b.maxY, a.maxY) - Math.min(b.minY, a.minY));
  }

  function intersectionArea(a, b) {
    var minX = Math.max(a.minX, b.minX);
    var minY = Math.max(a.minY, b.minY);
    var maxX = Math.min(a.maxX, b.maxX);
    var maxY = Math.min(a.maxY, b.maxY);
    return Math.max(0, maxX - minX) * Math.max(0, maxY - minY);
  }

  function contains(a, b) {
    return a.minX <= b.minX && a.minY <= b.minY && b.maxX <= a.maxX && b.maxY <= a.maxY;
  }

  function intersects(a, b) {
    return b.minX <= a.maxX && b.minY <= a.maxY && b.maxX >= a.minX && b.maxY >= a.minY;
  }

  function createNode(children) {
    return {
      children: children,
      height: 1,
      leaf: true,
      minX: Infinity,
      minY: Infinity,
      maxX: -Infinity,
      maxY: -Infinity
    };
  } // sort an array so that items come in groups of n unsorted items, with groups sorted between each other;
  // combines selection algorithm with binary divide & conquer approach


  function multiSelect(arr, left, right, n, compare) {
    var stack = [left, right];

    while (stack.length) {
      right = stack.pop();
      left = stack.pop();
      if (right - left <= n) continue;
      var mid = left + Math.ceil((right - left) / n / 2) * n;
      quickselect(arr, mid, left, right, compare);
      stack.push(left, mid, mid, right);
    }
  }

  var POINTS = 0,
      TOP = 1,
      LEFT = 2,
      RIGHT = 3,
      SIZE = 5; // data slot indices
  // Draw the axis labels and titles.

  function drawChartLabels(_chart, _info, _layout) {
    var ticks = d3.range(0, 120, 20);
    var edges = _layout.triangle.edges; // Place tick labels (percentages) along the edges.

    _chart.select(".ticks").attr("fill", _info.props.get("title_color").toString()).selectAll("g").data([ticks.map(function (tick) {
      return {
        tick: tick,
        pos: edges[0].eval(tick / 100),
        rot: -60,
        anchor: "end"
      };
    }), ticks.map(function (tick) {
      return {
        tick: tick,
        pos: edges[1].eval(tick / 100),
        rot: 0,
        anchor: "start"
      };
    }), ticks.map(function (tick) {
      return {
        tick: tick,
        pos: edges[2].eval(tick / 100),
        rot: 60,
        anchor: "end"
      };
    })]).join("g").selectAll("text").data(function (d) {
      return d;
    }).join("text").attr("transform", function (d) {
      return "translate(".concat(d.pos, ") rotate(").concat(d.rot, ")");
    }).attr("text-anchor", function (d) {
      return d.anchor;
    }).attr("dx", function (d) {
      return d.anchor === "start" ? 10 : -10;
    }).attr("dy", "0.3em").text(function (d) {
      return d.tick;
    }); // Place axis titles on the center of each edge of the triangle.


    _chart.select(".labels").attr("fill", _info.props.get("title_color").toString()).style("font", _info.props.get("title_font").toString()).selectAll("text").data([{
      label: _info.data.cols[RIGHT].caption,
      pos: edges[0].pt2,
      rot: 0
    }, {
      label: _info.data.cols[TOP].caption,
      pos: edges[1].pt2,
      rot: 60
    }, {
      label: _info.data.cols[LEFT].caption,
      pos: edges[2].pt2,
      rot: -60
    }]).join("text").attr("transform", function (d) {
      return "translate(".concat(d.pos, ") rotate(").concat(d.rot, ")");
    }).attr("dy", function (d) {
      return d.rot === 0 ? "2em" : "-2em";
    }).attr("dx", function (d) {
      return d.rot === 0 ? "-2em" : "2em";
    }).attr("text-anchor", function (d) {
      return d.rot === 0 ? "end" : "start";
    }).text(function (d) {
      return d.label;
    });
  } // Draw a colored triangle with gridlines.


  function drawBackgroundTriangle(_chart, _info, _layout) {
    // Draw main triangle.
    _chart.select(".triangle").selectAll("path").data([_layout.triangle]).join(function (_enter) {
      return _enter.append("path").attr("stroke-width", "1px");
    }).attr("d", function (_triangle) {
      return _triangle.toPath();
    }).attr("fill", _info.props.get("grid_background").toString()).attr("stroke", _info.props.get("grid_outline").toString()); // Draw gridlines.


    var edges = _layout.triangle.edges;
    var grid = d3.range(1, 10, 1).map(function (i) {
      return i / 10;
    });

    _chart.select(".grid").selectAll("g").data([grid.map(function (tick) {
      return [edges[0].eval(tick), edges[1].eval(1 - tick)];
    }), grid.map(function (tick) {
      return [edges[1].eval(tick), edges[2].eval(1 - tick)];
    }), grid.map(function (tick) {
      return [edges[2].eval(tick), edges[0].eval(1 - tick)];
    })]).join("g").selectAll("line").data(function (d) {
      return d;
    }).join(function (_enter) {
      return _enter.append("line").attr("stroke-width", "1px");
    }).attr("x1", function (d) {
      return d[0].x;
    }).attr("y1", function (d) {
      return d[0].y;
    }).attr("x2", function (d) {
      return d[1].x;
    }).attr("y2", function (d) {
      return d[1].y;
    }).attr("stroke", _info.props.get("grid_lines").toString());
  } // Draw the circles (data points) inside the main triangle.


  function drawCircles(_chart, _info, _layout) {
    var palette = _info.props.get("color");

    _chart.select(".data").selectAll("circle").data(_info.data.rows).join("circle").attr("r", _layout.circleRFn).attr("cx", _layout.circleXFn).attr("cy", _layout.circleYFn).attr("stroke", function (_d) {
      return palette.getOutlineColor(_d);
    }).attr("fill", function (_d) {
      return palette.getFillColor(_d);
    });
  } // Returns true if the element limits are outside the chart limits.


  function outsideChart(_chart, _elem) {
    return _elem.right > _chart.right || _elem.left < _chart.left || _elem.top < _chart.top || _elem.bottom > _chart.bottom;
  } // Uses the RBrush implementation hide overlapping point labels.


  function showHidePointLabels(_sel, _info) {
    var tree = new RBush();

    var chartBox = _info.node.getBoundingClientRect();

    _sel.each(function (_, i, n) {
      var bbox = n[i].getBoundingClientRect();
      var treeItem = {
        minX: bbox.left,
        minY: bbox.top,
        maxX: bbox.right,
        maxY: bbox.bottom
      };

      if (!tree.collides(treeItem) && !outsideChart(chartBox, bbox)) {
        tree.insert(treeItem);
        n[i].setAttribute("visibility", "visible");
      } else {
        n[i].setAttribute("visibility", "hidden");
      }
    });
  } // Draw a point label next to each circle.


  function drawPointLabels(_chart, _info, _layout) {
    var labelPos = _info.props.get("point_label_placement");

    var anchor = labelPos.indexOf("Left") !== -1 ? "end" : "start";
    var dy = labelPos.indexOf("Top") !== -1 ? "0em" : "1em";

    _chart.select(".point-labels").attr("fill", _info.props.get("point_label_color").toString()).style("font", _info.props.get("point_label_font").toString()).selectAll("text").data(_info.data.rows) // Notice here that new text elements are initially created hidden.
    .join(function (_enter) {
      return _enter.append("text").attr("visibility", "hidden");
    }).attr("text-anchor", anchor).attr("dy", dy).attr("x", _layout.labelXFn).attr("y", _layout.labelYFn).attr("opacity", function (d) {
      return _info.data.hasSelections && !d.selected ? 0.4 : 1;
    }).text(function (d) {
      return d.caption(POINTS);
    }).call(showHidePointLabels, _info);
  }
  /**
   * The Ternary chart shows a visualization that positions data points inside a triangle.
   * The location of a data point is determined by the weight of the top, left or right
   * value in relation to the total of these three weight components.
   * This example shows:
   * - Enabling or disabling properties based on the value of another property
   * - Changing render behaviour for small size visualizations
   * - Applying highlight and selection styling
   * - Storing text in a resource file for possible translation
   * - Using an external javascript library ('RBush' for label overlapping)
   * - Separating render logic from data handling as a coding pattern
   * - Memory efficient rendering by using accessor functions for calculations
   * - Using UpdateInfo.reason for render optimization
   */


  var TernaryChart = /*#__PURE__*/function (_RenderBase) {
    _inherits(TernaryChart, _RenderBase);

    var _super = _createSuper(TernaryChart);

    function TernaryChart() {
      var _this;

      _classCallCheck(this, TernaryChart);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args));

      _defineProperty(_assertThisInitialized(_this), "_ternary", new Ternary());

      return _this;
    }

    _createClass(TernaryChart, [{
      key: "create",
      // Initial setup of the visualization.
      value: function create(_node) {
        // Setup the ternary layout generator with data accessor functions.
        this._ternary.topValue = function (_d) {
          return _d.value(TOP);
        }; // get top value from data point


        this._ternary.leftValue = function (_d) {
          return _d.value(LEFT);
        }; // get left value from data point


        this._ternary.rightValue = function (_d) {
          return _d.value(RIGHT);
        }; // get right value from data point


        this._ternary.sizeValue = function (_d) {
          return _d.value(SIZE);
        }; // get size value from data point
        // Create an svg surface with groups for various elements.


        var svg = d3.select(_node).append("svg").attr("width", "100%").attr("height", "100%").style("position", "absolute");
        var chart = svg.append("g").attr("class", "chart");
        chart.append("g").attr("class", "triangle");
        chart.append("g").attr("class", "grid");
        chart.append("g").attr("class", "ticks").attr("font-family", "sans-serif").attr("font-size", 10);
        chart.append("g").attr("class", "labels");
        chart.append("g").attr("class", "data");
        chart.append("g").attr("class", "point-labels");
      } // Enable or disable properties based on other property values.

    }, {
      key: "updateProperty",
      value: function updateProperty(_name, _value) {
        switch (_name) {
          case "labels_visible":
            this.properties.setActive("point_label_font", _value);
            this.properties.setActive("point_label_color", _value);
            this.properties.setActive("point_label_placement", _value);
            break;
        }
      } // Process data, size, property, selection and highlight updates.

    }, {
      key: "update",
      value: function update(_info) {
        var props = _info.props;
        var svg = d3.select(_info.node).select("svg");
        var chart = svg.select(".chart"); // Apply chart properties to the ternary instance. If the size slot is mapped,
        // use a linear scale to determine point size. Otherwise, set a fixed point size.

        if (_info.data && _info.data.cols[SIZE].mapped) this._ternary.pointSize = d3.scaleLinear().domain(_info.data.cols[SIZE].domain.asArray()).range([props.get("min_point_size"), props.get("max_point_size")]);else // use a fixed point size of SIZE is not mapped
          this._ternary.pointSize = props.get("point_size");
        this._ternary.width = _info.node.clientWidth;
        this._ternary.height = _info.node.clientHeight;
        this._ternary.labelPlacement = _info.props.get("point_label_placement"); // Create a layout object that holds everything we need for rendering.

        var layout = this._ternary.createLayout(); // Set chart origin on the center of the main triangle.


        chart.attr("transform", "translate(".concat(layout.center.toString(), ")")); // Apply the background color to the chart.

        svg.style("background-color", props.get("background_color")); // Draw main triangle with gridlines (only if size or properties changed).

        if (_info.reason.size || _info.reason.properties) drawBackgroundTriangle(chart, _info, layout);

        if (_info.data) {
          // Draw axis labels and titles if visualization is large enough.
          if (_info.node.clientWidth > 200 && _info.node.clientHeight > 200) {
            drawChartLabels(chart, _info, layout);
          } else // remove labels and titles if visualization too small
            {
              chart.selectAll(".labels>*").remove();
              chart.selectAll(".ticks>*").remove();
            } // Draw data points (circles).


          drawCircles(chart, _info, layout); // Draw point labels.

          if (props.get("labels_visible")) drawPointLabels(chart, _info, layout);else // labels not visible, remove them
            chart.selectAll(".point-labels>*").remove();
        } else // no data, remove all labels and circles
          {
            chart.selectAll(".labels>*").remove();
            chart.selectAll(".data>*").remove();
            chart.selectAll(".ticks>*").remove();
            chart.selectAll(".point-labels>*").remove();
          }
      }
    }]);

    return TernaryChart;
  }(st);

  return TernaryChart;

});
